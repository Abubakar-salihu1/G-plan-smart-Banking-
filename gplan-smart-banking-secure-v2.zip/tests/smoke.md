# Smoke tests

1. `GET /health` returns status=ok.
2. Register with a unique email.
3. Read the OTP from configured email/SMS provider or development console.
4. Verify email and receive access token.
5. Login with valid credentials.
6. Enable TOTP MFA and verify login step-up.
7. Submit KYC; confirm NIN/BVN never appears in logs/API responses.
8. Create beneficiary.
9. Attempt transfer above configured limit; confirm rejection.
10. Attempt rapid transfers; confirm fraud step-up/review.
11. Freeze/unfreeze card.
12. Pay a bill; confirm PostgreSQL transaction and balance change.
13. Run backup and restore into a disposable PostgreSQL instance.
14. Verify webhook signatures and duplicate-event handling.
