# G-plan secure architecture

```text
Mobile/Web Client
      |
      v
 CDN/WAF/DDoS
      |
      v
 API Gateway / Load Balancer
      |
      +-----------------------------+
      |                             |
      v                             v
 Auth / KYC / Payments API       Admin/Compliance API
      |                             |
      +-------------+---------------+
                    |
              PostgreSQL Cluster
                    |
      +-------------+--------------------+
      |             |                    |
      v             v                    v
 Audit Ledger   Compliance Cases   Notifications
      |
      +---------- Provider Adapters --------+
      |          |          |              |
    Bank/Switch  Paystack  Flutterwave    KYC/AML
```

## Money movement principle
Never treat a frontend balance as authoritative. Every balance-changing operation must be a server-side database transaction with row locking, idempotency, immutable transaction references, reconciliation and provider confirmation.

## Secrets
Production secrets should live in AWS KMS/Secrets Manager, GCP KMS/Secret Manager, Azure Key Vault, HashiCorp Vault or an HSM-backed equivalent. The `FIELD_ENCRYPTION_KEY` in `.env.example` is only a development placeholder.

## Backups
Use encrypted, versioned PostgreSQL backups in a separate account/region. Test restoration regularly. Define RPO/RTO and document disaster-recovery procedures.
