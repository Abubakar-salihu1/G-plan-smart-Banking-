# Incident response

1. Detect: alert from SIEM/APM/fraud/monitoring.
2. Triage: classify security, fraud, privacy, availability or payment incident.
3. Contain: disable affected credentials/provider routes, freeze risky transactions/accounts when authorized.
4. Preserve evidence: logs, audit events, provider references and timestamps.
5. Eradicate: patch, rotate credentials/keys, remove persistence.
6. Recover: restore service and reconcile financial records.
7. Notify: follow contractual and legal/regulatory notification obligations.
8. Post-incident: root cause, control improvement, customer communication and retest.
