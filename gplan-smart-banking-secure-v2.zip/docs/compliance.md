# Nigeria compliance and governance baseline

This document is an engineering baseline, not legal advice. Engage qualified Nigerian regulatory counsel and compliance professionals before launch.

## CBN / payments
G-plan must select and document its regulatory model before handling customer funds. CBN's payment-system licensing framework separates activities such as Mobile Money Operations, Switching/Processing and Payment Solution Services. A technology company cannot assume that building an app authorizes it to hold or move customer funds.

The current CBN materials also emphasize automated AML/CFT/CPF monitoring, KYC/CDD, sanctions/watchlist controls, transaction monitoring, risk scoring and regulatory reporting. The application therefore has dedicated KYC, AML, fraud, compliance-case and audit components.

## Data protection
Nigeria's Data Protection Act 2023 governs personal-data processing. G-plan should implement privacy by design, lawful basis/consent where applicable, purpose limitation, minimization, retention controls, data-subject rights, breach procedures, vendor DPAs and appropriate technical/organizational measures.

Sensitive identifiers are encrypted at rest and hashed for lookup. Production KMS/HSM-backed key management is required.

## Payment-card security
If G-plan stores, processes or transmits cardholder data, PCI DSS scope must be formally assessed. Prefer tokenized card-provider integrations so G-plan does not store PAN/CVV. Current PCI SSC materials reference PCI DSS v4.0.1.

## AML/CFT/CPF
Required production controls should include:
- Customer due diligence and enhanced due diligence.
- PEP and sanctions screening.
- Risk-based customer profiles.
- Real-time transaction monitoring.
- Velocity, structuring, unusual activity and device-risk signals.
- Case management and analyst review.
- Suspicious-activity escalation/reporting according to applicable law.
- Record retention and auditability.

## Governance
Create named owners for:
- MLRO/compliance
- Information security
- Data protection/privacy
- Fraud/risk
- Engineering/SRE
- Internal audit
- Customer complaints/disputes
- Business continuity

## Source references
- CBN payment licensing and regulatory materials: https://www.cbn.gov.ng/
- NDPC NDP Act 2023: https://www.ndpc.gov.ng/ndp-act-2023/
- PCI SSC standards: https://www.pcisecuritystandards.org/
