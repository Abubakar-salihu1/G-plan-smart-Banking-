import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';
import { q } from '../db/pool.js';
export async function auth(req,res,next){
  const header=req.headers.authorization;
  const token=header?.startsWith('Bearer ')?header.slice(7):req.cookies?.gplan_access;
  if(!token)return res.status(401).json({error:'Authentication required'});
  try{const p=jwt.verify(token,env.JWT_ACCESS_SECRET);const u=await q('SELECT id,email,full_name,status FROM users WHERE id=$1',[p.sub]);if(!u.rowCount||u.rows[0].status!=='active')return res.status(401).json({error:'Account is not active'});req.user=u.rows[0];req.auth=p;next()}catch{res.status(401).json({error:'Invalid or expired session'})}
}
export const optionalAuth=async(req,res,next)=>{try{await auth(req,res,next)}catch{next()}};
