import rateLimit from 'express-rate-limit';
import { sha256 } from '../utils/crypto.js';
export const authLimiter=rateLimit({windowMs:15*60*1000,max:10,standardHeaders:true,legacyHeaders:false,message:{error:'Too many authentication attempts. Try again later.'}});
export const apiLimiter=rateLimit({windowMs:60*1000,max:120,standardHeaders:true,legacyHeaders:false});
export const paymentLimiter=rateLimit({windowMs:60*1000,max:10,standardHeaders:true,legacyHeaders:false});
export function requestContext(req,res,next){req.ipHash=sha256(req.ip||'unknown');req.deviceId=(req.headers['x-device-id']||'').slice(0,128);next()}
