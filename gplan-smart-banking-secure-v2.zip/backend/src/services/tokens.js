import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';
import { q } from '../db/pool.js';
import { hmac, randomToken } from '../utils/crypto.js';
export function accessToken(user){return jwt.sign({sub:user.id,email:user.email},env.JWT_ACCESS_SECRET,{expiresIn:env.ACCESS_TOKEN_TTL,issuer:'gplan-api',audience:'gplan-app'})}
export async function issueRefresh(userId,req){const raw=randomToken(48);const days=env.REFRESH_TOKEN_DAYS;await q(`INSERT INTO sessions(user_id,refresh_token_hash,device_id,ip_hash,user_agent,expires_at) VALUES($1,$2,$3,$4,$5,now()+($6||' days')::interval)`,[userId,hmac(raw),req.deviceId,req.ipHash,req.headers['user-agent']||'',days]);return raw}
export async function rotateRefresh(raw,req){const r=await q(`SELECT s.*,u.id user_id,u.email,u.full_name,u.status FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.refresh_token_hash=$1 AND s.revoked_at IS NULL AND s.expires_at>now()`,[hmac(raw)]);if(!r.rowCount)throw new Error('Invalid refresh session');const s=r.rows[0];await q('UPDATE sessions SET revoked_at=now() WHERE id=$1',[s.id]);return {user:{id:s.user_id,email:s.email,full_name:s.full_name,status:s.status},refresh:await issueRefresh(s.user_id,req)}}
