import { q } from '../db/pool.js';
import { env } from '../config/env.js';
export async function screenTransaction({userId,amount,recipient,reference}){
  const reasons=[];let risk='low';
  if(amount>=1000000){risk='high';reasons.push('amount_threshold')}
  if(env.AML_PROVIDER!=='rules' && env.AML_PROVIDER_URL){try{const r=await fetch(env.AML_PROVIDER_URL,{method:'POST',headers:{Authorization:`Bearer ${env.AML_PROVIDER_TOKEN}`,'Content-Type':'application/json'},body:JSON.stringify({userId,amount,recipient,reference})});const d=await r.json();if(d.risk==='high'){risk='high';reasons.push('external_provider_high_risk')}}catch(e){risk='medium';reasons.push('provider_unavailable')}}
  return {status:risk==='high'?'review':'clear',risk,reasons};
}
export async function createCase({userId,reference,type='aml',severity='high',notes}){await q(`INSERT INTO compliance_cases(user_id,transaction_reference,case_type,severity,notes) VALUES($1,$2,$3,$4,$5)`,[userId,reference,type,severity,notes||null])}
