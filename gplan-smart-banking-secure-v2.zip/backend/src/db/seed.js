import argon2 from 'argon2';
import { pool } from './pool.js';
const password=await argon2.hash('Gplan@12345',{type:argon2.argon2id,memoryCost:19456,timeCost:2,parallelism:1});
const client=await pool.connect();
try{await client.query('BEGIN');
const u=await client.query(`INSERT INTO users(email,phone,full_name,password_hash,status,email_verified_at,phone_verified_at) VALUES($1,$2,$3,$4,'active',now(),now()) ON CONFLICT(email) DO UPDATE SET password_hash=EXCLUDED.password_hash,status='active' RETURNING id`,['demo@gplan.app','+2348000000000','G-plan Demo User',password]);
const uid=u.rows[0].id;
await client.query(`INSERT INTO user_security(user_id) VALUES($1) ON CONFLICT DO NOTHING`,[uid]);
await client.query(`INSERT INTO kyc_profiles(user_id,tier,verification_status) VALUES($1,'tier_1','verified') ON CONFLICT DO NOTHING`,[uid]);
const a=await client.query(`INSERT INTO accounts(user_id,account_number,balance,available_balance) VALUES($1,'3012345678',250000,250000) ON CONFLICT(account_number) DO UPDATE SET balance=EXCLUDED.balance,available_balance=EXCLUDED.available_balance RETURNING id`,[uid]);
const aid=a.rows[0].id;
await client.query(`INSERT INTO transactions(account_id,type,amount,description,reference,category) VALUES($1,'credit',250000,'Opening balance',$2,'income') ON CONFLICT(reference) DO NOTHING`,[aid,'SEED-OPENING-001']);
await client.query(`INSERT INTO cards(user_id,account_id,brand,last4) SELECT $1,$2,'Visa','4821' WHERE NOT EXISTS(SELECT 1 FROM cards WHERE user_id=$1)`,[uid,aid]);
await client.query(`INSERT INTO bills(user_id,provider,category,amount,due_date) SELECT $1,'Airtel','Utilities',8500,current_date+5 WHERE NOT EXISTS(SELECT 1 FROM bills WHERE user_id=$1)`,[uid]);
await client.query(`INSERT INTO savings_goals(user_id,name,target_amount,current_amount,target_date) SELECT $1,'Emergency Fund',500000,125000,current_date+180 WHERE NOT EXISTS(SELECT 1 FROM savings_goals WHERE user_id=$1)`,[uid]);
await client.query('COMMIT'); console.log('Seed complete. Demo: demo@gplan.app / Gplan@12345');
}catch(e){await client.query('ROLLBACK');throw e}finally{client.release();await pool.end()}
