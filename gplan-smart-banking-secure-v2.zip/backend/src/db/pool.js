import pg from 'pg';
import { env } from '../config/env.js';
const { Pool } = pg;
export const pool = new Pool({ connectionString: env.DATABASE_URL, max: 20, idleTimeoutMillis: 30000, ssl: env.NODE_ENV==='production' ? {rejectUnauthorized:true} : false });
export const q=(text,params)=>pool.query(text,params);
