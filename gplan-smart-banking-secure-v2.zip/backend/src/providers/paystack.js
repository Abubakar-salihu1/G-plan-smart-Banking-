import crypto from 'node:crypto';
import { env } from '../config/env.js';
async function ps(path,options={}){const r=await fetch(`https://api.paystack.co${path}`,{...options,headers:{Authorization:`Bearer ${env.PAYSTACK_SECRET_KEY}`,'Content-Type':'application/json',...(options.headers||{})}});const d=await r.json();if(!r.ok||!d.status)throw new Error(d.message||'Paystack request failed');return d.data}
export const paystack={
  async createRecipient({name,accountNumber,bankCode}){return ps('/transferrecipient',{method:'POST',body:JSON.stringify({type:'nuban',name,account_number:accountNumber,bank_code:bankCode,currency:'NGN'})})},
  async transfer({amount,recipient,reference,reason}){return ps('/transfer',{method:'POST',body:JSON.stringify({source:'balance',amount:Math.round(amount*100),recipient,reference,reason,currency:'NGN'})})},
  async verify(reference){return ps(`/transfer/verify/${encodeURIComponent(reference)}`)},
  verifyWebhook(raw,signature){return !!signature && crypto.createHmac('sha512',env.PAYSTACK_WEBHOOK_SECRET||'').update(raw).digest('hex')===signature}
};
