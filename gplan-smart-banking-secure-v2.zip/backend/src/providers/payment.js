import { env } from '../config/env.js';
import { paystack } from './paystack.js';
import { flutterwave } from './flutterwave.js';
export function paymentProvider(){if(env.PAYMENT_PROVIDER==='paystack')return {name:'paystack',api:paystack};if(env.PAYMENT_PROVIDER==='flutterwave')return {name:'flutterwave',api:flutterwave};return {name:'ledger',api:null};}
