import { env } from '../config/env.js';
export async function submitKyc(payload){
  if(env.KYC_PROVIDER==='manual'||!env.KYC_PROVIDER_URL)return {status:'manual_review',providerReference:null};
  const r=await fetch(env.KYC_PROVIDER_URL,{method:'POST',headers:{Authorization:`Bearer ${env.KYC_PROVIDER_TOKEN}`,'Content-Type':'application/json'},body:JSON.stringify(payload)});if(!r.ok)throw new Error('KYC provider unavailable');return r.json();
}
