import crypto from 'node:crypto';
import { env } from '../config/env.js';
async function flw(path,body){const r=await fetch(`https://api.flutterwave.com/v3${path}`,{method:'POST',headers:{Authorization:`Bearer ${env.FLW_SECRET_KEY}`,'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();if(!r.ok||d.status!=='success')throw new Error(d.message||'Flutterwave request failed');return d.data}
export const flutterwave={
  async transfer({amount,accountNumber,bankCode,reference,narration}){return flw('/transfers',{account_bank:bankCode,account_number:accountNumber,amount,currency:'NGN',reference,narration,debit_currency:'NGN'})},
  verifyWebhook(raw,signature){return !!signature && signature===env.FLW_WEBHOOK_HASH}
};
