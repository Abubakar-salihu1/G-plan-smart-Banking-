import crypto from 'node:crypto';
import { env } from '../config/env.js';
const key=Buffer.from(env.FIELD_ENCRYPTION_KEY,'hex');
export function encrypt(value){if(value==null)return null;const iv=crypto.randomBytes(12);const cipher=crypto.createCipheriv('aes-256-gcm',key,iv);const ct=Buffer.concat([cipher.update(String(value),'utf8'),cipher.final()]);return [iv.toString('base64url'),cipher.getAuthTag().toString('base64url'),ct.toString('base64url')].join('.');}
export function decrypt(payload){if(!payload)return null;const [iv,tag,ct]=payload.split('.');const decipher=crypto.createDecipheriv('aes-256-gcm',key,Buffer.from(iv,'base64url'));decipher.setAuthTag(Buffer.from(tag,'base64url'));return Buffer.concat([decipher.update(Buffer.from(ct,'base64url')),decipher.final()]).toString('utf8');}
export function hmac(value){return crypto.createHmac('sha256',env.OTP_PEPPER).update(String(value)).digest('hex');}
export function sha256(value){return crypto.createHash('sha256').update(String(value)).digest('hex');}
export function randomToken(bytes=32){return crypto.randomBytes(bytes).toString('base64url');}
export function timingSafeEqualHex(a,b){try{const x=Buffer.from(a,'hex'),y=Buffer.from(b,'hex');return x.length===y.length&&crypto.timingSafeEqual(x,y)}catch{return false}}
