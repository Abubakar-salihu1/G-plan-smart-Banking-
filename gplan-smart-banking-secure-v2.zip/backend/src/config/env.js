import 'dotenv/config';
import { z } from 'zod';

const schema = z.object({
  NODE_ENV: z.enum(['development','test','production']).default('development'),
  PORT: z.coerce.number().int().positive().default(4000),
  APP_ORIGIN: z.string().default('http://localhost:5173'),
  DATABASE_URL: z.string().min(1),
  JWT_ACCESS_SECRET: z.string().min(32),
  JWT_REFRESH_SECRET: z.string().min(32),
  FIELD_ENCRYPTION_KEY: z.string().regex(/^[0-9a-fA-F]{64}$/),
  OTP_PEPPER: z.string().min(32),
  COOKIE_SECURE: z.enum(['true','false']).default('false').transform(v=>v==='true'),
  ACCESS_TOKEN_TTL: z.string().default('15m'),
  REFRESH_TOKEN_DAYS: z.coerce.number().default(30),
  OTP_TTL_MINUTES: z.coerce.number().default(5),
  MAX_TRANSFER_NGN: z.coerce.number().default(1000000),
  SMTP_HOST: z.string().optional(), SMTP_PORT: z.coerce.number().default(587), SMTP_USER: z.string().optional(), SMTP_PASS: z.string().optional(), MAIL_FROM: z.string().default('no-reply@gplan.app'),
  SMS_PROVIDER: z.enum(['console','termii','twilio']).default('console'), TERMII_API_KEY: z.string().optional(), TERMII_SENDER_ID: z.string().default('GPLAN'), TWILIO_ACCOUNT_SID: z.string().optional(), TWILIO_AUTH_TOKEN: z.string().optional(), TWILIO_FROM: z.string().optional(),
  PAYMENT_PROVIDER: z.enum(['ledger','paystack','flutterwave']).default('ledger'), PAYSTACK_SECRET_KEY: z.string().optional(), PAYSTACK_WEBHOOK_SECRET: z.string().optional(), FLW_SECRET_KEY: z.string().optional(), FLW_WEBHOOK_HASH: z.string().optional(),
  KYC_PROVIDER: z.string().default('manual'), KYC_PROVIDER_URL: z.string().optional(), KYC_PROVIDER_TOKEN: z.string().optional(), AML_PROVIDER: z.string().default('rules'), AML_PROVIDER_URL: z.string().optional(), AML_PROVIDER_TOKEN: z.string().optional(),
  BACKUP_DIR: z.string().default('./backups'), SENTRY_DSN: z.string().optional(), LOG_LEVEL: z.string().default('info')
});
export const env = schema.parse(process.env);
if(env.NODE_ENV==='production' && env.PAYMENT_PROVIDER==='ledger') console.warn('WARNING: PAYMENT_PROVIDER=ledger in production. Configure a licensed payment/banking provider before live funds.');
