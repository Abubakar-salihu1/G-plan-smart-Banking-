# G-plan Smart Banking Solution — Secure Full Stack

Production-oriented reference architecture for a Nigerian digital banking/fintech product. **It is not itself a banking licence or a substitute for regulatory approval, a bank/switch relationship, or an independent security/compliance assessment.**

## Stack
- Frontend: HTML/CSS/JavaScript
- API: Node.js + Express
- Database: PostgreSQL 17
- Passwords: Argon2id
- Auth: JWT access tokens + rotating, revocable refresh sessions in HTTP-only cookies
- MFA: TOTP authenticator + OTP step-up
- OTP delivery: SMTP email, Termii or Twilio adapters
- KYC: encrypted NIN/BVN fields + provider adapter/manual review workflow
- AML/CFT/CPF: rules engine + external-provider adapter + compliance cases
- Payments: internal ledger for demo, Paystack/Flutterwave adapters for approved live integrations
- Monitoring: health endpoint, structured request logging, Prometheus-ready dependency
- Backups: pg_dump job + backup directory/object-storage hook
- Security: Helmet, CORS allowlist, rate limits, input validation, audit logging, encryption at rest for sensitive fields, idempotency-ready data model

## Important production boundary
Real customer funds must **not** be placed in the local ledger mode. For live operation, G-plan must operate through an appropriately licensed/regulated structure and approved banking/payment partners. CBN licensing frameworks distinguish payment activities and specify regulatory requirements. See `docs/compliance.md`.

## Run locally
```bash
docker compose up -d
cd backend
cp .env.example .env
npm install
npm run db:migrate
npm run db:seed
npm start
```
Open `frontend/index.html` with a local static server such as VS Code Live Server. API: `http://localhost:4000`.

Demo:
- Email: `demo@gplan.app`
- Password: `Gplan@12345`

## Provider setup
Set `PAYMENT_PROVIDER=paystack` or `flutterwave` only after obtaining approved business credentials and completing the provider's onboarding/KYC. Never commit keys.

### Paystack
The adapter supports transfer-recipient creation, transfers and transfer verification. Paystack's current API requires secret-key authentication and NGN transfers use kobo amounts. Configure:
```env
PAYMENT_PROVIDER=paystack
PAYSTACK_SECRET_KEY=...
PAYSTACK_WEBHOOK_SECRET=...
```

### Flutterwave
The adapter supports NGN bank transfer initiation. Configure:
```env
PAYMENT_PROVIDER=flutterwave
FLW_SECRET_KEY=...
FLW_WEBHOOK_HASH=...
```

### KYC/AML
Use `KYC_PROVIDER_URL` and `AML_PROVIDER_URL` for your approved identity/screening vendor. The application encrypts NIN/BVN values and stores hashes for duplicate detection. Do not log raw identity numbers.

## Security controls included
1. Password hashing with Argon2id.
2. Login lockout after repeated failures.
3. Email verification before activation.
4. Optional TOTP MFA.
5. OTP step-up for elevated-risk transfers.
6. HTTP-only refresh cookies and refresh-token rotation.
7. Rate limiting for API/auth/payment paths.
8. Helmet security headers and strict CORS origin.
9. Zod request validation.
10. AES-256-GCM encryption for sensitive KYC values.
11. HMAC hashes for OTP/identity lookup values.
12. PostgreSQL row locks for balance-changing operations.
13. Fraud velocity/new-device/high-value checks.
14. AML review gate and compliance cases.
15. Audit events for security and money movement actions.
16. Provider webhook signature verification hooks.
17. Provider-event deduplication.
18. Backup job and operational runbook.
19. Separation of secrets from source code.
20. Security/compliance documentation and penetration-test checklist.

## What still requires external production work
- CBN licensing/approval and appropriate operating model.
- Sponsor/settlement bank, switch and/or licensed payment-provider contracts.
- BVN/NIN/identity verification vendor approval and credentials.
- Sanctions/PEP/adverse-media screening provider.
- Card issuing/processing scheme integration and PCI DSS scope assessment.
- SMS/email production contracts and deliverability controls.
- Cloud KMS/HSM and secret manager.
- WAF, DDoS protection, SIEM/SOC monitoring and incident response.
- Independent penetration test, code review, threat modelling and remediation.
- Disaster recovery exercises and tested restore procedures.
- Privacy impact assessment, data retention/deletion policy and NDPC compliance.

## Security testing
```bash
cd backend
npm test
npm audit --audit-level=high
```
For production, add SAST, DAST, dependency scanning, secret scanning, container scanning, IaC scanning and independent penetration testing. See `docs/pentest.md`.
