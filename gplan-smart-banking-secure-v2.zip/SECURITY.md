# Security policy

Do not report security vulnerabilities through public issues. Establish a private security contact before public deployment. Rotate all development/demo secrets before production.

Never commit:
- API keys
- database passwords
- JWT secrets
- KMS/HSM keys
- OTP secrets
- NIN/BVN/identity documents
- production customer data
