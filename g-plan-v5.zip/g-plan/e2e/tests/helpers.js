import { expect } from '@playwright/test';

export const PASSWORD = 'Sup3rSecret99';
export const uniqueEmail = (label = 'user') => `${label}-${Date.now()}-${Math.floor(Math.random() * 1e6)}@e2e.test`;

// Creates an account through the screens, using the on-screen demo code, and ends on the home screen.
export async function signUp(page, { name = 'Ada Obi', email = uniqueEmail('ada'), password = PASSWORD } = {}) {
  await page.goto('/');
  await page.getByRole('button', { name: 'New here? Create an account' }).click();
  await page.getByLabel('Full name').fill(name);
  await page.getByLabel('Email', { exact: true }).fill(email);
  await page.getByLabel('Password', { exact: true }).fill(password);
  await page.getByRole('checkbox').check();
  await page.getByRole('button', { name: 'Create account' }).click();
  await page.getByText('Demo mode: your code is').waitFor();
  const code = (await page.locator('b', { hasText: /^\d{6}$/ }).first().innerText()).trim();
  await page.getByLabel('Verification code').fill(code);
  await page.getByRole('button', { name: 'Confirm and continue' }).click();
  await expect(page.getByRole('heading', { name: new RegExp(`Hello, ${name.split(' ')[0]}`) })).toBeVisible();
  return { name, email, password };
}

export async function signOut(page) {
  await page.getByRole('button', { name: 'Sign out' }).click();
  await expect(page.getByRole('button', { name: 'Sign in' })).toBeVisible();
}

export async function signIn(page, { email, password }) {
  await page.getByLabel('Email', { exact: true }).fill(email);
  await page.getByLabel('Password', { exact: true }).fill(password);
  await page.getByRole('button', { name: 'Sign in' }).click();
}

export async function openMore(page, itemName) {
  await page.getByRole('navigation', { name: 'Main' }).getByRole('button', { name: 'More' }).click();
  await page.getByRole('button', { name: new RegExp(itemName) }).click();
}
