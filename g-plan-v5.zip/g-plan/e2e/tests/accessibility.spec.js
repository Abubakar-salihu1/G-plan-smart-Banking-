import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { signUp, openMore } from './helpers.js';

// Automated checks catch roughly a third of accessibility problems. They do not replace a screen-reader test.
const scan = async (page) => (await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa']).analyze()).violations
  .filter((v) => ['serious', 'critical'].includes(v.impact));
const report = (v) => v.map((x) => `${x.id}: ${x.help} (${x.nodes.length} place(s))`).join('\n');

test('sign-in screen has no serious accessibility problems', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('button', { name: 'Sign in' })).toBeVisible();
  const v = await scan(page);
  expect(v, report(v)).toEqual([]);
});

test('home, More, Security and Pockets have no serious accessibility problems', async ({ page }) => {
  await signUp(page);
  let v = await scan(page); expect(v, `home\n${report(v)}`).toEqual([]);
  await page.getByRole('navigation', { name: 'Main' }).getByRole('button', { name: 'More' }).click();
  v = await scan(page); expect(v, `more\n${report(v)}`).toEqual([]);
  await page.getByRole('button', { name: /Security centre/ }).click();
  await expect(page.getByRole('heading', { name: /Two-step verification/ })).toBeVisible();
  v = await scan(page); expect(v, `security\n${report(v)}`).toEqual([]);
  await openMore(page, 'Pockets');
  await expect(page.getByRole('heading', { name: 'Pockets' })).toBeVisible();
  v = await scan(page); expect(v, `pockets\n${report(v)}`).toEqual([]);
});

test('the skip link moves focus to the main content', async ({ page }) => {
  await signUp(page);
  await page.evaluate(() => document.activeElement?.blur());
  await page.keyboard.press('Tab');
  const skip = page.getByRole('link', { name: 'Skip to main content' });
  await expect(skip).toBeFocused();
  await page.keyboard.press('Enter');
  await expect(page.locator('main')).toBeFocused();
});

test('the language can be changed and is remembered', async ({ page }) => {
  await page.goto('/');
  await page.getByLabel('Language').selectOption('yo');
  await expect(page.locator('html')).toHaveAttribute('lang', 'yo');
  await expect(page.getByText(/not been checked by a native speaker|kò tíì yẹ̀ ẹ́ wò/)).toBeVisible();
  await page.reload();
  await expect(page.locator('html')).toHaveAttribute('lang', 'yo');
});
