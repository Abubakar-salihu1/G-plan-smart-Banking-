import { test, expect } from '@playwright/test';
import { signUp, signIn, signOut, PASSWORD, uniqueEmail } from './helpers.js';

test('send demo money to another person and see both balances change', async ({ page }) => {
  const bola = await signUp(page, { name: 'Bola Eze', email: uniqueEmail('bola') });
  await signOut(page);
  const ada = await signUp(page, { name: 'Ada Obi', email: uniqueEmail('ada') });

  await page.getByRole('button', { name: /Add ₦50,000 demo money/ }).click();
  await expect(page.getByText(/50,000/).first()).toBeVisible();

  await page.getByRole('navigation', { name: 'Main' }).getByRole('button', { name: 'Flow' }).click();
  await page.getByLabel(/Recipient.s G-Plan email or phone/).fill(bola.email);
  await page.getByLabel('Amount (₦)').fill('1000');
  await page.getByRole('button', { name: 'Review' }).click();
  await expect(page.getByRole('heading', { name: 'Review and confirm' })).toBeVisible();
  await expect(page.getByText('Bola Eze', { exact: false })).toBeVisible();
  await page.getByLabel('Enter your password to authorise').fill(PASSWORD);
  await page.getByRole('button', { name: /^Send ₦/ }).click();

  await page.getByRole('navigation', { name: 'Main' }).getByRole('button', { name: 'Pulse' }).click();
  await expect(page.getByText(/49,000/).first()).toBeVisible();

  await signOut(page);
  await signIn(page, bola);
  await expect(page.getByText(/1,000/).first()).toBeVisible();
});

test('a wrong password does not send anything', async ({ page }) => {
  const bola = await signUp(page, { name: 'Bola Eze', email: uniqueEmail('bola') });
  await signOut(page);
  await signUp(page, { name: 'Chi Eze', email: uniqueEmail('chi') });
  await page.getByRole('button', { name: /Add ₦50,000 demo money/ }).click();
  await page.getByRole('navigation', { name: 'Main' }).getByRole('button', { name: 'Flow' }).click();
  await page.getByLabel(/Recipient.s G-Plan email or phone/).fill(bola.email);
  await page.getByLabel('Amount (₦)').fill('500');
  await page.getByRole('button', { name: 'Review' }).click();
  await page.getByLabel('Enter your password to authorise').fill('definitely-wrong-1');
  await page.getByRole('button', { name: /^Send ₦/ }).click();
  await expect(page.getByRole('alert')).toBeVisible();
  await page.getByRole('navigation', { name: 'Main' }).getByRole('button', { name: 'Pulse' }).click();
  await expect(page.getByText(/50,000/).first()).toBeVisible();   // unchanged
});
