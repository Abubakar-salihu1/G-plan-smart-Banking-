import { test, expect } from '@playwright/test';
import { signUp, signIn, signOut, openMore } from './helpers.js';

test('lost phone: a recovery code signs you in once, and only once', async ({ page }) => {
  const me = await signUp(page);

  // Turn on two-step verification by email code.
  await openMore(page, 'Security centre');
  await page.getByLabel('Your password (to change security settings)').fill(me.password);
  await page.getByRole('button', { name: 'Email code' }).click();
  await page.getByText(/We sent a code by email/).waitFor();
  const demo = (await page.locator('b', { hasText: /^\d{6}$/ }).first().innerText()).trim();
  await page.getByLabel('Code', { exact: true }).fill(demo);
  await page.getByRole('button', { name: 'Confirm' }).click();

  // The ten codes are shown once. Save them, then continue.
  const panel = page.getByRole('region', { name: 'Your recovery codes' });
  await expect(panel).toBeVisible();
  const codes = await panel.locator('li').allInnerTexts();
  expect(codes).toHaveLength(10);
  for (const c of codes) expect(c).toMatch(/^[A-Z2-9]{4}(-[A-Z2-9]{4}){3}$/);
  await expect(panel.getByRole('button', { name: 'Done' })).toBeDisabled();
  await panel.getByLabel(/I have saved these codes/).check();
  await panel.getByRole('button', { name: 'Done' }).click();
  await expect(panel).toBeHidden();
  await expect(page.getByText('Recovery codes: 10 left')).toBeVisible();

  // Sign out, sign in, and use a recovery code instead of the email code.
  await signOut(page);
  await signIn(page, me);
  await expect(page.getByRole('heading', { name: 'Two-step verification' })).toBeVisible();
  await page.getByRole('button', { name: 'Lost your phone? Use a recovery code' }).click();
  await page.getByLabel('Recovery code').fill(codes[0].toLowerCase());   // any case is fine
  await page.getByRole('button', { name: 'Verify' }).click();
  await expect(page.getByRole('heading', { name: /Hello, Ada/ })).toBeVisible();

  // The same code is now dead.
  await signOut(page);
  await signIn(page, me);
  await page.getByRole('button', { name: 'Lost your phone? Use a recovery code' }).click();
  await page.getByLabel('Recovery code').fill(codes[0]);
  await page.getByRole('button', { name: 'Verify' }).click();
  await expect(page.getByRole('alert')).toContainText(/not right/i);

  // Another code still works, and the person was told about each use.
  await page.getByLabel('Recovery code').fill(codes[1]);
  await page.getByRole('button', { name: 'Verify' }).click();
  await expect(page.getByRole('heading', { name: /Hello, Ada/ })).toBeVisible();
  await page.getByRole('button', { name: /^Alerts/ }).click();
  await expect(page.getByText('A recovery code was used').first()).toBeVisible();
});
