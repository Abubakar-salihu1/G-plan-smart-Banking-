// Browser tests that click through the real app against a real server and database.
// Needs: a PostgreSQL database already migrated (DATABASE_URL), and the client built (npm --prefix ../client run build).
// Run:   cd e2e && npm install && npx playwright install --with-deps chromium && npm test
// The server starts itself in demo mode so sign-up and two-step codes show on screen instead of being emailed.
import { defineConfig, devices } from '@playwright/test';

const PORT = process.env.E2E_PORT || '4100';
export default defineConfig({
  testDir: './tests',
  timeout: 60_000,
  expect: { timeout: 10_000 },
  fullyParallel: false,
  workers: 1,
  retries: process.env.CI ? 1 : 0,
  reporter: process.env.CI ? [['github'], ['html', { open: 'never' }]] : 'list',
  use: { baseURL: `http://localhost:${PORT}`, trace: 'retain-on-failure', screenshot: 'only-on-failure', locale: 'en-NG' },
  projects: [{ name: 'chromium', use: { ...devices['Pixel 7'] } }],
  webServer: {
    command: 'npm --prefix ../server start',
    url: `http://localhost:${PORT}/api/health`,
    reuseExistingServer: !process.env.CI,
    timeout: 60_000,
    env: {
      PORT, DATABASE_URL: process.env.DATABASE_URL || 'postgres://gplan:gplan@localhost:5432/gplan_test',
      JWT_SECRET: process.env.JWT_SECRET || 'e2e-only-secret-not-for-production-use-0123456789',
      ENABLE_DEMO_FUNDING: 'true', DISABLE_JOBS: 'true', LOG_REQUESTS: 'false', RATE_LIMIT_MULTIPLIER: '100',
      CLIENT_ORIGIN: `http://localhost:${PORT}`,
    },
  },
});
