import { app } from './app.js';
import { config, assertProductionSafe } from './config.js';
import { runDueJobs, integrityCheck } from './services/jobs.js';
import { alert } from './services/monitor.js';
import { deliverPending } from './services/push.js';
import { runWatchdog } from './services/watchdog.js';

assertProductionSafe();

const server = app.listen(config.port, () => console.log(`G-Plan server (prototype) on :${config.port}`));

if (!config.disableJobs) {
  setInterval(() => runDueJobs().catch((e) => console.error('jobs', e.message)), 60_000);
  setInterval(() => deliverPending().catch((e) => console.error('push', e.message)), 5_000);
  setInterval(() => runWatchdog().catch((e) => console.error('watchdog', e.message)), 5 * 60_000);
  setTimeout(() => runWatchdog().catch((e) => console.error('watchdog', e.message)), 90_000);
  setInterval(() => integrityCheck().catch((e) => console.error('integrity', e.message)), 6 * 60 * 60 * 1000);
  setTimeout(() => integrityCheck().catch(() => {}), 30_000);
}

process.on('unhandledRejection', (e) => alert(`Unhandled rejection: ${e?.message || e}`));
process.on('SIGTERM', () => server.close(() => process.exit(0)));
