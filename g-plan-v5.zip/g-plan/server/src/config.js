import 'dotenv/config';

function need(key, devFallback) {
  const v = process.env[key] ?? (process.env.NODE_ENV === 'production' ? undefined : devFallback);
  if (!v) throw new Error(`Missing required env var: ${key}`);
  return v;
}

export const isWeakSecret = (v) =>
  !v || String(v).length < 32 || /change-?me|dev-only|example|placeholder|password|secret123|0123456789abcdef0123/i.test(String(v));

export const config = {
  port: Number(process.env.PORT || 4000),
  databaseUrl: need('DATABASE_URL'),
  jwtSecret: need('JWT_SECRET', 'dev-only-secret-change-me'),
  dataKey: process.env.DATA_KEY || need('JWT_SECRET', 'dev-only-secret-change-me'),
  clientOrigin: process.env.CLIENT_ORIGIN || 'http://localhost:5173',
  demoFunding: process.env.ENABLE_DEMO_FUNDING === 'true',
  allowedOrigins: (process.env.WEBAUTHN_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean),
  adminRequireMfa: process.env.ADMIN_REQUIRE_MFA === 'true',
  anthropicKey: process.env.ANTHROPIC_API_KEY || '',
  anthropicModel: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
  disableJobs: process.env.DISABLE_JOBS === 'true',
  // KYC document photos: off unless you opt in. They are encrypted at rest and purged after a retention window.
  // DEMO savings interest (only paid when ENABLE_DEMO_FUNDING=true). A placeholder rate, not an offer.
  savingsDemoApr: Number(process.env.SAVINGS_DEMO_APR ?? 0.08),
  kycDocs: process.env.KYC_DOCUMENTS === 'on',
  kycDocRetentionDays: Number(process.env.KYC_DOC_RETENTION_DAYS) || 30,
  kycDocMaxBytes: 2 * 1024 * 1024,
  // Web Push (VAPID). Off unless VAPID_PUBLIC_KEY is set. Generate keys with: npm run vapid
  push: {
    enabled: !!process.env.VAPID_PUBLIC_KEY,
    publicKey: process.env.VAPID_PUBLIC_KEY || '',
    privateKey: process.env.VAPID_PRIVATE_KEY || '',
    subject: process.env.VAPID_SUBJECT || '',
    extraHosts: (process.env.PUSH_ENDPOINT_HOSTS || '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean),
  },
  // Payments flagged 'review' are held for a compliance decision (set REVIEW_HOLD=false to only flag them).
  reviewHold: process.env.REVIEW_HOLD !== 'false',
  // Largest amount we accept in one request (minor units). Keeps math inside safe integers.
  maxAmountMinor: 1_000_000_000_000,
  // PLACEHOLDER per-transaction limits by KYC tier, in NGN kobo. NOT regulatory figures.
  tierLimitsMinor: { 0: 5_000_000, 1: 20_000_000, 2: 100_000_000, 3: 500_000_000 },
  // PLACEHOLDER daily outgoing totals by KYC tier (NGN kobo). Not regulatory figures.
  dailyLimitsMinor: { 0: 10_000_000, 1: 50_000_000, 2: 200_000_000, 3: 1_000_000_000 },
  // PLACEHOLDER risk thresholds (NGN kobo).
  stepUpMinor: 10_000_000,        // with two-step verification on, code needed from this amount
  highRiskMinor: 50_000_000,      // always needs verification from this amount
  newDeviceMinor: 5_000_000,      // needs verification on a device first seen in the last 15 minutes
  // DEMO fees and rates. Indicative only, never guaranteed settlement rates.
  fees: { externalTransferMinor: 1000, fxPercent: 0.5, internationalPercent: 1.5 },
  fxRatesToNgn: { NGN: 1, USD: 1550, GBP: 2000, EUR: 1700 },
};

// Refuse to start in production with placeholder secrets or fake delivery providers.
export function assertProductionSafe() {
  if (process.env.NODE_ENV !== 'production') return;
  const problems = [];
  if (isWeakSecret(process.env.JWT_SECRET)) problems.push('JWT_SECRET must be a random value of at least 32 characters, not a placeholder.');
  const keys = (process.env.DATA_KEYS || '').split(',').map((k) => k.trim()).filter(Boolean);
  if (!keys.length || !keys.every((k) => /^\d+:[0-9a-fA-F]{64}$/.test(k) && !isWeakSecret(k.split(':')[1]))) {
    problems.push('DATA_KEYS must hold at least one random key, like "1:<64 hex characters>" (generate with: openssl rand -hex 32).');
  }
  if (!config.demoFunding) {
    if ((process.env.SMS_PROVIDER || 'mock') === 'mock') problems.push('SMS_PROVIDER must be a real provider (termii or twilio) when demo mode is off, otherwise login codes would be written to the logs.');
    if ((process.env.EMAIL_PROVIDER || 'mock') === 'mock') problems.push('EMAIL_PROVIDER must be a real provider (resend) when demo mode is off.');
  } else {
    console.warn('WARNING: ENABLE_DEMO_FUNDING=true in production. Fake money and on-screen codes are enabled. Demo only.');
  }
  const pp = process.env.PAYMENT_PROVIDER || 'mock';
  if (!['mock', 'paystack', 'flutterwave'].includes(pp)) problems.push('PAYMENT_PROVIDER must be mock, paystack or flutterwave.');
  if (pp === 'paystack' && !process.env.PAYSTACK_SECRET_KEY) problems.push('PAYSTACK_SECRET_KEY is needed when PAYMENT_PROVIDER=paystack.');
  if (pp === 'flutterwave') {
    if (!process.env.FLUTTERWAVE_SECRET_KEY) problems.push('FLUTTERWAVE_SECRET_KEY is needed when PAYMENT_PROVIDER=flutterwave.');
    if (isWeakSecret(process.env.FLUTTERWAVE_WEBHOOK_HASH)) problems.push('FLUTTERWAVE_WEBHOOK_HASH must be a random value of at least 32 characters (the same value you set in the Flutterwave dashboard).');
  }
  if (config.kycDocs && !process.env.DATA_KEYS) problems.push('DATA_KEYS is needed when KYC_DOCUMENTS=on, because photos are encrypted with it.');
  if (config.push.enabled && (!process.env.VAPID_PRIVATE_KEY || !process.env.VAPID_SUBJECT)) problems.push('VAPID_PRIVATE_KEY and VAPID_SUBJECT are needed when VAPID_PUBLIC_KEY is set.');
  if (problems.length) throw new Error('Unsafe production configuration:\n- ' + problems.join('\n- '));
}
