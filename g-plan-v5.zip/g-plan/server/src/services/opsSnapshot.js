// Counts the things that mean "something is stuck or someone is waiting". One cheap query set, safe to run often.
import { pool } from '../db.js';
import { T } from '../utils/opsRules.js';

const n = async (sql, params = []) => Number((await pool.query(sql, params)).rows[0].n);

export async function opsSnapshot() {
  return {
    processingOld: await n(`SELECT COUNT(*) AS n FROM transactions WHERE state='processing' AND updated_at < now() - ($1 || ' minutes')::interval`, [String(T.processingMin)]),
    unconfirmedOld: await n(`SELECT COUNT(*) AS n FROM transactions WHERE state='processing_unconfirmed' AND updated_at < now() - ($1 || ' minutes')::interval`, [String(T.unconfirmedMin)]),
    heldOld: await n(`SELECT COUNT(*) AS n FROM transactions WHERE state='under_review' AND created_at < now() - ($1 || ' hours')::interval`, [String(T.heldHours)]),
    bulkStuck: await n(`SELECT COUNT(*) AS n FROM bulk_batches b WHERE b.status='running' AND b.decided_at < now() - ($1 || ' hours')::interval
                         AND EXISTS (SELECT 1 FROM bulk_items i WHERE i.batch_id=b.id AND i.status IN ('queued','sending'))`, [String(T.bulkStuckHours)]),
    failedBulkItems24h: await n(`SELECT COUNT(*) AS n FROM bulk_items i JOIN bulk_batches b ON b.id=i.batch_id WHERE i.status='failed' AND b.decided_at > now() - interval '24 hours'`),
    approvalsOld: (await n(`SELECT COUNT(*) AS n FROM business_payouts WHERE status='pending_approval' AND created_at < now() - ($1 || ' hours')::interval`, [String(T.approvalHours)]))
      + (await n(`SELECT COUNT(*) AS n FROM bulk_batches WHERE status='pending_approval' AND created_at < now() - ($1 || ' hours')::interval`, [String(T.approvalHours)]))
      + (await n(`SELECT COUNT(*) AS n FROM pocket_payments WHERE status='pending_approval' AND created_at < now() - ($1 || ' hours')::interval`, [String(T.approvalHours)])),
    reversalsOld: await n(`SELECT COUNT(*) AS n FROM reversal_requests WHERE status='pending' AND created_at < now() - ($1 || ' hours')::interval`, [String(T.reversalHours)]),
    supportOld: await n(`SELECT COUNT(*) AS n FROM support_threads WHERE status='open' AND last_sender='customer' AND last_message_at < now() - ($1 || ' hours')::interval`, [String(T.supportHours)]),
    kycOld: await n(`SELECT COUNT(*) AS n FROM kyc_submissions WHERE status='pending' AND created_at < now() - ($1 || ' hours')::interval`, [String(T.kycHours)]),
  };
}
