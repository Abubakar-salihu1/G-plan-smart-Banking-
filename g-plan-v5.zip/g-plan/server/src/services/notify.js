export async function notify(db, userId, title, body, kind = 'info') {
  await db.query('INSERT INTO notifications(user_id, title, body, kind) VALUES ($1,$2,$3,$4)',
    [userId, title, body ?? null, kind]);
}
