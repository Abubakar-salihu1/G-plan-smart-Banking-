// Rules for shared pockets. Pure functions (no database) so they can be tested on their own.
//   joint pocket : two people. Either may add money. Either may pay out up to the solo limit; above it the OTHER person approves.
//   child pocket : a parent (owner) and a child. The parent can do anything. The child can only pay people the parent
//                  approved, up to a weekly limit, and never when the pocket is frozen.
export const POCKET_PERMS = {
  owner: ['view', 'fund', 'pay', 'manage', 'approve'],
  partner: ['view', 'fund', 'pay', 'approve'],
  child: ['view', 'pay'],
};
export const pocketCan = (role, perm) => (POCKET_PERMS[role] || []).includes(perm);

// Start of the child's spending week: Monday 00:00 UTC.
export function weekStart(now = new Date()) {
  const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  const back = (d.getUTCDay() + 6) % 7;
  return new Date(d.getTime() - back * 86400000);
}

// What happens to a payment out of a pocket: { outcome: 'now' | 'approval' | 'deny', reason }.
export function paymentDecision({ kind, role, amountMinor, soloLimitMinor, weeklyLimitMinor, spentThisWeekMinor = 0, frozen, recipientApproved }) {
  if (!pocketCan(role, 'pay')) return { outcome: 'deny', reason: 'Your role cannot pay from this pocket.' };
  if (frozen && role !== 'owner') return { outcome: 'deny', reason: 'This pocket is frozen.' };
  if (kind === 'child') {
    if (role === 'owner') return { outcome: 'now' };
    if (!recipientApproved) return { outcome: 'deny', reason: 'You can only send to people your parent has approved.' };
    if (Number(spentThisWeekMinor) + Number(amountMinor) > Number(weeklyLimitMinor)) return { outcome: 'deny', reason: 'That is more than your weekly limit allows.' };
    return { outcome: 'now' };
  }
  // joint
  if (Number(amountMinor) > Number(soloLimitMinor)) return { outcome: 'approval' };
  return { outcome: 'now' };
}

// A joint payment must be approved by the other person, never the one who made it.
export const canApprove = (role, creatorId, approverId) => pocketCan(role, 'approve') && creatorId !== approverId;
