// Second factor: authenticator app (TOTP), or a code sent by SMS/email.
import { pool } from '../db.js';
import { AppError } from '../errors.js';
import { verifyTotp } from '../utils/totp.js';
import { decrypt } from '../utils/crypto.js';
import { sendOtp, verifyOtp } from './otp.js';

export async function getUserRow(userId) {
  return (await pool.query(
    'SELECT id, email, phone, full_name, role, status, mfa_method, totp_secret FROM users WHERE id=$1', [userId])).rows[0];
}

// For SMS/email users, call this to deliver a code. For authenticator users it does nothing.
export async function sendChallenge(user, purpose) {
  if (user.mfa_method === 'sms' || user.mfa_method === 'email') return sendOtp(user, purpose, user.mfa_method);
  return { sent: false, channel: user.mfa_method };
}

export async function checkSecondFactor(user, code, purpose) {
  if (!user.mfa_method) return false;
  if (user.mfa_method === 'totp') return verifyTotp(decrypt(user.totp_secret), code);
  return verifyOtp(user.id, purpose, code);
}

export async function requireSecondFactor(userId, code, purpose = 'stepup') {
  const user = await getUserRow(userId);
  if (!user.mfa_method) {
    throw new AppError(403, 'VERIFICATION_REQUIRED', 'Turn on two-step verification in Security to make this payment.');
  }
  if (!code || !(await checkSecondFactor(user, code, purpose))) {
    throw new AppError(401, 'OTP_REQUIRED',
      user.mfa_method === 'totp'
        ? 'Enter the 6-digit code from your authenticator app to confirm this payment.'
        : 'Enter the 6-digit code we sent you to confirm this payment.');
  }
}
