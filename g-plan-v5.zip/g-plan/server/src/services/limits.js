// Daily outgoing cap by KYC tier. Called while the sender's wallet row is locked, so two parallel
// payments from the same wallet cannot both slip under the cap.
import { config } from '../config.js';
import { AppError } from '../errors.js';

export async function assertDailyLimit(c, userId, amountMinor, currency, kycTier) {
  if (currency !== 'NGN') return;
  const limit = config.dailyLimitsMinor[kycTier] ?? config.dailyLimitsMinor[0];
  const r = await c.query(
    `SELECT COALESCE(SUM(amount_minor), 0) AS s FROM transactions
     WHERE initiator_user_id=$1 AND currency='NGN' AND created_at >= date_trunc('day', now())
       AND state IN ('processing','processing_unconfirmed','under_review','completed')
       AND type IN ('internal_transfer','external_transfer','international_transfer','bill_payment','card_payment')`, [userId]);
  if (r.rows[0].s + amountMinor > limit) {
    throw new AppError(422, 'DAILY_LIMIT', 'This would go over your daily sending limit. Try again tomorrow, or verify your identity in Security to raise it.');
  }
}

// ---------- Business wallets ----------
// Money leaving a business wallet is limited as one customer, whoever on the team sends it: the owner's verification
// level sets the limits, the owner can set a lower daily cap, and the daily total counts everything paid out of the
// business wallet today (not each person's own spending). Called while the wallet row is locked.
import { effectiveDailyLimit, overDailyLimit, remainingToday } from '../utils/limitMath.js';

export async function businessLimits(c, businessId) {
  const b = (await c.query(
    `SELECT b.daily_cap_minor, u.kyc_tier FROM businesses b JOIN users u ON u.id=b.owner_id WHERE b.id=$1`, [businessId])).rows[0];
  if (!b) throw new AppError(404, 'NO_BUSINESS', 'Business not found.');
  const tier = b.kyc_tier;
  return {
    perPaymentMinor: config.tierLimitsMinor[tier] ?? config.tierLimitsMinor[0],
    dailyMinor: effectiveDailyLimit(config.dailyLimitsMinor[tier] ?? config.dailyLimitsMinor[0], b.daily_cap_minor),
    capMinor: b.daily_cap_minor,
  };
}

export async function businessUsedToday(c, walletId) {
  const r = await c.query(
    `SELECT COALESCE(SUM(t.amount_minor), 0) AS s FROM transactions t
     WHERE t.currency='NGN' AND t.state IN ('processing','processing_unconfirmed','under_review','completed')
       AND t.type IN ('internal_transfer','external_transfer','international_transfer','bill_payment','card_payment')
       AND t.id IN (SELECT je.transaction_id FROM postings p JOIN journal_entries je ON je.id=p.entry_id
                    WHERE p.account_id=$1 AND p.direction='debit' AND p.created_at >= date_trunc('day', now()))`, [walletId]);
  return Number(r.rows[0].s);
}

export async function assertBusinessLimits(c, { businessId, walletId, amountMinor, currency }) {
  if (currency !== 'NGN') return;
  const lim = await businessLimits(c, businessId);
  if (amountMinor > lim.perPaymentMinor) {
    throw new AppError(422, 'LIMIT_EXCEEDED', 'This amount is above the business\'s limit per payment. The owner can raise it by verifying their identity in Security.');
  }
  const used = await businessUsedToday(c, walletId);
  if (overDailyLimit(used, amountMinor, lim.dailyMinor)) {
    const left = remainingToday(used, lim.dailyMinor);
    throw new AppError(422, 'DAILY_LIMIT', `This would go over the business's daily limit for everyone on the team. About ₦${Math.floor(left / 100).toLocaleString('en-NG')} is left today. Try again tomorrow${lim.capMinor === null ? ', or ask the owner to verify their identity to raise it' : ', or ask the owner to raise the business daily cap'}.`);
  }
}
