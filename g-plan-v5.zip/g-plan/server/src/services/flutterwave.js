// Flutterwave adapter for REAL bank transfers. DISABLED unless PAYMENT_PROVIDER=flutterwave.
// NOT production-ready: it has only been tested against a stubbed fetch, never against Flutterwave's live or
// sandbox API. Use TEST keys only until you have a regulated business account, have finished Flutterwave's
// go-live checks and a qualified engineer has reviewed this code. G-Plan itself holds no licence.
//
// Differences from Paystack that this file handles:
//  - amounts are in MAJOR units (naira), not kobo
//  - webhooks are authenticated with a shared secret hash in the `verif-hash` header, not an HMAC of the body
//  - transfer results arrive as `transfer.completed` with data.status SUCCESSFUL or FAILED
import crypto from 'node:crypto';
import { AppError } from '../errors.js';

const base = 'https://api.flutterwave.com/v3';
const key = () => process.env.FLUTTERWAVE_SECRET_KEY;
const hash = () => process.env.FLUTTERWAVE_WEBHOOK_HASH;
const headers = () => ({ Authorization: `Bearer ${key()}`, 'Content-Type': 'application/json' });
export const enabled = () => (process.env.PAYMENT_PROVIDER || 'mock') === 'flutterwave' && !!key();

// kobo -> naira as a decimal number with at most two places, using integer maths only.
export const toMajor = (minor) => {
  if (!Number.isSafeInteger(minor) || minor <= 0) throw new Error('Invalid amount');
  return Number(`${Math.floor(minor / 100)}.${String(minor % 100).padStart(2, '0')}`);
};

export async function resolveAccount(accountNumber, bankCode) {
  const r = await fetch(`${base}/accounts/resolve`, {
    method: 'POST', headers: headers(), signal: AbortSignal.timeout(10_000),
    body: JSON.stringify({ account_number: accountNumber, account_bank: bankCode }),
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok || d.status !== 'success' || !d.data?.account_name) throw new AppError(422, 'NAME_ENQUIRY_FAILED', 'Could not verify that account.');
  return d.data.account_name;
}

// Provider function for payExternal. A "NEW" or "PENDING" transfer stays unconfirmed until the webhook or
// the status check says otherwise. Our reference is sent so a retry can never create a second transfer.
export async function transferProvider({ reference, amountMinor, meta }) {
  const res = await fetch(`${base}/transfers`, {
    method: 'POST', headers: headers(), signal: AbortSignal.timeout(15_000),
    body: JSON.stringify({
      account_bank: meta.bankCode, account_number: meta.accountNumber, amount: toMajor(amountMinor), currency: 'NGN',
      narration: 'G-Plan transfer', reference, beneficiary_name: meta.accountName,
    }),
  });
  const d = await res.json().catch(() => ({}));
  if (!res.ok || d.status !== 'success') {
    // 4xx with a clear message: the transfer was refused. Anything else (5xx, odd shapes) is unknown, not failed.
    if (res.status >= 400 && res.status < 500) return { ok: false, reason: d.message || 'The transfer was declined.' };
    return { unconfirmed: true };
  }
  return outcomeOf(d.data?.status, d.data?.id);
}

function outcomeOf(status, id) {
  const s = String(status || '').toUpperCase();
  if (s === 'SUCCESSFUL') return { ok: true, providerRef: id != null ? String(id) : undefined };
  if (s === 'FAILED') return { ok: false, reason: 'The transfer failed.' };
  return { unconfirmed: true };
}

// Ask Flutterwave what happened to one of our references (used when a webhook never arrived).
export async function statusCheck(reference) {
  const r = await fetch(`${base}/transfers?reference=${encodeURIComponent(reference)}`, { headers: headers(), signal: AbortSignal.timeout(10_000) });
  const d = await r.json().catch(() => ({}));
  const t = Array.isArray(d.data) ? d.data.find((x) => x.reference === reference) : null;
  if (!r.ok || !t) return { unconfirmed: true };
  return outcomeOf(t.status, t.id);
}

// Flutterwave sends the secret hash you chose in the dashboard, unchanged, in `verif-hash`.
export function verifyWebhook(signature) {
  const h = hash();
  if (!h || !signature) return false;
  const a = Buffer.from(String(h)), b = Buffer.from(String(signature));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export { outcomeOf };
