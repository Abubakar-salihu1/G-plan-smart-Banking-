// ID photos for KYC tiers 2 and 3. Only active when KYC_DOCUMENTS=on.
// Controls: JPEG/PNG only, size and pixel limits, metadata removed, AES-256-GCM encryption with the DATA_KEYS
// key ring, never returned to the owner or to the browser cache, readable only by KYC reviewers with every view
// written to the audit log, and deleted automatically after a retention window.
// A real KYC provider is still the better home for these photos. This exists so the prototype can run the whole flow.
import { pool } from '../db.js';
import { config } from '../config.js';
import { AppError } from '../errors.js';
import { encryptBuffer, decryptBuffer } from '../utils/crypto.js';
import { inspectImage } from '../utils/image.js';
import crypto from 'node:crypto';

export const KINDS = ['id_front', 'id_back', 'selfie'];
export const requiredKinds = (tier) => (config.kycDocs && Number(tier) >= 2 ? ['id_front', 'selfie'] : []);

export const assertEnabled = () => {
  if (!config.kycDocs) throw new AppError(404, 'NOT_FOUND', 'Photo upload is not switched on.');
};

export async function storeDocument(userId, kind, body, declaredType) {
  assertEnabled();
  if (!KINDS.includes(kind)) throw new AppError(422, 'INVALID_KIND', 'Unknown photo type.');
  if (!Buffer.isBuffer(body) || body.length === 0) throw new AppError(422, 'NO_FILE', 'Choose a photo to upload.');
  let img;
  try { img = inspectImage(body); } catch (e) { throw new AppError(422, 'BAD_IMAGE', e.message); }
  if (declaredType && !String(declaredType).startsWith(img.mime)) throw new AppError(422, 'BAD_IMAGE', 'The file type does not match its contents.');

  const day = (await pool.query(
    `SELECT COUNT(*) AS n FROM kyc_documents WHERE user_id=$1 AND created_at > now() - interval '1 day'`, [userId])).rows[0].n;
  if (day >= 12) throw new AppError(429, 'TOO_MANY', 'Too many uploads today. Try again tomorrow.');

  const { keyVersion, data } = encryptBuffer(img.clean);
  const sha = crypto.createHash('sha256').update(img.clean).digest('hex');
  // One waiting photo per kind: a new upload replaces the earlier one that is not yet part of a submission.
  await pool.query(`DELETE FROM kyc_documents WHERE user_id=$1 AND kind=$2 AND submission_id IS NULL`, [userId, kind]);
  const r = await pool.query(
    `INSERT INTO kyc_documents(user_id, kind, mime, size_bytes, sha256, key_version, ciphertext)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id, kind, created_at`,
    [userId, kind, img.mime, img.clean.length, sha, keyVersion, data]);
  return r.rows[0];
}

export async function listOwn(userId) {
  return (await pool.query(
    `SELECT id, kind, submission_id IS NOT NULL AS submitted, created_at FROM kyc_documents WHERE user_id=$1 ORDER BY created_at DESC LIMIT 20`, [userId])).rows;
}

export async function deleteOwn(userId, id) {
  const r = await pool.query(`DELETE FROM kyc_documents WHERE id=$1 AND user_id=$2 AND submission_id IS NULL RETURNING id`, [id, userId]);
  if (!r.rows[0]) throw new AppError(404, 'NOT_FOUND', 'Photo not found, or it was already sent for review.');
}

export async function missingKinds(db, userId, tier) {
  const need = requiredKinds(tier);
  if (!need.length) return [];
  const have = (await db.query(`SELECT DISTINCT kind FROM kyc_documents WHERE user_id=$1 AND submission_id IS NULL`, [userId])).rows.map((x) => x.kind);
  return need.filter((k) => !have.includes(k));
}

export async function attach(db, userId, submissionId) {
  await db.query(`UPDATE kyc_documents SET submission_id=$2 WHERE user_id=$1 AND submission_id IS NULL`, [userId, submissionId]);
}

// Called when a reviewer decides: the photos are kept only for the retention window from now.
export async function markDecided(db, submissionId) {
  await db.query(
    `UPDATE kyc_documents SET purge_after = now() + ($2 || ' days')::interval WHERE submission_id=$1`, [submissionId, String(config.kycDocRetentionDays)]);
}

export async function listForReview(submissionId) {
  return (await pool.query(
    `SELECT id, kind, mime, size_bytes, created_at FROM kyc_documents WHERE submission_id=$1 ORDER BY kind`, [submissionId])).rows;
}

export async function countsBySubmission(ids) {
  if (!ids.length) return {};
  const r = await pool.query(`SELECT submission_id, COUNT(*) AS n FROM kyc_documents WHERE submission_id = ANY($1::uuid[]) GROUP BY submission_id`, [ids]);
  return Object.fromEntries(r.rows.map((x) => [x.submission_id, Number(x.n)]));
}

// Decrypts for a reviewer. The audit row is written BEFORE any bytes are returned.
export async function readForReview(docId, actor, ip) {
  const d = (await pool.query(`SELECT id, user_id, mime, key_version, ciphertext FROM kyc_documents WHERE id=$1 AND submission_id IS NOT NULL`, [docId])).rows[0];
  if (!d) throw new AppError(404, 'NOT_FOUND', 'Photo not found. It may have passed its retention period and been deleted.');
  await pool.query(
    `INSERT INTO audit_log(actor_type, actor_id, action, target_type, target_id, ip_address, metadata) VALUES ('admin',$1,'kyc.document_viewed','kyc_document',$2,$3,$4)`,
    [actor, d.id, ip || null, JSON.stringify({ customerId: d.user_id })]);
  return { mime: d.mime, bytes: decryptBuffer(d.ciphertext, d.key_version) };
}

export async function purgeExpired() {
  const a = await pool.query(`DELETE FROM kyc_documents WHERE purge_after IS NOT NULL AND purge_after < now()`);
  // Photos that were never sent for review are not worth keeping past a day.
  const b = await pool.query(`DELETE FROM kyc_documents WHERE submission_id IS NULL AND created_at < now() - interval '1 day'`);
  return a.rowCount + b.rowCount;
}
