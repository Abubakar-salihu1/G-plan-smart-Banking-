// Database-backed parts of business access: who is in which business, and the route guard.
import { pool } from '../db.js';
import { AppError } from '../errors.js';
import { bizCan } from './businessRules.js';

export * from './businessRules.js';

// The person's active membership, or null.
export async function activeMembership(db, userId) {
  const r = await db.query(
    `SELECT m.id, m.business_id, m.role, b.name, b.owner_id, b.approval_threshold_minor
     FROM business_members m JOIN businesses b ON b.id=m.business_id
     WHERE m.user_id=$1 AND m.status='active'`, [userId]);
  return r.rows[0] || null;
}

// Express middleware: loads the membership and checks one permission. Always checked on the server.
export const requireBizPerm = (perm) => async (req, _res, next) => {
  try {
    const m = await activeMembership(pool, req.user.id);
    if (!m) throw new AppError(404, 'NO_BUSINESS', 'You are not part of a business yet.');
    if (!bizCan(m.role, perm)) throw new AppError(403, 'FORBIDDEN', 'Your role on this business does not allow that.');
    req.biz = m;
    next();
  } catch (e) { next(e); }
};

// Alert every active member who holds a permission (for example the people who may see incoming money).
export async function notifyMembers(db, businessId, perm, title, body, kind = 'info', exceptUserId = null) {
  const rows = (await db.query(`SELECT user_id, role FROM business_members WHERE business_id=$1 AND status='active'`, [businessId])).rows;
  for (const m of rows) {
    if (m.user_id === exceptUserId || !bizCan(m.role, perm)) continue;
    await db.query('INSERT INTO notifications(user_id, title, body, kind) VALUES ($1,$2,$3,$4)', [m.user_id, title, body ?? null, kind]);
  }
}

export async function userName(db, userId) {
  return (await db.query('SELECT full_name FROM users WHERE id=$1', [userId])).rows[0]?.full_name || '';
}
