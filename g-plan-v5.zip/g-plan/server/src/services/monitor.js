// Lightweight monitoring: in-memory counters exposed in Prometheus text format, plus optional
// alert webhook (Slack/Discord/any URL that accepts {text}). Production should also use an
// external uptime monitor and a log/APM service.
import { config } from '../config.js';

const counters = new Map();
export function inc(name, labels = {}, n = 1) {
  const key = name + (Object.keys(labels).length ? '{' + Object.entries(labels).map(([k, v]) => `${k}="${v}"`).join(',') + '}' : '');
  counters.set(key, (counters.get(key) || 0) + n);
}
const gauges = new Map();
export function setGauge(name, value) { gauges.set(name, value); }
export function renderMetrics() {
  const lines = [`# G-Plan metrics (prototype)`, `gplan_uptime_seconds ${Math.round(process.uptime())}`];
  for (const [k, v] of gauges) lines.push(`${k} ${v}`);
  for (const [k, v] of counters) lines.push(`${k} ${v}`);
  return lines.join('\n') + '\n';
}
export async function alert(text) {
  console.error('[ALERT]', text);
  inc('gplan_alerts_total');
  const url = process.env.ALERT_WEBHOOK_URL;
  if (!url) return;
  try {
    await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: `G-Plan alert: ${text}` }) });
  } catch { /* alerting must never crash the app */ }
}
export const isProd = () => process.env.NODE_ENV === 'production' && !config.demoFunding;
