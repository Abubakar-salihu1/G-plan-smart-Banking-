// Reversals are NEW compensating ledger entries, never edits. Only run after maker-checker approval.
import { withTx } from '../db.js';
import { AppError } from '../errors.js';
import { postEntry, availableBalance, walkStates } from './ledger.js';
import { notify } from './notify.js';

export async function executeReversal(txnId, approverId) {
  return withTx(async (c) => {
    const t = (await c.query('SELECT * FROM transactions WHERE id=$1 FOR UPDATE', [txnId])).rows[0];
    if (!t) throw new AppError(404, 'NOT_FOUND', 'Transaction not found.');
    if (t.state !== 'completed') throw new AppError(422, 'NOT_REVERSIBLE', 'Only completed transactions can be reversed.');
    const entries = (await c.query(
      'SELECT id, description FROM journal_entries WHERE transaction_id=$1 AND reverses_entry_id IS NULL ORDER BY chain_no NULLS FIRST, seq', [txnId])).rows;
    if (!entries.length) throw new AppError(422, 'NOT_REVERSIBLE', 'Nothing to reverse.');
    const all = [];
    for (const e of entries) {
      const ps = (await c.query(
        `SELECT p.account_id, p.direction, p.amount_minor, p.currency, a.type AS acct_type, a.user_id
         FROM postings p JOIN accounts a ON a.id=p.account_id WHERE p.entry_id=$1`, [e.id])).rows;
      all.push({ entry: e, ps });
    }
    // Lock every account involved, then make sure no customer account would go negative.
    const ids = [...new Set(all.flatMap((x) => x.ps.map((p) => p.account_id)))];
    await c.query('SELECT id FROM accounts WHERE id = ANY($1::uuid[]) ORDER BY id FOR UPDATE', [ids]);
    for (const { ps } of all) {
      for (const p of ps) {
        if (p.direction === 'credit' && p.user_id) {
          if ((await availableBalance(c, p.account_id)) < p.amount_minor) {
            throw new AppError(422, 'RECIPIENT_FUNDS_SPENT',
              'The receiving account no longer holds these funds, so this cannot be reversed automatically. Escalate to compliance.');
          }
        }
      }
    }
    for (const { entry, ps } of all) {
      await postEntry(c, {
        transactionId: txnId, description: `Reversal of ${entry.description || entry.id}`, reversesEntryId: entry.id,
        postings: ps.map((p) => ({ accountId: p.account_id, direction: p.direction === 'debit' ? 'credit' : 'debit',
          amountMinor: p.amount_minor, currency: p.currency })),
      });
    }
    await walkStates(c, txnId, ['reversed']);
    await c.query(
      `INSERT INTO audit_log(actor_type, actor_id, action, target_type, target_id, metadata)
       VALUES ('admin',$1,'transaction.reversed','transaction',$2,'{}')`, [approverId, txnId]);
    const users = new Set(all.flatMap((x) => x.ps.map((p) => p.user_id)).filter(Boolean));
    for (const u of users) await notify(c, u, 'Transaction reversed', `Transaction ${t.reference} was reversed after review.`, 'info');
    return { reference: t.reference };
  });
}
