// Recovery codes in the database. A code works once, only at sign-in and password reset (never to approve payments),
// every use is audit-logged and alerts the person, and turning two-step off deletes them all.
import crypto from 'node:crypto';
import { pool } from '../db.js';
import { fingerprint } from '../utils/crypto.js';
import { generateCodes, normalize, format } from '../utils/recoveryCodes.js';
import { notify } from './notify.js';

// Replaces any earlier set. Returns the new codes in readable form. This is the only time they are visible.
export async function issueCodes(db, userId) {
  const raw = generateCodes();
  await db.query('DELETE FROM recovery_codes WHERE user_id=$1', [userId]);
  for (const code of raw) {
    const { version, hash } = fingerprint(code, undefined, 'recovery');
    await db.query('INSERT INTO recovery_codes(user_id, code_hash, key_version) VALUES ($1,$2,$3)', [userId, hash, version]);
  }
  return raw.map(format);
}

export async function codesLeft(db, userId) {
  return Number((await db.query('SELECT COUNT(*) AS n FROM recovery_codes WHERE user_id=$1 AND used_at IS NULL', [userId])).rows[0].n);
}

export async function deleteCodes(db, userId) {
  await db.query('DELETE FROM recovery_codes WHERE user_id=$1', [userId]);
}

// True if the code was valid and has now been used up.
export async function consumeCode(userId, input, ip) {
  const code = normalize(input);
  if (!code) return false;
  const rows = (await pool.query('SELECT id, code_hash, key_version FROM recovery_codes WHERE user_id=$1 AND used_at IS NULL', [userId])).rows;
  let hit = null;
  for (const r of rows) {   // compare every row so timing does not reveal which one matched
    const want = Buffer.from(fingerprint(code, r.key_version, 'recovery').hash, 'hex');
    const have = Buffer.from(r.code_hash, 'hex');
    if (want.length === have.length && crypto.timingSafeEqual(want, have)) hit = r;
  }
  if (!hit) return false;
  // Claim it atomically so the same code cannot be used twice at once.
  const claim = await pool.query('UPDATE recovery_codes SET used_at=now() WHERE id=$1 AND used_at IS NULL RETURNING id', [hit.id]);
  if (!claim.rows[0]) return false;
  const left = rows.length - 1;
  await pool.query(`INSERT INTO audit_log(actor_type, actor_id, action, ip_address) VALUES ('user',$1,'auth.recovery_code_used',$2)`, [userId, ip || null]);
  await notify(pool, userId, 'A recovery code was used',
    `One of your recovery codes was just used to sign in or reset your password. ${left} left.${left <= 2 ? ' Make a new set in Security soon.' : ''} If this was not you, change your password now.`, 'security');
  return true;
}
