// Turns "send 5k to ada@example.com" into a DRAFT. The assistant never moves money: the draft only pre-fills the
// normal Send screen, where the person still reviews it and authorises it with their password (and a code when asked),
// under the same limits, risk checks and confirmation as any other payment. Pure functions, no database.
const MAX = 1_000_000_000_00;

export function amountFrom(text) {
  const m = String(text).match(/(?:₦|ngn|n)?\s*(\d[\d,]*(?:\.\d{1,2})?)\s*(k|m|million|thousand)?\b/i);
  if (!m) return null;
  let v = parseFloat(m[1].replace(/,/g, ''));
  const u = (m[2] || '').toLowerCase();
  if (u === 'k' || u === 'thousand') v *= 1000;
  if (u === 'm' || u === 'million') v *= 1_000_000;
  const minor = Math.round(v * 100);
  return Number.isSafeInteger(minor) && minor > 0 && minor <= MAX ? minor : null;
}

// Returns { type: 'send', recipient, amountMinor, note } or null. Only G-Plan emails and phone numbers are drafted,
// because a bank account must be name-checked on the Send screen first.
export function parseAction(question) {
  const q = String(question || '').slice(0, 400);
  if (!/^\s*(please\s+)?(send|pay|transfer)\b/i.test(q)) return null;
  const email = q.match(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/);
  const phone = !email && q.match(/(?:\+?234|0)\d{10}\b|\+\d{10,14}\b/);
  const recipient = email ? email[0].toLowerCase() : phone ? phone[0] : null;
  if (!recipient) return null;
  const before = q.replace(recipient, ' ');
  const amountMinor = amountFrom(before.replace(/\b(send|pay|transfer|please)\b/gi, ' '));
  if (!amountMinor) return null;
  const note = (q.match(/\bfor\s+([A-Za-z0-9 ,.'-]{2,60})$/i) || [])[1]?.trim() || '';
  return { type: 'send', recipient, amountMinor, note };
}
