// Fraud scoring and AML monitoring. Rule-based and explainable: every decision lists its reasons.
// States: normal -> review -> additional_verification (-> restricted by staff). Uncertain signals
// never accuse the customer; they ask for extra verification or send the case to human review.
import fs from 'node:fs';
import { pool } from '../db.js';
import { config } from '../config.js';
import { AppError } from '../errors.js';
import { requireSecondFactor } from './mfa.js';

const ORDER = ['normal', 'review', 'additional_verification'];
const toNgn = (minor, ccy) => minor * (config.fxRatesToNgn[ccy] || 1);

export async function assessRisk(userId, { amountMinor, currency = 'NGN', deviceId, availableMinor = null, mfaEnabled = false }) {
  let level = 'normal';
  const reasons = [];
  const bump = (l, reason) => {
    if (ORDER.indexOf(l) > ORDER.indexOf(level)) level = l;
    reasons.push(reason);
  };
  const ngn = toNgn(amountMinor, currency);

  if (ngn >= config.highRiskMinor) bump('additional_verification', 'Large amount');
  else if (ngn >= config.stepUpMinor && mfaEnabled) bump('additional_verification', 'Amount above step-up threshold');

  if (deviceId && ngn >= config.newDeviceMinor) {
    const first = (await pool.query('SELECT MIN(created_at) AS t FROM sessions WHERE user_id=$1 AND device_id=$2', [userId, deviceId])).rows[0].t;
    if (first && Date.now() - new Date(first).getTime() < 15 * 60 * 1000) bump('additional_verification', 'New device');
  }
  const recent = (await pool.query(
    `SELECT COUNT(*) AS n FROM transactions WHERE initiator_user_id=$1 AND created_at > now() - interval '10 minutes'
     AND type IN ('internal_transfer','external_transfer','international_transfer','bill_payment','card_payment')`, [userId])).rows[0].n;
  if (recent >= 8) bump('additional_verification', 'Many payments in a short time');
  else if (recent >= 5) bump('review', 'Several payments in a short time');

  if (availableMinor != null && availableMinor > 0 && ngn >= 10_000_000 && amountMinor >= availableMinor * 0.8) {
    bump('review', 'Most of the balance in one payment');
  }
  return { level, reasons, needsVerification: level === 'additional_verification' };
}

// Enforce the verification a risk level demands, then return the level to store on the transaction.
export async function enforceRisk(req, risk, otp) {
  if (risk.needsVerification) await requireSecondFactor(req.user.id, otp, 'stepup');
  return risk.level;
}

export async function recordRisk(userId, risk, transactionId) {
  if (risk.level === 'normal') return;
  await pool.query(
    `INSERT INTO risk_events(user_id, transaction_id, level, reasons) VALUES ($1,$2,$3,$4)`,
    [userId, transactionId || null, risk.level, JSON.stringify(risk.reasons)]);
}

// ---------- AML ----------
let sanctioned = [];
try {
  sanctioned = JSON.parse(fs.readFileSync(new URL('../data/sanctions-demo.json', import.meta.url), 'utf8')).names.map((n) => n.toLowerCase());
} catch { sanctioned = []; }

const norm = (s) => String(s || '').toLowerCase().replace(/[^a-z ]/g, ' ').replace(/\s+/g, ' ').trim();

// DEMO screening against a placeholder list. Production must use a licensed screening provider.
export function screenName(name) {
  const n = norm(name);
  return sanctioned.some((s) => n.includes(s));
}

export async function openAmlCase(userId, transactionId, kind, details) {
  await pool.query(
    `INSERT INTO aml_cases(user_id, transaction_id, kind, details) VALUES ($1,$2,$3,$4)`,
    [userId, transactionId || null, kind, JSON.stringify(details)]);
}

export function assertNotSanctioned(name) {
  if (screenName(name)) {
    throw new AppError(403, 'SCREENING_HIT',
      'We cannot process this payment. It needs a compliance review. Contact support.');
  }
}

// Best-effort monitoring after a payment. Never blocks or fails the payment itself.
export async function monitorAml(userId, receipt) {
  try {
    const limit = config.tierLimitsMinor[0];
    const near = (await pool.query(
      `SELECT COUNT(*) AS n FROM transactions WHERE initiator_user_id=$1 AND created_at > now() - interval '24 hours'
       AND type IN ('internal_transfer','external_transfer') AND currency='NGN'
       AND amount_minor BETWEEN $2 AND $3`, [userId, Math.floor(limit * 0.9), limit])).rows[0].n;
    if (near >= 3) await openAmlCase(userId, receipt.transactionId, 'possible_structuring',
      { note: 'Three or more transfers just under a limit within 24 hours', count: near });

    const flow = (await pool.query(
      `SELECT
         COALESCE(SUM(amount_minor) FILTER (WHERE type='deposit'), 0) AS inn,
         COALESCE(SUM(amount_minor) FILTER (WHERE type IN ('external_transfer','international_transfer')), 0) AS outt
       FROM transactions WHERE initiator_user_id=$1 AND state='completed' AND created_at > now() - interval '1 hour'`,
      [userId])).rows[0];
    if (flow.inn >= 5_000_000 && flow.outt >= flow.inn * 0.8) await openAmlCase(userId, receipt.transactionId, 'rapid_in_out',
      { note: 'Most of a recent deposit sent out within an hour', inMinor: flow.inn, outMinor: flow.outt });
  } catch (e) { console.error('AML monitor error', e.message); }
}
