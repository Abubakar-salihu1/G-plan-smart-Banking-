// Sends one plain-text email. EMAIL_PROVIDER: mock (default, only logs) or resend. NOT tested against the live provider.
export async function sendEmail(to, subject, text) {
  if ((process.env.EMAIL_PROVIDER || 'mock') === 'resend') {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST', signal: AbortSignal.timeout(10_000),
      headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: process.env.EMAIL_FROM, to: [to], subject, text }),
    });
    if (!r.ok) throw new Error('Email provider error');
    return { mock: false };
  }
  console.log(`[MOCK EMAIL] to ${to}: ${subject}`);
  return { mock: true };
}
