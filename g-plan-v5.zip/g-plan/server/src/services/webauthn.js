// Passkeys (fingerprint / face / device PIN) via WebAuthn, verified server-side.
// Uses @simplewebauthn/server v10, loaded on demand so the app still runs if it is not installed.
import { pool } from '../db.js';
import { config } from '../config.js';
import { AppError } from '../errors.js';

async function lib() {
  try { return await import('@simplewebauthn/server'); }
  catch { throw new AppError(501, 'PASSKEYS_UNAVAILABLE', 'Passkeys are not available on this server. Run npm install.'); }
}

export function context(req) {
  const origin = req.get('origin');
  if (!origin) throw new AppError(400, 'NO_ORIGIN', 'Missing origin.');
  let url;
  try { url = new URL(origin); } catch { throw new AppError(400, 'BAD_ORIGIN', 'Bad origin.'); }
  const host = url.hostname;
  const ok = config.allowedOrigins.includes(origin) || host === 'localhost' ||
    host.endsWith('.app.github.dev') || host.endsWith('.onrender.com');
  if (!ok) throw new AppError(403, 'ORIGIN_NOT_ALLOWED', 'This origin is not allowed for passkeys.');
  return { origin, rpID: host };
}

const b64u = (buf) => Buffer.from(buf).toString('base64url');
const fromB64u = (s) => new Uint8Array(Buffer.from(s, 'base64url'));

async function saveChallenge(userId, challenge, purpose) {
  await pool.query('DELETE FROM auth_challenges WHERE user_id=$1 AND purpose=$2', [userId, purpose]);
  await pool.query(`INSERT INTO auth_challenges(user_id, challenge, purpose, expires_at)
                    VALUES ($1,$2,$3, now() + interval '5 minutes')`, [userId, challenge, purpose]);
}
async function takeChallenge(userId, purpose) {
  const r = await pool.query(
    `DELETE FROM auth_challenges WHERE user_id=$1 AND purpose=$2 AND expires_at > now() RETURNING challenge`, [userId, purpose]);
  if (!r.rows[0]) throw new AppError(400, 'CHALLENGE_EXPIRED', 'That took too long. Please try again.');
  return r.rows[0].challenge;
}

export async function registrationOptions(req, user) {
  const w = await lib();
  const { rpID } = context(req);
  const existing = (await pool.query('SELECT credential_id FROM passkeys WHERE user_id=$1', [user.id])).rows;
  const options = await w.generateRegistrationOptions({
    rpName: 'G-Plan', rpID, userID: user.id, userName: user.email, userDisplayName: user.full_name,
    attestationType: 'none',
    excludeCredentials: existing.map((e) => ({ id: e.credential_id })),
    authenticatorSelection: { residentKey: 'preferred', userVerification: 'required', authenticatorAttachment: 'platform' },
  });
  options.user.id = b64u(Buffer.from(user.id));   // client decodes base64url
  await saveChallenge(user.id, options.challenge, 'passkey-register');
  return options;
}

export async function registrationVerify(req, user, response, label) {
  const w = await lib();
  const { origin, rpID } = context(req);
  const expectedChallenge = await takeChallenge(user.id, 'passkey-register');
  const v = await w.verifyRegistrationResponse({
    response, expectedChallenge, expectedOrigin: origin, expectedRPID: rpID, requireUserVerification: true,
  });
  if (!v.verified || !v.registrationInfo) throw new AppError(400, 'PASSKEY_FAILED', 'Could not verify this passkey.');
  const { credentialID, credentialPublicKey, counter } = v.registrationInfo;
  await pool.query(
    `INSERT INTO passkeys(user_id, credential_id, public_key, counter, transports, label)
     VALUES ($1,$2,$3,$4,$5,$6)`,
    [user.id, b64u(credentialID), b64u(credentialPublicKey), counter, response.response?.transports || [], (label || 'This device').slice(0, 40)]);
}

export async function authOptions(req, user) {
  const w = await lib();
  const { rpID } = context(req);
  const creds = (await pool.query('SELECT credential_id, transports FROM passkeys WHERE user_id=$1', [user.id])).rows;
  if (!creds.length) throw new AppError(404, 'NO_PASSKEY', 'No passkey is set up for this account.');
  const options = await w.generateAuthenticationOptions({
    rpID, userVerification: 'required',
    allowCredentials: creds.map((c) => ({ id: c.credential_id, transports: c.transports || undefined })),
  });
  await saveChallenge(user.id, options.challenge, 'passkey-auth');
  return options;
}

export async function authVerify(req, user, response) {
  const w = await lib();
  const { origin, rpID } = context(req);
  const expectedChallenge = await takeChallenge(user.id, 'passkey-auth');
  const cred = (await pool.query('SELECT * FROM passkeys WHERE user_id=$1 AND credential_id=$2', [user.id, response.id])).rows[0];
  if (!cred) throw new AppError(401, 'PASSKEY_UNKNOWN', 'This passkey is not recognised.');
  const v = await w.verifyAuthenticationResponse({
    response, expectedChallenge, expectedOrigin: origin, expectedRPID: rpID, requireUserVerification: true,
    authenticator: { credentialID: fromB64u(cred.credential_id), credentialPublicKey: fromB64u(cred.public_key),
      counter: Number(cred.counter), transports: cred.transports || undefined },
  });
  if (!v.verified) throw new AppError(401, 'PASSKEY_FAILED', 'Passkey check failed.');
  await pool.query('UPDATE passkeys SET counter=$2, last_used_at=now() WHERE id=$1', [cred.id, v.authenticationInfo.newCounter]);
}
