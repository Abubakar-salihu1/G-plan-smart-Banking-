// MOCK providers. Nothing here talks to a real bank, biller or card network.
// Demo rules so you can show every state:
//   account/meter/phone ending 0000 -> provider declines (transaction fails, hold released)
//   account/meter/phone ending 9999 -> provider times out (processing_unconfirmed, resolved later)
import crypto from 'node:crypto';

const ref = (p) => `${p}-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
const lastOf = (v) => String(v || '').slice(-4);

export async function mockBank({ meta }) {
  const tail = lastOf(meta.accountNumber);
  if (tail === '9999') throw new Error('timeout');
  if (tail === '0000') return { ok: false, reason: 'The receiving bank declined this transfer (demo rule: accounts ending 0000).' };
  return { ok: true, providerRef: ref('MOCKBANK') };
}

export async function mockBiller({ meta }) {
  const tail = lastOf(meta.payeeRef);
  if (tail === '9999') throw new Error('timeout');
  if (tail === '0000') return { ok: false, reason: 'The provider could not complete this payment (demo rule: references ending 0000).' };
  const extra = meta.category === 'electricity'
    ? { token: Array.from({ length: 5 }, () => String(crypto.randomInt(0, 10000)).padStart(4, '0')).join('-') }
    : {};
  return { ok: true, providerRef: ref('MOCKBILL'), extra };
}

export async function mockCard() { return { ok: true, providerRef: ref('MOCKCARD') }; }
export async function mockInternational() { return { ok: true, providerRef: ref('MOCKINTL') }; }
export async function mockStatusCheck() { return { ok: true, providerRef: ref('RECON') }; }
