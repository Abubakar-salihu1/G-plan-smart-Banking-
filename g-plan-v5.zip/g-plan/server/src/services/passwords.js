import { pool } from '../db.js';
import { AppError } from '../errors.js';
import { verifyPassword, dummyHash } from '../utils/password.js';

export async function registerFailure(userId) {
  await pool.query(
    `UPDATE users SET failed_logins = failed_logins + 1,
       locked_until = CASE WHEN failed_logins + 1 >= 5 THEN now() + interval '15 minutes' ELSE locked_until END
     WHERE id=$1`, [userId]);
}

// Re-check the password before a sensitive action (authorising a payment, changing security settings).
export async function assertPassword(userId, password) {
  const u = (await pool.query('SELECT password_hash, locked_until FROM users WHERE id=$1', [userId])).rows[0];
  if (u?.locked_until && new Date(u.locked_until) > new Date()) {
    throw new AppError(423, 'LOCKED', 'Too many wrong attempts. Try again in a few minutes.');
  }
  const ok = await verifyPassword(String(password || ''), u?.password_hash || (await dummyHash()));
  if (!u || !ok) {
    if (u) await registerFailure(userId);
    throw new AppError(401, 'AUTH_FAILED', 'Password is incorrect. Nothing was sent.');
  }
}

export function passwordProblem(pw) {
  if (typeof pw !== 'string' || pw.length < 8) return 'Use a password with at least 8 characters.';
  if (!/[a-zA-Z]/.test(pw) || !/\d/.test(pw)) return 'Include at least one letter and one number.';
  if (/^(password|12345678|qwerty123|gplan123)/i.test(pw)) return 'That password is too common. Choose another.';
  return null;
}
