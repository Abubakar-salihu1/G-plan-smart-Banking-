// G-Plan Intelligence. Answers only from the user's own recorded data.
// Without ANTHROPIC_API_KEY a built-in rule-based assistant answers. With a key, the model answers
// from the same computed facts only (no raw IDs, contacts or credentials are sent).
import { pool } from '../db.js';
import { config } from '../config.js';
import { insights } from './insights.js';
import { fmt } from '../utils/format.js';
import { parseAction } from './assistantActions.js';

const money = (m) => fmt(m);
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);

function parseAmount(q) {
  const m = [...q.matchAll(/(\d[\d,]*(?:\.\d+)?)\s*(k|m|million|thousand)?/gi)];
  let best = null;
  for (const x of m) {
    let v = parseFloat(x[1].replace(/,/g, ''));
    const u = (x[2] || '').toLowerCase();
    if (u === 'k' || u === 'thousand') v *= 1000;
    if (u === 'm' || u === 'million') v *= 1_000_000;
    if (best == null || v > best) best = v;
  }
  return best == null ? null : Math.round(best * 100);
}

async function goalsFacts(userId) {
  const r = await pool.query(
    `SELECT g.name, g.target_minor, g.deadline,
       COALESCE((SELECT SUM(CASE WHEN p.direction='credit' THEN p.amount_minor ELSE -p.amount_minor END)
                 FROM postings p WHERE p.account_id=g.account_id),0) AS current_minor
     FROM goals g WHERE g.user_id=$1 ORDER BY g.created_at`, [userId]);
  return r.rows.map((g) => {
    const remaining = Math.max(0, g.target_minor - g.current_minor);
    let monthly = null;
    if (g.deadline && remaining > 0) {
      const days = Math.ceil((new Date(g.deadline + 'T00:00:00Z') - new Date()) / 86400000);
      monthly = Math.ceil(remaining / Math.max(1, Math.ceil(days / 30)));
    }
    return { name: g.name, targetMinor: g.target_minor, currentMinor: g.current_minor, remainingMinor: remaining, recommendedMonthlyMinor: monthly };
  });
}

function ruleBased(q, f, goals, explainRow) {
  const s = q.toLowerCase();
  const lines = [];
  const top = f.byCategory.filter((c) => c.spentMinor > 0);
  if (explainRow) {
    return [`Transaction ${explainRow.reference}:`, `• Type: ${explainRow.type.replace(/_/g, ' ')}${explainRow.description ? ` (${explainRow.description})` : ''}`,
      `• Amount: ${money(explainRow.amount_minor)}${explainRow.fee_minor ? ` plus fee ${money(explainRow.fee_minor)}` : ''}`,
      `• Status: ${explainRow.state.replace(/_/g, ' ')}${explainRow.failure_reason ? ` (${explainRow.failure_reason})` : ''}`,
      `• Date: ${new Date(explainRow.created_at).toLocaleString()}`, explainRow.is_demo ? '• This is a demo transaction. No real money moved.' : ''].filter(Boolean).join('\n');
  }
  if (/afford|buy|purchase/.test(s)) {
    const amt = parseAmount(q);
    if (!amt) return 'Tell me the price, for example "Can I afford a ₦80,000 phone?", and I will check it against your balance and upcoming payments.';
    const fc = f.forecast;
    lines.push(`Facts: you have ${money(fc.availableMinor)} available and ${money(fc.upcomingMinor)} of scheduled payments and auto-saves in the next 30 days.`);
    lines.push(`Estimate: about ${money(fc.safeToSpendMinor)} is free to spend after those.`);
    lines.push(amt <= fc.safeToSpendMinor
      ? `A ${money(amt)} purchase fits within that, leaving about ${money(fc.safeToSpendMinor - amt)}.`
      : amt <= fc.availableMinor
        ? `A ${money(amt)} purchase is possible but would use money set aside for upcoming payments. It is tight.`
        : `A ${money(amt)} purchase is more than your available balance.`);
    return lines.join('\n');
  }
  if (/savings? plan|reach|goal|rent goal|save for/.test(s)) {
    if (!goals.length) return 'You have no savings goals yet. Create one in Goals with a target and a deadline, and I will work out how much to save each month.';
    const named = goals.find((g) => s.includes(g.name.toLowerCase())) || null;
    const list = named ? [named] : goals;
    return list.map((g) => `${g.name}: ${money(g.currentMinor)} of ${money(g.targetMinor)} saved, ${money(g.remainingMinor)} to go.` +
      (g.recommendedMonthlyMinor ? ` Estimate: save about ${money(g.recommendedMonthlyMinor)} a month to finish on time.` : ' Add a deadline to get a monthly amount.')).join('\n')
      + `\nFacts: your saved total this month is ${money(f.saved)}. You can set an auto-save rule on any goal.`;
  }
  if (/largest|biggest|top expense|most expensive/.test(s)) {
    if (!f.topExpenses.length) return 'I do not see any spending this month yet.';
    return 'Your largest expenses this month:\n' + f.topExpenses.map((e) => `• ${money(e.amountMinor)}: ${e.description || e.category} (${e.category})`).join('\n');
  }
  if (/why/.test(s) && /(increase|up|more|higher|spend)/.test(s)) {
    const diff = f.spending - f.prev.spending;
    if (f.prev.spending === 0) return 'I do not have last month\'s spending to compare with yet.';
    const movers = f.byCategory.map((c) => ({ ...c, delta: c.spentMinor - c.prevMinor })).sort((a, b) => b.delta - a.delta);
    lines.push(`Facts: you spent ${money(f.spending)} this month versus ${money(f.prev.spending)} last month (${diff >= 0 ? '+' : '−'}${money(Math.abs(diff))}).`);
    const ups = movers.filter((m) => m.delta > 0).slice(0, 3);
    if (ups.length && diff > 0) lines.push('The biggest increases: ' + ups.map((m) => `${m.category} (+${money(m.delta)})`).join(', ') + '.');
    else if (diff <= 0) lines.push('Your spending did not go up this month.');
    return lines.join('\n');
  }
  if (/where|most|categor|breakdown/.test(s) && /(spend|spent|money)/.test(s)) {
    if (!top.length) return 'I do not see any spending this month yet.';
    return `Facts: you spent ${money(f.spending)} this month. Top categories:\n` + top.slice(0, 4).map((c) => `• ${cap(c.category)}: ${money(c.spentMinor)}`).join('\n');
  }
  if (/how much/.test(s) && /(spend|spent)/.test(s)) {
    return `Facts: you have spent ${money(f.spending)} so far this month and received ${money(f.income)}. Last month's spending was ${money(f.prev.spending)}.`;
  }
  if (/subscription|recurring|repeat/.test(s)) {
    if (!f.recurring.length) return 'I have not found repeating payments yet. I need at least three similar payments to spot a pattern.';
    return 'Repeating payments I found (estimates from your history):\n' + f.recurring.map((r) => `• ${r.name}: about ${money(r.amountMinor)} every ${r.every}`).join('\n');
  }
  if (/score|health/.test(s)) {
    if (f.health.score == null) return f.health.note;
    return `Your G-Plan score is ${f.health.score}/100.\n` + f.health.factors.map((x) => `• ${x.name}: ${x.points}/${x.outOf}. ${x.why}`).join('\n') + `\n${f.health.note}`;
  }
  if (/balance|how much do i have|available/.test(s)) {
    return `Facts: you have ${money(f.forecast.availableMinor)} available. Estimate: about ${money(f.forecast.safeToSpendMinor)} is free after upcoming payments.`;
  }
  return 'I can help with: how much you spent, where your money goes, your largest expenses, why spending changed, whether you can afford something, savings plans for your goals, repeating payments, your score, or explaining a transaction (paste its GP- reference).';
}

async function askModel(question, facts) {
  const system = 'You are G-Plan Intelligence, a banking assistant. Answer ONLY using the JSON facts provided. ' +
    'Never invent balances, transactions or numbers. Clearly label figures as "Fact" (recorded) or "Estimate" (calculated). ' +
    'Never promise investment returns or give legal or tax advice. Amounts are in kobo (divide by 100) in NGN. ' +
    'If the facts do not contain the answer, say so. Keep answers under 120 words.';
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST', signal: AbortSignal.timeout(20_000),
    headers: { 'Content-Type': 'application/json', 'x-api-key': config.anthropicKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: config.anthropicModel, max_tokens: 500, system,
      messages: [{ role: 'user', content: `Facts (JSON): ${JSON.stringify(facts)}\n\nQuestion: ${question}` }] }),
  });
  if (!r.ok) throw new Error('model error');
  const d = await r.json();
  return (d.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('\n').trim();
}

export async function answer(userId, question) {
  const q = String(question || '').slice(0, 400);
  // A payment instruction becomes a draft the person must review and authorise on the Send screen. Nothing is sent here.
  const draft = parseAction(q);
  if (draft) {
    return { source: 'rules', proposal: draft,
      answer: `I can set that up: ${money(draft.amountMinor)} to ${draft.recipient}. I will not send it myself. Tap Review to open it on the Send screen, where you check the details and authorise it with your password.` };
  }
  const f = await insights(userId);
  const goals = await goalsFacts(userId);
  let explainRow = null;
  const ref = q.match(/GP-[0-9A-F]{12}/i);
  if (ref) {
    explainRow = (await pool.query(
      `SELECT * FROM transactions WHERE reference=$1 AND initiator_user_id=$2`, [ref[0].toUpperCase(), userId])).rows[0] || null;
    if (!explainRow) return { answer: 'I could not find that reference in your account.', source: 'rules' };
  }
  if (config.anthropicKey) {
    try {
      const facts = { month: f.month, income: f.income, spending: f.spending, saved: f.saved, previousMonth: f.prev,
        byCategory: f.byCategory, topExpenses: f.topExpenses, forecast: f.forecast, recurring: f.recurring,
        health: f.health, goals, transaction: explainRow && { reference: explainRow.reference, type: explainRow.type,
          amount_minor: explainRow.amount_minor, state: explainRow.state, description: explainRow.description } };
      return { answer: await askModel(q, facts), source: 'model' };
    } catch { /* fall back to rules */ }
  }
  return { answer: ruleBased(q, f, goals, explainRow), source: 'rules' };
}
