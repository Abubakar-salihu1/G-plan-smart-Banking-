// Shared read queries over the ledger (always per wallet, derived from postings).
const NET = `SUM(CASE WHEN p.direction='credit' THEN p.amount_minor ELSE -p.amount_minor END)`;

export async function walletRows(db, userId, o = {}) {
  const { currency = 'NGN', from, to, q, type, category, dir, min, max, limit = 50, offset = 0, order = 'DESC' } = o;
  const params = [userId, currency];
  const where = [`a.user_id=$1`, `a.type='customer_wallet'`, `a.currency=$2`, `a.business_id IS NULL`, `a.pocket_id IS NULL`];
  const having = [];
  const add = (v) => { params.push(v); return `$${params.length}`; };
  if (from) where.push(`p.created_at >= ${add(from)}`);
  if (to) where.push(`p.created_at < ${add(to)}`);
  if (q) {
    const n = add(`%${q}%`);
    where.push(`(t.description ILIKE ${n} OR t.reference ILIKE ${n} OR t.category ILIKE ${n} OR t.meta::text ILIKE ${n})`);
  }
  if (type) where.push(`t.type::text = ${add(type)}`);
  if (category) where.push(`t.category = ${add(category)}`);
  if (dir === 'in') having.push(`${NET} > 0`);
  if (dir === 'out') having.push(`${NET} < 0`);
  if (min != null) having.push(`ABS(${NET}) >= ${add(min)}`);
  if (max != null) having.push(`ABS(${NET}) <= ${add(max)}`);
  const sql = `
    SELECT t.id, t.reference, t.type, t.state, t.description, t.category, t.meta, t.is_demo,
           t.currency, t.risk_level, MIN(p.created_at) AS created_at, ${NET} AS net_minor
    FROM transactions t
    JOIN journal_entries je ON je.transaction_id = t.id
    JOIN postings p ON p.entry_id = je.id
    JOIN accounts a ON a.id = p.account_id
    WHERE ${where.join(' AND ')}
    GROUP BY t.id
    ${having.length ? 'HAVING ' + having.join(' AND ') : ''}
    ORDER BY MIN(p.created_at) ${order === 'ASC' ? 'ASC' : 'DESC'}, t.id
    LIMIT ${Math.min(Number(limit) || 50, 5000)} OFFSET ${Math.max(Number(offset) || 0, 0)}`;
  return (await db.query(sql, params)).rows;
}

// Payments still in flight (money reserved by a hold, not yet in the ledger).
export async function pendingRows(db, userId) {
  const r = await db.query(
    `SELECT t.id, t.reference, t.type, t.state, t.description, t.category, t.meta, t.is_demo, t.currency,
            t.risk_level, t.created_at, -(t.amount_minor + t.fee_minor) AS net_minor
     FROM transactions t
     WHERE t.initiator_user_id=$1 AND t.state IN ('processing','processing_unconfirmed','under_review')
     ORDER BY t.created_at DESC LIMIT 20`, [userId]);
  return r.rows;
}

export function monthRange(month) {
  const m = /^\d{4}-\d{2}$/.test(month || '') ? month : new Date().toISOString().slice(0, 7);
  const [y, mo] = m.split('-').map(Number);
  const start = new Date(Date.UTC(y, mo - 1, 1));
  const end = new Date(Date.UTC(y, mo, 1));
  const prev = new Date(Date.UTC(y, mo - 2, 1));
  return { month: m, start: start.toISOString(), end: end.toISOString(), prevStart: prev.toISOString() };
}

export async function statement(db, userId, month, currency = 'NGN') {
  const { start, end, month: m } = monthRange(month);
  const open = (await db.query(
    `SELECT COALESCE(SUM(CASE WHEN p.direction='credit' THEN p.amount_minor ELSE -p.amount_minor END),0) AS bal
     FROM postings p JOIN accounts a ON a.id=p.account_id
     WHERE a.user_id=$1 AND a.type='customer_wallet' AND a.currency=$2 AND a.business_id IS NULL AND a.pocket_id IS NULL AND p.created_at < $3`,
    [userId, currency, start])).rows[0].bal;
  const rows = await walletRows(db, userId, { currency, from: start, to: end, limit: 5000, order: 'ASC' });
  let run = open;
  const lines = rows.map((r) => { run += r.net_minor; return { ...r, balance_minor: run }; });
  return { month: m, currency, openingMinor: open, closingMinor: run, lines };
}
