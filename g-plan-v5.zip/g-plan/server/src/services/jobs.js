// Background jobs: scheduled bills, auto-save rules, resolving unconfirmed payments, integrity checks.
// Safe to run on several servers at once: every action uses an idempotency key built from the item and date.
import { pool } from '../db.js';
import { biller, optionsFor } from './catalog.js';
import { walletOf, pocketWalletOf } from './ledger.js';
import { hashRequest, transfer } from './transfers.js';
import { payExternal, finalize } from './payments.js';
import { mockBiller, mockStatusCheck } from './providers.js';
import { notify } from './notify.js';
import { checkStatus } from './bankProvider.js';
import { purgeExpired } from './kycDocs.js';
import { cleanupSubscriptions } from './push.js';
import { runRoundups, runInterest } from './savings.js';
import { runHabitAlerts } from './habits.js';
import { runBulkFor } from './bulk.js';
import { runStatementEmails } from './statements.js';
import { runMandates } from './mandates.js';
import { fmt } from '../utils/format.js';
import { alert, inc } from './monitor.js';

export function nextDate(dateStr, frequency) {
  const d = new Date(dateStr + 'T00:00:00Z');
  if (frequency === 'weekly') return new Date(d.getTime() + 7 * 86400000).toISOString().slice(0, 10);
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate())).toISOString().slice(0, 10);
}

export function billAmount(b, bundleId, amountMinor) {
  const opts = optionsFor(b);
  if (opts) return opts.find((o) => o.id === bundleId)?.amountMinor ?? null;
  return amountMinor;
}

export async function runScheduledPayment(s) {
  const b = biller(s.biller_code);
  const wallet = await walletOf(pool, s.user_id);
  const date = String(s.next_run_on).slice(0, 10);
  let status = 'ok';
  try {
    const amount = billAmount(b, s.bundle_id, s.amount_minor) ?? s.amount_minor;
    const receipt = await payExternal({
      userId: s.user_id, walletId: wallet, amountMinor: amount, type: 'bill_payment',
      description: `${b.name}${s.payee_name ? ' · ' + s.payee_name : ''}`, category: b.category,
      meta: { biller: b.code, payeeRef: s.payee_ref, payee: b.name, category: b.category, scheduled: true },
      idemKey: `sched:${s.id}:${date}`, requestHash: hashRequest({ sched: s.id, date }), provider: mockBiller,
    });
    status = receipt.state;
  } catch (e) {
    status = e.code || 'error';
    await notify(pool, s.user_id, 'Scheduled payment skipped', `${b.name}: ${e.message}`, 'failed');
  }
  const done = s.frequency === 'once';
  await pool.query(
    `UPDATE scheduled_payments SET last_status=$2, last_run_at=now(),
       next_run_on = $3, status = $4 WHERE id=$1`,
    [s.id, status, done ? s.next_run_on : nextDate(date, s.frequency), done ? 'completed' : s.status]);
  return status;
}

// Weekly pocket money for child pockets, paid from the parent's wallet. A frozen pocket or a short wallet skips that week
// (the parent is told) and never builds up a backlog.
export async function runAllowances() {
  const due = (await pool.query(
    `SELECT id, name, owner_id, allowance_minor, allowance_next_on, frozen FROM pockets
     WHERE kind='child' AND allowance_minor > 0 AND allowance_next_on <= CURRENT_DATE ORDER BY allowance_next_on LIMIT 25`)).rows;
  let paid = 0;
  for (const p of due) {
    const date = String(p.allowance_next_on).slice(0, 10);
    if (!p.frozen) {
      try {
        await transfer({
          userId: p.owner_id, fromAccountId: await walletOf(pool, p.owner_id), toAccountId: await pocketWalletOf(pool, p.id), amountMinor: Number(p.allowance_minor),
          type: 'internal_transfer', description: `Allowance for ${p.name}`, category: 'transfers', meta: { pocketId: p.id, allowance: true },
          idemKey: `allowance:${p.id}:${date}`, requestHash: hashRequest({ allowance: p.id, date }),
        });
        paid++;
      } catch (e) {
        await notify(pool, p.owner_id, 'Allowance skipped', `${p.name}: ${e.message}`, 'failed');
      }
    }
    await pool.query('UPDATE pockets SET allowance_next_on=$2 WHERE id=$1', [p.id, nextDate(date, 'weekly')]);
  }
  return paid;
}

export async function runSavingsRule(r) {
  const goal = (await pool.query('SELECT account_id, name FROM goals WHERE id=$1', [r.goal_id])).rows[0];
  const wallet = await walletOf(pool, r.user_id);
  const date = String(r.next_run_on).slice(0, 10);
  let status = 'ok';
  try {
    await transfer({
      userId: r.user_id, fromAccountId: wallet, toAccountId: goal.account_id, amountMinor: r.amount_minor,
      type: 'goal_contribution', description: `Auto-save to ${goal.name}`, category: 'savings',
      idemKey: `rule:${r.id}:${date}`, requestHash: hashRequest({ rule: r.id, date }),
    });
    await notify(pool, r.user_id, 'Auto-save done', `${fmt(r.amount_minor)} saved to ${goal.name}.`, 'info');
  } catch (e) {
    status = e.code || 'error';
    await notify(pool, r.user_id, 'Auto-save skipped', `${goal.name}: ${e.message}`, 'failed');
  }
  await pool.query('UPDATE savings_rules SET last_status=$2, next_run_on=$3 WHERE id=$1',
    [r.id, status, nextDate(date, r.frequency)]);
  return status;
}

let running = false;
let lastHousekeeping = 0;
let lastRunAt = Date.now();   // when a run of the job loop last finished (the watchdog compares this with the clock)
// Minutes since the job loop last finished, or null when jobs are switched off on purpose.
export const jobsAgeMinutes = () => (process.env.DISABLE_JOBS === 'true' ? null : (Date.now() - lastRunAt) / 60_000);
export async function runDueJobs() {
  if (running) return { skipped: true };
  running = true;
  const out = { scheduled: 0, rules: 0, resolved: 0 };
  try {
    const due = (await pool.query(
      `SELECT * FROM scheduled_payments WHERE status='active' AND next_run_on <= CURRENT_DATE ORDER BY next_run_on LIMIT 25`)).rows;
    for (const s of due) { await runScheduledPayment(s); out.scheduled++; }

    const rules = (await pool.query(
      `SELECT * FROM savings_rules WHERE status='active' AND next_run_on <= CURRENT_DATE ORDER BY next_run_on LIMIT 25`)).rows;
    for (const r of rules) { await runSavingsRule(r); out.rules++; }

    out.roundups = await runRoundups();
    out.allowances = await runAllowances();
    out.habits = await runHabitAlerts();
    out.bulk = await runBulkFor(40_000);
    out.mandates = await runMandates();

    // Housekeeping at most once an hour: expired KYC photos and push devices of signed-out sessions.
    if (Date.now() - lastHousekeeping > 3600_000) {
      lastHousekeeping = Date.now();
      out.purged = await purgeExpired();
      await cleanupSubscriptions();
      out.interest = await runInterest();
      out.statementEmails = await runStatementEmails();
    }

    const stuck = (await pool.query(
      `SELECT id, reference, type FROM transactions WHERE state='processing_unconfirmed' AND updated_at < now() - interval '1 minute' LIMIT 25`)).rows;
    for (const t of stuck) {
      // Only live bank transfers are asked about at the provider. A reply of "still unknown" leaves the payment
      // reserved and unconfirmed (finalize keeps it that way), so nothing is guessed.
      const outcome = t.type === 'external_transfer' ? await checkStatus(t, mockStatusCheck) : await mockStatusCheck();
      await finalize(t.id, outcome); out.resolved++;
    }
  } catch (e) {
    console.error('job error', e.message);
    inc('gplan_job_errors_total');
  } finally { running = false; }
  lastRunAt = Date.now();
  return out;
}

// Ask the provider again about one payment that has no answer yet (used by the admin console button).
export async function recheckPayment(txnId) {
  const t = (await pool.query(`SELECT id, reference, type FROM transactions WHERE id=$1 AND state IN ('processing','processing_unconfirmed')`, [txnId])).rows[0];
  if (!t) throw new Error('That payment is not waiting for an answer.');
  const outcome = t.type === 'external_transfer' ? await checkStatus(t, mockStatusCheck) : await mockStatusCheck();
  await finalize(t.id, outcome);
  return outcome;
}

// Integrity: balance cache vs ledger, and both hash chains. Alerts if anything is off.
export async function integrityCheck() {
  const mism = (await pool.query('SELECT COUNT(*) AS n FROM balance_cache_mismatches')).rows[0].n;
  const chains = (await pool.query('SELECT verify_ledger_chain() AS ledger, verify_audit_chain() AS audit')).rows[0];
  const ok = mism === 0 && chains.ledger == null && chains.audit == null;
  if (!ok) await alert(`Integrity check FAILED: cache mismatches=${mism}, ledger chain break at ${chains.ledger}, audit chain break at ${chains.audit}`);
  return { ok, balanceMismatches: mism, ledgerBrokenAt: chains.ledger, auditBrokenAt: chains.audit };
}
