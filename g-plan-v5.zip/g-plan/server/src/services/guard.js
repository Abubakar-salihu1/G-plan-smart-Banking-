// Authorisation for outgoing payments: password re-entry + risk-based extra verification.
import { pool } from '../db.js';
import { AppError } from '../errors.js';
import { assertPassword } from './passwords.js';
import { assessRisk, enforceRisk } from './risk.js';
import { walletOf, availableBalance } from './ledger.js';

async function riskFor(req, amountMinor, currency, walletId = null) {
  const w = walletId || await walletOf(pool, req.user.id, currency);
  const available = w ? await availableBalance(pool, w) : null;
  return assessRisk(req.user.id, { amountMinor, currency, deviceId: req.session.deviceId, availableMinor: available, mfaEnabled: req.user.mfaEnabled });
}

// Used on the Review step: tells the app whether a verification code will be needed. Moves no money.
export async function previewRisk(req, amountMinor, currency = 'NGN') {
  const risk = await riskFor(req, amountMinor, currency);
  return {
    needsVerification: risk.needsVerification,
    method: req.user.mfaMethod || null,
    blocked: risk.needsVerification && !req.user.mfaEnabled,
    message: risk.needsVerification && !req.user.mfaEnabled
      ? 'For your safety, turn on two-step verification in Security before sending this amount.' : null,
  };
}

// walletId: pass the business wallet when paying from it, so the balance-based rules look at the right money.
export async function authorisePayment(req, { password, otp, amountMinor, currency = 'NGN', walletId = null }) {
  if (!Number.isSafeInteger(amountMinor) || amountMinor <= 0) throw new AppError(422, 'INVALID_AMOUNT', 'Enter a valid amount.');
  await assertPassword(req.user.id, password);
  const risk = await riskFor(req, amountMinor, currency, walletId);
  const level = await enforceRisk(req, risk, otp);
  return { risk, level };
}
