// Demo catalogue. Names and prices are illustrative and not tied to any real provider integration.
export const BANKS = [
  { code: '057', name: 'Zenith Bank' }, { code: '058', name: 'GTBank' }, { code: '044', name: 'Access Bank' },
  { code: '033', name: 'UBA' }, { code: '011', name: 'First Bank' }, { code: '070', name: 'Fidelity Bank' },
  { code: '232', name: 'Sterling Bank' }, { code: '035', name: 'Wema Bank' },
];

export const DATA_BUNDLES = [
  { id: '500mb', label: '500MB · 7 days', amountMinor: 50000 },
  { id: '1gb', label: '1GB · 30 days', amountMinor: 100000 },
  { id: '3gb', label: '3GB · 30 days', amountMinor: 250000 },
  { id: '10gb', label: '10GB · 30 days', amountMinor: 500000 },
];
export const CABLE_PACKAGES = [
  { id: 'basic', label: 'Basic', amountMinor: 250000 },
  { id: 'standard', label: 'Standard', amountMinor: 600000 },
  { id: 'premium', label: 'Premium', amountMinor: 1500000 },
];

const net = (code, name) => [
  { code: `${code}-airtime`, name: `${name} Airtime`, category: 'airtime', refLabel: 'Phone number', refRegex: '^0\\d{10}$' },
  { code: `${code}-data`, name: `${name} Data`, category: 'data', refLabel: 'Phone number', refRegex: '^0\\d{10}$', options: 'data' },
];
export const BILLERS = [
  ...net('mtn', 'MTN'), ...net('airtel', 'Airtel'), ...net('glo', 'Glo'), ...net('9mobile', '9mobile'),
  { code: 'ikeja-electric', name: 'Ikeja Electric (prepaid)', category: 'electricity', refLabel: 'Meter number', refRegex: '^\\d{10,13}$' },
  { code: 'eko-disco', name: 'Eko Electricity (prepaid)', category: 'electricity', refLabel: 'Meter number', refRegex: '^\\d{10,13}$' },
  { code: 'abuja-disco', name: 'Abuja Electricity (prepaid)', category: 'electricity', refLabel: 'Meter number', refRegex: '^\\d{10,13}$' },
  { code: 'dstv', name: 'DStv', category: 'cable', refLabel: 'Smartcard number', refRegex: '^\\d{10}$', options: 'cable' },
  { code: 'gotv', name: 'GOtv', category: 'cable', refLabel: 'Smartcard number', refRegex: '^\\d{10}$', options: 'cable' },
  { code: 'startimes', name: 'StarTimes', category: 'cable', refLabel: 'Smartcard number', refRegex: '^\\d{10,11}$', options: 'cable' },
  { code: 'rent', name: 'Rent (landlord or agent)', category: 'rent', refLabel: 'Payee name', refRegex: '^.{2,60}$' },
];

export const biller = (code) => BILLERS.find((b) => b.code === code);
export const optionsFor = (b) => (b.options === 'data' ? DATA_BUNDLES : b.options === 'cable' ? CABLE_PACKAGES : null);

// Auto-categorisation: bill category wins, then keywords in the description.
const KEYWORDS = {
  food: ['food', 'lunch', 'dinner', 'breakfast', 'restaurant', 'suya', 'rice', 'chicken', 'pizza', 'cafe'],
  transport: ['uber', 'bolt', 'fuel', 'transport', 'bus', 'taxi', 'petrol', 'flight'],
  shopping: ['shop', 'market', 'clothes', 'jumia', 'mall', 'shoprite', 'store', 'fashion'],
  entertainment: ['netflix', 'stream', 'movie', 'cinema', 'game', 'music', 'subscription'],
  health: ['pharmacy', 'hospital', 'clinic', 'drug', 'health'],
  education: ['school', 'fees', 'tuition', 'course', 'book'],
  rent: ['rent', 'landlord'],
};
export function categorise({ description = '', billCategory = null, fallback = 'transfers' }) {
  if (billCategory) return billCategory;
  const d = description.toLowerCase();
  for (const [cat, words] of Object.entries(KEYWORDS)) if (words.some((w) => d.includes(w))) return cat;
  return fallback;
}
