// Low-level ledger helpers. Everything here runs inside a caller-provided DB transaction.
import crypto from 'node:crypto';

export async function systemAccount(client, type, currency) {
  await client.query(
    `INSERT INTO accounts(type, currency, name) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING`,
    [type, currency, `${type} ${currency}`]
  );
  const r = await client.query(
    `SELECT id FROM accounts WHERE user_id IS NULL AND type=$1 AND currency=$2`,
    [type, currency]
  );
  return r.rows[0].id;
}

export async function createAccount(client, { userId, type, currency, name }) {
  const r = await client.query(
    `INSERT INTO accounts(user_id, type, currency, name) VALUES ($1,$2,$3,$4) RETURNING id`,
    [userId, type, currency, name]
  );
  return r.rows[0].id;
}

export async function walletOf(db, userId, currency = 'NGN') {
  const r = await db.query(
    `SELECT id FROM accounts WHERE user_id=$1 AND type='customer_wallet' AND currency=$2 AND business_id IS NULL AND pocket_id IS NULL LIMIT 1`,
    [userId, currency]);
  return r.rows[0]?.id || null;
}

// postings: [{ accountId, direction: 'debit'|'credit', amountMinor, currency }]
// The database rejects the commit if debits != credits.
export async function postEntry(client, { transactionId, description, postings, reversesEntryId = null, createdAt = null }) {
  const e = createdAt
    ? await client.query(
      `INSERT INTO journal_entries(transaction_id, description, reverses_entry_id, created_at)
       VALUES ($1,$2,$3,$4) RETURNING id`, [transactionId, description ?? null, reversesEntryId, createdAt])
    : await client.query(
      `INSERT INTO journal_entries(transaction_id, description, reverses_entry_id)
       VALUES ($1,$2,$3) RETURNING id`, [transactionId, description ?? null, reversesEntryId]);
  const entryId = e.rows[0].id;
  for (const p of postings) {
    if (createdAt) {
      await client.query(
        `INSERT INTO postings(entry_id, account_id, direction, amount_minor, currency, created_at)
         VALUES ($1,$2,$3,$4,$5,$6)`,
        [entryId, p.accountId, p.direction, p.amountMinor, p.currency, createdAt]);
    } else {
      await client.query(
        `INSERT INTO postings(entry_id, account_id, direction, amount_minor, currency)
         VALUES ($1,$2,$3,$4,$5)`,
        [entryId, p.accountId, p.direction, p.amountMinor, p.currency]);
    }
  }
  return entryId;
}

export async function availableBalance(client, accountId) {
  const r = await client.query(
    `SELECT
       COALESCE((SELECT SUM(CASE WHEN direction='credit' THEN amount_minor ELSE -amount_minor END)
                 FROM postings WHERE account_id=$1), 0)
       - COALESCE((SELECT SUM(amount_minor) FROM holds
                   WHERE account_id=$1 AND status='active'), 0) AS available`,
    [accountId]
  );
  return r.rows[0].available;
}

export async function ledgerBalance(client, accountId) {
  const r = await client.query(
    `SELECT COALESCE(SUM(CASE WHEN direction='credit' THEN amount_minor ELSE -amount_minor END),0) AS bal
     FROM postings WHERE account_id=$1`, [accountId]);
  return r.rows[0].bal;
}

// The shared wallet of a business. Personal code never reaches it: walletOf() skips it, and transfer() and
// payExternal() refuse to spend from it unless the caller passes the matching businessId (the business
// routes only do that after checking the person's role).
export async function businessWalletOf(db, businessId, currency = 'NGN') {
  const r = await db.query(`SELECT id FROM accounts WHERE business_id=$1 AND currency=$2 LIMIT 1`, [businessId, currency]);
  return r.rows[0]?.id || null;
}

// The wallet of a shared pocket (joint or child). Same rule as the business wallet: personal code never reaches it.
export async function pocketWalletOf(db, pocketId, currency = 'NGN') {
  const r = await db.query(`SELECT id FROM accounts WHERE pocket_id=$1 AND currency=$2 LIMIT 1`, [pocketId, currency]);
  return r.rows[0]?.id || null;
}

export function newReference() {
  return 'GP-' + crypto.randomBytes(6).toString('hex').toUpperCase();
}

// Walk the state machine. The database rejects any illegal jump.
export async function walkStates(c, txnId, states) {
  for (const s of states) await c.query('UPDATE transactions SET state=$1 WHERE id=$2', [s, txnId]);
}
