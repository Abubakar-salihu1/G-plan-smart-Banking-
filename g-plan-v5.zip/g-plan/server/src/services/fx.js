// Multi-currency wallets and conversion using INDICATIVE demo rates. Never a guaranteed settlement rate.
import { withTx } from '../db.js';
import { config } from '../config.js';
import { AppError } from '../errors.js';
import { postEntry, availableBalance, newReference, systemAccount, walkStates, walletOf, createAccount } from './ledger.js';
import { assertAmount, claimIdempotency, hashRequest } from './transfers.js';

export const currencies = () => Object.keys(config.fxRatesToNgn);

// Fee in minor units, rounded up, using whole-number basis points (no floating-point percentages).
export const feeOf = (amountMinor, percent) => Math.ceil((amountMinor * Math.round(percent * 100)) / 10000);

export function quote(from, to, amountMinor) {
  const rf = config.fxRatesToNgn[from], rt = config.fxRatesToNgn[to];
  if (!rf || !rt || from === to) throw new AppError(422, 'INVALID_PAIR', 'Choose two different supported currencies.');
  assertAmount(amountMinor);
  const feeMinor = feeOf(amountMinor, config.fees.fxPercent);
  const net = amountMinor - feeMinor;
  if (net <= 0) throw new AppError(422, 'INVALID_AMOUNT', 'Amount is too small to convert.');
  const receiveMinor = Math.floor((net * rf) / rt);
  if (receiveMinor <= 0) throw new AppError(422, 'INVALID_AMOUNT', 'Amount is too small to convert.');
  return { from, to, amountMinor, feeMinor, receiveMinor, rate: rf / rt, indicative: true };
}

export async function ensureWallet(userId, currency) {
  if (!config.fxRatesToNgn[currency]) throw new AppError(422, 'UNSUPPORTED_CURRENCY', 'That currency is not supported yet.');
  return withTx(async (c) => {
    const ex = await walletOf(c, userId, currency);
    if (ex) return ex;
    return createAccount(c, { userId, type: 'customer_wallet', currency, name: `${currency} wallet` });
  });
}

export async function convert({ userId, from, to, amountMinor, idemKey }) {
  const q = quote(from, to, amountMinor);
  if (!idemKey) throw new AppError(400, 'IDEMPOTENCY_KEY_REQUIRED', 'Missing Idempotency-Key header.');
  const requestHash = hashRequest({ from, to, amountMinor, kind: 'fx' });
  return withTx(async (c) => {
    const replay = await claimIdempotency(c, userId, idemKey, requestHash);
    if (replay) return replay;
    const wFrom = await walletOf(c, userId, from);
    const wTo = await walletOf(c, userId, to);
    if (!wFrom || !wTo) throw new AppError(422, 'WALLET_MISSING', 'Create both currency wallets first.');
    const posFrom = await systemAccount(c, 'fx_position', from);
    const posTo = await systemAccount(c, 'fx_position', to);
    const feeAcct = await systemAccount(c, 'fee', from);
    await c.query('SELECT id FROM accounts WHERE id = ANY($1::uuid[]) ORDER BY id FOR UPDATE',
      [[wFrom, wTo, posFrom, posTo, feeAcct]]);
    const user = (await c.query('SELECT status FROM users WHERE id=$1', [userId])).rows[0];
    if (!user || user.status !== 'active') throw new AppError(403, 'USER_RESTRICTED', 'Your account is restricted.');
    if ((await availableBalance(c, wFrom)) < amountMinor) {
      throw new AppError(422, 'INSUFFICIENT_FUNDS', 'Your available balance is too low for this conversion.');
    }
    const txn = (await c.query(
      `INSERT INTO transactions(reference, type, initiator_user_id, amount_minor, fee_minor, currency,
                                description, provider, is_demo, category, meta)
       VALUES ($1,'fx_conversion',$2,$3,$4,$5,$6,'internal_ledger',TRUE,'exchange',$7) RETURNING id, reference`,
      [newReference(), userId, amountMinor, q.feeMinor, from, `${from} to ${to} conversion`,
        JSON.stringify({ from, to, rate: q.rate, receiveMinor: q.receiveMinor, indicative: true })])).rows[0];
    await walkStates(c, txn.id, ['pending_authorisation', 'authorised', 'processing']);
    await postEntry(c, { transactionId: txn.id, description: `Convert ${from}`, postings: [
      { accountId: wFrom, direction: 'debit', amountMinor, currency: from },
      { accountId: posFrom, direction: 'credit', amountMinor: amountMinor - q.feeMinor, currency: from },
      { accountId: feeAcct, direction: 'credit', amountMinor: q.feeMinor, currency: from },
    ] });
    await postEntry(c, { transactionId: txn.id, description: `Convert to ${to}`, postings: [
      { accountId: posTo, direction: 'debit', amountMinor: q.receiveMinor, currency: to },
      { accountId: wTo, direction: 'credit', amountMinor: q.receiveMinor, currency: to },
    ] });
    await walkStates(c, txn.id, ['completed']);
    const receipt = { transactionId: txn.id, reference: txn.reference, type: 'fx_conversion', state: 'completed',
      amountMinor, feeMinor: q.feeMinor, currency: from, isDemo: true, failureReason: null,
      extra: { to, receiveMinor: q.receiveMinor, rate: q.rate, indicative: true }, replayed: false };
    await c.query('UPDATE idempotency_keys SET transaction_id=$1, response_body=$2 WHERE user_id=$3 AND idem_key=$4',
      [txn.id, JSON.stringify(receipt), userId, idemKey]);
    return receipt;
  });
}
