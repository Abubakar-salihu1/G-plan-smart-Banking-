// Habit alerts, run from the background job. Each completed payment is looked at once (habit_alert_log).
// A person can switch them off. They only ever add an alert in the app; they never block or change a payment.
import { pool } from '../db.js';
import { notify } from './notify.js';
import { fmt } from '../utils/format.js';
import { unusualCharge, priceRise, newRepeating, repeatKey } from '../utils/habitRules.js';

const TYPES = ['bill_payment', 'external_transfer', 'card_payment', 'international_transfer'];

export async function runHabitAlerts(limit = 50) {
  // Only fresh payments. Anything older is skipped so switching this on never replays someone's whole history.
  const rows = (await pool.query(
    `SELECT t.id, t.initiator_user_id AS user_id, t.amount_minor, t.type, t.category, t.description, t.created_at
     FROM transactions t LEFT JOIN alert_prefs p ON p.user_id=t.initiator_user_id
     WHERE t.state='completed' AND t.type = ANY($1) AND t.created_at > now() - interval '2 days' AND COALESCE(p.habit_alerts, TRUE)
       AND NOT EXISTS (SELECT 1 FROM habit_alert_log l WHERE l.txn_id=t.id)
     ORDER BY t.created_at LIMIT $2`, [TYPES, limit])).rows;
  let sent = 0;
  for (const t of rows) {
    const claim = await pool.query('INSERT INTO habit_alert_log(txn_id) VALUES ($1) ON CONFLICT DO NOTHING RETURNING txn_id', [t.id]);
    if (!claim.rows[0]) continue;
    const amount = Number(t.amount_minor);
    const past = (await pool.query(
      `SELECT amount_minor, category, description, created_at FROM transactions
       WHERE initiator_user_id=$1 AND state='completed' AND type = ANY($2) AND id<>$3 AND created_at < $4 AND created_at > $4 - interval '180 days'
       ORDER BY created_at DESC LIMIT 60`, [t.user_id, TYPES, t.id, t.created_at])).rows;

    const key = repeatKey(t.description);
    const same = key ? past.filter((x) => repeatKey(x.description) === key).slice(0, 6).map((x) => ({ amountMinor: Number(x.amount_minor), date: x.created_at })) : [];
    const current = { amountMinor: amount, date: t.created_at };

    let title, body;
    const rise = priceRise({ current, history: same });
    if (rise) {
      title = 'A regular payment went up';
      body = `${t.description}: ${fmt(rise.fromMinor)} before, ${fmt(rise.toMinor)} now (${rise.pct}% more). Check that the new price is right.`;
    } else if (key && newRepeating({ current, history: same })) {
      title = 'New repeating payment spotted';
      body = `${t.description} (${fmt(amount)}) has now come out three times at a steady rhythm. If you do not use it any more, cancel it.`;
    } else {
      const cat = t.category || 'other';
      const unusual = unusualCharge({ amountMinor: amount, history: past.filter((x) => (x.category || 'other') === cat).map((x) => Number(x.amount_minor)) });
      if (unusual) {
        title = 'Unusual payment';
        body = `${fmt(amount)} for ${t.description || cat} is much more than your usual ${cat} payments (about ${fmt(unusual.typicalMinor)}). If this was not you, freeze your cards and change your password.`;
      }
    }
    if (title) {
      await notify(pool, t.user_id, title, body, 'security');
      await pool.query('UPDATE habit_alert_log SET alerted=$2 WHERE txn_id=$1', [t.id, title]);
      sent++;
    }
  }
  return sent;
}
