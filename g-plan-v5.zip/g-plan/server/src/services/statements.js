// Yearly summary and the optional monthly "statement ready" email.
import { pool } from '../db.js';
import { config } from '../config.js';
import { walletRows } from './queries.js';
import { sendEmail } from './mailer.js';
import { summariseYear, TAX_NOTE } from '../utils/taxSummary.js';

export async function taxSummary(db, userId, year, currency = 'NGN') {
  const y = Number(year);
  const rows = await walletRows(db, userId, { currency, from: new Date(Date.UTC(y, 0, 1)).toISOString(), to: new Date(Date.UTC(y + 1, 0, 1)).toISOString(), limit: 5000, order: 'ASC' });
  return { year: y, currency, truncated: rows.length >= 5000, ...summariseYear(rows), note: TAX_NOTE };
}

// On or after the 1st of each month: tell opted-in people last month's statement is ready. The email holds NO amounts
// or transactions (email is not private); it only points them to the app. Each person is emailed once per month.
export async function runStatementEmails(limit = 50, now = new Date()) {
  const prev = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 1, 1));
  const month = prev.toISOString().slice(0, 7);
  const rows = (await pool.query(
    `SELECT u.id, u.email, u.full_name FROM users u JOIN alert_prefs p ON p.user_id=u.id AND p.statement_email
     WHERE u.status='active' AND u.email_verified_at IS NOT NULL AND u.created_at < $2
       AND NOT EXISTS (SELECT 1 FROM statement_mail_log l WHERE l.user_id=u.id AND l.month=$1) LIMIT $3`,
    [month, new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1)).toISOString(), limit])).rows;
  let sent = 0;
  for (const u of rows) {
    // Claim first so two servers never both send.
    const claim = await pool.query('INSERT INTO statement_mail_log(user_id, month) VALUES ($1,$2) ON CONFLICT DO NOTHING RETURNING user_id', [u.id, month]);
    if (!claim.rows[0]) continue;
    const label = prev.toLocaleString('en-NG', { month: 'long', year: 'numeric', timeZone: 'UTC' });
    try {
      await sendEmail(u.email, `Your G-Plan statement for ${label} is ready`,
        `Hello ${String(u.full_name).split(' ')[0]},\n\nYour statement for ${label} is ready. Sign in to G-Plan and open Activity and statements to view or download it:\n${config.clientOrigin}\n\nWe never put balances or transactions in emails. If you did not ask for these emails, sign in and turn them off under Alerts.\n`);
      sent++;
    } catch (e) {
      await pool.query('DELETE FROM statement_mail_log WHERE user_id=$1 AND month=$2', [u.id, month]);   // try again next hour
      console.error('statement email', e.message);
    }
  }
  return sent;
}
