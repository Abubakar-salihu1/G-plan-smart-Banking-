// Web Push (VAPID). Alerts still appear in the app and refresh every 20 seconds; push is an extra that wakes the
// phone. Off unless VAPID_PUBLIC_KEY is set.
// Privacy: a push shows only the alert's title ("Money received"), never amounts or names, because lock screens
// are visible to other people. Details are in the app.
// Safety: notifications are sent by a poller that reads COMMITTED rows, so a payment that rolls back never pushes.
// A push goes only to devices whose sign-in session is still active, so signing out or revoking a device stops it.
import { pool } from '../db.js';
import { config } from '../config.js';
import { endpointAllowed as allowed } from '../utils/pushEndpoint.js';

export { validKey } from '../utils/pushEndpoint.js';
export const endpointAllowed = (raw) => allowed(raw, config.push.extraHosts);

let lib;
async function webpush() {
  if (lib !== undefined) return lib;
  try {
    const m = (await import('web-push')).default;
    m.setVapidDetails(config.push.subject, config.push.publicKey, config.push.privateKey);
    lib = m;
  } catch (e) { console.error('web-push unavailable:', e.message); lib = null; }
  return lib;
}

export const payloadFor = (n) => JSON.stringify({ title: String(n.title).slice(0, 60), body: 'Open G-Plan to see the details.', tag: `gp-${n.kind || 'info'}`, url: '/' });

export async function deliverPending(limit = 50) {
  // Never push old news, and never let unpushed rows pile up when push is off.
  await pool.query(`UPDATE notifications SET pushed_at=now() WHERE pushed_at IS NULL AND (created_at <= now() - interval '15 minutes' OR $1::boolean = FALSE)`, [config.push.enabled]);
  if (!config.push.enabled) return 0;
  const wp = await webpush();
  if (!wp) return 0;
  const rows = (await pool.query(
    `UPDATE notifications SET pushed_at=now() WHERE id IN (
       SELECT id FROM notifications WHERE pushed_at IS NULL ORDER BY id LIMIT $1 FOR UPDATE SKIP LOCKED)
     RETURNING id, user_id, title, kind`, [limit])).rows;
  let sent = 0;
  for (const n of rows) {
    const subs = (await pool.query(
      `SELECT ps.id, ps.endpoint, ps.p256dh, ps.auth FROM push_subscriptions ps
       JOIN sessions s ON s.id=ps.session_id AND s.revoked_at IS NULL AND (s.refresh_expires_at IS NULL OR s.refresh_expires_at > now())
       WHERE ps.user_id=$1`, [n.user_id])).rows;
    for (const s of subs) {
      try {
        await wp.sendNotification({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, payloadFor(n), { TTL: 3600, urgency: 'normal', timeout: 8000 });
        sent++;
        pool.query('UPDATE push_subscriptions SET last_ok_at=now() WHERE id=$1', [s.id]).catch(() => {});
      } catch (e) {
        if (e.statusCode === 404 || e.statusCode === 410) await pool.query('DELETE FROM push_subscriptions WHERE id=$1', [s.id]);
        else console.error('push failed', e.statusCode || e.message);
      }
    }
  }
  return sent;
}

export async function cleanupSubscriptions() {
  const r = await pool.query(`DELETE FROM push_subscriptions ps USING sessions s WHERE s.id=ps.session_id AND s.revoked_at IS NOT NULL`);
  return r.rowCount;
}
