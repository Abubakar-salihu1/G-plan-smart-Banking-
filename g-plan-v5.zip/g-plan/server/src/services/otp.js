// One-time codes by SMS or email, with pluggable delivery.
// SMS_PROVIDER: mock | termii | twilio     EMAIL_PROVIDER: mock | resend
// In mock mode nothing is sent. In demo mode the API returns the code so judges can try the flow.
// Real providers need your own account and keys, and have NOT been tested in this prototype.
import crypto from 'node:crypto';
import { pool } from '../db.js';
import { config } from '../config.js';
import { AppError } from '../errors.js';

const PEPPER = () => config.dataKey;
const hash = (code, userId) => crypto.createHmac('sha256', PEPPER()).update(`${userId}:${code}`).digest('hex');

async function deliver(channel, to, text) {
  const sms = process.env.SMS_PROVIDER || 'mock';
  const email = process.env.EMAIL_PROVIDER || 'mock';
  if (channel === 'sms' && sms === 'termii') {
    const r = await fetch('https://api.ng.termii.com/api/sms/send', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: AbortSignal.timeout(10_000),
      body: JSON.stringify({ to, from: process.env.TERMII_SENDER_ID, sms: text, type: 'plain',
        channel: 'generic', api_key: process.env.TERMII_API_KEY }),
    });
    if (!r.ok) throw new Error('SMS provider error');
    return { mock: false };
  }
  if (channel === 'sms' && sms === 'twilio') {
    const auth = Buffer.from(`${process.env.TWILIO_ACCOUNT_SID}:${process.env.TWILIO_AUTH_TOKEN}`).toString('base64');
    const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${process.env.TWILIO_ACCOUNT_SID}/Messages.json`, {
      method: 'POST', signal: AbortSignal.timeout(10_000),
      headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ To: `+${to}`, From: process.env.TWILIO_FROM, Body: text }),
    });
    if (!r.ok) throw new Error('SMS provider error');
    return { mock: false };
  }
  if (channel === 'email' && email === 'resend') {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST', signal: AbortSignal.timeout(10_000),
      headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: process.env.EMAIL_FROM, to: [to], subject: 'Your G-Plan code', text }),
    });
    if (!r.ok) throw new Error('Email provider error');
    return { mock: false };
  }
  console.log(`[MOCK ${channel.toUpperCase()}] to ${channel === 'sms' ? to.slice(0, -4).replace(/\d/g, '*') + to.slice(-4) : to}: ${text}`);
  return { mock: true };
}

export async function sendOtp(user, purpose, channel) {
  const to = channel === 'sms' ? user.phone : user.email;
  if (!to) throw new AppError(422, 'NO_DESTINATION', channel === 'sms' ? 'Add a phone number to your profile first.' : 'No email on file.');
  // Basic send throttle: max 5 codes per 10 minutes per user.
  const recent = await pool.query(
    `SELECT COUNT(*) AS n FROM otp_codes WHERE user_id=$1 AND created_at > now() - interval '10 minutes'`, [user.id]);
  if (recent.rows[0].n >= 5) throw new AppError(429, 'OTP_THROTTLED', 'Too many codes requested. Wait a few minutes.');
  const code = String(crypto.randomInt(0, 1_000_000)).padStart(6, '0');
  await pool.query(
    `INSERT INTO otp_codes(user_id, purpose, channel, code_hash, expires_at)
     VALUES ($1,$2,$3,$4, now() + interval '5 minutes')`, [user.id, purpose, channel, hash(code, user.id)]);
  let mock = true;
  try { ({ mock } = await deliver(channel, to, `Your G-Plan code is ${code}. It expires in 5 minutes. Never share it.`)); }
  catch { throw new AppError(502, 'OTP_DELIVERY_FAILED', 'We could not send the code. Try again shortly.'); }
  return { sent: true, channel, demoCode: mock && config.demoFunding ? code : undefined };
}

export async function verifyOtp(userId, purpose, code) {
  const c = String(code || '').replace(/\s/g, '');
  if (!/^\d{6}$/.test(c)) return false;
  const r = (await pool.query(
    `SELECT id, code_hash, attempts FROM otp_codes
     WHERE user_id=$1 AND purpose=$2 AND consumed_at IS NULL AND expires_at > now()
     ORDER BY created_at DESC LIMIT 1`, [userId, purpose])).rows[0];
  if (!r || r.attempts >= 5) return false;
  await pool.query('UPDATE otp_codes SET attempts = attempts + 1 WHERE id=$1', [r.id]);
  const a = Buffer.from(r.code_hash), b = Buffer.from(hash(c, userId));
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return false;
  await pool.query('UPDATE otp_codes SET consumed_at=now() WHERE id=$1', [r.id]);
  return true;
}
