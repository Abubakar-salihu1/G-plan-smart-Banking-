// Identity verification adapter. No real KYC provider is connected in this prototype.
// KYC_PROVIDER=mock (default) only checks the format of the ID number and approves tier 1 automatically.
// To integrate a real provider (BVN/NIN/liveness/address), implement verifyIdentity() against its API.
// IMPORTANT: full ID numbers are used for the check and then discarded. Only the last 4 digits are stored.
import { AppError } from '../errors.js';

export async function verifyIdentity({ tier, idType, idNumber }) {
  const provider = process.env.KYC_PROVIDER || 'mock';
  if (provider !== 'mock') throw new AppError(501, 'KYC_PROVIDER_NOT_CONFIGURED', 'The identity provider is not set up yet.');
  if (!['bvn', 'nin'].includes(idType)) throw new AppError(422, 'INVALID_ID_TYPE', 'Choose BVN or NIN.');
  if (!/^\d{11}$/.test(String(idNumber || ''))) throw new AppError(422, 'INVALID_ID', 'Enter the 11-digit number.');
  return { verified: true, auto: tier === 1, mock: true };
}
