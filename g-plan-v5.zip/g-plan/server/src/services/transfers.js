// Internal money movement. Every transfer: idempotency -> lock -> validate -> post -> complete.
// All validation happens here, on the server. The client is never trusted.
import crypto from 'node:crypto';
import { withTx } from '../db.js';
import { config } from '../config.js';
import { AppError } from '../errors.js';
import { postEntry, availableBalance, newReference, systemAccount, walkStates } from './ledger.js';
import { notify } from './notify.js';
import { fmt, maskName } from '../utils/format.js';
import { assertDailyLimit, assertBusinessLimits } from './limits.js';

export function hashRequest(obj) {
  return crypto.createHash('sha256').update(JSON.stringify(obj)).digest('hex');
}

export function assertAmount(amountMinor) {
  if (!Number.isSafeInteger(amountMinor) || amountMinor <= 0 || amountMinor > config.maxAmountMinor) {
    throw new AppError(422, 'INVALID_AMOUNT', 'Enter a valid amount greater than zero.');
  }
}

// Returns null if this key is new, or the stored receipt if it is a replay.
export async function claimIdempotency(c, userId, idemKey, requestHash) {
  const ins = await c.query(
    `INSERT INTO idempotency_keys(user_id, idem_key, request_hash) VALUES ($1,$2,$3)
     ON CONFLICT (user_id, idem_key) DO NOTHING RETURNING id`,
    [userId, idemKey, requestHash]
  );
  if (ins.rows[0]) return null;
  const ex = (await c.query(
    `SELECT request_hash, response_body, transaction_id FROM idempotency_keys WHERE user_id=$1 AND idem_key=$2`,
    [userId, idemKey])).rows[0];
  if (ex.request_hash !== requestHash) {
    throw new AppError(422, 'IDEMPOTENCY_MISMATCH', 'This key was already used for a different request.');
  }
  if (ex.response_body) return { ...ex.response_body, replayed: true };
  if (ex.transaction_id) {
    const t = (await c.query('SELECT * FROM transactions WHERE id=$1', [ex.transaction_id])).rows[0];
    return receiptFromRow(t, true);
  }
  throw new AppError(409, 'IN_PROGRESS', 'This request is still being processed.');
}

export function receiptFromRow(t, replayed = false) {
  return {
    transactionId: t.id, reference: t.reference, type: t.type, state: t.state,
    amountMinor: t.amount_minor, feeMinor: t.fee_minor, currency: t.currency,
    isDemo: t.is_demo, failureReason: t.failure_reason, extra: t.meta || {}, replayed,
  };
}

/**
 * Move money between two ledger accounts as one atomic, idempotent transaction.
 * opts.fromSystem = true is for demo funding only: source is a system account.
 */
export async function transfer({
  userId, fromAccountId, toAccountId, amountMinor, type, description,
  idemKey, requestHash, fromSystem = false, category = null, meta = {}, riskLevel = 'normal',
  createdAt = null, businessId = null, pocketId = null,
}) {
  assertAmount(amountMinor);
  if (fromAccountId === toAccountId) {
    throw new AppError(422, 'SAME_ACCOUNT', 'Source and destination must be different.');
  }
  if (!idemKey) throw new AppError(400, 'IDEMPOTENCY_KEY_REQUIRED', 'Missing Idempotency-Key header.');

  return withTx(async (c) => {
    const replay = await claimIdempotency(c, userId, idemKey, requestHash);
    if (replay) return replay;

    // Lock both accounts in a fixed order (prevents deadlocks and double-spend races).
    const locked = await c.query(
      `SELECT id, user_id, type, currency, status, business_id, pocket_id FROM accounts
       WHERE id = ANY($1::uuid[]) ORDER BY id FOR UPDATE`,
      [[fromAccountId, toAccountId]]
    );
    const from = locked.rows.find((a) => a.id === fromAccountId);
    const to = locked.rows.find((a) => a.id === toAccountId);
    if (!from || !to) throw new AppError(404, 'ACCOUNT_NOT_FOUND', 'Account not found.');

    if (fromSystem) {
      if (from.user_id !== null) throw new AppError(403, 'FORBIDDEN', 'Not allowed.');
    } else if (businessId) {
      // The business routes checked the person's role; here we only make sure the wallet is that business's.
      if (from.business_id !== businessId) throw new AppError(403, 'FORBIDDEN', 'That is not this business wallet.');
    } else if (pocketId) {
      // The pocket routes checked the person's role and the pocket's rules; here we only make sure it is that pocket's wallet.
      if (from.pocket_id !== pocketId) throw new AppError(403, 'FORBIDDEN', 'That is not this pocket.');
    } else if (from.business_id || from.pocket_id || from.user_id !== userId) {
      throw new AppError(403, 'FORBIDDEN', 'You can only send from your own accounts.');
    }
    if (from.status !== 'active') throw new AppError(422, 'ACCOUNT_FROZEN', 'This account is not active.');
    if (to.status !== 'active') throw new AppError(422, 'RECIPIENT_UNAVAILABLE', 'The recipient account is not available.');
    if (from.currency !== to.currency) {
      throw new AppError(422, 'CURRENCY_MISMATCH', 'Cross-currency transfers are not supported here. Use Exchange.');
    }

    const user = (await c.query('SELECT kyc_tier, status, full_name FROM users WHERE id=$1', [userId])).rows[0];
    if (!user || user.status !== 'active') {
      throw new AppError(403, 'USER_RESTRICTED', 'Your account is restricted. Contact support.');
    }
    const sendingToOthers = !fromSystem && (to.user_id !== userId || !!from.business_id || !!to.business_id || !!from.pocket_id || !!to.pocket_id);
    if (sendingToOthers && from.currency === 'NGN' && businessId && from.business_id === businessId) {
      // Business money: limited as one customer (the owner's level, a shared daily total), not by the sender's own tier.
      await assertBusinessLimits(c, { businessId, walletId: fromAccountId, amountMinor, currency: from.currency });
    } else if (sendingToOthers && from.currency === 'NGN') {
      if (amountMinor > config.tierLimitsMinor[user.kyc_tier]) {
        throw new AppError(422, 'LIMIT_EXCEEDED',
          'This amount is above your current transfer limit. Verify your identity in Security to raise it.');
      }
      await assertDailyLimit(c, userId, amountMinor, from.currency, user.kyc_tier);
    }
    if (!fromSystem) {
      const available = await availableBalance(c, fromAccountId);
      if (available < amountMinor) {
        throw new AppError(422, 'INSUFFICIENT_FUNDS', 'Your available balance is too low for this transfer.');
      }
    }

    const txn = (await c.query(
      `INSERT INTO transactions(reference, type, initiator_user_id, amount_minor, currency,
                                description, provider, is_demo, category, meta, risk_level)
       VALUES ($1,$2,$3,$4,$5,$6,'internal_ledger', TRUE, $7, $8, $9) RETURNING id, reference`,
      [newReference(), type, userId, amountMinor, from.currency, description ?? null,
        category, JSON.stringify(meta), riskLevel]
    )).rows[0];
    await walkStates(c, txn.id, ['pending_authorisation', 'authorised', 'processing']);

    // A payment the risk rules flagged 'review' is held: the money is reserved, nothing is posted,
    // and a compliance reviewer approves or declines it.
    if (riskLevel === 'review' && config.reviewHold && !fromSystem && type === 'internal_transfer') {
      await walkStates(c, txn.id, ['under_review']);
      await c.query('INSERT INTO holds(account_id, transaction_id, amount_minor) VALUES ($1,$2,$3)', [fromAccountId, txn.id, amountMinor]);
      await c.query(`UPDATE transactions SET meta = meta || $2::jsonb WHERE id=$1`, [txn.id, JSON.stringify({ toAccountId })]);
      await notify(c, userId, 'Payment held for review',
        `${fmt(amountMinor, from.currency)} is reserved while our team checks it. You will get an alert when it is decided. Ref ${txn.reference}`, 'pending');
      const heldReceipt = {
        transactionId: txn.id, reference: txn.reference, type, state: 'under_review',
        amountMinor, feeMinor: 0, currency: from.currency, isDemo: true, failureReason: null, extra: {}, replayed: false,
      };
      await c.query('UPDATE idempotency_keys SET transaction_id=$1, response_body=$2 WHERE user_id=$3 AND idem_key=$4',
        [txn.id, JSON.stringify(heldReceipt), userId, idemKey]);
      return heldReceipt;
    }

    await postEntry(c, {
      transactionId: txn.id,
      description: description ?? type,
      postings: [
        { accountId: fromAccountId, direction: 'debit', amountMinor, currency: from.currency },
        { accountId: toAccountId, direction: 'credit', amountMinor, currency: from.currency },
      ],
      createdAt,
    });
    await walkStates(c, txn.id, ['completed']);

    await c.query(
      `INSERT INTO audit_log(actor_type, actor_id, action, target_type, target_id, metadata)
       VALUES ('user',$1,$2,'transaction',$3,$4)`,
      [userId, `transfer.${type}`, txn.id, JSON.stringify({ amountMinor, currency: from.currency })]
    );

    if (type === 'internal_transfer' && to.user_id && to.user_id !== userId && !to.business_id && !from.business_id && !to.pocket_id && !from.pocket_id) {
      await notify(c, to.user_id, 'Money received', `${fmt(amountMinor, from.currency)} from ${maskName(user.full_name)}`, 'credit');
      await notify(c, userId, 'Money sent', `${fmt(amountMinor, from.currency)} sent. Ref ${txn.reference}`, 'debit');
    }

    const receipt = {
      transactionId: txn.id, reference: txn.reference, type, state: 'completed',
      amountMinor, feeMinor: 0, currency: from.currency, isDemo: true, failureReason: null,
      extra: {}, replayed: false,
    };
    await c.query(
      `UPDATE idempotency_keys SET transaction_id=$1, response_body=$2 WHERE user_id=$3 AND idem_key=$4`,
      [txn.id, JSON.stringify(receipt), userId, idemKey]
    );
    return receipt;
  });
}

export async function fundWalletDemo({ userId, walletId, amountMinor, idemKey, description = 'Demo funding', type = 'deposit', category = 'income' }) {
  const settlement = await withTx((c) => systemAccount(c, 'settlement', 'NGN'));
  return transfer({
    userId, fromAccountId: settlement, toAccountId: walletId, amountMinor,
    type, description, idemKey, category,
    requestHash: hashRequest({ walletId, amountMinor, kind: 'demo-fund', description }), fromSystem: true,
  });
}

// A reviewer approved a held internal transfer: post it now.
export async function completeHeldTransfer(txnId, actorId) {
  return withTx(async (c) => {
    const t = (await c.query('SELECT * FROM transactions WHERE id=$1 FOR UPDATE', [txnId])).rows[0];
    if (!t || t.state !== 'under_review' || t.type !== 'internal_transfer') {
      throw new AppError(409, 'NOT_HELD', 'This payment is not waiting for review.');
    }
    const hold = (await c.query(`SELECT id, account_id FROM holds WHERE transaction_id=$1 AND status='active'`, [txnId])).rows[0];
    const toId = t.meta?.toAccountId;
    if (!hold || !toId) throw new AppError(409, 'NOT_HELD', 'This payment cannot be completed.');
    const locked = await c.query(`SELECT id, user_id, status FROM accounts WHERE id = ANY($1::uuid[]) ORDER BY id FOR UPDATE`, [[hold.account_id, toId]]);
    const to = locked.rows.find((a) => a.id === toId);
    if (!to || to.status !== 'active') throw new AppError(422, 'RECIPIENT_UNAVAILABLE', 'The recipient account is no longer available. Decline this payment instead.');
    await walkStates(c, txnId, ['processing']);
    await postEntry(c, {
      transactionId: txnId, description: t.description ?? t.type,
      postings: [
        { accountId: hold.account_id, direction: 'debit', amountMinor: t.amount_minor, currency: t.currency },
        { accountId: toId, direction: 'credit', amountMinor: t.amount_minor, currency: t.currency },
      ],
    });
    await c.query(`UPDATE holds SET status='captured', resolved_at=now() WHERE id=$1`, [hold.id]);
    await walkStates(c, txnId, ['completed']);
    await c.query(
      `INSERT INTO audit_log(actor_type, actor_id, action, target_type, target_id, metadata) VALUES ('admin',$1,'payment.review_approved','transaction',$2,'{}')`,
      [actorId, txnId]);
    await notify(c, t.initiator_user_id, 'Payment approved', `${fmt(t.amount_minor, t.currency)} was approved and sent. Ref ${t.reference}`, 'debit');
    if (to.user_id) await notify(c, to.user_id, 'Money received', `${fmt(t.amount_minor, t.currency)} received.`, 'credit');
    await c.query(`UPDATE payment_requests SET status='paid' WHERE paid_txn_id=$1`, [txnId]);
    const fresh = (await c.query('SELECT * FROM transactions WHERE id=$1', [txnId])).rows[0];
    const receipt = receiptFromRow(fresh);
    await c.query('UPDATE idempotency_keys SET response_body=$1 WHERE transaction_id=$2', [JSON.stringify(receipt), txnId]);
    return receipt;
  });
}
