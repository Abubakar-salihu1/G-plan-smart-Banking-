// Payments that leave G-Plan (bank transfers, bills, card purchases, international).
// Flow: reserve funds with a HOLD -> call the (mock) provider -> post to the ledger on success,
// or release the hold on failure. A provider timeout is never assumed to be success or failure:
// it becomes processing_unconfirmed and is resolved later by a status check.
import { withTx } from '../db.js';
import { config } from '../config.js';
import { AppError } from '../errors.js';
import { postEntry, availableBalance, newReference, systemAccount, walkStates } from './ledger.js';
import { assertAmount, claimIdempotency, receiptFromRow } from './transfers.js';
import { notify } from './notify.js';
import { fmt } from '../utils/format.js';
import { assertDailyLimit, assertBusinessLimits } from './limits.js';
import { mockBank, mockBiller, mockCard, mockInternational } from './providers.js';
import { bankProvider, providerName, isLive } from './bankProvider.js';

export async function payExternal({
  userId, walletId, amountMinor, feeMinor = 0, currency = 'NGN', type, description,
  category = null, meta = {}, riskLevel = 'normal', idemKey, requestHash, provider, businessId = null,
}) {
  assertAmount(amountMinor);
  if (!idemKey) throw new AppError(400, 'IDEMPOTENCY_KEY_REQUIRED', 'Missing Idempotency-Key header.');

  // Phase 1: validate, create the transaction and reserve the money.
  const p1 = await withTx(async (c) => {
    const replay = await claimIdempotency(c, userId, idemKey, requestHash);
    if (replay) return { replay };

    const w = (await c.query(
      'SELECT id, user_id, currency, status, business_id FROM accounts WHERE id=$1 FOR UPDATE', [walletId])).rows[0];
    const mayUse = !!w && (businessId ? w.business_id === businessId : (!w.business_id && !w.pocket_id && w.user_id === userId));
    if (!mayUse) throw new AppError(403, 'FORBIDDEN', 'You can only pay from your own wallet.');
    if (w.status !== 'active') throw new AppError(422, 'ACCOUNT_FROZEN', 'This wallet is not active.');
    if (w.currency !== currency) throw new AppError(422, 'CURRENCY_MISMATCH', 'Wallet currency does not match.');

    const user = (await c.query('SELECT kyc_tier, status FROM users WHERE id=$1', [userId])).rows[0];
    if (!user || user.status !== 'active') {
      throw new AppError(403, 'USER_RESTRICTED', 'Your account is restricted. Contact support.');
    }
    if (businessId) {
      await assertBusinessLimits(c, { businessId, walletId, amountMinor, currency });
    } else {
      if (currency === 'NGN' && amountMinor > config.tierLimitsMinor[user.kyc_tier]) {
        throw new AppError(422, 'LIMIT_EXCEEDED',
          'This amount is above your current limit. Verify your identity in Security to raise it.');
      }
      await assertDailyLimit(c, userId, amountMinor, currency, user.kyc_tier);
    }
    const total = amountMinor + feeMinor;
    const available = await availableBalance(c, walletId);
    if (available < total) {
      throw new AppError(422, 'INSUFFICIENT_FUNDS', 'Your available balance is too low for this payment.');
    }

    const txn = (await c.query(
      `INSERT INTO transactions(reference, type, initiator_user_id, amount_minor, fee_minor, currency,
                                description, provider, is_demo, category, meta, risk_level)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$11, $12, $8, $9, $10) RETURNING *`,
      [newReference(), type, userId, amountMinor, feeMinor, currency, description ?? null,
        category, JSON.stringify(meta), riskLevel, providerLabel(type), providerIsDemo(type)])).rows[0];
    await walkStates(c, txn.id, ['pending_authorisation', 'authorised', 'processing']);
    await c.query(
      `INSERT INTO holds(account_id, transaction_id, amount_minor) VALUES ($1,$2,$3)`,
      [walletId, txn.id, total]);
    await c.query('UPDATE idempotency_keys SET transaction_id=$1 WHERE user_id=$2 AND idem_key=$3',
      [txn.id, userId, idemKey]);
    // Flagged 'review': keep the money reserved and wait for a compliance decision before calling the provider.
    if (riskLevel === 'review' && config.reviewHold) {
      await walkStates(c, txn.id, ['under_review']);
      await notify(c, userId, 'Payment held for review',
        `${fmt(amountMinor, currency)} is reserved while our team checks it. You will get an alert when it is decided. Ref ${txn.reference}`, 'pending');
      const fresh = (await c.query('SELECT * FROM transactions WHERE id=$1', [txn.id])).rows[0];
      const heldReceipt = receiptFromRow(fresh);
      await c.query('UPDATE idempotency_keys SET response_body=$1 WHERE transaction_id=$2', [JSON.stringify(heldReceipt), txn.id]);
      return { held: heldReceipt };
    }
    return { txn };
  });
  if (p1.replay) return p1.replay;
  if (p1.held) return p1.held;

  // Provider call (outside any DB transaction, so no locks are held while waiting).
  let outcome;
  try {
    outcome = await provider({
      txnId: p1.txn.id, reference: p1.txn.reference, amountMinor, currency, meta: { ...meta, category },
    });
  } catch {
    outcome = { unconfirmed: true };
  }
  return finalize(p1.txn.id, outcome);
}

// Phase 2: settle a transaction that is processing (or processing_unconfirmed).
export async function finalize(txnId, outcome) {
  return withTx(async (c) => {
    const t = (await c.query('SELECT * FROM transactions WHERE id=$1 FOR UPDATE', [txnId])).rows[0];
    if (!t || !['processing', 'processing_unconfirmed'].includes(t.state)) return t ? receiptFromRow(t) : null;
    const hold = (await c.query(
      `SELECT id, account_id, amount_minor FROM holds WHERE transaction_id=$1 AND status='active'`, [txnId])).rows[0];
    if (!hold) return receiptFromRow(t);
    const userId = t.initiator_user_id;
    const label = t.description || t.type.replace(/_/g, ' ');

    if (outcome.unconfirmed) {
      // Tell the person once. Later status checks that still say "unknown" must not repeat the alert every minute.
      if (t.state === 'processing') {
        await walkStates(c, txnId, ['processing_unconfirmed']);
        await notify(c, userId, 'Payment pending confirmation',
          `${label}: we are waiting for confirmation. Your money is reserved, not lost. Ref ${t.reference}`, 'pending');
      }
    } else if (outcome.ok) {
      const settlement = await systemAccount(c, 'settlement', t.currency);
      const feeAcct = t.fee_minor > 0 ? await systemAccount(c, 'fee', t.currency) : null;
      const ids = [hold.account_id, settlement, feeAcct].filter(Boolean);
      await c.query('SELECT id FROM accounts WHERE id = ANY($1::uuid[]) ORDER BY id FOR UPDATE', [ids]);
      const postings = [
        { accountId: hold.account_id, direction: 'debit', amountMinor: t.amount_minor + t.fee_minor, currency: t.currency },
        { accountId: settlement, direction: 'credit', amountMinor: t.amount_minor, currency: t.currency },
      ];
      if (feeAcct) postings.push({ accountId: feeAcct, direction: 'credit', amountMinor: t.fee_minor, currency: t.currency });
      await postEntry(c, { transactionId: txnId, description: label, postings });
      await c.query(`UPDATE holds SET status='captured', resolved_at=now() WHERE id=$1`, [hold.id]);
      await c.query(
        `UPDATE transactions SET provider_reference=$2, meta = meta || $3::jsonb WHERE id=$1`,
        [txnId, outcome.providerRef || null, JSON.stringify(outcome.extra || {})]);
      await walkStates(c, txnId, ['completed']);
      await notify(c, userId, 'Payment successful', `${label}: ${fmt(t.amount_minor, t.currency)}. Ref ${t.reference}`, 'debit');
      await c.query(
        `INSERT INTO audit_log(actor_type, actor_id, action, target_type, target_id, metadata)
         VALUES ('user',$1,$2,'transaction',$3,$4)`,
        [userId, `payment.${t.type}`, txnId, JSON.stringify({ amountMinor: t.amount_minor, currency: t.currency })]);
    } else {
      await c.query(`UPDATE holds SET status='released', resolved_at=now() WHERE id=$1`, [hold.id]);
      await c.query('UPDATE transactions SET failure_reason=$2 WHERE id=$1', [txnId, outcome.reason || 'Payment failed.']);
      await walkStates(c, txnId, ['failed']);
      await notify(c, userId, 'Payment failed',
        `${label}: ${outcome.reason || 'Payment failed.'} No money was taken. Ref ${t.reference}`, 'failed');
    }

    const fresh = (await c.query('SELECT * FROM transactions WHERE id=$1', [txnId])).rows[0];
    const receipt = receiptFromRow(fresh);
    await c.query('UPDATE idempotency_keys SET response_body=$1 WHERE transaction_id=$2', [JSON.stringify(receipt), txnId]);
    return receipt;
  });
}

// What to record on the transaction: only bank transfers can be live, everything else is still a mock.
const providerLabel = (type) => (type === 'external_transfer' && isLive() ? providerName() : 'mock_provider');
const providerIsDemo = (type) => !(type === 'external_transfer' && isLive());

const providerFor = (type) => ({
  external_transfer: bankProvider(),
  bill_payment: mockBiller, card_payment: mockCard, international_transfer: mockInternational,
}[type]);

// A reviewer approved a held outgoing payment: now call the provider and settle.
export async function approveHeldExternal(txnId, actorId) {
  const t = await withTx(async (c) => {
    const row = (await c.query('SELECT * FROM transactions WHERE id=$1 FOR UPDATE', [txnId])).rows[0];
    if (!row || row.state !== 'under_review' || !providerFor(row.type)) throw new AppError(409, 'NOT_HELD', 'This payment is not waiting for review.');
    await walkStates(c, txnId, ['processing']);
    await c.query(
      `INSERT INTO audit_log(actor_type, actor_id, action, target_type, target_id, metadata) VALUES ('admin',$1,'payment.review_approved','transaction',$2,'{}')`,
      [actorId, txnId]);
    return row;
  });
  let outcome;
  try {
    outcome = await providerFor(t.type)({ txnId: t.id, reference: t.reference, amountMinor: t.amount_minor, currency: t.currency, meta: { ...t.meta, category: t.category } });
  } catch { outcome = { unconfirmed: true }; }
  return finalize(t.id, outcome);
}

// A reviewer declined a held payment (internal or outgoing): release the reserved money.
export async function rejectHeld(txnId, actorId, reason = 'Declined after review.') {
  return withTx(async (c) => {
    const t = (await c.query('SELECT * FROM transactions WHERE id=$1 FOR UPDATE', [txnId])).rows[0];
    if (!t || t.state !== 'under_review') throw new AppError(409, 'NOT_HELD', 'This payment is not waiting for review.');
    await c.query(`UPDATE holds SET status='released', resolved_at=now() WHERE transaction_id=$1 AND status='active'`, [txnId]);
    await c.query('UPDATE transactions SET failure_reason=$2 WHERE id=$1', [txnId, reason]);
    await walkStates(c, txnId, ['failed']);
    await c.query(`UPDATE payment_requests SET status='pending', paid_txn_id=NULL WHERE paid_txn_id=$1`, [txnId]);
    await c.query(
      `INSERT INTO audit_log(actor_type, actor_id, action, target_type, target_id, metadata) VALUES ('admin',$1,'payment.review_declined','transaction',$2,'{}')`,
      [actorId, txnId]);
    await notify(c, t.initiator_user_id, 'Payment declined after review',
      `${t.description || t.type}: ${fmt(t.amount_minor, t.currency)} was not sent and your money is back in your balance. Ref ${t.reference}`, 'failed');
    const fresh = (await c.query('SELECT * FROM transactions WHERE id=$1', [txnId])).rows[0];
    const receipt = receiptFromRow(fresh);
    await c.query('UPDATE idempotency_keys SET response_body=$1 WHERE transaction_id=$2', [JSON.stringify(receipt), txnId]);
    return receipt;
  });
}
