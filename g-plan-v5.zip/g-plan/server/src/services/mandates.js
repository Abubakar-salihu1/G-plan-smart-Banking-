// Direct debits, run from the background job. A collection happens only if: the customer approved the mandate, it is
// still active, the amount is within the cap, notice was given, and the customer's wallet has the money (never an
// overdraft). The money moves as an ordinary wallet payment FROM THE CUSTOMER to the business wallet, so the customer's
// own limits, risk checks and freeze all still apply.
import { pool } from '../db.js';
import { AppError } from '../errors.js';
import { walletOf, businessWalletOf } from './ledger.js';
import { transfer, hashRequest } from './transfers.js';
import { monitorAml } from './risk.js';
import { notify } from './notify.js';
import { notifyMembers } from './businessAccess.js';
import { fmt } from '../utils/format.js';
import { nextDueOn, firstDueFrom, addDays, shouldPause } from '../utils/mandateRules.js';

const todayOf = (now) => now.toISOString().slice(0, 10);
const dateStr = (d) => (typeof d === 'string' ? d.slice(0, 10) : d.toISOString().slice(0, 10));

export async function runMandates(now = new Date()) {
  const today = todayOf(now);
  await pool.query(`UPDATE mandates SET status='expired' WHERE status='pending' AND expires_at < now()`);
  // A recovered crash: a collection stuck in "collecting" goes back; its idempotency key stops a second payment.
  await pool.query(`UPDATE mandate_collections SET status='scheduled' WHERE status='collecting' AND claimed_at < now() - interval '10 minutes'`);
  // Collections for mandates that are no longer active are cancelled, never collected late.
  await pool.query(
    `UPDATE mandate_collections c SET status='cancelled', error='The direct debit was no longer active on the due date.'
     FROM mandates m WHERE m.id=c.mandate_id AND c.status='scheduled' AND (m.status IN ('cancelled','declined','expired') OR (m.status='paused' AND c.due_on < $1))`, [today]);

  // The day-before reminder.
  const remind = (await pool.query(
    `SELECT c.id, c.amount_minor, c.due_on, m.payer_id, m.label, b.name FROM mandate_collections c JOIN mandates m ON m.id=c.mandate_id JOIN businesses b ON b.id=m.business_id
     WHERE c.status='scheduled' AND c.notice_sent_at IS NULL AND c.due_on = $1 AND m.status='active' LIMIT 100`, [addDays(today, 1)])).rows;
  for (const c of remind) {
    await notify(pool, c.payer_id, 'Direct debit tomorrow', `${c.name} will collect ${fmt(Number(c.amount_minor))} tomorrow for ${c.label}. Keep enough in your wallet. You can cancel it any time in Direct debits.`, 'pending');
    await pool.query('UPDATE mandate_collections SET notice_sent_at=now() WHERE id=$1', [c.id]);
  }

  const claimed = (await pool.query(
    `UPDATE mandate_collections SET status='collecting', claimed_at=now() WHERE id IN (
       SELECT c.id FROM mandate_collections c JOIN mandates m ON m.id=c.mandate_id
       WHERE c.status='scheduled' AND c.due_on <= $1 AND m.status='active' ORDER BY c.due_on LIMIT 25 FOR UPDATE OF c SKIP LOCKED) RETURNING id`, [today])).rows;
  for (const c of claimed) await collect(c.id, today);
  return claimed.length;
}

async function collect(collectionId, today) {
  const c = (await pool.query(
    `SELECT c.*, m.payer_id, m.business_id, m.label, m.frequency, m.fixed_amount_minor, m.max_amount_minor, m.notice_days, m.start_on, m.end_on, b.name
     FROM mandate_collections c JOIN mandates m ON m.id=c.mandate_id JOIN businesses b ON b.id=m.business_id WHERE c.id=$1`, [collectionId])).rows[0];
  let receipt = null; let error = null;
  try {
    const from = await walletOf(pool, c.payer_id, 'NGN');
    const to = await businessWalletOf(pool, c.business_id);
    if (!from || !to) throw new AppError(422, 'NO_WALLET', 'A wallet was not available.');
    receipt = await transfer({
      userId: c.payer_id, fromAccountId: from, toAccountId: to, amountMinor: Number(c.amount_minor), type: 'internal_transfer', category: 'bills',
      description: `Direct debit · ${c.name} · ${c.label}`, meta: { mandateId: c.mandate_id, collectionId: c.id, directDebit: true },
      idemKey: `mandate:${c.id}`, requestHash: hashRequest({ collection: c.id }),
    });
  } catch (e) {
    error = e instanceof AppError ? e.message : 'Something went wrong. Nothing was taken.';
    if (!(e instanceof AppError)) console.error('direct debit', e.message);
  }

  if (receipt) {
    await pool.query(`UPDATE mandate_collections SET status='paid', txn_id=$2, error=NULL WHERE id=$1`, [c.id, receipt.transactionId]);
    await pool.query('UPDATE mandates SET failures_in_a_row=0 WHERE id=$1', [c.mandate_id]);
    await notify(pool, c.payer_id, 'Direct debit paid', `${fmt(Number(c.amount_minor))} was collected by ${c.name} for ${c.label}.`, 'debit');
    await notifyMembers(pool, c.business_id, 'wallet.read', 'Direct debit collected', `${fmt(Number(c.amount_minor))} collected for ${c.label}.`, 'credit');
    if (!receipt.replayed && receipt.state === 'completed') monitorAml(c.payer_id, receipt).catch(() => {});
  } else {
    await pool.query(`UPDATE mandate_collections SET status='failed', error=$2 WHERE id=$1`, [c.id, error]);
    const m = (await pool.query('UPDATE mandates SET failures_in_a_row=failures_in_a_row+1 WHERE id=$1 RETURNING failures_in_a_row', [c.mandate_id])).rows[0];
    await notify(pool, c.payer_id, 'Direct debit failed', `${c.name} could not collect ${fmt(Number(c.amount_minor))} for ${c.label}: ${error} Nothing was taken.`, 'failed');
    await notifyMembers(pool, c.business_id, 'wallet.read', 'Direct debit failed', `${fmt(Number(c.amount_minor))} for ${c.label} could not be collected: ${error}`, 'failed');
    if (shouldPause(m.failures_in_a_row)) {
      await pool.query(`UPDATE mandates SET status='paused' WHERE id=$1 AND status='active'`, [c.mandate_id]);
      await notify(pool, c.payer_id, 'Direct debit paused', `${c.name} direct debit was paused after repeated failures. Open Direct debits to resume it.`, 'security');
      await notifyMembers(pool, c.business_id, 'wallet.read', 'Direct debit paused', `The ${c.label} direct debit was paused after repeated failures.`, 'failed');
    }
  }

  // Fixed-amount mandates schedule their own next collection (the customer approved this rhythm and amount).
  if (c.fixed_amount_minor) {
    const m = (await pool.query('SELECT status FROM mandates WHERE id=$1', [c.mandate_id])).rows[0];
    if (m.status === 'active') await scheduleNext(c, today);
  }
}

async function scheduleNext(c, today) {
  const anchor = Number(dateStr(c.start_on).slice(8, 10));
  const earliest = addDays(today, c.notice_days);
  const next = firstDueFrom(nextDueOn(dateStr(c.due_on), c.frequency, anchor), c.frequency, earliest, anchor);
  if (c.end_on && next > dateStr(c.end_on)) return;
  const r = await pool.query(
    `INSERT INTO mandate_collections(mandate_id, due_on, amount_minor) VALUES ($1,$2,$3) ON CONFLICT (mandate_id, due_on) DO NOTHING RETURNING id`,
    [c.mandate_id, next, c.fixed_amount_minor]);
  if (r.rows[0]) await notify(pool, c.payer_id, 'Next direct debit scheduled', `${c.name} will collect ${fmt(Number(c.fixed_amount_minor))} on ${next} for ${c.label}. Cancel any time in Direct debits.`, 'info');
}

// Used when a customer approves (or resumes) a fixed-amount mandate: line up the first collection.
export async function scheduleFirst(db, mandate, today) {
  if (!mandate.fixed_amount_minor) return null;
  const anchor = Number(dateStr(mandate.start_on).slice(8, 10));
  const due = firstDueFrom(dateStr(mandate.start_on), mandate.frequency, addDays(today, mandate.notice_days), anchor);
  if (mandate.end_on && due > dateStr(mandate.end_on)) return null;
  const r = await db.query(
    `INSERT INTO mandate_collections(mandate_id, due_on, amount_minor) VALUES ($1,$2,$3) ON CONFLICT (mandate_id, due_on) DO NOTHING RETURNING due_on`,
    [mandate.id, due, mandate.fixed_amount_minor]);
  return r.rows[0]?.due_on || null;
}
