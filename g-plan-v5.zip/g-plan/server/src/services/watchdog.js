// The watchdog: every few minutes, look for stuck money and neglected queues, and tell a human once (then remind).
// It runs separately from the job loop on purpose, so it still notices when the job loop itself has hung.
// With several server instances, each may send the same alert once; that is acceptable noise, not silence.
import { pool } from '../db.js';
import { alert, setGauge } from './monitor.js';
import { opsSnapshot } from './opsSnapshot.js';
import { evaluateOps, shouldSend } from '../utils/opsRules.js';
import { integrityCheck, jobsAgeMinutes } from './jobs.js';

let lastIntegrity = { at: 0, ok: true };

export async function runWatchdog(now = Date.now()) {
  const snap = await opsSnapshot();
  snap.jobsStaleMinutes = jobsAgeMinutes();
  // The integrity check is heavier, so it is re-run at most every 30 minutes here (it also runs every 6 hours on its own).
  if (now - lastIntegrity.at > 30 * 60_000) {
    try { lastIntegrity = { at: now, ok: (await integrityCheck()).ok }; } catch { /* a failing check is reported by the check itself */ }
  }
  snap.integrityOk = lastIntegrity.ok;

  for (const [k, v] of Object.entries(snap)) if (typeof v === 'number') setGauge(`gplan_ops_${k.replace(/[A-Z]/g, (c) => '_' + c.toLowerCase())}`, v);
  const issues = evaluateOps(snap);

  const open = new Map((await pool.query('SELECT * FROM ops_alerts WHERE resolved_at IS NULL')).rows.map((r) => [r.issue_key, r]));
  for (const i of issues) {
    const prev = open.get(i.key) || (await pool.query('SELECT * FROM ops_alerts WHERE issue_key=$1', [i.key])).rows[0];
    if (shouldSend(prev, i.severity, now)) {
      await alert(`${i.severity === 'page' ? 'ACT NOW: ' : ''}${i.text}`);
      await pool.query(
        `INSERT INTO ops_alerts(issue_key, severity, text) VALUES ($1,$2,$3)
         ON CONFLICT (issue_key) DO UPDATE SET severity=EXCLUDED.severity, text=EXCLUDED.text, last_sent_at=now(),
           first_seen = CASE WHEN ops_alerts.resolved_at IS NULL THEN ops_alerts.first_seen ELSE now() END, resolved_at=NULL`, [i.key, i.severity, i.text]);
    }
  }
  // Things that were wrong and now are not: say so once.
  const nowKeys = new Set(issues.map((i) => i.key));
  for (const [key, row] of open) {
    if (!nowKeys.has(key)) {
      await pool.query('UPDATE ops_alerts SET resolved_at=now() WHERE issue_key=$1 AND resolved_at IS NULL', [key]);
      await alert(`Resolved: ${row.text.split('.')[0]}.`);
    }
  }
  return { issues: issues.map((i) => i.key) };
}
