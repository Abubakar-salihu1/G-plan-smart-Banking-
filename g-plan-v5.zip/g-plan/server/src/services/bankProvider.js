// One place that decides which provider moves bank money: mock (default), Paystack or Flutterwave.
import { AppError } from '../errors.js';
import { mockBank } from './providers.js';
import * as paystack from './paystack.js';
import * as flutterwave from './flutterwave.js';

export const providerName = () => {
  if (paystack.enabled()) return 'paystack';
  if (flutterwave.enabled()) return 'flutterwave';
  return 'mock';
};
export const isLive = () => providerName() !== 'mock';

export const bankProvider = () => ({ paystack: paystack.transferProvider, flutterwave: flutterwave.transferProvider }[providerName()] || mockBank);

export async function resolveName(bankCode, accountNumber) {
  const p = providerName();
  if (p === 'paystack') return paystack.resolveAccount(accountNumber, bankCode);
  if (p === 'flutterwave') return flutterwave.resolveAccount(accountNumber, bankCode);
  return `DEMO ACCOUNT ${String(accountNumber).slice(-4)}`;
}

// Used by the background job for payments stuck in processing_unconfirmed.
export async function checkStatus(txn, mockCheck) {
  if (providerName() === 'flutterwave') return flutterwave.statusCheck(txn.reference);
  return mockCheck();
}

export function assertConfigured() {
  const want = process.env.PAYMENT_PROVIDER || 'mock';
  if (!['mock', 'paystack', 'flutterwave'].includes(want)) throw new AppError(500, 'BAD_PROVIDER', `Unknown PAYMENT_PROVIDER: ${want}`);
}
