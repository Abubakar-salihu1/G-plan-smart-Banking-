// Roles on a shared business wallet. These are pure rules (no database), so they are easy to test.
//   owner   : everything, including people, settings, approving payouts and moving money in from their own wallet
//   finance : sees the wallet, creates invoices, sends payouts (large ones wait for the owner)
//   staff   : creates and sees invoices, cannot see the balance or move money
//   auditor : read-only on everything, including the wallet statement and the team list
export const ROLES = ['owner', 'finance', 'staff', 'auditor'];
export const INVITABLE = ['finance', 'staff', 'auditor'];

export const BIZ_PERMS = {
  owner: ['invoices.read', 'invoices.create', 'invoices.cancel', 'report.read', 'wallet.read', 'wallet.topup', 'payouts.read', 'payouts.create', 'payouts.approve', 'team.read', 'team.manage', 'settings.manage', 'mandates.read', 'mandates.manage'],
  finance: ['invoices.read', 'invoices.create', 'invoices.cancel', 'report.read', 'wallet.read', 'payouts.read', 'payouts.create', 'mandates.read', 'mandates.manage'],
  staff: ['invoices.read', 'invoices.create'],
  auditor: ['invoices.read', 'report.read', 'wallet.read', 'payouts.read', 'team.read', 'mandates.read'],
};
export const bizCan = (role, perm) => (BIZ_PERMS[role] || []).includes(perm);

// Does a payout run now, or wait for the owner? The owner is the principal, so their own payouts run at once.
export function payoutNeedsApproval(role, amountMinor, thresholdMinor) {
  if (role === 'owner') return false;
  return Number(amountMinor) > Number(thresholdMinor);
}
