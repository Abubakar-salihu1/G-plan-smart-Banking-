// Round-ups and DEMO savings interest.
// Round-ups: after a payment completes, the amount is rounded up to the next step (₦100, ₦500 or ₦1,000) and the
// difference moves from the wallet into the chosen goal. It runs from a background job, never inside a payment,
// so a problem here can never hold up or undo a payment. Each payment is looked at once (roundup_log).
// Interest: DEMO ONLY (needs ENABLE_DEMO_FUNDING). Paying real interest on customer money needs a licence and
// real funding; the rate below is a placeholder, not an offer.
import { pool } from '../db.js';
import { config } from '../config.js';
import { AppError } from '../errors.js';
import { walletOf } from './ledger.js';
import { transfer, hashRequest, fundWalletDemo } from './transfers.js';
import { notify } from './notify.js';
import { fmt } from '../utils/format.js';

import { STEPS, roundUpMinor, monthlyInterestMinor } from '../utils/savingsMath.js';
export { STEPS, roundUpMinor, monthlyInterestMinor };
export const ROUNDUP_TYPES = ['external_transfer', 'bill_payment', 'card_payment'];

export async function runRoundups(limit = 50) {
  const rows = (await pool.query(
    `SELECT t.id, t.initiator_user_id AS user_id, t.amount_minor, s.step_minor, g.account_id, g.name
     FROM transactions t
     JOIN roundup_settings s ON s.user_id=t.initiator_user_id AND s.enabled
     JOIN goals g ON g.id=s.goal_id AND g.user_id=s.user_id
     WHERE t.state='completed' AND t.type = ANY($1) AND t.created_at > s.since
       AND NOT EXISTS (SELECT 1 FROM roundup_log l WHERE l.txn_id=t.id)
     ORDER BY t.created_at LIMIT $2`, [ROUNDUP_TYPES, limit])).rows;
  let saved = 0;
  for (const t of rows) {
    const ru = roundUpMinor(Number(t.amount_minor), t.step_minor);
    // Claim the payment first. If two servers race, only one gets the row.
    const claim = await pool.query(
      `INSERT INTO roundup_log(txn_id, user_id, amount_minor) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING RETURNING txn_id`, [t.id, t.user_id, ru]);
    if (!claim.rows[0] || ru === 0) continue;
    try {
      await transfer({
        userId: t.user_id, fromAccountId: await walletOf(pool, t.user_id), toAccountId: t.account_id, amountMinor: ru,
        type: 'goal_contribution', category: 'savings', description: `Round-up to ${t.name}`,
        idemKey: `roundup:${t.id}`, requestHash: hashRequest({ roundup: t.id }),
      });
      await pool.query('UPDATE roundup_log SET saved=TRUE WHERE txn_id=$1', [t.id]);
      saved++;
    } catch (e) {
      // Not enough money, or the wallet is frozen: skip this one quietly. Never retried, never blocks anything.
      if (!(e instanceof AppError)) console.error('roundup', e.message);
    }
  }
  return saved;
}

export async function runInterest() {
  if (!config.demoFunding || !(config.savingsDemoApr > 0)) return 0;
  const monthStart = new Date(Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), 1)).toISOString().slice(0, 10);
  // Balance each goal held when this month began, for goals not yet paid for this month.
  const rows = (await pool.query(
    `SELECT g.id, g.user_id, g.name, g.account_id,
            COALESCE(SUM(CASE WHEN p.direction='credit' THEN p.amount_minor ELSE -p.amount_minor END),0) AS bal
     FROM goals g LEFT JOIN postings p ON p.account_id=g.account_id AND p.created_at < $1::date
     WHERE NOT EXISTS (SELECT 1 FROM interest_log i WHERE i.goal_id=g.id AND i.month_start=$1::date)
     GROUP BY g.id LIMIT 100`, [monthStart])).rows;
  let paid = 0;
  for (const g of rows) {
    const amount = monthlyInterestMinor(Number(g.bal), config.savingsDemoApr);
    const claim = await pool.query(`INSERT INTO interest_log(goal_id, month_start, amount_minor) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING RETURNING goal_id`, [g.id, monthStart, amount]);
    if (!claim.rows[0] || amount === 0) continue;
    try {
      await fundWalletDemo({ userId: g.user_id, walletId: g.account_id, amountMinor: amount, idemKey: `interest:${g.id}:${monthStart}`,
        description: `Demo interest on ${g.name}`, type: 'deposit', category: 'savings' });
      await notify(pool, g.user_id, 'Demo interest added', `${fmt(amount)} demo interest was added to ${g.name}. No real money.`, 'credit');
      paid++;
    } catch (e) {
      await pool.query('DELETE FROM interest_log WHERE goal_id=$1 AND month_start=$2', [g.id, monthStart]);   // try again next hour
      console.error('interest', e.message);
    }
  }
  return paid;
}
