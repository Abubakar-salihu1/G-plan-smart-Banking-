// Sends bulk and payroll batches one item at a time from the background job, from the business wallet.
// Why a job: a batch can be 200 payments, far more than one web request should wait for.
// Safety: every item has its own idempotency key (bulk:<itemId>), so a crash or restart can never pay anyone twice;
// one failed item never stops the others; and if the person who started the batch loses their role, it stops.
import { pool } from '../db.js';
import { config } from '../config.js';
import { AppError } from '../errors.js';
import { businessWalletOf, walletOf } from './ledger.js';
import { transfer, hashRequest } from './transfers.js';
import { payExternal } from './payments.js';
import { assertNotSanctioned, recordRisk, monitorAml } from './risk.js';
import { bankProvider, resolveName, isLive } from './bankProvider.js';
import { activeMembership, bizCan } from './businessAccess.js';
import { notify } from './notify.js';
import { fmt } from '../utils/format.js';
import { namesMatch } from '../utils/bulkParse.js';

export async function runBulk(limit = 10) {
  // An item stuck in 'sending' (server stopped mid-way) goes back in the queue. Its idempotency key prevents a repeat payment.
  await pool.query(`UPDATE bulk_items SET status='queued' WHERE status='sending' AND claimed_at < now() - interval '10 minutes'`);
  const claimed = (await pool.query(
    `UPDATE bulk_items SET status='sending', claimed_at=now() WHERE id IN (
       SELECT i.id FROM bulk_items i JOIN bulk_batches b ON b.id=i.batch_id WHERE b.status='running' AND i.status='queued'
       ORDER BY b.created_at, i.line LIMIT $1 FOR UPDATE OF i SKIP LOCKED) RETURNING id, batch_id`, [limit])).rows;
  const batches = new Set();
  for (const c of claimed) { await processItem(c.id); batches.add(c.batch_id); }
  // Close batches with nothing left to do (also catches batches that were started with no queued items left).
  for (const id of batches) await finishIfDone(id);
  return claimed.length;
}

// Keep going until nothing is left or the time budget is spent (the job loop runs once a minute, and a payroll
// of 200 people should not take 20 minutes). Returns how many items were handled.
export async function runBulkFor(budgetMs = 40_000) {
  const start = Date.now(); let total = 0;
  while (Date.now() - start < budgetMs) {
    const n = await runBulk(10);
    total += n;
    if (n === 0) break;
  }
  return total;
}

async function cancelBatch(batchId, why) {
  await pool.query(`UPDATE bulk_items SET status='skipped', error=$2 WHERE batch_id=$1 AND status IN ('queued','sending')`, [batchId, why]);
}

async function processItem(itemId) {
  const it = (await pool.query(
    `SELECT i.*, b.business_id, b.executed_by, b.label, b.risk_level, bz.name AS business_name
     FROM bulk_items i JOIN bulk_batches b ON b.id=i.batch_id JOIN businesses bz ON bz.id=b.business_id WHERE i.id=$1`, [itemId])).rows[0];
  const fail = (msg) => pool.query(`UPDATE bulk_items SET status='failed', error=$2 WHERE id=$1`, [itemId, String(msg).slice(0, 200)]);
  try {
    // The person who started this must still be allowed to: same business, still holds the permission.
    const m = it.executed_by ? await activeMembership(pool, it.executed_by) : null;
    if (!m || m.business_id !== it.business_id || !(bizCan(m.role, 'payouts.create'))) { await cancelBatch(it.batch_id, 'The person who started this batch can no longer send payouts.'); return; }
    const walletId = await businessWalletOf(pool, it.business_id);
    const base = { userId: it.executed_by, businessId: it.business_id, amountMinor: Number(it.amount_minor), riskLevel: it.risk_level, idemKey: `bulk:${it.id}`, requestHash: hashRequest({ bulk: it.id }) };
    let receipt;
    if (it.kind === 'internal') {
      const u = (await pool.query(`SELECT id, full_name FROM users WHERE email=$1 AND status='active'`, [it.email])).rows[0];
      const to = u ? await walletOf(pool, u.id, 'NGN') : null;
      if (!to) return fail('No G-Plan account found for that email.');
      assertNotSanctioned(u.full_name);
      receipt = await transfer({ ...base, fromAccountId: walletId, toAccountId: to, type: 'internal_transfer', category: 'transfers',
        description: `${it.business_name} · ${it.label} · ${it.name}`, meta: { businessId: it.business_id, bulkItemId: it.id } });
    } else {
      const bankName = await resolveName(it.bank_code, it.account_number);
      assertNotSanctioned(bankName);
      if (isLive() && !namesMatch(it.name, bankName)) return fail('The bank shows a different name for that account, so it was not paid.');
      receipt = await payExternal({ ...base, walletId, feeMinor: config.fees.externalTransferMinor, type: 'external_transfer', category: 'transfers',
        description: `${it.business_name} · ${it.label} · ${it.name}`, provider: bankProvider(),
        meta: { bankCode: it.bank_code, accountNumber: it.account_number, accountName: bankName, payee: bankName, businessId: it.business_id, bulkItemId: it.id } });
    }
    await pool.query(`UPDATE bulk_items SET status='sent', txn_id=$2, error=NULL WHERE id=$1`, [itemId, receipt.transactionId]);
    if (!receipt.replayed && receipt.state === 'completed') monitorAml(it.executed_by, receipt).catch(() => {});
  } catch (e) {
    // A refusal (low balance, limit, sanctions) fails this one item only.
    if (e instanceof AppError) await fail(e.message);
    else { console.error('bulk item', e.message); await fail('Something went wrong. Check the wallet activity before retrying.'); }
  }
}

async function finishIfDone(batchId) {
  const left = Number((await pool.query(`SELECT COUNT(*) AS n FROM bulk_items WHERE batch_id=$1 AND status IN ('queued','sending')`, [batchId])).rows[0].n);
  if (left > 0) return;
  const done = (await pool.query(`UPDATE bulk_batches SET status='done', decided_at=now() WHERE id=$1 AND status='running' RETURNING created_by, executed_by, label, business_id`, [batchId])).rows[0];
  if (!done) return;
  const s = (await pool.query(
    `SELECT COUNT(*) FILTER (WHERE status='sent') AS sent, COUNT(*) FILTER (WHERE status IN ('failed','skipped')) AS bad,
            COALESCE(SUM(amount_minor) FILTER (WHERE status='sent'),0) AS paid FROM bulk_items WHERE batch_id=$1`, [batchId])).rows[0];
  const text = `${done.label}: ${s.sent} paid (${fmt(Number(s.paid))}), ${s.bad} not paid.${s.bad > 0 ? ' Open the batch to see why.' : ''}`;
  for (const uid of new Set([done.created_by, done.executed_by].filter(Boolean))) await notify(pool, uid, s.bad > 0 ? 'Batch finished with problems' : 'Batch finished', text, s.bad > 0 ? 'failed' : 'info');
}
