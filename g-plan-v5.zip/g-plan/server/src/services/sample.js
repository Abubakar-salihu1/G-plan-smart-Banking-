// DEMO ONLY: generates three months of realistic sample history so insights, budgets, subscriptions
// and the health score have something to show. Every row is marked as demo.
import { withTx } from '../db.js';
import { AppError } from '../errors.js';
import { postEntry, newReference, systemAccount, walletOf, walkStates } from './ledger.js';

const ITEMS = [
  { d: 1, type: 'deposit', amt: 350000, desc: 'Salary (demo)', cat: 'income', dir: 'in' },
  { d: 2, type: 'bill_payment', amt: 100000, desc: 'Rent payment (demo)', cat: 'rent', meta: { payee: 'Rent' } },
  { d: 3, type: 'bill_payment', amt: 5000, desc: 'MTN Airtime', cat: 'airtime', meta: { payee: 'MTN Airtime' } },
  { d: 4, type: 'bill_payment', amt: 10000, desc: 'MTN Data 3GB', cat: 'data', meta: { payee: 'MTN Data' } },
  { d: 6, type: 'bill_payment', amt: 18000, desc: 'Ikeja Electric', cat: 'electricity', meta: { payee: 'Ikeja Electric' } },
  { d: 7, type: 'external_transfer', amt: 4500, desc: 'StreamBox subscription (demo)', cat: 'entertainment', meta: { payee: 'StreamBox' } },
  { d: 9, type: 'bill_payment', amt: 8500, desc: 'DStv', cat: 'cable', meta: { payee: 'DStv' } },
  { d: 10, type: 'card_payment', amt: 12000, desc: 'Chicken Republic (demo)', cat: 'food', meta: { payee: 'Chicken Republic' }, foodBoost: true },
  { d: 12, type: 'card_payment', amt: 7500, desc: 'Uber ride (demo)', cat: 'transport', meta: { payee: 'Uber' } },
  { d: 14, type: 'card_payment', amt: 22000, desc: 'Shoprite groceries (demo)', cat: 'shopping', meta: { payee: 'Shoprite' } },
  { d: 18, type: 'card_payment', amt: 9000, desc: 'Suya Spot (demo)', cat: 'food', meta: { payee: 'Suya Spot' }, foodBoost: true },
];

export async function loadSampleData(userId) {
  return withTx(async (c) => {
    const done = await c.query(`SELECT 1 FROM audit_log WHERE actor_id=$1 AND action='demo.sample'`, [userId]);
    if (done.rowCount) throw new AppError(409, 'ALREADY_LOADED', 'Sample history was already loaded for this account.');
    const wallet = await walletOf(c, userId);
    const settlement = await systemAccount(c, 'settlement', 'NGN');
    await c.query('SELECT id FROM accounts WHERE id = ANY($1::uuid[]) ORDER BY id FOR UPDATE', [[wallet, settlement]]);
    const now = new Date();
    for (const offset of [2, 1, 0]) {
      for (const it of ITEMS) {
        const day = offset === 0 ? Math.min(it.d, now.getUTCDate()) : it.d;
        const when = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - offset, day, 9, 30));
        if (when > now) continue;
        const amt = Math.round(it.amt * (offset === 0 && it.foodBoost ? 1.6 : 1)) * 100;
        const t = (await c.query(
          `INSERT INTO transactions(reference, type, initiator_user_id, amount_minor, currency, description,
                                    provider, is_demo, category, meta, created_at)
           VALUES ($1,$2,$3,$4,'NGN',$5,'sample_data',TRUE,$6,$7,$8) RETURNING id`,
          [newReference(), it.type, userId, amt, it.desc, it.cat, JSON.stringify(it.meta || {}), when])).rows[0];
        await walkStates(c, t.id, ['pending_authorisation', 'authorised', 'processing']);
        const inflow = it.dir === 'in';
        await postEntry(c, { transactionId: t.id, description: it.desc, createdAt: when, postings: [
          { accountId: inflow ? settlement : wallet, direction: 'debit', amountMinor: amt, currency: 'NGN' },
          { accountId: inflow ? wallet : settlement, direction: 'credit', amountMinor: amt, currency: 'NGN' },
        ] });
        await walkStates(c, t.id, ['completed']);
      }
    }
    for (const [cat, limit] of [['food', 30000], ['transport', 15000], ['shopping', 25000], ['entertainment', 5000]]) {
      await c.query(`INSERT INTO budgets(user_id, category, monthly_limit_minor) VALUES ($1,$2,$3)
                     ON CONFLICT (user_id, category) DO NOTHING`, [userId, cat, limit * 100]);
    }
    await c.query(`INSERT INTO audit_log(actor_type, actor_id, action) VALUES ('user',$1,'demo.sample')`, [userId]);
  });
}
