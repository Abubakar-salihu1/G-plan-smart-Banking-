// Spending insights computed only from the user's own recorded transactions.
import { pool } from '../db.js';
import { walletRows, monthRange } from './queries.js';
import { walletOf, availableBalance } from './ledger.js';

const SPEND = new Set(['bill_payment', 'external_transfer', 'internal_transfer', 'card_payment', 'international_transfer']);

export function classify(r) {
  if (r.type === 'goal_contribution') return 'save';
  if (r.type === 'fx_conversion' || r.type === 'fee') return 'other';
  if (r.net_minor > 0) return 'income';
  if (r.net_minor < 0 && SPEND.has(r.type)) return 'spend';
  return 'other';
}

function aggregate(rows) {
  let income = 0, spending = 0, saved = 0;
  const cats = new Map();
  for (const r of rows) {
    const k = classify(r);
    if (k === 'income') income += r.net_minor;
    else if (k === 'spend') {
      spending += -r.net_minor;
      const c = r.category || 'other';
      cats.set(c, (cats.get(c) || 0) + -r.net_minor);
    } else if (k === 'save') saved += -r.net_minor;
  }
  return { income, spending, saved, cats };
}

const inRange = (r, a, b) => { const t = new Date(r.created_at).toISOString(); return t >= a && t < b; };
const median = (a) => { const s = [...a].sort((x, y) => x - y); return s.length ? s[Math.floor(s.length / 2)] : 0; };
const addMonth = (d) => new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate()));

export function detectRecurring(spendRows) {
  const groups = new Map();
  for (const r of spendRows) {
    const key = String(r.meta?.payee || r.meta?.biller || r.description || '').toLowerCase().trim();
    if (!key) continue;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(r);
  }
  const out = [];
  for (const [key, list] of groups) {
    if (list.length < 3) continue;
    list.sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
    const amounts = list.map((r) => -r.net_minor);
    const med = median(amounts);
    if (!amounts.every((a) => Math.abs(a - med) <= med * 0.1)) continue;
    const gaps = [];
    for (let i = 1; i < list.length; i++) gaps.push((new Date(list[i].created_at) - new Date(list[i - 1].created_at)) / 86400000);
    const g = median(gaps);
    const every = g >= 25 && g <= 35 ? 'month' : g >= 6 && g <= 8 ? 'week' : null;
    if (!every) continue;
    const last = list[list.length - 1];
    out.push({ name: last.meta?.payee || last.description || key, amountMinor: med, every,
      occurrences: list.length, lastDate: last.created_at, category: last.category || 'other',
      kind: last.category === 'entertainment' ? 'subscription' : 'recurring payment' });
  }
  return out.sort((a, b) => b.amountMinor - a.amountMinor);
}

function occurrences(nextRunOn, frequency, horizonDays = 30) {
  let d = new Date(nextRunOn + 'T00:00:00Z');
  const end = Date.now() + horizonDays * 86400000;
  let n = 0;
  while (d.getTime() <= end && n < 10) {
    n++;
    if (frequency === 'once') break;
    d = frequency === 'weekly' ? new Date(d.getTime() + 7 * 86400000) : addMonth(d);
  }
  return n;
}

export async function upcomingObligations(userId) {
  const sp = (await pool.query(
    `SELECT amount_minor, frequency, next_run_on FROM scheduled_payments WHERE user_id=$1 AND status='active'`, [userId])).rows;
  const sr = (await pool.query(
    `SELECT amount_minor, frequency, next_run_on FROM savings_rules WHERE user_id=$1 AND status='active'`, [userId])).rows;
  let total = 0;
  for (const x of [...sp, ...sr]) total += x.amount_minor * occurrences(x.next_run_on, x.frequency);
  return total;
}

export function healthScore({ cur, budgetsStatus }) {
  const factors = [];
  const { income, spending, saved } = cur;
  if (income <= 0 && spending <= 0) return { score: null, note: 'Not enough activity this month to calculate a score yet.', factors };
  let score = 0, max = 0;
  if (income > 0) {
    const rate = saved / income;
    const pts = Math.round(Math.min(1, rate / 0.2) * 40);
    score += pts; max += 40;
    factors.push({ name: 'Saving habit', points: pts, outOf: 40,
      why: `You set aside ${Math.round(rate * 100)}% of this month's income. 20% or more earns full points.` });
    const flow = spending <= income ? 30 : Math.max(0, Math.round(30 * (income / spending)));
    score += flow; max += 30;
    factors.push({ name: 'Cash flow', points: flow, outOf: 30,
      why: spending <= income ? 'You spent less than you received this month.' : 'You spent more than you received this month.' });
  }
  if (budgetsStatus.length) {
    const ok = budgetsStatus.filter((b) => b.spentMinor <= b.budgetMinor).length;
    const pts = Math.round((ok / budgetsStatus.length) * 30);
    score += pts; max += 30;
    factors.push({ name: 'Budget adherence', points: pts, outOf: 30,
      why: `${ok} of ${budgetsStatus.length} budgets are within their limit.` });
  }
  return { score: max ? Math.round((score / max) * 100) : null,
    note: 'A simple score from your own activity. It is not a credit rating and is not shared with lenders.', factors };
}

export async function insights(userId, month) {
  const rng = monthRange(month);
  const since = new Date(Date.now() - 120 * 86400000).toISOString();
  const from = rng.prevStart < since ? rng.prevStart : since;
  const rows = await walletRows(pool, userId, { from, limit: 3000, order: 'ASC' });
  const cur = aggregate(rows.filter((r) => inRange(r, rng.start, rng.end)));
  const prev = aggregate(rows.filter((r) => inRange(r, rng.prevStart, rng.start)));
  const budgets = (await pool.query('SELECT category, monthly_limit_minor FROM budgets WHERE user_id=$1', [userId])).rows;
  const budgetMap = new Map(budgets.map((b) => [b.category, b.monthly_limit_minor]));
  const cats = new Set([...cur.cats.keys(), ...budgetMap.keys()]);
  const byCategory = [...cats].map((category) => ({
    category, spentMinor: cur.cats.get(category) || 0, budgetMinor: budgetMap.get(category) || null,
    prevMinor: prev.cats.get(category) || 0,
  })).sort((a, b) => b.spentMinor - a.spentMinor);
  const budgetsStatus = byCategory.filter((c) => c.budgetMinor);
  const spendRows = rows.filter((r) => classify(r) === 'spend');
  const topExpenses = spendRows.filter((r) => inRange(r, rng.start, rng.end))
    .sort((a, b) => a.net_minor - b.net_minor).slice(0, 5)
    .map((r) => ({ reference: r.reference, description: r.description, category: r.category || 'other',
      amountMinor: -r.net_minor, date: r.created_at }));

  const wallet = await walletOf(pool, userId);
  const available = wallet ? await availableBalance(pool, wallet) : 0;
  const last30 = spendRows.filter((r) => Date.now() - new Date(r.created_at).getTime() <= 30 * 86400000)
    .reduce((s, r) => s + -r.net_minor, 0);
  const avgDaily = Math.round(last30 / 30);
  const upcoming = await upcomingObligations(userId);
  const free = Math.max(0, available - upcoming);
  const forecast = {
    isEstimate: true, availableMinor: available, upcomingMinor: upcoming, safeToSpendMinor: free,
    avgDailySpendMinor: avgDaily, runwayDays: avgDaily > 0 ? Math.floor(free / avgDaily) : null,
  };
  return {
    month: rng.month,
    income: cur.income, spending: cur.spending, saved: cur.saved,
    prev: { income: prev.income, spending: prev.spending, saved: prev.saved },
    byCategory, budgets: budgets.map((b) => ({ category: b.category, limitMinor: b.monthly_limit_minor })),
    topExpenses, forecast, recurring: detectRecurring(spendRows),
    health: healthScore({ cur, budgetsStatus }),
  };
}
