// Paystack adapter for REAL bank transfers. DISABLED unless PAYMENT_PROVIDER=paystack.
// NOT production-ready: it is untested against the live API. Use TEST keys only until you have a
// regulated business account, completed Paystack's go-live checks, and reviewed this code with a
// qualified engineer. G-Plan itself holds no licence. Real money movement carries legal responsibility.
import crypto from 'node:crypto';
import { AppError } from '../errors.js';

const base = 'https://api.paystack.co';
const key = () => process.env.PAYSTACK_SECRET_KEY;
const headers = () => ({ Authorization: `Bearer ${key()}`, 'Content-Type': 'application/json' });
export const enabled = () => (process.env.PAYMENT_PROVIDER || 'mock') === 'paystack' && !!key();

export async function resolveAccount(accountNumber, bankCode) {
  const r = await fetch(`${base}/bank/resolve?account_number=${encodeURIComponent(accountNumber)}&bank_code=${encodeURIComponent(bankCode)}`, { headers: headers(), signal: AbortSignal.timeout(10_000) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok || !d.status) throw new AppError(422, 'NAME_ENQUIRY_FAILED', 'Could not verify that account.');
  return d.data.account_name;
}

// Provider function for payExternal. Pending/OTP responses stay unconfirmed until the webhook arrives.
export async function transferProvider({ reference, amountMinor, meta }) {
  const rec = await fetch(`${base}/transferrecipient`, { method: 'POST', headers: headers(), signal: AbortSignal.timeout(15_000), body: JSON.stringify({
    type: 'nuban', name: meta.accountName, account_number: meta.accountNumber, bank_code: meta.bankCode, currency: 'NGN' }) });
  const rd = await rec.json().catch(() => ({}));
  if (!rec.ok || !rd.status) return { ok: false, reason: 'The recipient could not be set up.' };
  const tr = await fetch(`${base}/transfer`, { method: 'POST', headers: headers(), signal: AbortSignal.timeout(15_000), body: JSON.stringify({
    source: 'balance', amount: amountMinor, recipient: rd.data.recipient_code, reference: reference.toLowerCase(), reason: 'G-Plan transfer' }) });
  const td = await tr.json().catch(() => ({}));
  if (!tr.ok || !td.status) return { ok: false, reason: td.message || 'The transfer was declined.' };
  if (td.data.status === 'success') return { ok: true, providerRef: td.data.transfer_code };
  if (td.data.status === 'failed' || td.data.status === 'reversed') return { ok: false, reason: 'The transfer failed.' };
  return { unconfirmed: true };
}

export function verifyWebhook(rawBody, signature) {
  if (!key() || !signature) return false;
  const h = crypto.createHmac('sha512', key()).update(rawBody).digest('hex');
  const a = Buffer.from(h), b = Buffer.from(String(signature));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
