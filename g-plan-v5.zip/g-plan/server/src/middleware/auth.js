import crypto from 'node:crypto';
import jwt from 'jsonwebtoken';
import { pool } from '../db.js';
import { config } from '../config.js';
import { AppError } from '../errors.js';

export function signToken(userId, sid) {
  return jwt.sign({ sub: userId, sid }, config.jwtSecret, { expiresIn: '15m', algorithm: 'HS256', issuer: 'gplan-api', audience: 'gplan-app' });
}

export const sha256 = (v) => crypto.createHash('sha256').update(String(v)).digest('hex');
export function safeEqual(a, b) {
  if (!a || !b) return false;
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

const COOKIE = 'gp_rt';
const cookieOpts = () => ({ httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict', path: '/api/auth' });
export const REFRESH_DAYS = 7;
export const SESSION_MAX_DAYS = 30;

export function setRefreshCookie(res, sid, secret) {
  res.cookie(COOKIE, `${sid}.${secret}`, { ...cookieOpts(), maxAge: REFRESH_DAYS * 86400 * 1000 });
}
export const clearRefreshCookie = (res) => res.clearCookie(COOKIE, cookieOpts());
export function readRefreshCookie(req) {
  const m = new RegExp(`(?:^|;\\s*)${COOKIE}=([^;]+)`).exec(req.headers.cookie || '');
  if (!m) return null;
  const [sid, secret] = decodeURIComponent(m[1]).split('.');
  return sid && secret ? { sid, secret } : null;
}

// Creates a session and returns a short-lived access token. When `res` is given, also sets the
// httpOnly refresh cookie (the long-lived secret never reaches JavaScript).
export async function createSession(db, userId, req, method = 'password', res = null) {
  const secret = crypto.randomBytes(32).toString('base64url');
  const r = await db.query(
    `INSERT INTO sessions(user_id, device_id, user_agent, ip, method, refresh_hash, refresh_expires_at)
     VALUES ($1,$2,$3,$4,$5,$6, now() + interval '${REFRESH_DAYS} days') RETURNING id`,
    [userId, (req.get('x-device-id') || '').slice(0, 64) || null,
      (req.get('user-agent') || '').slice(0, 200), req.ip, method, sha256(secret)]);
  const sid = r.rows[0].id;
  if (res) setRefreshCookie(res, sid, secret);
  return signToken(userId, sid);
}

export async function requireAuth(req, _res, next) {
  if (req.user) return next();   // several routers share this guard; check once per request
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) throw new AppError(401, 'UNAUTHENTICATED', 'Please sign in.');
    let payload;
    try { payload = jwt.verify(token, config.jwtSecret, { algorithms: ['HS256'], issuer: 'gplan-api', audience: 'gplan-app' }); }
    catch { throw new AppError(401, 'SESSION_EXPIRED', 'Your session expired. Please sign in again.'); }
    if (!payload.sid) throw new AppError(401, 'SESSION_EXPIRED', 'Your session expired. Please sign in again.');
    const r = await pool.query(
      `SELECT s.id, s.device_id, s.created_at, u.status, u.role, u.mfa_method
       FROM sessions s JOIN users u ON u.id = s.user_id
       WHERE s.id=$1 AND s.user_id=$2 AND s.revoked_at IS NULL`, [payload.sid, payload.sub]);
    const s = r.rows[0];
    if (!s || s.status === 'closed') throw new AppError(401, 'SESSION_ENDED', 'This session has ended. Please sign in again.');
    req.user = { id: payload.sub, role: s.role, mfaEnabled: !!s.mfa_method, mfaMethod: s.mfa_method };
    req.session = { id: s.id, deviceId: s.device_id, createdAt: s.created_at };
    pool.query(`UPDATE sessions SET last_seen_at=now() WHERE id=$1 AND last_seen_at < now() - interval '1 minute'`, [s.id]).catch(() => {});
    next();
  } catch (e) { next(e); }
}
