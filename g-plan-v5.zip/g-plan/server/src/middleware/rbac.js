import { config } from '../config.js';
import { AppError } from '../errors.js';

// Strict role-based access. No single role can do everything:
// - admin can read the audit log and approve reversals, but cannot review KYC, cheques or restrict customers.
// - the person who requests a reversal can never be the one who approves it.
export const PERMS = {
  support: ['customers.read', 'service.handle', 'disputes.handle', 'reversals.request', 'transactions.read', 'support.chat'],
  ops: ['transactions.read', 'cheques.review', 'reversals.request', 'ops.read', 'ops.act'],
  compliance: ['customers.read', 'customers.restrict', 'kyc.review', 'risk.read', 'transactions.read', 'payments.review'],
  admin: ['audit.read', 'reversals.read', 'reversals.approve', 'customers.read', 'transactions.read', 'ops.read'],
};

export const can = (role, perm) => (PERMS[role] || []).includes(perm);

export function requireStaff(req, _res, next) {
  if (!PERMS[req.user.role]) return next(new AppError(403, 'FORBIDDEN', 'This area is for G-Plan staff only.'));
  if (config.adminRequireMfa && !req.user.mfaEnabled) {
    return next(new AppError(403, 'STAFF_MFA_REQUIRED', 'Turn on two-step verification before using the admin console.'));
  }
  next();
}
