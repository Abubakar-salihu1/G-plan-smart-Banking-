import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import { config } from './config.js';
import { pool } from './db.js';
import { errorHandler, wrap } from './errors.js';
import { inc, renderMetrics } from './services/monitor.js';
import authRoutes from './routes/auth.js';
import accountRoutes from './routes/accounts.js';
import transferRoutes from './routes/transfers.js';
import billRoutes from './routes/bills.js';
import requestRoutes from './routes/requests.js';
import goalRoutes from './routes/goals.js';
import insightRoutes from './routes/insights.js';
import cardRoutes from './routes/cards.js';
import securityRoutes from './routes/security.js';
import adminRoutes from './routes/admin.js';
import businessRoutes from './routes/business.js';
import { paystackWebhook, flutterwaveWebhook } from './routes/webhooks.js';
import kycDocRoutes from './routes/kycdocs.js';
import pushRoutes from './routes/push.js';
import pocketRoutes from './routes/pockets.js';
import receiptRoutes from './routes/receipts.js';
import bulkRoutes from './routes/bulk.js';
import mandateRoutes from './routes/mandates.js';
import supportRoutes from './routes/support.js';

export const app = express();
// Only trust X-Forwarded-For when you really are behind a proxy (set TRUST_PROXY=1 on Render, Heroku, etc.).
// Otherwise anyone could fake their IP and dodge the rate limits.
if (process.env.TRUST_PROXY) app.set('trust proxy', /^\d+$/.test(process.env.TRUST_PROXY) ? Number(process.env.TRUST_PROXY) : process.env.TRUST_PROXY);
app.disable('x-powered-by');

// Structured request logs (no bodies, no query strings, no tokens) and metrics.
app.use((req, res, next) => {
  const start = Date.now();
  const id = crypto.randomUUID();
  res.setHeader('X-Request-Id', id);
  res.on('finish', () => {
    inc('gplan_http_requests_total', { status: String(res.statusCode) });
    if (process.env.LOG_REQUESTS !== 'false') {
      console.log(JSON.stringify({ t: new Date().toISOString(), id, m: req.method, p: req.path, s: res.statusCode, ms: Date.now() - start }));
    }
  });
  next();
});

app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: false,
    directives: {
      defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", 'https://fonts.googleapis.com'],
      styleSrcAttr: ["'unsafe-inline'"], fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      imgSrc: ["'self'", 'data:', 'blob:'], connectSrc: ["'self'"], frameAncestors: ["'none'"], objectSrc: ["'none'"], baseUri: ["'self'"],
    },
  },
  referrerPolicy: { policy: 'no-referrer' },
}));
app.use(cors({ origin: config.clientOrigin }));

const mult = Number(process.env.RATE_LIMIT_MULTIPLIER) || 1;
const limiter = (windowMs, limit, extra = {}) => rateLimit({ windowMs, limit: limit * mult, standardHeaders: true, legacyHeaders: false, ...extra });

// Webhooks need the raw body to check signatures, so they come before the JSON parser.
app.post('/api/webhooks/paystack', express.raw({ type: '*/*', limit: '200kb' }), wrap(paystackWebhook));
app.post('/api/webhooks/flutterwave', express.raw({ type: '*/*', limit: '200kb' }), wrap(flutterwaveWebhook));
// KYC photos arrive as raw image bytes (not JSON). The rate limit runs first so an anonymous caller cannot make
// the server buffer large bodies; the route itself then requires sign-in before reading anything.
app.use('/api/kyc/documents', limiter(60 * 1000, 12), express.raw({ type: ['image/jpeg', 'image/png'], limit: config.kycDocMaxBytes }));
app.use('/api/receipts/scan', limiter(60 * 1000, 10), express.raw({ type: ['image/jpeg', 'image/png'], limit: config.kycDocMaxBytes }));
app.use(express.json({ limit: '50kb' }));

app.get('/api/health', (_req, res) => res.json({ ok: true, mode: 'prototype', integrations: 'mock', demo: config.demoFunding }));
app.get('/api/ready', wrap(async (_req, res) => {
  await pool.query('SELECT 1');
  res.json({ ready: true });
}));
app.get('/api/metrics', (req, res) => {
  const t = process.env.METRICS_TOKEN;
  if (!t) return res.status(404).end();
  if (req.get('x-metrics-token') !== t) return res.status(401).end();
  res.type('text/plain').send(renderMetrics());
});

// Session refresh happens on every page load and every 15 minutes, so it gets its own, looser limit and
// does not eat into the strict limit that protects sign-in, codes and password reset.
app.use('/api/auth', limiter(15 * 60 * 1000, 40, { skip: (req) => req.path === '/refresh' }));
app.use('/api/auth/refresh', limiter(15 * 60 * 1000, 300));
app.use('/api/auth', authRoutes);
app.use('/api/transfers', limiter(60 * 1000, 30));
app.use('/api/bills/pay', limiter(60 * 1000, 30));
app.use('/api', limiter(60 * 1000, 180),
  accountRoutes, transferRoutes, billRoutes, requestRoutes, goalRoutes, insightRoutes, cardRoutes, securityRoutes, businessRoutes, kycDocRoutes, pushRoutes, pocketRoutes, receiptRoutes, bulkRoutes, mandateRoutes, supportRoutes, adminRoutes);

app.use('/api', (_req, res) => res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Not found.' } }));

// Serve the built client when present (single-service deployment).
const dist = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../client/dist');
if (fs.existsSync(path.join(dist, 'index.html'))) {
  app.use(express.static(dist, { maxAge: '1h', index: false }));
  app.get(/^\/(?!api).*/, (_req, res) => res.sendFile(path.join(dist, 'index.html')));
}

app.use(errorHandler);
