// Support chat helpers. Pure functions (no database).

// Questions people ask most. Shown before they open a chat, so many never need to wait for a person.
export const FAQ = [
  { id: 'lost-phone', words: ['lost', 'phone', 'code', 'locked', 'two-step', '2fa', 'authenticator', 'recovery'], q: 'I lost my phone and cannot get my code', a: 'On the sign-in code screen, choose "Lost your phone? Use a recovery code" and enter one of the recovery codes you saved when you turned on two-step verification. Each works once. Then open Security and make a new set. If you have no codes, open a chat with us.' },
  { id: 'forgot-password', words: ['forgot', 'password', 'reset', 'cannot', 'login', 'sign'], q: 'I forgot my password', a: 'On the sign-in screen choose "Forgot password". We email you a code. Resetting signs out every device.' },
  { id: 'transfer-pending', words: ['transfer', 'pending', 'not', 'received', 'processing', 'unconfirmed', 'delay'], q: 'My transfer is pending or the person has not received it', a: 'Open Activity and check the status. "Processing" or "waiting for confirmation" means the bank has not answered yet: your money is reserved, not lost, and it settles or returns on its own. If it is still pending after a few hours, open a chat and include the reference (it starts with GP-).' },
  { id: 'limit', words: ['limit', 'daily', 'exceeded', 'raise', 'higher', 'tier', 'kyc', 'verify', 'verification'], q: 'How do I raise my limits?', a: 'Open Security and complete the next identity level. Higher levels have higher limits. Level 2 and 3 are reviewed by a person, which can take a day or two.' },
  { id: 'debit', words: ['direct', 'debit', 'mandate', 'cancel', 'subscription', 'collect', 'charged'], q: 'I want to stop a direct debit', a: 'Open More, then Direct debits, choose it and press "Cancel direct debit". It needs no password and takes effect at once. Nothing more is collected.' },
  { id: 'fraud', words: ['fraud', 'stolen', 'scam', 'hacked', 'unauthorised', 'unauthorized', 'not', 'me', 'stranger'], q: 'I think someone else used my account', a: 'Change your password now in Security, sign out other devices, and freeze your cards in Cards. Then open a chat and tell us what you saw. Never share your password, codes or card details with anyone, including us.' },
  { id: 'card', words: ['card', 'freeze', 'block', 'virtual', 'limit', 'declined'], q: 'My card was declined or I want to freeze it', a: 'Open Cards. You can freeze a card, change its limits and see why a payment was declined.' },
  { id: 'refund', words: ['refund', 'wrong', 'mistake', 'dispute', 'reverse', 'reversal', 'sent'], q: 'I sent money to the wrong person', a: 'Open the payment in Activity and choose to report a problem. Payments to another person cannot be undone by us without their agreement, but we will help. Include the reference in a chat.' },
  { id: 'statement', words: ['statement', 'pdf', 'csv', 'download', 'tax', 'summary', 'year'], q: 'Where is my statement?', a: 'Open Activity and statements. Pick a month to download a PDF or CSV, or open "Yearly summary" for a year of totals.' },
  { id: 'delete', words: ['delete', 'close', 'account', 'remove', 'privacy', 'data'], q: 'How do I close my account or delete my data?', a: 'Open Profile and help, then Privacy. Your balance must be zero. Some records must be kept for a period the law requires.' },
];

const norm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9\s-]/g, ' ').split(/\s+/).filter((w) => w.length > 1);
// Best matches first. A match needs at least two shared words so a single common word does not bring back noise.
export function suggestFaq(query, limit = 3) {
  const words = new Set(norm(query));
  if (words.size === 0) return [];
  return FAQ.map((f) => ({ f, score: f.words.filter((w) => words.has(w)).length })).filter((x) => x.score >= 2)
    .sort((a, b) => b.score - a.score).slice(0, limit).map((x) => ({ id: x.f.id, q: x.f.q, a: x.f.a }));
}

const luhn = (digits) => { let sum = 0; let alt = false; for (let i = digits.length - 1; i >= 0; i--) { let n = Number(digits[i]); if (alt) { n *= 2; if (n > 9) n -= 9; } sum += n; alt = !alt; } return sum % 10 === 0; };

// Customers should never paste secrets into a chat that many staff can read. Returns a reason, or null.
export function findSecret(text) {
  const t = String(text || '');
  for (const m of t.matchAll(/\b(?:\d[ -]?){13,19}\b/g)) { const d = m[0].replace(/\D/g, ''); if (d.length >= 13 && d.length <= 19 && luhn(d)) return 'a card number'; }
  if (/\b(?:my\s+)?(?:password|passcode|pin)\s*(?:is|:|=)\s*\S+/i.test(t)) return 'a password or PIN';
  if (/\b(?:otp|code|token)\s*(?:is|:|=)\s*\d{4,8}\b/i.test(t)) return 'a verification code';
  for (const tok of t.split(/[\s,;]+/)) if (/^[A-HJKMNP-Za-hjkmnp-z2-9]{4}(-?[A-HJKMNP-Za-hjkmnp-z2-9]{4}){3}$/.test(tok) && /\d/.test(tok) && /[a-z]/i.test(tok)) return 'a recovery code';
  return null;
}
