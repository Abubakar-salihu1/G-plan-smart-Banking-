// Checks what the receipt reader (or the person) typed before anything is saved. The reader's output is treated as
// untrusted text: text printed on a receipt can say anything, so only these fields are ever used, and only after checking.
export const RECEIPT_CATEGORIES = ['groceries', 'food', 'transport', 'shopping', 'health', 'bills', 'entertainment', 'education', 'other'];

export function parseReceipt(raw, now = new Date()) {
  if (!raw || typeof raw !== 'object') throw new Error('We could not read that receipt.');
  const merchant = String(raw.merchant ?? '').replace(/[\u0000-\u001f\u007f<>]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80);
  if (merchant.length < 1) throw new Error('Add the shop or business name.');
  const cur = String(raw.currency ?? 'NGN').toUpperCase();
  if (cur !== 'NGN' && cur !== '₦' && cur !== 'NAIRA') throw new Error('Only naira receipts are supported for now.');

  let totalMinor;
  if (raw.totalMinor !== undefined) totalMinor = Number(raw.totalMinor);
  else {
    const t = typeof raw.total === 'string' ? Number(raw.total.replace(/[,\s₦]/g, '')) : Number(raw.total);
    totalMinor = Math.round(t * 100);
  }
  if (!Number.isSafeInteger(totalMinor) || totalMinor <= 0 || totalMinor > 1_000_000_000_00) throw new Error('Enter the total amount.');

  let date = null;
  if (typeof raw.date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(raw.date)) {
    const d = new Date(raw.date + 'T00:00:00Z');
    const ok = !isNaN(d) && d.toISOString().slice(0, 10) === raw.date && d <= new Date(now.getTime() + 86400000) && d >= new Date(now.getTime() - 2 * 365 * 86400000);
    if (ok) date = raw.date;
  }
  const category = RECEIPT_CATEGORIES.includes(raw.category) ? raw.category : 'other';
  return { merchant, totalMinor, date, category };
}

// The reader may wrap the JSON in words. Take the outermost braces and parse that, nothing else.
export function jsonFrom(text) {
  const s = String(text || ''); const a = s.indexOf('{'); const b = s.lastIndexOf('}');
  if (a < 0 || b <= a) throw new Error('We could not read that receipt.');
  try { return JSON.parse(s.slice(a, b + 1)); } catch { throw new Error('We could not read that receipt.'); }
}
