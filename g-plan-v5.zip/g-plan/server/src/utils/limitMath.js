// Pure limit rules (no database), so they can be tested on their own.
// A business is limited as ONE customer: its owner's verification level sets the ceiling, and the owner may set a lower
// business-wide daily cap that applies to everyone on the team together.
export const effectiveDailyLimit = (tierLimitMinor, capMinor) =>
  capMinor === null || capMinor === undefined ? Number(tierLimitMinor) : Math.min(Number(tierLimitMinor), Number(capMinor));

// Would paying amountMinor take today's total over the limit?
export const overDailyLimit = (usedMinor, amountMinor, limitMinor) => Number(usedMinor) + Number(amountMinor) > Number(limitMinor);

// How much is left today, never below zero.
export const remainingToday = (usedMinor, limitMinor) => Math.max(0, Number(limitMinor) - Number(usedMinor));
