// Pure checks for push subscriptions (no database, no config), so they can be tested on their own.
const HOSTS = ['fcm.googleapis.com', 'updates.push.services.mozilla.com', 'web.push.apple.com'];
const SUFFIXES = ['.push.apple.com', '.notify.windows.com', '.push.services.mozilla.com'];

// The browser tells us where to POST. Without a check that would let a signed-in user make the server call any
// URL (SSRF), so only the known push services are accepted (add more with PUSH_ENDPOINT_HOSTS).
export function endpointAllowed(raw, extraHosts = []) {
  let u;
  try { u = new URL(String(raw)); } catch { return false; }
  if (u.protocol !== 'https:' || u.username || u.password || (u.port && u.port !== '443')) return false;
  const h = u.hostname.toLowerCase();
  if (/^[\d.]+$/.test(h) || h.includes(':')) return false;   // no IP literals
  return HOSTS.includes(h) || SUFFIXES.some((s) => h.endsWith(s)) || extraHosts.includes(h);
}

export const validKey = (v, min, max) => typeof v === 'string' && /^[A-Za-z0-9_-]+$/.test(v) && v.length >= min && v.length <= max;
