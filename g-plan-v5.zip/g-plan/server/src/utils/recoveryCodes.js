// Recovery codes: ten one-time codes shown once when two-step verification is turned on.
// 16 characters from a 31-letter alphabet (about 79 bits), so guessing is hopeless, and no look-alike characters
// (no 0, 1, I, L, O) so they are easy to copy from paper. Pure functions, no database.
import crypto from 'node:crypto';

const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
export const CODE_COUNT = 10;

const one = () => {
  let s = '';
  while (s.length < 16) { const b = crypto.randomBytes(1)[0]; if (b < 248) s += ALPHABET[b % ALPHABET.length]; }   // 248 = 31 x 8: no modulo bias
  return s;
};
export const format = (raw) => raw.match(/.{4}/g).join('-');

export function generateCodes(n = CODE_COUNT) {
  const set = new Set();
  while (set.size < n) set.add(one());
  return [...set];   // raw, 16 characters; show with format()
}

// What the person typed, in any case, with or without dashes or spaces. Null if it cannot be a recovery code.
export function normalize(input) {
  const s = String(input ?? '').toUpperCase().replace(/[\s-]/g, '');
  return /^[A-HJKMNP-Z2-9]{16}$/.test(s) ? s : null;
}
export const looksLikeRecovery = (input) => normalize(input) !== null;
