// What counts as an operational problem, and when to say so. Pure functions (no database) so they can be tested.
// "page" = act now, money or customers are affected. "warn" = look at it today.
export const T = {
  unconfirmedMin: 30,      // a bank transfer with no answer from the provider
  processingMin: 15,       // a payment stuck mid-way (usually a crash): money reserved, outcome never recorded
  heldHours: 4,            // customers waiting on a review
  bulkStuckHours: 2,       // a batch that is "running" but not moving
  approvalHours: 24,       // payouts and batches waiting for an owner
  reversalHours: 24,
  kycHours: 48,
  supportHours: 24,        // a customer message nobody has answered
  jobsStaleMin: 10,        // the background job loop has not finished a run
};

const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;

// s: counts from opsSnapshot. Returns the list of problems that exist right now.
export function evaluateOps(s) {
  const out = []; const add = (key, severity, text) => out.push({ key, severity, text });
  if (s.integrityOk === false) add('integrity', 'page', 'Ledger or audit integrity check FAILED. Stop and investigate before anything else.');
  if (s.processingOld > 0) add('processing_stuck', 'page', `${plural(s.processingOld, 'payment is', 'payments are')} stuck mid-way for over ${T.processingMin} minutes. The customer's money is reserved but the outcome was never recorded. Check Stuck and failed money in the admin console.`);
  if (s.unconfirmedOld > 0) add('unconfirmed', 'page', `${plural(s.unconfirmedOld, 'bank transfer has', 'bank transfers have')} had no answer from the provider for over ${T.unconfirmedMin} minutes. Check the provider dashboard, then Recheck in the admin console.`);
  if (s.jobsStaleMinutes !== null && s.jobsStaleMinutes !== undefined && s.jobsStaleMinutes > T.jobsStaleMin) add('jobs_stale', 'page', `Background jobs have not finished a run for ${Math.round(s.jobsStaleMinutes)} minutes. Scheduled payments, payroll, round-ups and alerts are not running.`);
  if (s.heldOld > 0) add('held_old', 'warn', `${plural(s.heldOld, 'payment has', 'payments have')} waited over ${T.heldHours} hours in the held-payments review queue. Customers are waiting.`);
  if (s.bulkStuck > 0) add('bulk_stuck', 'warn', `${plural(s.bulkStuck, 'bulk or payroll batch has', 'bulk or payroll batches have')} been "running" for over ${T.bulkStuckHours} hours without finishing.`);
  if (s.failedBulkItems24h > 0) add('bulk_failed', 'warn', `${plural(s.failedBulkItems24h, 'payroll or bulk payment', 'payroll or bulk payments')} failed in the last 24 hours. Open Stuck and failed money to see why. People may be waiting for their salary.`);
  if (s.approvalsOld > 0) add('approvals_old', 'warn', `${plural(s.approvalsOld, 'business payout or batch is', 'business payouts or batches are')} waiting over ${T.approvalHours} hours for an owner to approve.`);
  if (s.reversalsOld > 0) add('reversals_old', 'warn', `${plural(s.reversalsOld, 'reversal request has', 'reversal requests have')} waited over ${T.reversalHours} hours for approval.`);
  if (s.kycOld > 0) add('kyc_old', 'warn', `${plural(s.kycOld, 'identity check has', 'identity checks have')} waited over ${T.kycHours} hours for review.`);
  if (s.supportOld > 0) add('support_old', 'warn', `${plural(s.supportOld, 'customer chat has', 'customer chats have')} gone unanswered for over ${T.supportHours} hours.`);
  return out;
}

// Say it when it is new or has come back; remind a "page" hourly and a "warn" every 12 hours; never more often.
export function shouldSend(prev, severity, nowMs) {
  if (!prev || prev.resolved_at) return true;
  const every = severity === 'page' ? 60 * 60_000 : 12 * 60 * 60_000;
  return nowMs - new Date(prev.last_sent_at).getTime() >= every;
}
