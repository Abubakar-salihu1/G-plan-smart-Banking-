// Reads and checks a bulk-payout CSV. Pure functions, no database. Nothing is sent from here: the file is
// checked completely first, and if ANY row is wrong the whole file is refused so no one is half-paid by mistake.
export const MAX_ROWS = 200;
export const MAX_CHARS = 40_000;
const COLUMNS = ['name', 'bank_code', 'account_number', 'email', 'amount', 'note'];

// Splits CSV text into rows of fields. Handles quotes, doubled quotes, commas and line breaks inside quotes, BOM, CRLF.
export function parseCsv(text) {
  const s = String(text ?? '').replace(/^\uFEFF/, '');
  const rows = []; let row = []; let field = ''; let q = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (q) {
      if (c === '"') { if (s[i + 1] === '"') { field += '"'; i++; } else q = false; } else field += c;
    } else if (c === '"' && field === '') q = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && s[i + 1] === '\n') i++; row.push(field); field = ''; rows.push(row); row = []; }
    else field += c;
  }
  if (q) throw new Error('The file has a quote that is never closed.');
  if (field !== '' || row.length) { row.push(field); rows.push(row); }
  return rows.filter((r) => r.some((x) => x.trim() !== ''));
}

// "12,500.50" -> 1250050 kobo. Rejects anything that is not a plain amount with at most two decimals.
export function amountToMinor(v) {
  const t = String(v ?? '').replace(/[,\s₦]/g, '');
  if (!/^\d+(\.\d{1,2})?$/.test(t)) return null;
  const [w, f = ''] = t.split('.');
  const minor = Number(w) * 100 + Number((f + '00').slice(0, 2));
  return Number.isSafeInteger(minor) && minor > 0 && minor <= 1_000_000_000_00 ? minor : null;
}

const clean = (v, n) => String(v ?? '').replace(/[\u0000-\u001f\u007f<>]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n);
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

// Returns { items, problems, totalMinor }. problems is a list of { line, message }; items is only usable when problems is empty.
export function checkBulk(text, bankCodes) {
  if (String(text ?? '').length > MAX_CHARS) return { items: [], problems: [{ line: 0, message: 'The file is too big. Split it into smaller files.' }], totalMinor: 0 };
  let rows;
  try { rows = parseCsv(text); } catch (e) { return { items: [], problems: [{ line: 0, message: e.message }], totalMinor: 0 }; }
  if (rows.length < 2) return { items: [], problems: [{ line: 0, message: 'The file needs a header row and at least one payment.' }], totalMinor: 0 };
  const head = rows[0].map((h) => h.trim().toLowerCase());
  const missing = ['name', 'amount'].filter((c) => !head.includes(c));
  if (missing.length || !head.every((h) => COLUMNS.includes(h))) {
    return { items: [], problems: [{ line: 1, message: `The first row must use these column names: ${COLUMNS.join(', ')} (name and amount are required).` }], totalMinor: 0 };
  }
  if (rows.length - 1 > MAX_ROWS) return { items: [], problems: [{ line: 0, message: `A file can have at most ${MAX_ROWS} payments.` }], totalMinor: 0 };

  const idx = Object.fromEntries(COLUMNS.map((c) => [c, head.indexOf(c)]));
  const get = (r, c) => (idx[c] >= 0 ? r[idx[c]] ?? '' : '');
  const items = []; const problems = []; const seen = new Set(); let totalMinor = 0;
  rows.slice(1).forEach((r, k) => {
    const line = k + 2; const bad = (message) => problems.push({ line, message });
    if (r.length > head.length) return bad('Too many columns on this line. Put names containing commas in quotes.');
    const name = clean(get(r, 'name'), 80);
    const amountMinor = amountToMinor(get(r, 'amount'));
    const email = clean(get(r, 'email'), 120).toLowerCase();
    const bankCode = clean(get(r, 'bank_code'), 10);
    const account = clean(get(r, 'account_number'), 20);
    const note = clean(get(r, 'note'), 140);
    if (name.length < 2) return bad('Name is missing.');
    if (amountMinor === null) return bad('Amount must be a plain number like 25000 or 25,000.50.');
    let kind;
    if (email && !bankCode && !account) { if (!EMAIL.test(email)) return bad('That email is not valid.'); kind = 'internal'; }
    else if (bankCode && account && !email) {
      if (!bankCodes.includes(bankCode)) return bad('Unknown bank code.');
      if (!/^\d{10}$/.test(account)) return bad('Account numbers have exactly 10 digits.');
      kind = 'bank';
    } else return bad('Give either an email (G-Plan account) or a bank code with an account number, not both and not neither.');
    const dest = kind === 'bank' ? `${bankCode}:${account}` : `e:${email}`;
    const key = `${dest}|${amountMinor}|${note}`;
    if (seen.has(key)) return bad('This looks like a duplicate of an earlier line (same destination, amount and note).');
    seen.add(key);
    totalMinor += amountMinor;
    items.push({ line, kind, name, bankCode: kind === 'bank' ? bankCode : null, accountNumber: kind === 'bank' ? account : null, email: kind === 'internal' ? email : null, amountMinor, note: note || null });
  });
  if (totalMinor > 10_000_000_000_00) problems.push({ line: 0, message: 'The total is too large for one file.' });
  return { items, problems, totalMinor };
}

// For live providers: does the bank's account name plausibly belong to the person named in the file?
// Banks print names in any order, so one shared word of three or more letters is enough.
export function namesMatch(expected, bankName) {
  const words = (s) => new Set(String(s).toLowerCase().replace(/[^a-z\s]/g, ' ').split(/\s+/).filter((w) => w.length >= 3));
  const a = words(expected); const b = words(bankName);
  for (const w of a) if (b.has(w)) return true;
  return false;
}
