// Which stored hashes should be upgraded, decided without touching any hashing library (so it is easy to test).
// Target when the Argon2id add-on is installed: argon2id with OWASP's minimum (19 MiB memory, 2 passes, 1 lane).
// Otherwise the built-in scrypt parameters are the target.
export const ARGON = { memoryCost: 19456, timeCost: 2, parallelism: 1, outputLen: 32 };
export const SCRYPT = { N: 65536, R: 8, P: 2 };

// "$argon2id$v=19$m=19456,t=2,p=1$salt$hash" -> { m, t, p } or null
export function parseArgon(stored) {
  const m = /^\$argon2id\$v=\d+\$m=(\d+),t=(\d+),p=(\d+)\$/.exec(String(stored));
  return m ? { m: Number(m[1]), t: Number(m[2]), p: Number(m[3]) } : null;
}

export function needsRehashFor(stored, { argon }) {
  const s = String(stored || '');
  if (argon) {
    const a = parseArgon(s);
    // Keep an argon2id hash that is at least as strong as the target; anything else (scrypt, bcrypt, weaker) is upgraded.
    return !(a && a.m >= ARGON.memoryCost && a.t >= ARGON.timeCost && a.p >= ARGON.parallelism);
  }
  if (s.startsWith('$argon2id$')) return false;   // never downgrade an argon2id hash just because the add-on is missing right now
  return !s.startsWith(`scrypt$${SCRYPT.N}$${SCRYPT.R}$${SCRYPT.P}$`);
}
