// Password hashing. Argon2id when the optional add-on @node-rs/argon2 is installed (it ships prebuilt binaries, so there is
// nothing to compile); otherwise scrypt, which is built into Node. Both use OWASP's minimum parameters. Old scrypt and bcrypt
// hashes still verify and are upgraded to the best available scheme the next time that person signs in.
import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import { ARGON, SCRYPT, needsRehashFor } from './passwordRules.js';

const argon = await import('@node-rs/argon2').catch(() => null);
if (!argon) console.warn('Argon2id add-on not installed: passwords use scrypt. Run "npm install" to add @node-rs/argon2.');
export const hashingScheme = () => (argon ? 'argon2id' : 'scrypt');

const { N, R, P } = SCRYPT; const KEYLEN = 32;
const scrypt = (pw, salt, n, r, p) => new Promise((resolve, reject) => {
  crypto.scrypt(String(pw), salt, KEYLEN, { N: n, r, p, maxmem: 256 * 1024 * 1024 }, (e, k) => (e ? reject(e) : resolve(k)));
});

export async function hashPassword(pw) {
  if (argon) return argon.hash(String(pw), { algorithm: 2, ...ARGON });   // 2 = Argon2id
  const salt = crypto.randomBytes(16);
  const key = await scrypt(pw, salt, N, R, P);
  return `scrypt$${N}$${R}$${P}$${salt.toString('base64')}$${key.toString('base64')}`;
}

export async function verifyPassword(pw, stored) {
  if (!stored) return false;
  if (stored.startsWith('$argon2id$')) {
    if (!argon) { console.error('A password is stored with Argon2id but the add-on is not installed. Run npm install.'); return false; }
    try { return await argon.verify(stored, String(pw)); } catch { return false; }
  }
  if (stored.startsWith('scrypt$')) {
    const [, n, r, p, s, k] = stored.split('$');
    const key = await scrypt(pw, Buffer.from(s, 'base64'), Number(n), Number(r), Number(p));
    const expected = Buffer.from(k, 'base64');
    return key.length === expected.length && crypto.timingSafeEqual(key, expected);
  }
  if (/^\$2[aby]\$/.test(stored)) return bcrypt.compare(String(pw), stored);
  return false;
}

export const needsRehash = (stored) => needsRehashFor(stored, { argon: !!argon });

let dummy;
// Used when the email is unknown, so the response takes the same time as a real check.
export async function dummyHash() {
  dummy ||= await hashPassword('not-a-real-password-for-timing-only');
  return dummy;
}
