// Minimal, dependency-free checks for uploaded ID photos: what the bytes really are, how big the picture is,
// and removal of metadata (GPS position, camera serial, edit history) before anything is stored.
// Only JPEG and PNG are accepted. The browser-supplied Content-Type is never trusted on its own.

const PNG_SIG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

export function sniff(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf.subarray(0, 8).equals(PNG_SIG)) return 'image/png';
  return null;
}

const SOF = new Set([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf]);
// JPEG segments we drop: Exif/XMP (E1), APP3-APP11, IPTC/Photoshop (ED), APP15 (EF), comments (FE).
// We keep JFIF (E0), ICC colour profile (E2), and Adobe (EE) because they change how colours are drawn.
const DROP = (m) => m === 0xe1 || (m >= 0xe3 && m <= 0xeb) || m === 0xed || m === 0xef || m === 0xfe;

// Walks the JPEG once. Returns { width, height, clean } where clean is the buffer without metadata segments.
export function parseJpeg(buf) {
  if (buf[0] !== 0xff || buf[1] !== 0xd8) throw new Error('Not a JPEG');
  const out = [buf.subarray(0, 2)];
  let i = 2, width = 0, height = 0;
  while (i < buf.length) {
    if (buf[i] !== 0xff) throw new Error('Damaged JPEG');
    while (buf[i] === 0xff) i++;                       // fill bytes
    const m = buf[i++];
    if (m === 0xd9) { out.push(Buffer.from([0xff, 0xd9])); i = buf.length; break; }          // EOI
    if (m === 0x01 || (m >= 0xd0 && m <= 0xd7)) { out.push(Buffer.from([0xff, m])); continue; }   // no length
    if (i + 2 > buf.length) throw new Error('Damaged JPEG');
    const len = buf.readUInt16BE(i);
    if (len < 2 || i + len > buf.length) throw new Error('Damaged JPEG');
    if (SOF.has(m)) { height = buf.readUInt16BE(i + 3); width = buf.readUInt16BE(i + 5); }
    if (m === 0xda) { out.push(Buffer.from([0xff, m]), buf.subarray(i)); i = buf.length; break; }   // scan data runs to the end
    if (!DROP(m)) out.push(Buffer.from([0xff, m]), buf.subarray(i, i + len));
    i += len;
  }
  if (!width || !height) throw new Error('Damaged JPEG');
  return { width, height, clean: Buffer.concat(out) };
}

// PNG ancillary chunks that carry text, time or Exif are dropped. Everything else is copied untouched.
const PNG_DROP = new Set(['tEXt', 'zTXt', 'iTXt', 'eXIf', 'tIME']);
export function parsePng(buf) {
  if (!buf.subarray(0, 8).equals(PNG_SIG)) throw new Error('Not a PNG');
  const out = [buf.subarray(0, 8)];
  let i = 8, width = 0, height = 0, sawEnd = false, first = true;
  while (i + 12 <= buf.length) {
    const len = buf.readUInt32BE(i);
    const type = buf.toString('latin1', i + 4, i + 8);
    const end = i + 12 + len;
    if (end > buf.length) throw new Error('Damaged PNG');
    if (first) { if (type !== 'IHDR' || len !== 13) throw new Error('Damaged PNG'); width = buf.readUInt32BE(i + 8); height = buf.readUInt32BE(i + 12); first = false; }
    if (!PNG_DROP.has(type)) out.push(buf.subarray(i, end));
    i = end;
    if (type === 'IEND') { sawEnd = true; break; }
  }
  if (!sawEnd || !width || !height) throw new Error('Damaged PNG');
  return { width, height, clean: Buffer.concat(out) };
}

// One call for the route: verifies, measures and cleans. Throws a plain Error with a safe message.
export function inspectImage(buf, { minSide = 300, maxSide = 8000 } = {}) {
  const mime = sniff(buf);
  if (!mime) throw new Error('Use a JPEG or PNG photo.');
  let r;
  try { r = mime === 'image/jpeg' ? parseJpeg(buf) : parsePng(buf); } catch { throw new Error('That photo looks damaged. Take it again.'); }
  if (Math.min(r.width, r.height) < minSide) throw new Error('The photo is too small to read. Move closer and take it again.');
  if (Math.max(r.width, r.height) > maxSide) throw new Error('The photo is too large. Use your phone camera at normal quality.');
  return { mime, width: r.width, height: r.height, clean: r.clean };
}
