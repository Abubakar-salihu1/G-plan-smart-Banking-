// Pure money rules for round-ups and demo interest (no database), so they can be tested on their own.
export const STEPS = [10000, 50000, 100000];

// How much to add to reach the next step. Exact multiples add nothing.
export function roundUpMinor(amountMinor, stepMinor) {
  if (!Number.isSafeInteger(amountMinor) || amountMinor <= 0 || !STEPS.includes(stepMinor)) return 0;
  return (stepMinor - (amountMinor % stepMinor)) % stepMinor;
}

// Interest for one month on the balance a goal had when the month began. Whole kobo, rounded down.
export function monthlyInterestMinor(balanceMinor, apr) {
  if (!Number.isSafeInteger(balanceMinor) || balanceMinor <= 0 || !(apr > 0) || apr > 1) return 0;
  return Math.floor((balanceMinor * apr) / 12);
}

