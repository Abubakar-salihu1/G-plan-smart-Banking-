// Rules for direct debits. Pure functions (no database) so they can be tested on their own.
// The customer is protected by: their own approval, a cap per collection, advance notice, one collection per period,
// cancellation at any time, and an automatic pause after repeated failures.
export const FREQUENCIES = ['weekly', 'monthly', 'quarterly'];
export const PAUSE_AFTER_FAILURES = 3;

const iso = (d) => d.toISOString().slice(0, 10);
const parse = (s) => new Date(`${s}T00:00:00Z`);
export const validDate = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && iso(parse(s)) === s;
export const addDays = (s, n) => iso(new Date(parse(s).getTime() + n * 86400000));

// The next date on the same rhythm. Monthly clamps to the end of short months (31 Jan -> 28 Feb, then 28 Mar is avoided
// by always counting from the ORIGINAL day when given as anchorDay).
export function nextDueOn(dateStr, frequency, anchorDay) {
  const d = parse(dateStr);
  if (frequency === 'weekly') return addDays(dateStr, 7);
  const add = frequency === 'quarterly' ? 3 : 1;
  const day = anchorDay || d.getUTCDate();
  const y = d.getUTCFullYear(), m = d.getUTCMonth() + add;
  const last = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
  return iso(new Date(Date.UTC(y, m, Math.min(day, last))));
}

// Smallest rhythm date on or after `earliest`, stepping forward from `from` (used to catch up after downtime
// without ever collecting for the missed periods).
export function firstDueFrom(from, frequency, earliest, anchorDay) {
  let d = from; let guard = 0;
  while (d < earliest && guard++ < 1000) d = nextDueOn(d, frequency, anchorDay);
  return d;
}

// Can the business schedule this collection? Returns null if fine, or a plain message.
export function checkSchedule({ mandate, amountMinor, dueOn, today, lastCollection }) {
  if (mandate.status !== 'active') return 'This direct debit is not active.';
  if (!Number.isSafeInteger(amountMinor) || amountMinor <= 0) return 'Enter a valid amount.';
  if (amountMinor > Number(mandate.max_amount_minor)) return 'That is more than the customer agreed to. The limit per collection is set in the mandate.';
  if (mandate.fixed_amount_minor && amountMinor !== Number(mandate.fixed_amount_minor)) return 'This mandate collects one fixed amount.';
  if (!validDate(dueOn)) return 'Choose a valid collection date.';
  if (dueOn < addDays(today, mandate.notice_days)) return `The customer must get at least ${mandate.notice_days} days notice. Choose a later date.`;
  if (mandate.end_on && dueOn > mandate.end_on) return 'That is after the end date of this direct debit.';
  if (dueOn < mandate.start_on) return 'That is before the start date of this direct debit.';
  if (lastCollection && lastCollection.status !== 'cancelled') {
    const earliest = mandate.frequency === 'weekly' ? addDays(lastCollection.due_on, 7) : nextDueOn(lastCollection.due_on, mandate.frequency);
    if (dueOn < earliest) return `Only one collection is allowed per ${mandate.frequency === 'weekly' ? 'week' : mandate.frequency === 'monthly' ? 'month' : 'quarter'}. The next one can be on ${earliest} or later.`;
  }
  return null;
}

export const shouldPause = (failuresInARow) => failuresInARow >= PAUSE_AFTER_FAILURES;
export const isDue = (c, today) => c.status === 'scheduled' && c.due_on <= today;
// A reminder goes out the day before.
export const needsReminder = (c, today) => c.status === 'scheduled' && !c.notice_sent_at && c.due_on === addDays(today, 1);
