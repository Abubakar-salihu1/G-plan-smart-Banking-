// Adds up a year of wallet activity into a plain summary. Pure (no database), so it can be tested on its own.
// This is a SUMMARY OF ACTIVITY IN G-PLAN. It is not tax advice and not a tax return: not everything received is taxable
// income, and money that moved outside G-Plan is not here.
const SPEND = new Set(['bill_payment', 'external_transfer', 'internal_transfer', 'card_payment', 'international_transfer']);

export function summariseYear(rows) {
  const months = Array.from({ length: 12 }, () => ({ received: 0, spent: 0, saved: 0, interest: 0 }));
  const t = { receivedFromPeople: 0, addedToWallet: 0, interest: 0, otherIn: 0, spent: 0, saved: 0, savedBack: 0 };
  const byCategory = {};
  for (const r of rows) {
    const net = Number(r.net_minor); const m = new Date(r.created_at).getUTCMonth(); const type = r.type;
    if (type === 'fx_conversion') continue;                       // swapping currencies is neither income nor spending
    if (type === 'goal_contribution') {
      if (net < 0) { t.saved += -net; months[m].saved += -net; } else { t.savedBack += net; }
      continue;
    }
    if (net > 0) {
      if (/^demo interest/i.test(r.description || '')) { t.interest += net; months[m].interest += net; }
      else if (type === 'deposit') t.addedToWallet += net;
      else if (type === 'internal_transfer') { t.receivedFromPeople += net; months[m].received += net; }
      else { t.otherIn += net; months[m].received += net; }
    } else if (net < 0 && SPEND.has(type)) {
      const c = r.category || 'other';
      t.spent += -net; months[m].spent += -net; byCategory[c] = (byCategory[c] || 0) + -net;
    }
  }
  const categories = Object.entries(byCategory).sort((a, b) => b[1] - a[1]).map(([category, totalMinor]) => ({ category, totalMinor }));
  return { totals: t, months, categories };
}

export const TAX_NOTE = 'This is a summary of what happened in your G-Plan wallet. It is not tax advice or a tax return. Not everything you receive is taxable income, and money that moved outside G-Plan is not included. Ask a qualified tax adviser what applies to you.';
