// Habit rules: spot a payment that is out of the ordinary for THIS person. Explainable, no learning, no database.
// They only look at the person's own completed payments. An alert is a nudge, never a block.
export const median = (a) => {
  if (!a.length) return 0;
  const s = [...a].sort((x, y) => x - y);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : Math.round((s[m - 1] + s[m]) / 2);
};

// Much bigger than usual for that category: at least 3x the typical amount, bigger than anything before, and above ₦5,000.
export function unusualCharge({ amountMinor, history, minHistory = 5, factor = 3, floorMinor = 500_000 }) {
  if (!Number.isSafeInteger(amountMinor) || amountMinor <= 0 || history.length < minHistory) return null;
  const typical = median(history);
  if (amountMinor >= Math.max(typical * factor, floorMinor) && amountMinor > Math.max(...history)) return { typicalMinor: typical };
  return null;
}

// Same payee, wording of the description without digits, reference codes or punctuation.
export function repeatKey(description) {
  return String(description || '').toLowerCase().replace(/gp-[0-9a-f]+/g, ' ').replace(/[0-9]+/g, ' ').replace(/[^a-z ]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 40);
}

const DAY = 86400000;
const days = (a, b) => Math.abs(new Date(a) - new Date(b)) / DAY;
const within = (x, lo, hi) => x >= lo && x <= hi;
// history: earlier payments to the same payee, newest first: [{ amountMinor, date }]
const rhythm = (cur, hist) => hist.length >= 2 && within(days(cur.date, hist[0].date), 5, 45) && within(days(hist[0].date, hist[1].date), 5, 45);

// A repeating payment whose price went up by 10% or more (and at least ₦100).
export function priceRise({ current, history }) {
  if (!rhythm(current, history)) return null;
  const last = history[0].amountMinor;
  const stable = Math.abs(history[1].amountMinor - last) <= last * 0.05;
  if (stable && current.amountMinor >= last * 1.1 && current.amountMinor - last >= 10_000) return { fromMinor: last, toMinor: current.amountMinor, pct: Math.round(((current.amountMinor - last) / last) * 100) };
  return null;
}

// The third payment of a regular, similar-sized payment: worth telling the person once.
export function newRepeating({ current, history }) {
  if (history.length !== 2 || !rhythm(current, history)) return false;
  const gaps = [days(current.date, history[0].date), days(history[0].date, history[1].date)];
  const even = Math.abs(gaps[0] - gaps[1]) <= Math.max(4, Math.max(...gaps) * 0.2);
  const same = Math.abs(history[0].amountMinor - current.amountMinor) <= current.amountMinor * 0.05 && Math.abs(history[1].amountMinor - current.amountMinor) <= current.amountMinor * 0.05;
  return even && same;
}
