// Field encryption with versioned keys (AES-256-GCM) so keys can be rotated.
// Set DATA_KEYS="1:<64 hex chars>,2:<64 hex chars>" and DATA_KEY_CURRENT=2 in production.
// Without DATA_KEYS, a dev key derived from DATA_KEY/JWT_SECRET is used (version 0).
// For a real deployment, load these keys from a managed secret store or KMS, never from the repo.
import crypto from 'node:crypto';
import { config } from '../config.js';

const keys = new Map();
for (const part of (process.env.DATA_KEYS || '').split(',').map((s) => s.trim()).filter(Boolean)) {
  const [v, hex] = part.split(':');
  if (v && /^[0-9a-fA-F]{64}$/.test(hex || '')) keys.set(String(v), Buffer.from(hex, 'hex'));
}
if (!keys.size) keys.set('0', crypto.createHash('sha256').update(config.dataKey).digest());
const currentVersion = process.env.DATA_KEY_CURRENT && keys.has(process.env.DATA_KEY_CURRENT)
  ? process.env.DATA_KEY_CURRENT : [...keys.keys()].pop();

export const currentKeyVersion = () => currentVersion;

export function encrypt(text) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', keys.get(currentVersion), iv);
  const enc = Buffer.concat([c.update(text, 'utf8'), c.final()]);
  return `v${currentVersion}.` + [iv, c.getAuthTag(), enc].map((b) => b.toString('base64')).join('.');
}

export function decrypt(s) {
  const [vTag, ...rest] = s.split('.');
  const key = keys.get(vTag.replace(/^v/, ''));
  if (!key) throw new Error('Unknown encryption key version');
  const [iv, tag, enc] = rest.map((x) => Buffer.from(x, 'base64'));
  const d = crypto.createDecipheriv('aes-256-gcm', key, iv);
  d.setAuthTag(tag);
  return Buffer.concat([d.update(enc), d.final()]).toString('utf8');
}

export const keyVersionOf = (s) => String(s).split('.')[0].replace(/^v/, '');

// Binary variant for files (for example KYC photos). Layout: iv(12) | tag(16) | ciphertext. The key version
// is returned separately so it can be stored in its own column and keys can be rotated.
export function encryptBuffer(buf) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', keys.get(currentVersion), iv);
  const enc = Buffer.concat([c.update(buf), c.final()]);
  return { keyVersion: currentVersion, data: Buffer.concat([iv, c.getAuthTag(), enc]) };
}

export function decryptBuffer(data, keyVersion) {
  const key = keys.get(String(keyVersion));
  if (!key) throw new Error('Unknown encryption key version');
  const d = crypto.createDecipheriv('aes-256-gcm', key, data.subarray(0, 12));
  d.setAuthTag(data.subarray(12, 28));
  return Buffer.concat([d.update(data.subarray(28)), d.final()]);
}

// Keyed hash for values we only ever need to compare (for example recovery codes). Uses the key of the given version,
// so codes stored before a key rotation still verify. Returns { version, hash }.
export function fingerprint(value, version = currentVersion, purpose = 'fp') {
  const key = keys.get(String(version));
  if (!key) throw new Error('Unknown encryption key version');
  return { version: String(version), hash: crypto.createHmac('sha256', key).update(`${purpose}:${value}`).digest('hex') };
}
