export function normalisePhone(raw) {
  const d = String(raw || '').replace(/\D/g, '');
  if (d.length === 13 && d.startsWith('234')) return d;
  if (d.length === 11 && d.startsWith('0')) return '234' + d.slice(1);
  if (d.length === 10) return '234' + d;
  return null;
}

export const maskName = (name) => String(name || '').split(' ').filter(Boolean).map((w) => w.slice(0, 2) + '***').join(' ');

export function fmt(minor, currency = 'NGN') {
  const sym = currency === 'NGN' ? '₦' : currency + ' ';
  return sym + (minor / 100).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export const isEmail = (e) => typeof e === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e) && e.length <= 254;
