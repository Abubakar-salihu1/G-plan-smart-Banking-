import { Router } from 'express';
import { pool } from '../db.js';
import { config } from '../config.js';
import { AppError, wrap } from '../errors.js';
import { requireAuth } from '../middleware/auth.js';
import { walletOf } from '../services/ledger.js';
import { hashRequest } from '../services/transfers.js';
import { payExternal } from '../services/payments.js';
import { mockBiller } from '../services/providers.js';
import { BILLERS, DATA_BUNDLES, CABLE_PACKAGES, biller } from '../services/catalog.js';
import { authorisePayment } from '../services/guard.js';
import { assertPassword } from '../services/passwords.js';
import { billAmount, runScheduledPayment } from '../services/jobs.js';
import { recordRisk } from '../services/risk.js';

const router = Router();
router.use(requireAuth);

function validate(b, payeeRef, bundleId, amountMinor) {
  if (!b) throw new AppError(422, 'UNKNOWN_BILLER', 'Choose a provider.');
  if (!new RegExp(b.refRegex).test(String(payeeRef || ''))) throw new AppError(422, 'INVALID_REFERENCE', `Check the ${b.refLabel.toLowerCase()}.`);
  const amt = billAmount(b, bundleId, amountMinor);
  if (!Number.isSafeInteger(amt) || amt < 10000) throw new AppError(422, 'INVALID_AMOUNT', 'Choose a bundle or enter an amount of at least ₦100.');
  return amt;
}

router.get('/bills/catalog', (_req, res) => {
  res.json({ demo: true, note: 'Demo providers and prices. No real biller is connected.',
    billers: BILLERS, dataBundles: DATA_BUNDLES, cablePackages: CABLE_PACKAGES });
});

router.post('/bills/pay', wrap(async (req, res) => {
  const { billerCode, payeeRef, bundleId, amountMinor, password, otp } = req.body || {};
  const b = biller(billerCode);
  const amt = validate(b, payeeRef, bundleId, amountMinor);
  const { risk, level } = await authorisePayment(req, { password, otp, amountMinor: amt });
  const wallet = await walletOf(pool, req.user.id, 'NGN');
  const receipt = await payExternal({
    userId: req.user.id, walletId: wallet, amountMinor: amt, type: 'bill_payment',
    description: b.name, category: b.category, riskLevel: level,
    meta: { biller: b.code, payeeRef, payee: b.name, category: b.category },
    idemKey: req.get('Idempotency-Key'), requestHash: hashRequest({ billerCode, payeeRef, bundleId, amt }), provider: mockBiller,
  });
  if (!receipt.replayed && ['completed', 'under_review'].includes(receipt.state)) recordRisk(req.user.id, risk, receipt.transactionId).catch(() => {});
  res.status(receipt.replayed ? 200 : 201).json({ receipt });
}));

// ---- Scheduled / recurring payments ----
router.get('/bills/scheduled', wrap(async (req, res) => {
  const r = await pool.query(
    `SELECT id, biller_code, payee_ref, payee_name, bundle_id, amount_minor, frequency, next_run_on, status, last_status
     FROM scheduled_payments WHERE user_id=$1 AND status IN ('active','paused') ORDER BY next_run_on`, [req.user.id]);
  res.json({ scheduled: r.rows.map((s) => ({ ...s, billerName: biller(s.biller_code)?.name || s.biller_code,
    amount_minor: billAmount(biller(s.biller_code), s.bundle_id, s.amount_minor) ?? s.amount_minor })) });
}));

router.post('/bills/scheduled', wrap(async (req, res) => {
  const { billerCode, payeeRef, payeeName, bundleId, amountMinor, frequency, startDate, password } = req.body || {};
  await assertPassword(req.user.id, password);
  const b = biller(billerCode);
  const amt = validate(b, payeeRef, bundleId, amountMinor);
  if (!['once', 'weekly', 'monthly'].includes(frequency)) throw new AppError(422, 'INVALID_FREQUENCY', 'Choose once, weekly or monthly.');
  const start = startDate && /^\d{4}-\d{2}-\d{2}$/.test(startDate) ? startDate : new Date().toISOString().slice(0, 10);
  if (start < new Date().toISOString().slice(0, 10)) throw new AppError(422, 'INVALID_DATE', 'Pick today or a future date.');
  const n = (await pool.query(`SELECT COUNT(*) AS n FROM scheduled_payments WHERE user_id=$1 AND status IN ('active','paused')`, [req.user.id])).rows[0].n;
  if (n >= 20) throw new AppError(422, 'TOO_MANY', 'You can have up to 20 scheduled payments.');
  const r = await pool.query(
    `INSERT INTO scheduled_payments(user_id, biller_code, payee_ref, payee_name, bundle_id, amount_minor, frequency, next_run_on)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
    [req.user.id, billerCode, payeeRef, payeeName ? String(payeeName).slice(0, 60) : null, bundleId || null, amt, frequency, start]);
  await pool.query(`INSERT INTO audit_log(actor_type, actor_id, action, target_id) VALUES ('user',$1,'schedule.create',$2)`, [req.user.id, r.rows[0].id]);
  res.status(201).json({ id: r.rows[0].id });
}));

router.patch('/bills/scheduled/:id', wrap(async (req, res) => {
  const status = req.body?.status;
  if (!['active', 'paused', 'cancelled'].includes(status)) throw new AppError(422, 'INVALID_STATUS', 'Invalid status.');
  await pool.query('UPDATE scheduled_payments SET status=$3 WHERE id=$1 AND user_id=$2 AND status<>$4', [req.params.id, req.user.id, status, 'completed']);
  res.json({ ok: true });
}));

// DEMO: run a scheduled payment now so the flow can be shown without waiting for the date.
router.post('/bills/scheduled/:id/run-now', wrap(async (req, res) => {
  if (!config.demoFunding) throw new AppError(404, 'NOT_FOUND', 'Not found.');
  const s = (await pool.query(`SELECT * FROM scheduled_payments WHERE id=$1 AND user_id=$2 AND status='active'`, [req.params.id, req.user.id])).rows[0];
  if (!s) throw new AppError(404, 'NOT_FOUND', 'Scheduled payment not found.');
  res.json({ result: await runScheduledPayment(s) });
}));

export default router;
