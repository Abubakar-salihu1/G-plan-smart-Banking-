// Business mode: a business profile with a shared wallet and a team with roles.
//   owner / finance / staff / auditor, see services/businessAccess.js for exactly what each may do.
// Money rules: invoices are paid into the business wallet; payouts leave it. A payout above the business's
// approval threshold that a finance manager creates waits for the owner (maker and checker are always different people).
// Every permission is checked on the server; the client only hides buttons.
import crypto from 'node:crypto';
import { Router } from 'express';
import { pool, withTx } from '../db.js';
import { config } from '../config.js';
import { AppError, wrap } from '../errors.js';
import { requireAuth } from '../middleware/auth.js';
import { isEmail, fmt } from '../utils/format.js';
import { monthRange } from '../services/queries.js';
import { notify } from '../services/notify.js';
import { createAccount, walletOf, businessWalletOf, availableBalance, ledgerBalance } from '../services/ledger.js';
import { transfer, hashRequest, assertAmount } from '../services/transfers.js';
import { payExternal } from '../services/payments.js';
import { authorisePayment } from '../services/guard.js';
import { assertPassword } from '../services/passwords.js';
import { getUserRow, checkSecondFactor } from '../services/mfa.js';
import { businessLimits, businessUsedToday } from '../services/limits.js';
import { recordRisk, monitorAml, assertNotSanctioned } from '../services/risk.js';
import { bankProvider, resolveName } from '../services/bankProvider.js';
import { BANKS } from '../services/catalog.js';
import { INVITABLE, BIZ_PERMS, bizCan, payoutNeedsApproval, activeMembership, requireBizPerm, userName } from '../services/businessAccess.js';

const router = Router();
router.use(requireAuth);

const audit = (req, action, target, meta = {}) =>
  pool.query(`INSERT INTO audit_log(actor_type, actor_id, action, target_type, target_id, ip_address, metadata) VALUES ('user',$1,$2,'business',$3,$4,$5)`,
    [req.user.id, action, target || null, req.ip, JSON.stringify(meta)]);

const myInvites = async (userId) => (await pool.query(
  `SELECT m.id, m.role, b.name FROM business_members m JOIN businesses b ON b.id=m.business_id WHERE m.user_id=$1 AND m.status='invited' ORDER BY m.created_at DESC`, [userId])).rows
  .map((i) => ({ id: i.id, role: i.role, businessName: i.name }));

// ---------------------------------------------------------------- profile
router.get('/business', wrap(async (req, res) => {
  const m = await activeMembership(pool, req.user.id);
  const invites = await myInvites(req.user.id);
  if (!m) return res.json({ business: null, invites });
  const b = (await pool.query('SELECT id, name, category, daily_cap_minor FROM businesses WHERE id=$1', [m.business_id])).rows[0];
  const offer = (await pool.query(
    `SELECT t.id, t.from_user, t.to_user, t.keep_access, t.expires_at, fu.full_name AS from_name, tu.full_name AS to_name
     FROM business_transfers t JOIN users fu ON fu.id=t.from_user JOIN users tu ON tu.id=t.to_user
     WHERE t.business_id=$1 AND t.status='pending' AND t.expires_at > now()`, [m.business_id])).rows[0];
  res.json({
    business: { id: b.id, name: b.name, category: b.category, myRole: m.role, permissions: BIZ_PERMS[m.role],
      approvalThresholdMinor: bizCan(m.role, 'payouts.read') ? m.approval_threshold_minor : undefined,
      dailyCapMinor: bizCan(m.role, 'payouts.read') ? b.daily_cap_minor : undefined },
    // The new owner sees an offer to accept. The current owner sees the offer they made, so they can withdraw it.
    ownershipOffer: offer && (offer.to_user === req.user.id ? { id: offer.id, direction: 'incoming', otherName: offer.from_name, expiresAt: offer.expires_at }
      : offer.from_user === req.user.id ? { id: offer.id, direction: 'outgoing', otherName: offer.to_name, expiresAt: offer.expires_at } : null),
    invites,
  });
}));

router.post('/business', wrap(async (req, res) => {
  const { name, category } = req.body || {};
  if (typeof name !== 'string' || name.trim().length < 2 || name.length > 80) throw new AppError(422, 'INVALID_NAME', 'Enter your business name.');
  const u = (await pool.query('SELECT kyc_tier FROM users WHERE id=$1', [req.user.id])).rows[0];
  if (u.kyc_tier < 1) throw new AppError(403, 'KYC_REQUIRED', 'Verify your identity first (level 1 in Security), then set up your business.');
  if (await activeMembership(pool, req.user.id)) throw new AppError(409, 'EXISTS', 'You are already part of a business.');
  try {
    await withTx(async (c) => {
      const b = (await c.query('INSERT INTO businesses(owner_id, name, category) VALUES ($1,$2,$3) RETURNING id',
        [req.user.id, name.trim(), String(category || '').slice(0, 40) || null])).rows[0];
      await c.query(`INSERT INTO business_members(business_id, user_id, role, status) VALUES ($1,$2,'owner','active')`, [b.id, req.user.id]);
      const wid = await createAccount(c, { userId: req.user.id, type: 'customer_wallet', currency: 'NGN', name: 'Business wallet' });
      await c.query('UPDATE accounts SET business_id=$2 WHERE id=$1', [wid, b.id]);
    });
  } catch (e) {
    if (e.code === '23505') throw new AppError(409, 'EXISTS', 'You already have a business profile.');
    throw e;
  }
  await audit(req, 'business.created');
  res.status(201).json({ ok: true });
}));

router.post('/business/settings', requireBizPerm('settings.manage'), wrap(async (req, res) => {
  const { approvalThresholdMinor, dailyCapMinor } = req.body || {};
  const amount = (x) => { const v = Number(x); if (!Number.isSafeInteger(v) || v < 0 || v > config.maxAmountMinor) throw new AppError(422, 'INVALID_AMOUNT', 'Enter a valid amount.'); return v; };
  if (approvalThresholdMinor === undefined && dailyCapMinor === undefined) throw new AppError(422, 'NOTHING_TO_SAVE', 'Choose a setting to change.');
  if (approvalThresholdMinor !== undefined) {
    const v = amount(approvalThresholdMinor);
    await pool.query('UPDATE businesses SET approval_threshold_minor=$2 WHERE id=$1', [req.biz.business_id, v]);
    await audit(req, 'business.threshold_changed', req.biz.business_id, { approvalThresholdMinor: v });
  }
  // null removes the business cap; the owner's verification level still applies.
  if (dailyCapMinor !== undefined) {
    const v = dailyCapMinor === null ? null : amount(dailyCapMinor);
    await pool.query('UPDATE businesses SET daily_cap_minor=$2 WHERE id=$1', [req.biz.business_id, v]);
    await audit(req, 'business.daily_cap_changed', req.biz.business_id, { dailyCapMinor: v });
  }
  res.json({ ok: true });
}));

// ---------------------------------------------------------------- team
router.get('/business/members', requireBizPerm('team.read'), wrap(async (req, res) => {
  const r = await pool.query(
    `SELECT m.id, m.user_id, m.role, m.status, m.created_at, u.full_name, u.email FROM business_members m JOIN users u ON u.id=m.user_id
     WHERE m.business_id=$1 AND m.status IN ('active','invited') ORDER BY (m.role='owner') DESC, m.created_at`, [req.biz.business_id]);
  res.json({ members: r.rows.map((m) => ({ id: m.id, role: m.role, status: m.status, name: m.full_name, email: m.email, you: m.user_id === req.user.id })) });
}));

// The reply never reveals whether the email belongs to a G-Plan account (no account probing).
router.post('/business/members', requireBizPerm('team.manage'), wrap(async (req, res) => {
  const { email, role } = req.body || {};
  if (!isEmail(email)) throw new AppError(422, 'INVALID_EMAIL', 'Enter a valid email.');
  if (!INVITABLE.includes(role)) throw new AppError(422, 'INVALID_ROLE', 'Choose finance manager, staff or auditor.');
  const today = (await pool.query(`SELECT COUNT(*) AS n FROM business_members WHERE business_id=$1 AND created_at > now() - interval '1 day'`, [req.biz.business_id])).rows[0].n;
  if (today >= 20) throw new AppError(429, 'TOO_MANY', 'Too many invitations today. Try again tomorrow.');
  const u = (await pool.query(`SELECT id FROM users WHERE email=$1 AND status='active' AND email_verified_at IS NOT NULL`, [String(email).toLowerCase()])).rows[0];
  if (u && u.id !== req.user.id) {
    const r = await pool.query(
      `INSERT INTO business_members(business_id, user_id, role, status, invited_by) VALUES ($1,$2,$3,'invited',$4)
       ON CONFLICT (business_id, user_id) DO UPDATE SET role=EXCLUDED.role, status='invited', invited_by=EXCLUDED.invited_by, updated_at=now()
       WHERE business_members.status IN ('removed','declined','invited') RETURNING id`, [req.biz.business_id, u.id, role, req.user.id]);
    if (r.rows[0]) {
      await notify(pool, u.id, 'Business invitation', `${req.biz.name} invited you to join as ${role === 'finance' ? 'finance manager' : role}. Open Business to accept or decline.`, 'info');
      await audit(req, 'business.member_invited', req.biz.business_id, { role });
    }
  }
  res.status(202).json({ ok: true, note: 'If that person has a verified G-Plan account, they will see your invitation in Business.' });
}));

router.post('/business/invites/:id/:decision(accept|decline)', wrap(async (req, res) => {
  const inv = (await pool.query(
    `SELECT m.id, m.role, m.business_id, b.name, b.owner_id FROM business_members m JOIN businesses b ON b.id=m.business_id
     WHERE m.id=$1 AND m.user_id=$2 AND m.status='invited'`, [req.params.id, req.user.id])).rows[0];
  if (!inv) throw new AppError(404, 'NOT_FOUND', 'Invitation not found.');
  if (req.params.decision === 'decline') {
    await pool.query(`UPDATE business_members SET status='declined', updated_at=now() WHERE id=$1`, [inv.id]);
    return res.json({ ok: true });
  }
  if (inv.role === 'finance') {
    const u = (await pool.query('SELECT kyc_tier FROM users WHERE id=$1', [req.user.id])).rows[0];
    if (u.kyc_tier < 1) throw new AppError(403, 'KYC_REQUIRED', 'Finance managers must verify their identity first (level 1 in Security).');
  }
  try {
    await pool.query(`UPDATE business_members SET status='active', updated_at=now() WHERE id=$1`, [inv.id]);
  } catch (e) {
    if (e.code === '23505') throw new AppError(409, 'ALREADY_IN_BUSINESS', 'You are already part of a business. Leave it before joining another.');
    throw e;
  }
  await notify(pool, inv.owner_id, 'Invitation accepted', `A new ${inv.role === 'finance' ? 'finance manager' : inv.role} joined ${inv.name}.`, 'info');
  res.json({ ok: true });
}));

router.post('/business/members/:id/role', requireBizPerm('team.manage'), wrap(async (req, res) => {
  if (!INVITABLE.includes(req.body?.role)) throw new AppError(422, 'INVALID_ROLE', 'Choose finance manager, staff or auditor.');
  const r = await pool.query(
    `UPDATE business_members SET role=$3, updated_at=now() WHERE id=$1 AND business_id=$2 AND role<>'owner' AND status IN ('active','invited') RETURNING user_id`,
    [req.params.id, req.biz.business_id, req.body.role]);
  if (!r.rows[0]) throw new AppError(404, 'NOT_FOUND', 'Team member not found.');
  await audit(req, 'business.role_changed', req.biz.business_id, { role: req.body.role });
  await notify(pool, r.rows[0].user_id, 'Your business role changed', `You are now ${req.body.role === 'finance' ? 'a finance manager' : 'a member with the ' + req.body.role + ' role'} at ${req.biz.name}.`, 'security');
  res.json({ ok: true });
}));

router.delete('/business/members/:id', requireBizPerm('team.manage'), wrap(async (req, res) => {
  const r = await pool.query(
    `UPDATE business_members SET status='removed', updated_at=now() WHERE id=$1 AND business_id=$2 AND role<>'owner' AND status IN ('active','invited') RETURNING user_id`,
    [req.params.id, req.biz.business_id]);
  if (!r.rows[0]) throw new AppError(404, 'NOT_FOUND', 'Team member not found.');
  // Anything they proposed that is still waiting for approval is withdrawn with them.
  await pool.query(`UPDATE business_payouts SET status='cancelled', decided_at=now() WHERE business_id=$1 AND created_by=$2 AND status='pending_approval'`, [req.biz.business_id, r.rows[0].user_id]);
  await audit(req, 'business.member_removed', req.biz.business_id);
  await notify(pool, r.rows[0].user_id, 'Removed from a business', `You no longer have access to ${req.biz.name}.`, 'security');
  res.json({ ok: true });
}));

router.post('/business/leave', wrap(async (req, res) => {
  const m = await activeMembership(pool, req.user.id);
  if (!m) throw new AppError(404, 'NO_BUSINESS', 'You are not part of a business.');
  if (m.role === 'owner') throw new AppError(422, 'OWNER_CANNOT_LEAVE', 'The owner cannot leave. Remove the team and close your account instead.');
  await pool.query(`UPDATE business_members SET status='removed', updated_at=now() WHERE id=$1`, [m.id]);
  await pool.query(`UPDATE business_payouts SET status='cancelled', decided_at=now() WHERE business_id=$1 AND created_by=$2 AND status='pending_approval'`, [m.business_id, req.user.id]);
  res.json({ ok: true });
}));

// ---------------------------------------------------------------- invoices
router.post('/business/invoices', requireBizPerm('invoices.create'), wrap(async (req, res) => {
  const b = req.biz;
  const { customerName, customerEmail, items, dueDays, note } = req.body || {};
  if (typeof customerName !== 'string' || customerName.trim().length < 2) throw new AppError(422, 'INVALID_NAME', "Enter your customer's name.");
  if (customerEmail && !isEmail(customerEmail)) throw new AppError(422, 'INVALID_EMAIL', 'Enter a valid customer email, or leave it empty.');
  if (!Array.isArray(items) || items.length < 1 || items.length > 50) throw new AppError(422, 'INVALID_ITEMS', 'Add between 1 and 50 line items.');
  // The total is always computed here, never taken from the client.
  let total = 0;
  const clean = items.map((i) => {
    const qty = Number(i.qty), unit = Number(i.unitMinor);
    if (!Number.isInteger(qty) || qty < 1 || qty > 100000 || !Number.isInteger(unit) || unit < 1 || unit > 1_000_000_000_00
      || typeof i.description !== 'string' || !i.description.trim()) throw new AppError(422, 'INVALID_ITEMS', 'Check the line items: description, quantity and price are needed.');
    total += qty * unit;
    return { description: i.description.trim().slice(0, 100), qty, unitMinor: unit };
  });
  if (!Number.isSafeInteger(total) || total <= 0 || total > 1_000_000_000_000) throw new AppError(422, 'INVALID_AMOUNT', 'The invoice total is not valid.');
  const days = [7, 14, 30, 60].includes(Number(dueDays)) ? Number(dueDays) : 30;
  const payer = customerEmail ? (await pool.query(`SELECT id FROM users WHERE email=$1 AND status='active'`, [customerEmail.toLowerCase()])).rows[0] : null;
  if (payer && (await pool.query(`SELECT 1 FROM business_members WHERE business_id=$1 AND user_id=$2 AND status='active'`, [b.business_id, payer.id])).rowCount) {
    throw new AppError(422, 'SELF_INVOICE', 'You cannot invoice someone on your own team.');
  }

  const inv = await withTx(async (c) => {
    await c.query('SELECT id FROM businesses WHERE id=$1 FOR UPDATE', [b.business_id]);   // keeps invoice numbers gap-free and unique
    const n = (await c.query('SELECT COUNT(*) AS n FROM payment_requests WHERE business_id=$1 AND invoice_number IS NOT NULL', [b.business_id])).rows[0].n;
    const number = `INV-${new Date().getUTCFullYear()}-${String(n + 1).padStart(4, '0')}`;
    const r = await c.query(
      `INSERT INTO payment_requests(requester_id, payer_id, payer_email, amount_minor, note, token, business_id, invoice_number, customer_name, items, expires_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10, now() + ($11 || ' days')::interval) RETURNING id, token, invoice_number`,
      [req.user.id, payer?.id || null, customerEmail ? customerEmail.toLowerCase() : null, total,
        String(note || '').slice(0, 140) || `${b.name} invoice`, crypto.randomBytes(9).toString('base64url'),
        b.business_id, number, customerName.trim().slice(0, 80), JSON.stringify(clean), String(days)]);
    if (payer) await notify(c, payer.id, 'New invoice', `${b.name} sent you invoice ${number} for ${fmt(total)}.`, 'request');
    return r.rows[0];
  });
  res.status(201).json({ invoice: { id: inv.id, number: inv.invoice_number, token: inv.token, totalMinor: total } });
}));

router.get('/business/invoices', requireBizPerm('invoices.read'), wrap(async (req, res) => {
  const r = await pool.query(
    `SELECT r.id, r.invoice_number, r.customer_name, r.payer_email, r.amount_minor, r.status, r.token, r.created_at, r.expires_at, r.items, u.full_name AS created_by
     FROM payment_requests r JOIN users u ON u.id=r.requester_id WHERE r.business_id=$1 ORDER BY r.created_at DESC LIMIT 100`, [req.biz.business_id]);
  res.json({ invoices: r.rows.map((x) => ({ ...x, overdue: x.status === 'pending' && new Date(x.expires_at) < new Date() })) });
}));

router.post('/business/invoices/:id/cancel', requireBizPerm('invoices.cancel'), wrap(async (req, res) => {
  const r = await pool.query(`UPDATE payment_requests SET status='cancelled' WHERE id=$1 AND business_id=$2 AND status='pending' RETURNING id`, [req.params.id, req.biz.business_id]);
  if (!r.rows[0]) throw new AppError(404, 'NOT_FOUND', 'Invoice not found, or it can no longer be cancelled.');
  res.json({ ok: true });
}));

router.get('/business/report', requireBizPerm('report.read'), wrap(async (req, res) => {
  const bid = req.biz.business_id;
  const { month, start, end } = monthRange(req.query.month);
  const paid = (await pool.query(
    `SELECT COUNT(*) AS n, COALESCE(SUM(r.amount_minor),0) AS total FROM payment_requests r JOIN transactions t ON t.id=r.paid_txn_id
     WHERE r.business_id=$1 AND r.status='paid' AND t.created_at >= $2 AND t.created_at < $3`, [bid, start, end])).rows[0];
  const open = (await pool.query(
    `SELECT COUNT(*) AS n, COALESCE(SUM(amount_minor),0) AS total,
            COUNT(*) FILTER (WHERE expires_at < now()) AS overdue
     FROM payment_requests WHERE business_id=$1 AND status IN ('pending','paying')`, [bid])).rows[0];
  const top = (await pool.query(
    `SELECT r.customer_name, SUM(r.amount_minor) AS total FROM payment_requests r JOIN transactions t ON t.id=r.paid_txn_id
     WHERE r.business_id=$1 AND r.status='paid' AND t.created_at >= $2 AND t.created_at < $3
     GROUP BY r.customer_name ORDER BY total DESC LIMIT 5`, [bid, start, end])).rows;
  res.json({ report: { month, paidCount: paid.n, paidMinor: paid.total, outstandingCount: open.n, outstandingMinor: open.total,
    overdueCount: open.overdue, topCustomers: top.map((t) => ({ name: t.customer_name, totalMinor: t.total })) } });
}));

// ---------------------------------------------------------------- wallet
router.get('/business/wallet', requireBizPerm('wallet.read'), wrap(async (req, res) => {
  const wid = await businessWalletOf(pool, req.biz.business_id);
  if (!wid) throw new AppError(404, 'NO_WALLET', 'The business wallet is not set up.');
  const rows = (await pool.query(
    `SELECT t.id, t.reference, t.type, t.state, t.description, MAX(p.created_at) AS created_at,
            SUM(CASE WHEN p.direction='credit' THEN p.amount_minor ELSE -p.amount_minor END) AS net_minor
     FROM postings p JOIN journal_entries je ON je.id=p.entry_id JOIN transactions t ON t.id=je.transaction_id
     WHERE p.account_id=$1 GROUP BY t.id ORDER BY MAX(p.created_at) DESC LIMIT 30`, [wid])).rows;
  const lim = await businessLimits(pool, req.biz.business_id);
  const used = await businessUsedToday(pool, wid);
  res.json({ wallet: { availableMinor: await availableBalance(pool, wid), ledgerMinor: await ledgerBalance(pool, wid) },
    limits: { perPaymentMinor: lim.perPaymentMinor, dailyMinor: lim.dailyMinor, usedTodayMinor: used, capMinor: lim.capMinor }, activity: rows });
}));

// Owner moves money from their personal wallet into the business wallet.
router.post('/business/wallet/topup', requireBizPerm('wallet.topup'), wrap(async (req, res) => {
  const { amountMinor, password, otp } = req.body || {};
  assertAmount(amountMinor);
  const from = await walletOf(pool, req.user.id, 'NGN');
  const to = await businessWalletOf(pool, req.biz.business_id);
  const { risk, level } = await authorisePayment(req, { password, otp, amountMinor });
  const receipt = await transfer({
    userId: req.user.id, fromAccountId: from, toAccountId: to, amountMinor, type: 'internal_transfer',
    description: `Top-up of ${req.biz.name} wallet`, category: 'transfers', riskLevel: level, meta: { businessId: req.biz.business_id },
    idemKey: req.get('Idempotency-Key'), requestHash: hashRequest({ topup: amountMinor, to }),
  });
  if (!receipt.replayed) {
    recordRisk(req.user.id, risk, receipt.transactionId).catch(() => {});
    if (receipt.state === 'completed') monitorAml(req.user.id, receipt).catch(() => {});
  }
  res.status(receipt.replayed ? 200 : 201).json({ receipt });
}));

// ---------------------------------------------------------------- payouts
const payoutView = (p) => ({
  id: p.id, kind: p.kind, amountMinor: p.amount_minor, note: p.note, status: p.status, createdAt: p.created_at,
  createdBy: p.created_by_name, decidedAt: p.decided_at, state: p.txn_state || null, reference: p.txn_ref || null,
  recipient: p.kind === 'bank'
    ? { name: p.recipient.accountName, bank: p.recipient.bankName, accountLast4: String(p.recipient.accountNumber || '').slice(-4) }
    : { name: p.recipient.name, email: p.recipient.email },
});

async function loadPayout(db, id, businessId) {
  return (await db.query(
    `SELECT p.*, u.full_name AS created_by_name, t.state AS txn_state, t.reference AS txn_ref
     FROM business_payouts p JOIN users u ON u.id=p.created_by LEFT JOIN transactions t ON t.id=p.txn_id
     WHERE p.id=$1 AND p.business_id=$2`, [id, businessId])).rows[0];
}

// Runs the money movement for a payout that has been claimed (status already 'executed'). `actor` is the person
// whose authorisation counts (the creator, or the owner approving).
async function runPayout(p, biz, actor, level) {
  const bizWallet = await businessWalletOf(pool, p.business_id);
  const base = { userId: actor.id, businessId: p.business_id, amountMinor: Number(p.amount_minor), riskLevel: level, idemKey: `payout:${p.id}`, requestHash: hashRequest({ payout: p.id }) };
  const note = p.note ? ` · ${p.note}` : '';
  if (p.kind === 'internal') {
    return transfer({ ...base, fromAccountId: bizWallet, toAccountId: p.recipient.walletId, type: 'internal_transfer',
      description: `${biz.name} payout to ${p.recipient.name}${note}`, category: 'transfers', meta: { businessId: p.business_id, payoutId: p.id } });
  }
  return payExternal({ ...base, walletId: bizWallet, feeMinor: config.fees.externalTransferMinor, type: 'external_transfer',
    description: `${biz.name} payout to ${p.recipient.accountName}${note}`, category: 'transfers',
    meta: { ...p.recipient, payee: p.recipient.accountName, businessId: p.business_id, payoutId: p.id }, provider: bankProvider() });
}

async function execute(req, p, risk, level, { revertTo }) {
  // Claim first so two clicks (or two approvers) cannot pay twice.
  const claim = await pool.query(
    `UPDATE business_payouts SET status='executed', decided_by=$2, decided_at=now() WHERE id=$1 AND status='pending_approval' RETURNING id`, [p.id, req.user.id]);
  if (!claim.rows[0]) throw new AppError(409, 'NOT_PENDING', 'This payout was already handled.');
  try {
    const receipt = await runPayout(p, req.biz, req.user, level);
    await pool.query('UPDATE business_payouts SET txn_id=$2 WHERE id=$1', [p.id, receipt.transactionId]);
    if (!receipt.replayed) {
      recordRisk(req.user.id, risk, receipt.transactionId).catch(() => {});
      if (receipt.state === 'completed') monitorAml(req.user.id, receipt).catch(() => {});
    }
    return receipt;
  } catch (e) {
    // A known refusal (low balance, limit, frozen wallet) happened before any money moved, so the payout can be
    // put back. An unexpected error is left claimed for an operator to look at: the idempotency key
    // `payout:<id>` guarantees a retry can never pay twice.
    if (e instanceof AppError) {
      await pool.query(`UPDATE business_payouts SET status=$2, decided_by=NULL, decided_at=$3 WHERE id=$1 AND status='executed' AND txn_id IS NULL`, [p.id, revertTo, revertTo === 'cancelled' ? new Date() : null]);
    }
    throw e;
  }
}

router.post('/business/payouts', requireBizPerm('payouts.create'), wrap(async (req, res) => {
  const { kind, amountMinor, email, bankCode, accountNumber, note, password, otp } = req.body || {};
  const clientKey = req.get('Idempotency-Key');
  if (!clientKey) throw new AppError(400, 'IDEMPOTENCY_KEY_REQUIRED', 'Missing Idempotency-Key header.');
  if (!['internal', 'bank'].includes(kind)) throw new AppError(422, 'INVALID_KIND', 'Choose G-Plan account or bank account.');
  assertAmount(amountMinor);
  const text = typeof note === 'string' ? note.slice(0, 140) : null;
  const bizWallet = await businessWalletOf(pool, req.biz.business_id);

  // A retry with the same key returns the same payout and never creates a second one.
  const prior = (await pool.query('SELECT id FROM business_payouts WHERE created_by=$1 AND client_key=$2', [req.user.id, clientKey])).rows[0];
  if (prior) {
    const p = await loadPayout(pool, prior.id, req.biz.business_id);
    return res.status(200).json({ payout: payoutView(p), needsApproval: p.status === 'pending_approval', replayed: true });
  }

  let recipient;
  if (kind === 'internal') {
    if (!isEmail(email)) throw new AppError(422, 'INVALID_EMAIL', 'Enter the recipient\'s G-Plan email.');
    const u = (await pool.query(`SELECT id, full_name FROM users WHERE email=$1 AND status='active'`, [String(email).toLowerCase()])).rows[0];
    if (!u) throw new AppError(404, 'RECIPIENT_NOT_FOUND', 'No G-Plan account found for that email.');
    assertNotSanctioned(u.full_name);
    const walletId = await walletOf(pool, u.id, 'NGN');
    if (!walletId) throw new AppError(404, 'RECIPIENT_NOT_FOUND', 'No G-Plan account found for that email.');
    recipient = { name: u.full_name, email: String(email).toLowerCase(), walletId };
  } else {
    const bank = BANKS.find((b) => b.code === bankCode);
    if (!bank) throw new AppError(422, 'INVALID_BANK', 'Choose a bank.');
    if (!/^\d{10}$/.test(String(accountNumber || ''))) throw new AppError(422, 'INVALID_ACCOUNT', 'Account numbers have 10 digits.');
    const accountName = await resolveName(bankCode, accountNumber);   // never trust a name sent by the client
    assertNotSanctioned(accountName);
    recipient = { bankCode, bankName: bank.name, accountNumber: String(accountNumber), accountName };
  }

  // The person creating the payout always proves it is them, even when the owner must approve afterwards.
  const { risk, level } = await authorisePayment(req, { password, otp, amountMinor, walletId: bizWallet });
  const ins = await pool.query(
    `INSERT INTO business_payouts(business_id, created_by, client_key, kind, amount_minor, recipient, note) VALUES ($1,$2,$3,$4,$5,$6,$7)
     ON CONFLICT (created_by, client_key) DO NOTHING RETURNING *`,
    [req.biz.business_id, req.user.id, clientKey, kind, amountMinor, JSON.stringify(recipient), text]);
  if (!ins.rows[0]) throw new AppError(409, 'IN_PROGRESS', 'This payout is already being created.');
  const p = ins.rows[0];
  await audit(req, 'business.payout_created', req.biz.business_id, { payoutId: p.id, amountMinor, kind });

  if (payoutNeedsApproval(req.biz.role, amountMinor, req.biz.approval_threshold_minor)) {
    await notify(pool, req.biz.owner_id, 'Payout waiting for approval', `${fmt(amountMinor)} payout proposed for ${req.biz.name}. Open Business to approve or reject it.`, 'pending');
    return res.status(202).json({ payout: payoutView(await loadPayout(pool, p.id, req.biz.business_id)), needsApproval: true });
  }
  const receipt = await execute(req, p, risk, level, { revertTo: 'cancelled' });
  res.status(201).json({ payout: payoutView(await loadPayout(pool, p.id, req.biz.business_id)), needsApproval: false, receipt });
}));

router.get('/business/payouts', requireBizPerm('payouts.read'), wrap(async (req, res) => {
  const r = await pool.query(
    `SELECT p.*, u.full_name AS created_by_name, t.state AS txn_state, t.reference AS txn_ref
     FROM business_payouts p JOIN users u ON u.id=p.created_by LEFT JOIN transactions t ON t.id=p.txn_id
     WHERE p.business_id=$1 ORDER BY p.created_at DESC LIMIT 50`, [req.biz.business_id]);
  res.json({ payouts: r.rows.map(payoutView) });
}));

router.post('/business/payouts/:id/approve', requireBizPerm('payouts.approve'), wrap(async (req, res) => {
  const p = await loadPayout(pool, req.params.id, req.biz.business_id);
  if (!p || p.status !== 'pending_approval') throw new AppError(404, 'NOT_FOUND', 'Payout not found, or it was already handled.');
  if (p.created_by === req.user.id) throw new AppError(403, 'SAME_PERSON', 'Someone else must approve a payout you created.');
  const bizWallet = await businessWalletOf(pool, req.biz.business_id);
  const { risk, level } = await authorisePayment(req, { password: req.body?.password, otp: req.body?.otp, amountMinor: Number(p.amount_minor), walletId: bizWallet });
  const receipt = await execute(req, p, risk, level, { revertTo: 'pending_approval' });
  await audit(req, 'business.payout_approved', req.biz.business_id, { payoutId: p.id });
  await notify(pool, p.created_by, 'Payout approved', `Your ${fmt(Number(p.amount_minor))} payout was approved by the owner.`, 'info');
  res.json({ payout: payoutView(await loadPayout(pool, p.id, req.biz.business_id)), receipt });
}));

router.post('/business/payouts/:id/reject', requireBizPerm('payouts.approve'), wrap(async (req, res) => {
  const r = await pool.query(
    `UPDATE business_payouts SET status='rejected', decided_by=$3, decided_at=now() WHERE id=$1 AND business_id=$2 AND status='pending_approval' RETURNING created_by, amount_minor`,
    [req.params.id, req.biz.business_id, req.user.id]);
  if (!r.rows[0]) throw new AppError(404, 'NOT_FOUND', 'Payout not found, or it was already handled.');
  await audit(req, 'business.payout_rejected', req.biz.business_id, { payoutId: req.params.id });
  await notify(pool, r.rows[0].created_by, 'Payout rejected', `The owner rejected your ${fmt(Number(r.rows[0].amount_minor))} payout. No money moved.`, 'failed');
  res.json({ ok: true });
}));

// The person who proposed a payout may withdraw it while it is waiting.
router.post('/business/payouts/:id/cancel', requireBizPerm('payouts.create'), wrap(async (req, res) => {
  const r = await pool.query(
    `UPDATE business_payouts SET status='cancelled', decided_at=now() WHERE id=$1 AND business_id=$2 AND created_by=$3 AND status='pending_approval' RETURNING id`,
    [req.params.id, req.biz.business_id, req.user.id]);
  if (!r.rows[0]) throw new AppError(404, 'NOT_FOUND', 'Payout not found, or it was already handled.');
  res.json({ ok: true });
}));

// ---------------------------------------------------------------- handing the business to a new owner
// Both people confirm with password and a two-step code. The new owner must already be on the team. The business
// wallet, approvals and limits move with the ownership (limits follow the NEW owner's verification level).
async function proveIt(req) {
  await assertPassword(req.user.id, req.body?.password);
  const u = await getUserRow(req.user.id);
  if (!u.mfa_method) throw new AppError(403, 'MFA_REQUIRED', 'Turn on two-step verification in Security before changing who owns a business.');
  if (!(await checkSecondFactor(u, req.body?.code, 'stepup'))) throw new AppError(401, 'BAD_CODE', 'Enter a valid verification code to confirm.');
}

router.post('/business/ownership/offer', requireBizPerm('settings.manage'), wrap(async (req, res) => {
  const { memberId, keepAccess } = req.body || {};
  await proveIt(req);
  const m = (await pool.query(
    `SELECT m.user_id, u.full_name, u.kyc_tier FROM business_members m JOIN users u ON u.id=m.user_id
     WHERE m.id=$1 AND m.business_id=$2 AND m.status='active' AND m.role<>'owner' AND u.status='active'`, [memberId, req.biz.business_id])).rows[0];
  if (!m) throw new AppError(404, 'NOT_FOUND', 'Choose someone who is already on your team.');
  if (m.kyc_tier < 1) throw new AppError(422, 'KYC_REQUIRED', 'The new owner must verify their identity first (level 1 in Security).');
  try {
    await pool.query(`INSERT INTO business_transfers(business_id, from_user, to_user, keep_access) VALUES ($1,$2,$3,$4)`,
      [req.biz.business_id, req.user.id, m.user_id, keepAccess !== false]);
  } catch (e) {
    if (e.code === '23505') throw new AppError(409, 'ALREADY_OFFERED', 'There is already an offer waiting. Withdraw it first.');
    throw e;
  }
  await notify(pool, m.user_id, 'You were offered a business', `${(await userName(pool, req.user.id)) || 'The owner'} wants to make you the owner of ${req.biz.name}. Open Business to review it. The offer ends in 3 days.`, 'security');
  await audit(req, 'business.ownership_offered', req.biz.business_id, { to: m.user_id });
  res.status(201).json({ ok: true });
}));

router.post('/business/ownership/:id/cancel', requireBizPerm('settings.manage'), wrap(async (req, res) => {
  const r = await pool.query(`UPDATE business_transfers SET status='cancelled', decided_at=now() WHERE id=$1 AND business_id=$2 AND status='pending' RETURNING to_user`, [req.params.id, req.biz.business_id]);
  if (!r.rows[0]) throw new AppError(404, 'NOT_FOUND', 'Offer not found.');
  await audit(req, 'business.ownership_withdrawn', req.biz.business_id);
  res.json({ ok: true });
}));

router.post('/business/ownership/:id/decline', wrap(async (req, res) => {
  const r = await pool.query(`UPDATE business_transfers SET status='declined', decided_at=now() WHERE id=$1 AND to_user=$2 AND status='pending' RETURNING from_user, business_id`, [req.params.id, req.user.id]);
  if (!r.rows[0]) throw new AppError(404, 'NOT_FOUND', 'Offer not found.');
  await notify(pool, r.rows[0].from_user, 'Ownership offer declined', 'They did not take the business. Nothing changed.', 'info');
  res.json({ ok: true });
}));

router.post('/business/ownership/:id/accept', wrap(async (req, res) => {
  await proveIt(req);
  const t = (await pool.query(
    `SELECT t.*, b.name FROM business_transfers t JOIN businesses b ON b.id=t.business_id WHERE t.id=$1 AND t.to_user=$2 AND t.status='pending'`, [req.params.id, req.user.id])).rows[0];
  if (!t) throw new AppError(404, 'NOT_FOUND', 'Offer not found.');
  if (new Date(t.expires_at) < new Date()) {
    await pool.query(`UPDATE business_transfers SET status='expired', decided_at=now() WHERE id=$1`, [t.id]);
    throw new AppError(410, 'EXPIRED', 'This offer has expired. Ask the owner to make a new one.');
  }
  await withTx(async (c) => {
    // Claim the offer, and re-check that both people are still who they were.
    const claim = await c.query(`UPDATE business_transfers SET status='accepted', decided_at=now() WHERE id=$1 AND status='pending' RETURNING id`, [t.id]);
    if (!claim.rows[0]) throw new AppError(409, 'NOT_PENDING', 'This offer was already handled.');
    const cur = (await c.query(`SELECT owner_id FROM businesses WHERE id=$1 FOR UPDATE`, [t.business_id])).rows[0];
    if (cur.owner_id !== t.from_user) throw new AppError(409, 'CHANGED', 'The owner changed since this offer was made.');
    const me = (await c.query(`SELECT id FROM business_members WHERE business_id=$1 AND user_id=$2 AND status='active' AND role<>'owner'`, [t.business_id, t.to_user])).rows[0];
    if (!me) throw new AppError(409, 'NOT_ON_TEAM', 'You are no longer on this team.');
    // Order matters: there can be only one active owner at a time.
    if (t.keep_access) await c.query(`UPDATE business_members SET role='finance', updated_at=now() WHERE business_id=$1 AND user_id=$2`, [t.business_id, t.from_user]);
    else await c.query(`UPDATE business_members SET status='removed', updated_at=now() WHERE business_id=$1 AND user_id=$2`, [t.business_id, t.from_user]);
    await c.query(`UPDATE business_members SET role='owner', updated_at=now() WHERE id=$1`, [me.id]);
    await c.query(`UPDATE businesses SET owner_id=$2 WHERE id=$1`, [t.business_id, t.to_user]);
    await c.query(`UPDATE accounts SET user_id=$2 WHERE business_id=$1`, [t.business_id, t.to_user]);   // the wallet follows its owner
    if (!t.keep_access) await c.query(`UPDATE business_payouts SET status='cancelled', decided_at=now() WHERE business_id=$1 AND created_by=$2 AND status='pending_approval'`, [t.business_id, t.from_user]);
    await c.query(`INSERT INTO audit_log(actor_type, actor_id, action, target_type, target_id, ip_address, metadata) VALUES ('user',$1,'business.ownership_accepted','business',$2,$3,$4)`,
      [req.user.id, t.business_id, req.ip, JSON.stringify({ from: t.from_user, keepAccess: t.keep_access })]);
  });
  await notify(pool, t.from_user, 'Business handed over', `${t.name} now belongs to the new owner.${t.keep_access ? ' You stay on as a finance manager.' : ' You no longer have access.'}`, 'security');
  await notify(pool, req.user.id, 'You now own a business', `You are now the owner of ${t.name}. Check the approval limit and the daily cap in Business.`, 'security');
  res.json({ ok: true });
}));

export default router;
