// Shared pockets: joint wallets and child wallets. Rules are in services/pocketRules.js. Every check is on the server.
import crypto from 'node:crypto';
import { Router } from 'express';
import { pool, withTx } from '../db.js';
import { config } from '../config.js';
import { AppError, wrap } from '../errors.js';
import { requireAuth } from '../middleware/auth.js';
import { isEmail, fmt } from '../utils/format.js';
import { notify } from '../services/notify.js';
import { createAccount, walletOf, pocketWalletOf, availableBalance } from '../services/ledger.js';
import { transfer, hashRequest, assertAmount } from '../services/transfers.js';
import { authorisePayment } from '../services/guard.js';
import { recordRisk, monitorAml, assertNotSanctioned } from '../services/risk.js';
import { pocketCan, paymentDecision, canApprove, weekStart, POCKET_PERMS } from '../services/pocketRules.js';

const router = Router();
router.use(requireAuth);

const KIND_ROLE = { joint: 'partner', child: 'child' };
const audit = (req, action, pocketId, meta = {}) =>
  pool.query(`INSERT INTO audit_log(actor_type, actor_id, action, target_type, target_id, ip_address, metadata) VALUES ('user',$1,$2,'pocket',$3,$4,$5)`,
    [req.user.id, action, pocketId || null, req.ip, JSON.stringify(meta)]);

// Loads the pocket and the caller's active membership, or 404 (never reveals pockets the caller is not in).
async function ctx(req, perm) {
  const r = await pool.query(
    `SELECT p.*, m.role AS my_role, m.id AS my_member_id FROM pockets p JOIN pocket_members m ON m.pocket_id=p.id AND m.user_id=$2 AND m.status='active' WHERE p.id=$1`,
    [req.params.id, req.user.id]);
  const p = r.rows[0];
  if (!p) throw new AppError(404, 'NOT_FOUND', 'Pocket not found.');
  if (perm && !pocketCan(p.my_role, perm)) throw new AppError(403, 'FORBIDDEN', 'Your role does not allow that.');
  return p;
}

const spentThisWeek = async (db, pocketId, userId) => Number((await db.query(
  `SELECT COALESCE(SUM(amount_minor),0) AS n FROM pocket_payments WHERE pocket_id=$1 AND created_by=$2 AND status='executed' AND created_at >= $3`,
  [pocketId, userId, weekStart()])).rows[0].n);

// ---------------------------------------------------------------- list, create
router.get('/pockets', wrap(async (req, res) => {
  const rows = (await pool.query(
    `SELECT p.id, p.kind, p.name, p.frozen, p.solo_limit_minor, p.weekly_limit_minor, p.allowance_minor, m.role
     FROM pockets p JOIN pocket_members m ON m.pocket_id=p.id AND m.user_id=$1 AND m.status='active' ORDER BY p.created_at`, [req.user.id])).rows;
  const pockets = [];
  for (const p of rows) {
    const wid = await pocketWalletOf(pool, p.id);
    const pending = Number((await pool.query(`SELECT COUNT(*) AS n FROM pocket_payments WHERE pocket_id=$1 AND status='pending_approval'`, [p.id])).rows[0].n);
    pockets.push({ id: p.id, kind: p.kind, name: p.name, myRole: p.role, frozen: p.frozen, balanceMinor: await availableBalance(pool, wid), pendingCount: pending,
      permissions: POCKET_PERMS[p.role],
      ...(p.role !== 'child' ? { soloLimitMinor: p.solo_limit_minor, weeklyLimitMinor: p.weekly_limit_minor, allowanceMinor: p.allowance_minor } : { weeklyLimitMinor: p.weekly_limit_minor }),
      ...(p.role === 'child' ? { spentThisWeekMinor: await spentThisWeek(pool, p.id, req.user.id) } : {}) });
  }
  const invites = (await pool.query(
    `SELECT m.id, m.role, p.kind, p.name, u.full_name AS from_name FROM pocket_members m JOIN pockets p ON p.id=m.pocket_id JOIN users u ON u.id=p.owner_id
     WHERE m.user_id=$1 AND m.status='invited' ORDER BY m.created_at DESC`, [req.user.id])).rows
    .map((i) => ({ id: i.id, role: i.role, kind: i.kind, name: i.name, fromName: i.from_name }));
  res.json({ pockets, invites });
}));

router.post('/pockets', wrap(async (req, res) => {
  const { kind, name } = req.body || {};
  if (!['joint', 'child'].includes(kind)) throw new AppError(422, 'INVALID_KIND', 'Choose a joint pocket or a child pocket.');
  if (typeof name !== 'string' || name.trim().length < 2 || name.length > 40) throw new AppError(422, 'INVALID_NAME', 'Give the pocket a name.');
  const u = (await pool.query('SELECT kyc_tier FROM users WHERE id=$1', [req.user.id])).rows[0];
  if (u.kyc_tier < 1) throw new AppError(403, 'KYC_REQUIRED', 'Verify your identity first (level 1 in Security).');
  const owned = Number((await pool.query(`SELECT COUNT(*) AS n FROM pockets WHERE owner_id=$1`, [req.user.id])).rows[0].n);
  if (owned >= 5) throw new AppError(422, 'TOO_MANY', 'You can have up to 5 pockets.');
  const id = await withTx(async (c) => {
    const p = (await c.query(`INSERT INTO pockets(kind, name, owner_id, allowance_next_on) VALUES ($1,$2,$3,NULL) RETURNING id`, [kind, name.trim(), req.user.id])).rows[0];
    await c.query(`INSERT INTO pocket_members(pocket_id, user_id, role, status) VALUES ($1,$2,'owner','active')`, [p.id, req.user.id]);
    const wid = await createAccount(c, { userId: req.user.id, type: 'customer_wallet', currency: 'NGN', name: name.trim() });
    await c.query('UPDATE accounts SET pocket_id=$2 WHERE id=$1', [wid, p.id]);
    return p.id;
  });
  await audit(req, 'pocket.created', id, { kind });
  res.status(201).json({ id });
}));

// ---------------------------------------------------------------- detail
router.get('/pockets/:id', wrap(async (req, res) => {
  const p = await ctx(req, 'view');
  const wid = await pocketWalletOf(pool, p.id);
  const members = (await pool.query(
    `SELECT m.id, m.user_id, m.role, m.status, u.full_name, u.email FROM pocket_members m JOIN users u ON u.id=m.user_id
     WHERE m.pocket_id=$1 AND m.status IN ('active','invited') ORDER BY (m.role='owner') DESC, m.created_at`, [p.id])).rows
    .map((m) => ({ id: m.id, role: m.role, status: m.status, name: m.full_name, email: p.my_role === 'child' ? undefined : m.email, you: m.user_id === req.user.id }));
  const recipients = (await pool.query(
    `SELECT r.id, u.full_name, u.email FROM pocket_recipients r JOIN users u ON u.id=r.user_id WHERE r.pocket_id=$1 ORDER BY r.created_at`, [p.id])).rows
    .map((r) => ({ id: r.id, name: r.full_name, email: r.email }));
  const payments = (await pool.query(
    `SELECT x.id, x.amount_minor, x.note, x.status, x.created_at, x.created_by, cu.full_name AS by_name, tu.full_name AS to_name, t.state AS txn_state
     FROM pocket_payments x JOIN users cu ON cu.id=x.created_by JOIN users tu ON tu.id=x.to_user_id LEFT JOIN transactions t ON t.id=x.txn_id
     WHERE x.pocket_id=$1 ORDER BY x.created_at DESC LIMIT 40`, [p.id])).rows
    .map((x) => ({ id: x.id, amountMinor: x.amount_minor, note: x.note, status: x.status, createdAt: x.created_at, by: x.by_name, to: x.to_name, state: x.txn_state, mine: x.created_by === req.user.id }));
  res.json({ pocket: { id: p.id, kind: p.kind, name: p.name, frozen: p.frozen, myRole: p.my_role, balanceMinor: await availableBalance(pool, wid),
    soloLimitMinor: p.solo_limit_minor, weeklyLimitMinor: p.weekly_limit_minor, allowanceMinor: p.allowance_minor, allowanceNextOn: p.allowance_next_on,
    spentThisWeekMinor: p.my_role === 'child' ? await spentThisWeek(pool, p.id, req.user.id) : undefined }, members, recipients, payments });
}));

// ---------------------------------------------------------------- people
// The reply never says whether the email has an account (no account probing).
router.post('/pockets/:id/members', wrap(async (req, res) => {
  const p = await ctx(req, 'manage');
  if (!isEmail(req.body?.email)) throw new AppError(422, 'INVALID_EMAIL', 'Enter a valid email.');
  const role = KIND_ROLE[p.kind];
  const count = Number((await pool.query(`SELECT COUNT(*) AS n FROM pocket_members WHERE pocket_id=$1 AND role=$2 AND status IN ('active','invited')`, [p.id, role])).rows[0].n);
  if (count >= (role === 'partner' ? 1 : 5)) throw new AppError(422, 'FULL', role === 'partner' ? 'A joint pocket has one partner.' : 'You can add up to 5 children.');
  const u = (await pool.query(`SELECT id FROM users WHERE email=$1 AND status='active' AND email_verified_at IS NOT NULL`, [req.body.email.toLowerCase()])).rows[0];
  if (u && u.id !== req.user.id) {
    try {
      const r = await pool.query(
        `INSERT INTO pocket_members(pocket_id, user_id, role, status, invited_by) VALUES ($1,$2,$3,'invited',$4)
         ON CONFLICT (pocket_id, user_id) DO UPDATE SET role=EXCLUDED.role, status='invited', invited_by=EXCLUDED.invited_by, updated_at=now()
         WHERE pocket_members.status IN ('removed','declined') RETURNING id`, [p.id, u.id, role, req.user.id]);
      if (r.rows[0]) {
        await notify(pool, u.id, 'Pocket invitation', `${p.name}: you were invited to a ${p.kind === 'joint' ? 'joint' : 'child'} pocket. Open Pockets to accept or decline.`, 'info');
        await audit(req, 'pocket.member_invited', p.id, { role });
      }
    } catch (e) { if (e.code !== '23505') throw e; }
  }
  res.status(202).json({ ok: true, note: 'If that person has a verified G-Plan account, they will see your invitation in Pockets.' });
}));

router.post('/pockets/invites/:memberId/:decision(accept|decline)', wrap(async (req, res) => {
  const inv = (await pool.query(
    `SELECT m.id, m.role, m.pocket_id, p.name, p.owner_id FROM pocket_members m JOIN pockets p ON p.id=m.pocket_id WHERE m.id=$1 AND m.user_id=$2 AND m.status='invited'`,
    [req.params.memberId, req.user.id])).rows[0];
  if (!inv) throw new AppError(404, 'NOT_FOUND', 'Invitation not found.');
  if (req.params.decision === 'decline') {
    await pool.query(`UPDATE pocket_members SET status='declined', updated_at=now() WHERE id=$1`, [inv.id]);
    return res.json({ ok: true });
  }
  try { await pool.query(`UPDATE pocket_members SET status='active', updated_at=now() WHERE id=$1`, [inv.id]); }
  catch (e) { if (e.code === '23505') throw new AppError(409, 'ALREADY_CHILD', 'You already have a child pocket.'); throw e; }
  await notify(pool, inv.owner_id, 'Invitation accepted', `Someone joined ${inv.name}.`, 'info');
  res.json({ ok: true });
}));

router.delete('/pockets/:id/members/:memberId', wrap(async (req, res) => {
  const p = await ctx(req, 'manage');
  const r = await pool.query(`UPDATE pocket_members SET status='removed', updated_at=now() WHERE id=$1 AND pocket_id=$2 AND role<>'owner' AND status IN ('active','invited') RETURNING user_id`, [req.params.memberId, p.id]);
  if (!r.rows[0]) throw new AppError(404, 'NOT_FOUND', 'Member not found.');
  await pool.query(`UPDATE pocket_payments SET status='cancelled', decided_at=now() WHERE pocket_id=$1 AND created_by=$2 AND status='pending_approval'`, [p.id, r.rows[0].user_id]);
  await audit(req, 'pocket.member_removed', p.id);
  await notify(pool, r.rows[0].user_id, 'Removed from a pocket', `You no longer have access to ${p.name}.`, 'security');
  res.json({ ok: true });
}));

router.post('/pockets/:id/leave', wrap(async (req, res) => {
  const p = await ctx(req);
  if (p.my_role === 'owner') throw new AppError(422, 'OWNER_CANNOT_LEAVE', 'The owner cannot leave. Remove the others and move the money out first.');
  await pool.query(`UPDATE pocket_members SET status='removed', updated_at=now() WHERE id=$1`, [p.my_member_id]);
  await pool.query(`UPDATE pocket_payments SET status='cancelled', decided_at=now() WHERE pocket_id=$1 AND created_by=$2 AND status='pending_approval'`, [p.id, req.user.id]);
  res.json({ ok: true });
}));

// Owner-only settings: limits, freeze, weekly allowance for a child pocket.
router.post('/pockets/:id/settings', wrap(async (req, res) => {
  const p = await ctx(req, 'manage');
  const b = req.body || {};
  const num = (v) => { const n = Number(v); if (!Number.isSafeInteger(n) || n < 0 || n > config.maxAmountMinor) throw new AppError(422, 'INVALID_AMOUNT', 'Enter a valid amount.'); return n; };
  if (b.soloLimitMinor !== undefined) await pool.query('UPDATE pockets SET solo_limit_minor=$2 WHERE id=$1', [p.id, num(b.soloLimitMinor)]);
  if (b.weeklyLimitMinor !== undefined) await pool.query('UPDATE pockets SET weekly_limit_minor=$2 WHERE id=$1', [p.id, num(b.weeklyLimitMinor)]);
  if (typeof b.frozen === 'boolean') await pool.query('UPDATE pockets SET frozen=$2 WHERE id=$1', [p.id, b.frozen]);
  if (b.allowanceMinor !== undefined) {
    if (p.kind !== 'child') throw new AppError(422, 'NOT_CHILD', 'Allowance is only for child pockets.');
    const a = num(b.allowanceMinor);
    // The first top-up is next Monday, or today if they chose a start date that is today or later.
    const today = new Date().toISOString().slice(0, 10);
    const start = typeof b.startDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(b.startDate) && b.startDate >= today ? b.startDate : today;
    await pool.query('UPDATE pockets SET allowance_minor=$2, allowance_next_on=$3 WHERE id=$1', [p.id, a, a > 0 ? start : null]);
  }
  await audit(req, 'pocket.settings_changed', p.id, { keys: Object.keys(b) });
  res.json({ ok: true });
}));

// People a child may pay. Only the parent edits this.
router.post('/pockets/:id/recipients', wrap(async (req, res) => {
  const p = await ctx(req, 'manage');
  if (p.kind !== 'child') throw new AppError(422, 'NOT_CHILD', 'Approved recipients are only for child pockets.');
  if (!isEmail(req.body?.email)) throw new AppError(422, 'INVALID_EMAIL', 'Enter a valid email.');
  const count = Number((await pool.query('SELECT COUNT(*) AS n FROM pocket_recipients WHERE pocket_id=$1', [p.id])).rows[0].n);
  if (count >= 20) throw new AppError(422, 'TOO_MANY', 'You can approve up to 20 people.');
  const u = (await pool.query(`SELECT id, full_name FROM users WHERE email=$1 AND status='active'`, [req.body.email.toLowerCase()])).rows[0];
  if (!u) throw new AppError(404, 'RECIPIENT_NOT_FOUND', 'No G-Plan account found for that email.');   // the parent is vetting a payee, so a clear answer helps
  assertNotSanctioned(u.full_name);
  await pool.query('INSERT INTO pocket_recipients(pocket_id, user_id, added_by) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING', [p.id, u.id, req.user.id]);
  res.status(201).json({ ok: true });
}));
router.delete('/pockets/:id/recipients/:rid', wrap(async (req, res) => {
  const p = await ctx(req, 'manage');
  await pool.query('DELETE FROM pocket_recipients WHERE id=$1 AND pocket_id=$2', [req.params.rid, p.id]);
  res.json({ ok: true });
}));

// ---------------------------------------------------------------- money
router.post('/pockets/:id/fund', wrap(async (req, res) => {
  const p = await ctx(req, 'fund');
  const { amountMinor, password, otp } = req.body || {};
  assertAmount(amountMinor);
  const from = await walletOf(pool, req.user.id, 'NGN');
  const to = await pocketWalletOf(pool, p.id);
  const { risk, level } = await authorisePayment(req, { password, otp, amountMinor });
  const receipt = await transfer({
    userId: req.user.id, fromAccountId: from, toAccountId: to, amountMinor, type: 'internal_transfer', description: `Added to ${p.name}`, category: 'transfers',
    riskLevel: level, meta: { pocketId: p.id }, idemKey: req.get('Idempotency-Key'), requestHash: hashRequest({ fund: amountMinor, to }),
  });
  if (!receipt.replayed) {
    recordRisk(req.user.id, risk, receipt.transactionId).catch(() => {});
    if (receipt.state === 'completed') monitorAml(req.user.id, receipt).catch(() => {});
  }
  res.status(receipt.replayed ? 200 : 201).json({ receipt });
}));

async function runPayment(pay, pocket, actor, level) {
  const to = await walletOf(pool, pay.to_user_id, 'NGN');
  if (!to) throw new AppError(422, 'RECIPIENT_UNAVAILABLE', 'That person cannot receive money right now.');
  const toName = (await pool.query('SELECT full_name FROM users WHERE id=$1', [pay.to_user_id])).rows[0].full_name;
  return transfer({
    userId: actor.id, pocketId: pocket.id, fromAccountId: await pocketWalletOf(pool, pocket.id), toAccountId: to, amountMinor: Number(pay.amount_minor),
    type: 'internal_transfer', description: `${pocket.name} payment to ${toName}${pay.note ? ' · ' + pay.note : ''}`, category: 'transfers', riskLevel: level,
    meta: { pocketId: pocket.id, paymentId: pay.id }, idemKey: `pocketpay:${pay.id}`, requestHash: hashRequest({ pocketPayment: pay.id }),
  });
}

async function execute(req, pay, pocket, risk, level, revertTo) {
  const claim = await pool.query(`UPDATE pocket_payments SET status='executed', decided_by=$2, decided_at=now() WHERE id=$1 AND status='pending_approval' RETURNING id`, [pay.id, req.user.id]);
  if (!claim.rows[0]) throw new AppError(409, 'NOT_PENDING', 'This payment was already handled.');
  try {
    const receipt = await runPayment(pay, pocket, req.user, level);
    await pool.query('UPDATE pocket_payments SET txn_id=$2 WHERE id=$1', [pay.id, receipt.transactionId]);
    if (!receipt.replayed) {
      recordRisk(req.user.id, risk, receipt.transactionId).catch(() => {});
      if (receipt.state === 'completed') monitorAml(req.user.id, receipt).catch(() => {});
    }
    return receipt;
  } catch (e) {
    // A known refusal happened before money moved, so put it back. Unknown errors stay claimed; the idempotency key stops a double payment.
    if (e instanceof AppError) await pool.query(`UPDATE pocket_payments SET status=$2, decided_by=NULL, decided_at=$3 WHERE id=$1 AND status='executed' AND txn_id IS NULL`, [pay.id, revertTo, revertTo === 'cancelled' ? new Date() : null]);
    throw e;
  }
}

router.post('/pockets/:id/pay', wrap(async (req, res) => {
  const p = await ctx(req, 'pay');
  const { email, recipientId, amountMinor, note, password, otp } = req.body || {};
  const clientKey = req.get('Idempotency-Key');
  if (!clientKey) throw new AppError(400, 'IDEMPOTENCY_KEY_REQUIRED', 'Missing Idempotency-Key header.');
  assertAmount(amountMinor);
  const prior = (await pool.query('SELECT id, status FROM pocket_payments WHERE created_by=$1 AND client_key=$2', [req.user.id, clientKey])).rows[0];
  if (prior) return res.status(200).json({ paymentId: prior.id, needsApproval: prior.status === 'pending_approval', replayed: true });

  // Who gets the money. A child can only choose from the approved list.
  let toUser, approved = false;
  if (recipientId) {
    toUser = (await pool.query(`SELECT u.id, u.full_name FROM pocket_recipients r JOIN users u ON u.id=r.user_id WHERE r.id=$1 AND r.pocket_id=$2 AND u.status='active'`, [recipientId, p.id])).rows[0];
    approved = !!toUser;
  } else if (isEmail(email)) {
    toUser = (await pool.query(`SELECT id, full_name FROM users WHERE email=$1 AND status='active'`, [email.toLowerCase()])).rows[0];
    approved = !!toUser && !!(await pool.query('SELECT 1 FROM pocket_recipients WHERE pocket_id=$1 AND user_id=$2', [p.id, toUser.id])).rowCount;
  }
  if (!toUser) throw new AppError(404, 'RECIPIENT_NOT_FOUND', p.my_role === 'child' ? 'Choose someone your parent approved.' : 'No G-Plan account found for that email.');
  assertNotSanctioned(toUser.full_name);
  const wid = await pocketWalletOf(pool, p.id);
  const { risk, level } = await authorisePayment(req, { password, otp, amountMinor, walletId: wid });

  // Decide and record in one locked step, so two quick requests cannot both slip under a weekly or solo limit.
  const out = await withTx(async (c) => {
    await c.query('SELECT pg_advisory_xact_lock(hashtext($1))', [p.id]);
    const decision = paymentDecision({ kind: p.kind, role: p.my_role, amountMinor, soloLimitMinor: p.solo_limit_minor, weeklyLimitMinor: p.weekly_limit_minor,
      spentThisWeekMinor: p.my_role === 'child' ? await spentThisWeek(c, p.id, req.user.id) : 0, frozen: p.frozen, recipientApproved: approved });
    if (decision.outcome === 'deny') throw new AppError(403, 'NOT_ALLOWED', decision.reason);
    const row = (await c.query(
      `INSERT INTO pocket_payments(pocket_id, created_by, client_key, to_user_id, amount_minor, note, status) VALUES ($1,$2,$3,$4,$5,$6,'pending_approval')
       ON CONFLICT (created_by, client_key) DO NOTHING RETURNING *`, [p.id, req.user.id, clientKey, toUser.id, amountMinor, typeof note === 'string' ? note.slice(0, 140) : null])).rows[0];
    if (!row) throw new AppError(409, 'IN_PROGRESS', 'This payment is already being created.');
    return { decision, row };
  });

  await audit(req, 'pocket.payment_created', p.id, { paymentId: out.row.id, amountMinor });
  if (out.decision.outcome === 'approval') {
    const others = (await pool.query(`SELECT user_id FROM pocket_members WHERE pocket_id=$1 AND status='active' AND user_id<>$2`, [p.id, req.user.id])).rows;
    for (const o of others) await notify(pool, o.user_id, 'Pocket payment waiting', `${fmt(amountMinor)} from ${p.name} needs your approval. Open Pockets.`, 'pending');
    return res.status(202).json({ paymentId: out.row.id, needsApproval: true });
  }
  const receipt = await execute(req, out.row, p, risk, level, 'cancelled');
  if (p.my_role === 'child') {
    await notify(pool, p.owner_id, 'Child pocket payment', `${fmt(amountMinor)} was sent from ${p.name} to ${toUser.full_name}.`, 'info');
  }
  res.status(201).json({ paymentId: out.row.id, needsApproval: false, receipt });
}));

router.post('/pockets/:id/payments/:pid/approve', wrap(async (req, res) => {
  const p = await ctx(req, 'approve');
  const pay = (await pool.query(`SELECT * FROM pocket_payments WHERE id=$1 AND pocket_id=$2 AND status='pending_approval'`, [req.params.pid, p.id])).rows[0];
  if (!pay) throw new AppError(404, 'NOT_FOUND', 'Payment not found, or it was already handled.');
  if (!canApprove(p.my_role, pay.created_by, req.user.id)) throw new AppError(403, 'SAME_PERSON', 'The other person must approve a payment you made.');
  if (p.frozen && p.my_role !== 'owner') throw new AppError(403, 'FROZEN', 'This pocket is frozen.');
  const wid = await pocketWalletOf(pool, p.id);
  const { risk, level } = await authorisePayment(req, { password: req.body?.password, otp: req.body?.otp, amountMinor: Number(pay.amount_minor), walletId: wid });
  const receipt = await execute(req, pay, p, risk, level, 'pending_approval');
  await audit(req, 'pocket.payment_approved', p.id, { paymentId: pay.id });
  await notify(pool, pay.created_by, 'Pocket payment approved', `Your ${fmt(Number(pay.amount_minor))} payment from ${p.name} was approved.`, 'info');
  res.json({ ok: true, receipt });
}));

router.post('/pockets/:id/payments/:pid/reject', wrap(async (req, res) => {
  const p = await ctx(req, 'approve');
  const r = await pool.query(
    `UPDATE pocket_payments SET status='rejected', decided_by=$3, decided_at=now() WHERE id=$1 AND pocket_id=$2 AND status='pending_approval' AND created_by<>$3 RETURNING created_by, amount_minor`,
    [req.params.pid, p.id, req.user.id]);
  if (!r.rows[0]) throw new AppError(404, 'NOT_FOUND', 'Payment not found, or you made it yourself.');
  await notify(pool, r.rows[0].created_by, 'Pocket payment rejected', `Your ${fmt(Number(r.rows[0].amount_minor))} payment from ${p.name} was rejected. No money moved.`, 'failed');
  res.json({ ok: true });
}));

router.post('/pockets/:id/payments/:pid/cancel', wrap(async (req, res) => {
  const p = await ctx(req, 'pay');
  const r = await pool.query(`UPDATE pocket_payments SET status='cancelled', decided_at=now() WHERE id=$1 AND pocket_id=$2 AND created_by=$3 AND status='pending_approval' RETURNING id`, [req.params.pid, p.id, req.user.id]);
  if (!r.rows[0]) throw new AppError(404, 'NOT_FOUND', 'Payment not found, or it was already handled.');
  res.json({ ok: true });
}));

export default router;
