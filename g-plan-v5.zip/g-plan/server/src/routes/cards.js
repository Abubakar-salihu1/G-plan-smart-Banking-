import crypto from 'node:crypto';
import { Router } from 'express';
import { pool } from '../db.js';
import { AppError, wrap } from '../errors.js';
import { requireAuth } from '../middleware/auth.js';
import { walletOf } from '../services/ledger.js';
import { hashRequest, assertAmount } from '../services/transfers.js';
import { payExternal } from '../services/payments.js';
import { mockCard } from '../services/providers.js';
import { notify } from '../services/notify.js';
import { assertPassword } from '../services/passwords.js';
import { fmt } from '../utils/format.js';

const router = Router();
router.use(requireAuth);

const CATEGORIES = ['food', 'transport', 'shopping', 'entertainment', 'health', 'education', 'gambling', 'other'];
const pub = (c) => ({
  id: c.id, label: c.label, kind: c.kind, last4: c.last4, expiry: c.expiry, status: c.status, physicalStatus: c.physical_status,
  monthlyLimitMinor: c.monthly_limit_minor, onlineEnabled: c.online_enabled, internationalEnabled: c.international_enabled,
  blockedCategories: c.blocked_categories, demo: true,
});

async function issue(userId, label, kind) {
  const last4 = String(crypto.randomInt(0, 10000)).padStart(4, '0');
  const d = new Date(); d.setUTCFullYear(d.getUTCFullYear() + 3);
  const expiry = `${String(d.getUTCMonth() + 1).padStart(2, '0')}/${String(d.getUTCFullYear()).slice(2)}`;
  return (await pool.query(
    `INSERT INTO cards(user_id, label, kind, last4, expiry, physical_status) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
    [userId, label, kind, last4, expiry, kind === 'physical' ? 'requested' : null])).rows[0];
}

router.get('/cards', wrap(async (req, res) => {
  const r = await pool.query(`SELECT * FROM cards WHERE user_id=$1 AND status<>'cancelled' ORDER BY created_at DESC`, [req.user.id]);
  const spent = await pool.query(
    `SELECT meta->>'card_id' AS card_id, SUM(amount_minor) AS spent FROM transactions
     WHERE initiator_user_id=$1 AND type='card_payment' AND state='completed' AND created_at >= date_trunc('month', now())
     GROUP BY 1`, [req.user.id]);
  const map = new Map(spent.rows.map((s) => [s.card_id, s.spent]));
  res.json({ cards: r.rows.map((c) => ({ ...pub(c), spentThisMonthMinor: map.get(c.id) || 0 })), categories: CATEGORIES });
}));

router.post('/cards', wrap(async (req, res) => {
  const { label, kind } = req.body || {};
  const k = kind === 'physical' ? 'physical' : 'virtual';
  const n = (await pool.query(`SELECT COUNT(*) AS n FROM cards WHERE user_id=$1 AND status<>'cancelled'`, [req.user.id])).rows[0].n;
  if (n >= 3) throw new AppError(422, 'TOO_MANY', 'You can have up to 3 active cards.');
  const c = await issue(req.user.id, String(label || (k === 'physical' ? 'Physical card' : 'Virtual card')).slice(0, 30), k);
  if (k === 'physical') {
    await pool.query(`INSERT INTO service_requests(user_id, type, details) VALUES ($1,'physical_card',$2)`, [req.user.id, JSON.stringify({ cardId: c.id })]);
  }
  await notify(pool, req.user.id, 'Card created', `${c.label} ending ${c.last4} is ready (demo card).`, 'card');
  res.status(201).json({ card: pub(c) });
}));

router.patch('/cards/:id', wrap(async (req, res) => {
  const b = req.body || {};
  const c = (await pool.query('SELECT * FROM cards WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id])).rows[0];
  if (!c || c.status === 'cancelled') throw new AppError(404, 'NOT_FOUND', 'Card not found.');
  const sets = [], params = [];
  const set = (col, v) => { params.push(v); sets.push(`${col}=$${params.length}`); };
  if (b.status !== undefined) {
    if (!['active', 'frozen'].includes(b.status)) throw new AppError(422, 'INVALID_STATUS', 'Invalid status.');
    set('status', b.status);
  }
  if (b.monthlyLimitMinor !== undefined) { assertAmount(b.monthlyLimitMinor); set('monthly_limit_minor', b.monthlyLimitMinor); }
  if (b.onlineEnabled !== undefined) set('online_enabled', !!b.onlineEnabled);
  if (b.internationalEnabled !== undefined) set('international_enabled', !!b.internationalEnabled);
  if (b.blockedCategories !== undefined) {
    if (!Array.isArray(b.blockedCategories) || !b.blockedCategories.every((x) => CATEGORIES.includes(x))) throw new AppError(422, 'INVALID_CATEGORY', 'Invalid category.');
    set('blocked_categories', b.blockedCategories);
  }
  if (!sets.length) return res.json({ ok: true });
  params.push(c.id);
  await pool.query(`UPDATE cards SET ${sets.join(', ')} WHERE id=$${params.length}`, params);
  if (b.status) await notify(pool, req.user.id, b.status === 'frozen' ? 'Card frozen' : 'Card unfrozen', `${c.label} ending ${c.last4}`, 'card');
  await pool.query(`INSERT INTO audit_log(actor_type, actor_id, action, target_id) VALUES ('user',$1,'card.update',$2)`, [req.user.id, c.id]);
  res.json({ ok: true });
}));

// Lost or damaged: cancel and issue a replacement with the same label.
router.post('/cards/:id/replace', wrap(async (req, res) => {
  await assertPassword(req.user.id, req.body?.password);
  const c = (await pool.query('SELECT * FROM cards WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id])).rows[0];
  if (!c || c.status === 'cancelled') throw new AppError(404, 'NOT_FOUND', 'Card not found.');
  await pool.query(`UPDATE cards SET status='cancelled' WHERE id=$1`, [c.id]);
  const n = await issue(req.user.id, c.label, c.kind);
  await pool.query(`INSERT INTO service_requests(user_id, type, details) VALUES ($1,'card_replacement',$2)`, [req.user.id, JSON.stringify({ oldCardId: c.id, newCardId: n.id })]);
  await notify(pool, req.user.id, 'Card replaced', `Old card ending ${c.last4} is blocked. New card ends ${n.last4}.`, 'card');
  res.status(201).json({ card: pub(n) });
}));

// DEMO purchase so the card controls can be shown working. No real card network is involved.
router.post('/cards/:id/charge', wrap(async (req, res) => {
  const { merchant, category, amountMinor, online, international } = req.body || {};
  assertAmount(amountMinor);
  const c = (await pool.query('SELECT * FROM cards WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id])).rows[0];
  if (!c || c.status === 'cancelled') throw new AppError(404, 'NOT_FOUND', 'Card not found.');
  const cat = CATEGORIES.includes(category) ? category : 'other';
  const name = String(merchant || 'Demo merchant').slice(0, 40);
  const decline = async (reason) => {
    await notify(pool, req.user.id, 'Card payment declined', `${name} ${fmt(amountMinor)}: ${reason}`, 'card');
    throw new AppError(422, 'CARD_DECLINED', `Declined: ${reason}`);
  };
  if (c.status === 'frozen') await decline('this card is frozen.');
  if (online && !c.online_enabled) await decline('online payments are turned off for this card.');
  if (international && !c.international_enabled) await decline('international use is turned off for this card.');
  if (c.blocked_categories.includes(cat)) await decline(`${cat} payments are blocked on this card.`);
  const spent = (await pool.query(
    `SELECT COALESCE(SUM(amount_minor),0) AS s FROM transactions WHERE type='card_payment' AND state IN ('completed','processing')
     AND meta->>'card_id'=$1 AND created_at >= date_trunc('month', now())`, [c.id])).rows[0].s;
  if (spent + amountMinor > c.monthly_limit_minor) await decline('this would go over the card\'s monthly limit.');
  const wallet = await walletOf(pool, req.user.id, 'NGN');
  const receipt = await payExternal({
    userId: req.user.id, walletId: wallet, amountMinor, type: 'card_payment', description: `${name} (card •••• ${c.last4})`,
    category: cat === 'other' ? 'shopping' : cat, meta: { card_id: c.id, merchant: name, payee: name },
    idemKey: req.get('Idempotency-Key'), requestHash: hashRequest({ card: c.id, amountMinor, name }), provider: mockCard,
  });
  res.status(receipt.replayed ? 200 : 201).json({ receipt });
}));

export default router;
