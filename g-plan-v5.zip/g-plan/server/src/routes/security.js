import { Router } from 'express';
import { pool } from '../db.js';
import { AppError, wrap } from '../errors.js';
import { requireAuth } from '../middleware/auth.js';
import { assertPassword } from '../services/passwords.js';
import { newSecret, otpauthUrl, verifyTotp } from '../utils/totp.js';
import { encrypt, decrypt } from '../utils/crypto.js';
import { sendOtp, verifyOtp } from '../services/otp.js';
import { getUserRow, checkSecondFactor } from '../services/mfa.js';
import { notify } from '../services/notify.js';
import { verifyIdentity } from '../services/kyc.js';
import * as kycDocs from '../services/kycDocs.js';
import { screenName, openAmlCase } from '../services/risk.js';
import * as passkeys from '../services/webauthn.js';
import { assertAmount } from '../services/transfers.js';
import { config } from '../config.js';
import { issueCodes, codesLeft, deleteCodes } from '../services/recovery.js';

const router = Router();
router.use(requireAuth);
const audit = (req, action, target) =>
  pool.query(`INSERT INTO audit_log(actor_type, actor_id, action, target_id, ip_address) VALUES ('user',$1,$2,$3,$4)`, [req.user.id, action, target || null, req.ip]);

router.get('/security/overview', wrap(async (req, res) => {
  const id = req.user.id;
  const u = (await pool.query(
    `SELECT mfa_method, kyc_tier, email_verified_at, phone_verified_at, phone, last_login_at FROM users WHERE id=$1`, [id])).rows[0];
  const sessions = (await pool.query(
    `SELECT id, user_agent, ip, method, created_at, last_seen_at FROM sessions
     WHERE user_id=$1 AND revoked_at IS NULL AND last_seen_at > now() - interval '12 hours' ORDER BY last_seen_at DESC LIMIT 10`, [id])).rows;
  const logins = (await pool.query(
    `SELECT success, method, reason, ip, user_agent, created_at FROM login_events WHERE user_id=$1 ORDER BY created_at DESC LIMIT 15`, [id])).rows;
  const pk = (await pool.query('SELECT id, label, created_at, last_used_at FROM passkeys WHERE user_id=$1 ORDER BY created_at', [id])).rows;
  const kyc = (await pool.query('SELECT tier_requested, id_type, status, created_at FROM kyc_submissions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 3', [id])).rows;
  const checks = [!!u.mfa_method, pk.length > 0, !!u.email_verified_at, !!u.phone_verified_at, u.kyc_tier >= 1];
  res.json({
    mfaMethod: u.mfa_method, kycTier: u.kyc_tier, hasPhone: !!u.phone, emailVerified: !!u.email_verified_at, phoneVerified: !!u.phone_verified_at,
    passkeys: pk, sessions: sessions.map((s) => ({ ...s, current: s.id === req.session.id })), logins, kyc,
    recoveryCodesLeft: u.mfa_method ? await codesLeft(pool, id) : null,
    protection: { done: checks.filter(Boolean).length, total: checks.length },
  });
}));

// ---- Two-step verification: authenticator app ----
router.post('/security/mfa/totp/setup', wrap(async (req, res) => {
  await assertPassword(req.user.id, req.body?.password);
  const secret = newSecret();
  await pool.query('UPDATE users SET totp_pending=$2 WHERE id=$1', [req.user.id, encrypt(secret)]);
  const u = await getUserRow(req.user.id);
  res.json({ secret, otpauthUrl: otpauthUrl(secret, u.email) });
}));

router.post('/security/mfa/totp/confirm', wrap(async (req, res) => {
  const row = (await pool.query('SELECT totp_pending FROM users WHERE id=$1', [req.user.id])).rows[0];
  if (!row?.totp_pending) throw new AppError(422, 'NO_SETUP', 'Start the setup first.');
  const secret = decrypt(row.totp_pending);
  if (!verifyTotp(secret, req.body?.code)) throw new AppError(401, 'BAD_CODE', 'That code is not right. Check your phone clock and try again.');
  await pool.query(`UPDATE users SET totp_secret=$2, totp_pending=NULL, mfa_method='totp' WHERE id=$1`, [req.user.id, encrypt(secret)]);
  await audit(req, 'mfa.enabled', 'totp');
  await notify(pool, req.user.id, 'Two-step verification on', 'Authenticator app added.', 'security');
  res.json({ ok: true, recoveryCodes: await issueCodes(pool, req.user.id) });
}));

// ---- Two-step verification: code by SMS or email ----
router.post('/security/mfa/otp/start', wrap(async (req, res) => {
  const { channel, password } = req.body || {};
  if (!['sms', 'email'].includes(channel)) throw new AppError(422, 'INVALID_CHANNEL', 'Choose SMS or email.');
  await assertPassword(req.user.id, password);
  const u = await getUserRow(req.user.id);
  res.json(await sendOtp(u, 'mfa-enable', channel));
}));
router.post('/security/mfa/otp/confirm', wrap(async (req, res) => {
  const { channel, code } = req.body || {};
  if (!['sms', 'email'].includes(channel)) throw new AppError(422, 'INVALID_CHANNEL', 'Choose SMS or email.');
  if (!(await verifyOtp(req.user.id, 'mfa-enable', code))) throw new AppError(401, 'BAD_CODE', 'That code is not right or has expired.');
  await pool.query(`UPDATE users SET mfa_method=$2, ${channel === 'sms' ? 'phone_verified_at' : 'email_verified_at'}=now(),
                    totp_secret=NULL, totp_pending=NULL WHERE id=$1`, [req.user.id, channel]);
  await audit(req, 'mfa.enabled', channel);
  await notify(pool, req.user.id, 'Two-step verification on', `Codes will be sent by ${channel}.`, 'security');
  res.json({ ok: true, recoveryCodes: await issueCodes(pool, req.user.id) });
}));

router.post('/security/mfa/disable', wrap(async (req, res) => {
  await assertPassword(req.user.id, req.body?.password);
  const u = await getUserRow(req.user.id);
  if (!u.mfa_method) return res.json({ ok: true });
  if (!(await checkSecondFactor(u, req.body?.code, 'stepup'))) throw new AppError(401, 'BAD_CODE', 'Enter a valid verification code to turn this off.');
  await pool.query(`UPDATE users SET mfa_method=NULL, totp_secret=NULL, totp_pending=NULL WHERE id=$1`, [req.user.id]);
  await deleteCodes(pool, req.user.id);
  await audit(req, 'mfa.disabled');
  await notify(pool, req.user.id, 'Two-step verification off', 'If this was not you, change your password now.', 'security');
  res.json({ ok: true });
}));

// ---- Recovery codes: a new set replaces the old one. Needs the password AND a current second-factor code. ----
router.post('/security/recovery-codes/regenerate', wrap(async (req, res) => {
  await assertPassword(req.user.id, req.body?.password);
  const u = await getUserRow(req.user.id);
  if (!u.mfa_method) throw new AppError(422, 'NO_MFA', 'Turn on two-step verification first.');
  if (!(await checkSecondFactor(u, req.body?.code, 'stepup'))) throw new AppError(401, 'BAD_CODE', 'Enter a valid verification code to make new recovery codes.');
  const codes = await issueCodes(pool, req.user.id);
  await audit(req, 'mfa.recovery_codes_regenerated');
  await notify(pool, req.user.id, 'New recovery codes made', 'Your old recovery codes no longer work. If this was not you, change your password now.', 'security');
  res.json({ ok: true, recoveryCodes: codes });
}));

// ---- Verify email / phone (without enabling two-step) ----
router.post('/security/verify/send', wrap(async (req, res) => {
  const { channel } = req.body || {};
  if (!['sms', 'email'].includes(channel)) throw new AppError(422, 'INVALID_CHANNEL', 'Choose SMS or email.');
  res.json(await sendOtp(await getUserRow(req.user.id), 'verify-contact', channel));
}));
router.post('/security/verify/confirm', wrap(async (req, res) => {
  const { channel, code } = req.body || {};
  if (!['sms', 'email'].includes(channel)) throw new AppError(422, 'INVALID_CHANNEL', 'Choose SMS or email.');
  if (!(await verifyOtp(req.user.id, 'verify-contact', code))) throw new AppError(401, 'BAD_CODE', 'That code is not right or has expired.');
  await pool.query(`UPDATE users SET ${channel === 'sms' ? 'phone_verified_at' : 'email_verified_at'}=now() WHERE id=$1`, [req.user.id]);
  res.json({ ok: true });
}));

// ---- Passkeys (biometric login) ----
router.post('/security/passkeys/options', wrap(async (req, res) => {
  await assertPassword(req.user.id, req.body?.password);
  res.json(await passkeys.registrationOptions(req, await getUserRow(req.user.id)));
}));
router.post('/security/passkeys/verify', wrap(async (req, res) => {
  await passkeys.registrationVerify(req, await getUserRow(req.user.id), req.body?.response, req.body?.label);
  await audit(req, 'passkey.added');
  await notify(pool, req.user.id, 'Passkey added', 'You can now sign in with your fingerprint, face or device PIN.', 'security');
  res.json({ ok: true });
}));
router.delete('/security/passkeys/:id', wrap(async (req, res) => {
  await assertPassword(req.user.id, req.body?.password);
  await pool.query('DELETE FROM passkeys WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id]);
  await audit(req, 'passkey.removed', req.params.id);
  res.json({ ok: true });
}));

// ---- Sessions ----
router.post('/security/sessions/revoke-others', wrap(async (req, res) => {
  await pool.query('UPDATE sessions SET revoked_at=now() WHERE user_id=$1 AND id<>$2 AND revoked_at IS NULL', [req.user.id, req.session.id]);
  await audit(req, 'sessions.revoke_others');
  res.json({ ok: true });
}));
router.post('/security/sessions/:id/revoke', wrap(async (req, res) => {
  await pool.query('UPDATE sessions SET revoked_at=now() WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id]);
  res.json({ ok: true });
}));

// ---- KYC (mock verification, ID number is never stored) ----
router.post('/kyc', wrap(async (req, res) => {
  const { tier, idType, idNumber } = req.body || {};
  const t = Number(tier);
  if (![1, 2, 3].includes(t)) throw new AppError(422, 'INVALID_TIER', 'Choose a tier.');
  const u = (await pool.query('SELECT full_name, kyc_tier FROM users WHERE id=$1', [req.user.id])).rows[0];
  if (t <= u.kyc_tier) throw new AppError(422, 'ALREADY_VERIFIED', 'You are already at this level.');
  if (t > u.kyc_tier + 1) throw new AppError(422, 'ORDER', 'Complete the previous tier first.');
  const today = (await pool.query(`SELECT COUNT(*) AS n FROM kyc_submissions WHERE user_id=$1 AND created_at > now() - interval '1 day'`, [req.user.id])).rows[0].n;
  if (today >= 3) throw new AppError(429, 'TOO_MANY', 'Too many attempts today. Try again tomorrow.');
  const missing = await kycDocs.missingKinds(pool, req.user.id, t);
  if (missing.length) throw new AppError(422, 'DOCUMENTS_REQUIRED', `Upload these photos first: ${missing.map((k) => k.replace('_', ' ')).join(', ')}.`);
  const v = await verifyIdentity({ tier: t, idType, idNumber });
  if (screenName(u.full_name)) {
    await openAmlCase(req.user.id, null, 'screening_hit_at_kyc', { tier: t });
    throw new AppError(403, 'REVIEW_REQUIRED', 'We need to review your application. Our team will contact you.');
  }
  const last4 = String(idNumber).slice(-4);
  const status = v.auto ? 'approved' : 'pending';
  const sub = (await pool.query(`INSERT INTO kyc_submissions(user_id, tier_requested, id_type, id_last4, status) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
    [req.user.id, t, idType, last4, status])).rows[0];
  await kycDocs.attach(pool, req.user.id, sub.id);
  if (status !== 'pending') await kycDocs.markDecided(pool, sub.id);
  if (v.auto) await pool.query('UPDATE users SET kyc_tier=$2 WHERE id=$1', [req.user.id, t]);
  await audit(req, 'kyc.submitted', `tier${t}`);
  res.status(201).json({ status, mock: true,
    note: v.auto ? 'Demo verification: approved automatically. A real provider check is not connected.' : 'Submitted for review by our compliance team.' });
}));

// ---- Notifications ----
router.get('/notifications', wrap(async (req, res) => {
  const r = await pool.query('SELECT id, title, body, kind, read_at, created_at FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50', [req.user.id]);
  const unread = (await pool.query('SELECT COUNT(*) AS n FROM notifications WHERE user_id=$1 AND read_at IS NULL', [req.user.id])).rows[0].n;
  res.json({ notifications: r.rows, unread });
}));
router.post('/notifications/read-all', wrap(async (req, res) => {
  await pool.query('UPDATE notifications SET read_at=now() WHERE user_id=$1 AND read_at IS NULL', [req.user.id]);
  res.json({ ok: true });
}));

// ---- Service requests ----
const SERVICE_TYPES = ['checkbook', 'physical_card', 'card_replacement', 'statement_request', 'address_change', 'other'];
router.post('/services', wrap(async (req, res) => {
  const { type, note } = req.body || {};
  if (!SERVICE_TYPES.includes(type)) throw new AppError(422, 'INVALID_TYPE', 'Choose a request type.');
  const r = await pool.query(`INSERT INTO service_requests(user_id, type, details) VALUES ($1,$2,$3) RETURNING id`,
    [req.user.id, type, JSON.stringify({ note: String(note || '').slice(0, 300) })]);
  await notify(pool, req.user.id, 'Request received', `Your ${type.replace(/_/g, ' ')} request was received (demo).`, 'info');
  res.status(201).json({ id: r.rows[0].id });
}));
router.get('/services', wrap(async (req, res) => {
  const r = await pool.query('SELECT id, type, details, status, created_at FROM service_requests WHERE user_id=$1 ORDER BY created_at DESC LIMIT 20', [req.user.id]);
  res.json({ requests: r.rows, types: SERVICE_TYPES });
}));

// ---- Mobile cheque deposit (DEMO: the photo is not uploaded or stored) ----
router.post('/cheques', wrap(async (req, res) => {
  const { amountMinor, payerName, chequeLast4 } = req.body || {};
  assertAmount(amountMinor);
  if (amountMinor > 100_000_000) throw new AppError(422, 'LIMIT_EXCEEDED', 'Cheque deposits are limited to ₦1,000,000 in this demo.');
  if (typeof payerName !== 'string' || payerName.trim().length < 2) throw new AppError(422, 'INVALID_NAME', 'Enter the name on the cheque.');
  if (screenName(payerName)) { await openAmlCase(req.user.id, null, 'screening_hit_cheque', { }); throw new AppError(403, 'REVIEW_REQUIRED', 'This deposit needs a compliance review.'); }
  const n = (await pool.query(`SELECT COUNT(*) AS n FROM cheque_deposits WHERE user_id=$1 AND created_at > now() - interval '1 day'`, [req.user.id])).rows[0].n;
  if (n >= 5) throw new AppError(429, 'TOO_MANY', 'Too many cheque deposits today.');
  const r = await pool.query(`INSERT INTO cheque_deposits(user_id, amount_minor, payer_name, cheque_last4) VALUES ($1,$2,$3,$4) RETURNING id`,
    [req.user.id, amountMinor, payerName.trim().slice(0, 60), /^\d{4}$/.test(String(chequeLast4 || '')) ? chequeLast4 : null]);
  await notify(pool, req.user.id, 'Cheque received for review', 'We will credit your wallet after it is reviewed (demo).', 'info');
  res.status(201).json({ id: r.rows[0].id });
}));
router.get('/cheques', wrap(async (req, res) => {
  const r = await pool.query('SELECT id, amount_minor, payer_name, status, created_at FROM cheque_deposits WHERE user_id=$1 ORDER BY created_at DESC LIMIT 20', [req.user.id]);
  res.json({ cheques: r.rows });
}));

// ---- Disputes ----
router.post('/disputes', wrap(async (req, res) => {
  const { reference, reason } = req.body || {};
  if (typeof reason !== 'string' || reason.trim().length < 5) throw new AppError(422, 'INVALID_REASON', 'Tell us what went wrong.');
  const t = (await pool.query(
    `SELECT t.id FROM transactions t WHERE t.reference=$1 AND (t.initiator_user_id=$2 OR EXISTS (
       SELECT 1 FROM journal_entries je JOIN postings p ON p.entry_id=je.id JOIN accounts a ON a.id=p.account_id
       WHERE je.transaction_id=t.id AND a.user_id=$2))`, [String(reference || '').toUpperCase(), req.user.id])).rows[0];
  if (!t) throw new AppError(404, 'NOT_FOUND', 'Transaction not found.');
  const dup = await pool.query(`SELECT 1 FROM disputes WHERE user_id=$1 AND transaction_id=$2 AND status='open'`, [req.user.id, t.id]);
  if (dup.rowCount) throw new AppError(409, 'ALREADY_OPEN', 'You already reported this transaction.');
  await pool.query('INSERT INTO disputes(user_id, transaction_id, reason) VALUES ($1,$2,$3)', [req.user.id, t.id, reason.trim().slice(0, 500)]);
  await notify(pool, req.user.id, 'Problem reported', 'Our support team will review it.', 'info');
  res.status(201).json({ ok: true });
}));
router.get('/disputes', wrap(async (req, res) => {
  const r = await pool.query(
    `SELECT d.id, d.reason, d.status, d.resolution_note, d.created_at, t.reference FROM disputes d
     JOIN transactions t ON t.id=d.transaction_id WHERE d.user_id=$1 ORDER BY d.created_at DESC LIMIT 20`, [req.user.id]);
  res.json({ disputes: r.rows });
}));

export default router;
