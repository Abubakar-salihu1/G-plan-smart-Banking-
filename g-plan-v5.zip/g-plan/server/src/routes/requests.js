import { Router } from 'express';
import crypto from 'node:crypto';
import { pool } from '../db.js';
import { AppError, wrap } from '../errors.js';
import { requireAuth } from '../middleware/auth.js';
import { walletOf, businessWalletOf } from '../services/ledger.js';
import { transfer, hashRequest, assertAmount } from '../services/transfers.js';
import { authorisePayment, previewRisk } from '../services/guard.js';
import { notify } from '../services/notify.js';
import { notifyMembers } from '../services/businessAccess.js';
import { recordRisk, monitorAml } from '../services/risk.js';
import { fmt, maskName, isEmail } from '../utils/format.js';

const router = Router();
router.use(requireAuth);
const token = () => crypto.randomBytes(9).toString('base64url');

// Create a request to one person, a shareable payment link, or a split between friends.
router.post('/requests', wrap(async (req, res) => {
  const { amountMinor, note, payerEmail, splitEmails, splitTotalMinor } = req.body || {};
  const text = typeof note === 'string' ? note.slice(0, 140) : null;
  const make = async (amt, email) => {
    let payerId = null;
    if (email) {
      if (!isEmail(email)) throw new AppError(422, 'INVALID_EMAIL', `${email} is not a valid email.`);
      const u = (await pool.query('SELECT id FROM users WHERE email=$1 AND status=$2', [email.toLowerCase(), 'active'])).rows[0];
      if (u?.id === req.user.id) throw new AppError(422, 'SELF_REQUEST', 'You cannot request money from yourself.');
      payerId = u?.id || null;
    }
    const t = token();
    const r = (await pool.query(
      `INSERT INTO payment_requests(requester_id, payer_id, payer_email, amount_minor, note, token, split_group)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id, token`,
      [req.user.id, payerId, email ? email.toLowerCase() : null, amt, text, t, req._group || null])).rows[0];
    if (payerId) await notify(pool, payerId, 'Payment request', `${fmt(amt)} requested${text ? ': ' + text : ''}`, 'request');
    return r;
  };
  if (Array.isArray(splitEmails) && splitEmails.length) {
    assertAmount(splitTotalMinor);
    const emails = [...new Set(splitEmails.map((e) => String(e).trim().toLowerCase()).filter(Boolean))].slice(0, 10);
    const share = Math.floor(splitTotalMinor / (emails.length + 1));
    if (share <= 0) throw new AppError(422, 'INVALID_AMOUNT', 'Total is too small to split.');
    req._group = crypto.randomUUID();
    const out = [];
    for (const e of emails) out.push(await make(share, e));
    return res.status(201).json({ requests: out, shareMinor: share, note: 'Each person pays an equal share. Yours is included.' });
  }
  assertAmount(amountMinor);
  const r = await make(amountMinor, payerEmail || null);
  res.status(201).json({ requests: [r], link: r.token });
}));

router.get('/requests', wrap(async (req, res) => {
  const me = (await pool.query('SELECT email FROM users WHERE id=$1', [req.user.id])).rows[0];
  const incoming = (await pool.query(
    `SELECT r.id, r.amount_minor, r.note, r.token, r.status, r.created_at, COALESCE(b.name, u.full_name) AS requester
     FROM payment_requests r JOIN users u ON u.id=r.requester_id LEFT JOIN businesses b ON b.id=r.business_id
     WHERE (r.payer_id=$1 OR r.payer_email=$2) AND r.status='pending' AND r.expires_at > now() ORDER BY r.created_at DESC`,
    [req.user.id, me.email])).rows.map((r) => ({ ...r, requester: maskName(r.requester) }));
  const outgoing = (await pool.query(
    `SELECT id, amount_minor, note, token, status, payer_email, created_at FROM payment_requests
     WHERE requester_id=$1 ORDER BY created_at DESC LIMIT 30`, [req.user.id])).rows;
  res.json({ incoming, outgoing });
}));

router.get('/requests/link/:token', wrap(async (req, res) => {
  const r = (await pool.query(
    `SELECT r.id, r.amount_minor, r.note, r.status, r.expires_at, COALESCE(b.name, u.full_name) AS full_name FROM payment_requests r
     JOIN users u ON u.id=r.requester_id LEFT JOIN businesses b ON b.id=r.business_id WHERE r.token=$1`, [req.params.token])).rows[0];
  if (!r) throw new AppError(404, 'NOT_FOUND', 'Payment link not found.');
  res.json({ request: { id: r.id, amountMinor: r.amount_minor, note: r.note, status: r.status,
    requester: maskName(r.full_name), expired: new Date(r.expires_at) < new Date() },
    verification: await previewRisk(req, r.amount_minor, 'NGN') });
}));

router.post('/requests/pay', wrap(async (req, res) => {
  const { token: tk, password, otp } = req.body || {};
  const r = (await pool.query('SELECT * FROM payment_requests WHERE token=$1', [String(tk || '')])).rows[0];
  if (!r) throw new AppError(404, 'NOT_FOUND', 'Payment request not found.');
  if (r.requester_id === req.user.id) throw new AppError(422, 'SELF_PAY', 'You cannot pay your own request.');
  if (r.business_id && (await pool.query(`SELECT 1 FROM business_members WHERE business_id=$1 AND user_id=$2 AND status='active'`, [r.business_id, req.user.id])).rowCount) {
    throw new AppError(422, 'SELF_PAY', 'You cannot pay your own business invoice. Use Top up in Business to add money to the business wallet.');
  }
  const me = (await pool.query('SELECT email FROM users WHERE id=$1', [req.user.id])).rows[0];
  if ((r.payer_id && r.payer_id !== req.user.id) || (r.payer_email && r.payer_email !== me.email)) {
    throw new AppError(403, 'FORBIDDEN', 'This request was sent to someone else.');
  }
  // Invoices from a business are paid into the shared business wallet, not the owner's personal wallet.
  const toAccountId = r.business_id ? await businessWalletOf(pool, r.business_id) : await walletOf(pool, r.requester_id);
  if (!toAccountId) throw new AppError(409, 'NOT_PAYABLE', 'This request cannot be paid right now.');
  const { risk, level } = await authorisePayment(req, { password, otp, amountMinor: r.amount_minor });
  // Claim the request atomically so it cannot be paid twice.
  const claim = await pool.query(
    `UPDATE payment_requests SET status='paying', payer_id=$2 WHERE id=$1 AND status IN ('pending') AND expires_at > now() RETURNING id`,
    [r.id, req.user.id]);
  if (!claim.rows[0]) {
    // Only the same payer may continue a payment that is already in progress (a retry).
    const again = (await pool.query('SELECT status, payer_id FROM payment_requests WHERE id=$1', [r.id])).rows[0];
    if (again.status !== 'paying' || again.payer_id !== req.user.id) throw new AppError(409, 'NOT_PAYABLE', 'This request is no longer payable.');
  }
  try {
    const receipt = await transfer({
      userId: req.user.id, fromAccountId: await walletOf(pool, req.user.id), toAccountId,
      amountMinor: r.amount_minor, type: 'internal_transfer', description: r.invoice_number ? `Invoice ${r.invoice_number}` : (r.note || 'Payment request'),
      category: 'transfers', riskLevel: level, meta: { requestId: r.id },
      idemKey: req.get('Idempotency-Key') || `request:${r.id}:${req.user.id}`, requestHash: hashRequest({ request: r.id }),
    });
    await pool.query(`UPDATE payment_requests SET status=$3, paid_txn_id=$2 WHERE id=$1`,
      [r.id, receipt.transactionId, receipt.state === 'completed' ? 'paid' : 'paying']);
    if (!receipt.replayed && receipt.state === 'completed') {
      if (r.business_id) {
        await notifyMembers(pool, r.business_id, 'wallet.read', 'Invoice paid', `${fmt(r.amount_minor)} received${r.invoice_number ? ' for ' + r.invoice_number : ''}`, 'credit', r.requester_id);
        await notify(pool, r.requester_id, 'Invoice paid', `${r.invoice_number || 'Your invoice'} was paid.`, 'credit');
      } else {
        await notify(pool, r.requester_id, 'Request paid', `${fmt(r.amount_minor)} received${r.note ? ' for ' + r.note : ''}`, 'credit');
      }
      recordRisk(req.user.id, risk, receipt.transactionId).catch(() => {});
      monitorAml(req.user.id, receipt).catch(() => {});
    } else if (!receipt.replayed && receipt.state === 'under_review') {
      recordRisk(req.user.id, risk, receipt.transactionId).catch(() => {});
    }
    res.status(receipt.replayed ? 200 : 201).json({ receipt });
  } catch (e) {
    await pool.query(`UPDATE payment_requests SET status='pending' WHERE id=$1 AND status='paying'`, [r.id]);
    throw e;
  }
}));

router.post('/requests/:id/decline', wrap(async (req, res) => {
  const me = (await pool.query('SELECT email FROM users WHERE id=$1', [req.user.id])).rows[0];
  await pool.query(`UPDATE payment_requests SET status='declined' WHERE id=$1 AND status='pending' AND (payer_id=$2 OR payer_email=$3)`,
    [req.params.id, req.user.id, me.email]);
  res.json({ ok: true });
}));
router.post('/requests/:id/cancel', wrap(async (req, res) => {
  await pool.query(`UPDATE payment_requests SET status='cancelled' WHERE id=$1 AND requester_id=$2 AND status='pending'`, [req.params.id, req.user.id]);
  res.json({ ok: true });
}));

export default router;
