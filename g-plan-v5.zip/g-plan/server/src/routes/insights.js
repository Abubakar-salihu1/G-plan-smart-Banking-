import { Router } from 'express';
import { pool } from '../db.js';
import { AppError, wrap } from '../errors.js';
import { requireAuth } from '../middleware/auth.js';
import { insights } from '../services/insights.js';
import { answer } from '../services/assistant.js';
import { assertAmount } from '../services/transfers.js';

const router = Router();
router.use(requireAuth);

router.get('/insights', wrap(async (req, res) => {
  res.json({ insights: await insights(req.user.id, req.query.month) });
}));

router.put('/budgets', wrap(async (req, res) => {
  const { category, limitMinor } = req.body || {};
  if (typeof category !== 'string' || !/^[a-z ]{2,24}$/.test(category)) throw new AppError(422, 'INVALID_CATEGORY', 'Choose a category.');
  assertAmount(limitMinor);
  await pool.query(
    `INSERT INTO budgets(user_id, category, monthly_limit_minor) VALUES ($1,$2,$3)
     ON CONFLICT (user_id, category) DO UPDATE SET monthly_limit_minor=EXCLUDED.monthly_limit_minor`,
    [req.user.id, category, limitMinor]);
  res.json({ ok: true });
}));

router.delete('/budgets/:category', wrap(async (req, res) => {
  await pool.query('DELETE FROM budgets WHERE user_id=$1 AND category=$2', [req.user.id, req.params.category]);
  res.json({ ok: true });
}));

router.post('/assistant', wrap(async (req, res) => {
  const q = req.body?.question;
  if (typeof q !== 'string' || q.trim().length < 2) throw new AppError(422, 'INVALID_QUESTION', 'Ask a question.');
  res.json(await answer(req.user.id, q));
}));

export default router;
