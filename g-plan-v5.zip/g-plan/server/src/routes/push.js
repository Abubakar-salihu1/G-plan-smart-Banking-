import { Router } from 'express';
import { pool } from '../db.js';
import { AppError, wrap } from '../errors.js';
import { requireAuth } from '../middleware/auth.js';
import { config } from '../config.js';
import { endpointAllowed, validKey } from '../services/push.js';

const router = Router();
router.use(requireAuth);

router.get('/push/config', (_req, res) => res.json({ enabled: config.push.enabled, publicKey: config.push.enabled ? config.push.publicKey : null }));

router.post('/push/subscribe', wrap(async (req, res) => {
  if (!config.push.enabled) throw new AppError(404, 'NOT_FOUND', 'Push alerts are not switched on.');
  const { endpoint, keys } = req.body || {};
  if (typeof endpoint !== 'string' || endpoint.length > 600 || !endpointAllowed(endpoint)) throw new AppError(422, 'INVALID_ENDPOINT', 'This browser\'s push service is not supported.');
  if (!validKey(keys?.p256dh, 80, 100) || !validKey(keys?.auth, 20, 30)) throw new AppError(422, 'INVALID_KEYS', 'The push keys look wrong.');
  // The same device can be handed to another person: the endpoint then moves to whoever is signed in now.
  await pool.query(
    `INSERT INTO push_subscriptions(user_id, session_id, endpoint, p256dh, auth, user_agent) VALUES ($1,$2,$3,$4,$5,$6)
     ON CONFLICT (endpoint) DO UPDATE SET user_id=EXCLUDED.user_id, session_id=EXCLUDED.session_id, p256dh=EXCLUDED.p256dh, auth=EXCLUDED.auth, user_agent=EXCLUDED.user_agent`,
    [req.user.id, req.session.id, endpoint, keys.p256dh, keys.auth, (req.get('user-agent') || '').slice(0, 200)]);
  // Keep at most 10 devices per person.
  await pool.query(
    `DELETE FROM push_subscriptions WHERE user_id=$1 AND id NOT IN (SELECT id FROM push_subscriptions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 10)`, [req.user.id]);
  res.status(201).json({ ok: true });
}));

// Habit alerts (unusual payments, price rises, new repeating payments) can be switched off.
router.get('/alerts/prefs', wrap(async (req, res) => {
  const r = (await pool.query('SELECT habit_alerts, statement_email FROM alert_prefs WHERE user_id=$1', [req.user.id])).rows[0];
  res.json({ habitAlerts: r ? r.habit_alerts : true, statementEmail: r ? r.statement_email : false });
}));
router.put('/alerts/prefs', wrap(async (req, res) => {
  const { habitAlerts, statementEmail } = req.body || {};
  if (habitAlerts !== undefined && typeof habitAlerts !== 'boolean') throw new AppError(422, 'INVALID', 'Choose on or off.');
  if (statementEmail !== undefined && typeof statementEmail !== 'boolean') throw new AppError(422, 'INVALID', 'Choose on or off.');
  if (habitAlerts === undefined && statementEmail === undefined) throw new AppError(422, 'INVALID', 'Choose a setting.');
  await pool.query(
    `INSERT INTO alert_prefs(user_id, habit_alerts, statement_email) VALUES ($1, COALESCE($2, TRUE), COALESCE($3, FALSE))
     ON CONFLICT (user_id) DO UPDATE SET habit_alerts=COALESCE($2, alert_prefs.habit_alerts), statement_email=COALESCE($3, alert_prefs.statement_email), updated_at=now()`,
    [req.user.id, habitAlerts ?? null, statementEmail ?? null]);
  res.json({ ok: true });
}));

router.post('/push/unsubscribe', wrap(async (req, res) => {
  const { endpoint } = req.body || {};
  if (typeof endpoint === 'string') await pool.query('DELETE FROM push_subscriptions WHERE endpoint=$1 AND user_id=$2', [endpoint, req.user.id]);
  res.json({ ok: true });
}));

export default router;
