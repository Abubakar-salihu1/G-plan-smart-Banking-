// In-app support chat. Customers talk to G-Plan staff in threads. Staff are never shown more than the thread itself and the
// customer's name and email, and every time staff open a thread it is written to the audit log.
import { Router } from 'express';
import { pool, withTx } from '../db.js';
import { AppError, wrap } from '../errors.js';
import { requireAuth } from '../middleware/auth.js';
import { requireStaff, can } from '../middleware/rbac.js';
import { notify } from '../services/notify.js';
import { suggestFaq, findSecret } from '../utils/supportRules.js';

const router = Router();

function cleanBody(v) {
  const body = String(v ?? '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim();
  if (!body) throw new AppError(422, 'EMPTY', 'Write your message first.');
  if (body.length > 2000) throw new AppError(422, 'TOO_LONG', 'That message is too long. Keep it under 2,000 characters.');
  return body;
}

// ---------------------------------------------------------------- customer side
router.get('/support/faq', requireAuth, (req, res) => res.json({ suggestions: suggestFaq(req.query.q) }));

router.get('/support/threads', requireAuth, wrap(async (req, res) => {
  const r = await pool.query(
    `SELECT id, subject, status, created_at, last_message_at, last_sender, (last_sender='staff' AND (customer_read_at IS NULL OR customer_read_at < last_message_at)) AS unread
     FROM support_threads WHERE user_id=$1 ORDER BY last_message_at DESC LIMIT 30`, [req.user.id]);
  res.json({ threads: r.rows.map((t) => ({ id: t.id, subject: t.subject, status: t.status, lastMessageAt: t.last_message_at, unread: t.unread })) });
}));

router.post('/support/threads', requireAuth, wrap(async (req, res) => {
  const subject = String(req.body?.subject ?? '').trim();
  if (subject.length < 3 || subject.length > 80) throw new AppError(422, 'INVALID_SUBJECT', 'Give your question a short title.');
  const body = cleanBody(req.body?.body);
  const secret = findSecret(`${subject} ${body}`);
  if (secret) throw new AppError(422, 'SECRET_IN_MESSAGE', `Please remove ${secret}. G-Plan staff never need it, and this chat is read by several people.`);
  const open = Number((await pool.query(`SELECT COUNT(*) AS n FROM support_threads WHERE user_id=$1 AND status<>'closed'`, [req.user.id])).rows[0].n);
  if (open >= 5) throw new AppError(429, 'TOO_MANY', 'You already have 5 open chats. Close one first.');
  const id = await withTx(async (c) => {
    const t = (await c.query(`INSERT INTO support_threads(user_id, subject) VALUES ($1,$2) RETURNING id`, [req.user.id, subject])).rows[0];
    await c.query(`INSERT INTO support_messages(thread_id, sender, body) VALUES ($1,'customer',$2)`, [t.id, body]);
    return t.id;
  });
  res.status(201).json({ id });
}));

async function mine(req) {
  const t = (await pool.query('SELECT * FROM support_threads WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id])).rows[0];
  if (!t) throw new AppError(404, 'NOT_FOUND', 'Chat not found.');
  return t;
}

router.get('/support/threads/:id', requireAuth, wrap(async (req, res) => {
  const t = await mine(req);
  const msgs = (await pool.query('SELECT id, sender, body, created_at FROM support_messages WHERE thread_id=$1 ORDER BY id', [t.id])).rows;
  await pool.query('UPDATE support_threads SET customer_read_at=now() WHERE id=$1', [t.id]);
  res.json({ thread: { id: t.id, subject: t.subject, status: t.status }, messages: msgs.map((m) => ({ id: m.id, from: m.sender, body: m.body, at: m.created_at })) });
}));

router.post('/support/threads/:id/messages', requireAuth, wrap(async (req, res) => {
  const t = await mine(req);
  const body = cleanBody(req.body?.body);
  const secret = findSecret(body);
  if (secret) throw new AppError(422, 'SECRET_IN_MESSAGE', `Please remove ${secret}. G-Plan staff never need it, and this chat is read by several people.`);
  if (t.status === 'closed' && t.closed_at && Date.now() - new Date(t.closed_at).getTime() > 14 * 86400000) throw new AppError(409, 'CLOSED', 'This chat was closed a while ago. Please start a new one.');
  const recent = Number((await pool.query(`SELECT COUNT(*) AS n FROM support_messages m JOIN support_threads t ON t.id=m.thread_id WHERE t.user_id=$1 AND m.sender='customer' AND m.created_at > now() - interval '1 hour'`, [req.user.id])).rows[0].n);
  if (recent >= 20) throw new AppError(429, 'SLOW_DOWN', 'You are sending a lot of messages. Please wait a little.');
  await withTx(async (c) => {
    await c.query(`INSERT INTO support_messages(thread_id, sender, body) VALUES ($1,'customer',$2)`, [t.id, body]);
    await c.query(`UPDATE support_threads SET status='open', last_message_at=now(), last_sender='customer', closed_at=NULL, customer_read_at=now() WHERE id=$1`, [t.id]);
  });
  res.status(201).json({ ok: true });
}));

router.post('/support/threads/:id/close', requireAuth, wrap(async (req, res) => {
  const t = await mine(req);
  await pool.query(`UPDATE support_threads SET status='closed', closed_at=now() WHERE id=$1`, [t.id]);
  res.json({ ok: true });
}));

// ---------------------------------------------------------------- staff side
const staff = (perm) => [requireAuth, requireStaff, (req, _res, next) => (can(req.user.role, perm) ? next() : next(new AppError(403, 'FORBIDDEN', 'Your role cannot use customer chat.')))];

router.get('/admin/support/threads', staff('support.chat'), wrap(async (req, res) => {
  const status = ['open', 'waiting_customer', 'closed'].includes(req.query.status) ? req.query.status : 'open';
  const r = await pool.query(
    `SELECT t.id, t.subject, t.status, t.last_message_at, t.last_sender, u.full_name, u.email,
            (SELECT body FROM support_messages m WHERE m.thread_id=t.id ORDER BY m.id DESC LIMIT 1) AS preview
     FROM support_threads t JOIN users u ON u.id=t.user_id WHERE t.status=$1 ORDER BY t.last_message_at ASC LIMIT 50`, [status]);
  res.json({ threads: r.rows.map((t) => ({ id: t.id, subject: t.subject, status: t.status, name: t.full_name, email: t.email, lastMessageAt: t.last_message_at, lastFrom: t.last_sender, preview: String(t.preview || '').slice(0, 120) })) });
}));

router.get('/admin/support/threads/:id', staff('support.chat'), wrap(async (req, res) => {
  const t = (await pool.query(`SELECT t.*, u.full_name, u.email FROM support_threads t JOIN users u ON u.id=t.user_id WHERE t.id=$1`, [req.params.id])).rows[0];
  if (!t) throw new AppError(404, 'NOT_FOUND', 'Chat not found.');
  await pool.query(`INSERT INTO audit_log(actor_type, actor_id, action, target_type, target_id, ip_address) VALUES ('admin',$1,'support.thread_viewed','support_thread',$2,$3)`, [req.user.id, t.id, req.ip]);
  const msgs = (await pool.query('SELECT id, sender, staff_id, body, created_at FROM support_messages WHERE thread_id=$1 ORDER BY id', [t.id])).rows;
  res.json({ thread: { id: t.id, subject: t.subject, status: t.status, name: t.full_name, email: t.email }, messages: msgs.map((m) => ({ id: m.id, from: m.sender, body: m.body, at: m.created_at })) });
}));

router.post('/admin/support/threads/:id/messages', staff('support.chat'), wrap(async (req, res) => {
  const body = cleanBody(req.body?.body);
  const t = (await pool.query('SELECT id, user_id, status FROM support_threads WHERE id=$1', [req.params.id])).rows[0];
  if (!t) throw new AppError(404, 'NOT_FOUND', 'Chat not found.');
  if (t.status === 'closed') throw new AppError(409, 'CLOSED', 'This chat is closed.');
  await withTx(async (c) => {
    await c.query(`INSERT INTO support_messages(thread_id, sender, staff_id, body) VALUES ($1,'staff',$2,$3)`, [t.id, req.user.id, body]);
    await c.query(`UPDATE support_threads SET status='waiting_customer', last_message_at=now(), last_sender='staff' WHERE id=$1`, [t.id]);
  });
  await notify(pool, t.user_id, 'G-Plan support replied', 'You have a new reply in Help and chat.', 'info');
  res.status(201).json({ ok: true });
}));

router.post('/admin/support/threads/:id/close', staff('support.chat'), wrap(async (req, res) => {
  const r = await pool.query(`UPDATE support_threads SET status='closed', closed_at=now() WHERE id=$1 AND status<>'closed' RETURNING user_id`, [req.params.id]);
  if (!r.rows[0]) throw new AppError(404, 'NOT_FOUND', 'Chat not found, or already closed.');
  res.json({ ok: true });
}));

export default router;
