// Receipts: scan or type in a receipt, keep only the details, and match it to the payment if there is one.
import { Router } from 'express';
import { pool } from '../db.js';
import { AppError, wrap } from '../errors.js';
import { requireAuth } from '../middleware/auth.js';
import { config } from '../config.js';
import { inspectImage } from '../utils/image.js';
import { parseReceipt, RECEIPT_CATEGORIES } from '../utils/receiptParse.js';
import { readReceipt, readerEnabled } from '../services/receipts.js';

const router = Router();
router.use(requireAuth);

router.get('/receipts/config', (_req, res) => res.json({ reader: readerEnabled(), categories: RECEIPT_CATEGORIES, maxBytes: config.kycDocMaxBytes }));

// Body is the raw photo (parsed in app.js). The photo is read once and thrown away: nothing from it is stored.
router.post('/receipts/scan', wrap(async (req, res) => {
  if (!readerEnabled()) return res.json({ manual: true, message: 'Reading photos is not switched on. Type the details in.' });
  if (req.get('X-Receipt-Consent') !== 'yes') throw new AppError(400, 'CONSENT_REQUIRED', 'Please agree to send this photo to be read.');
  if (!Buffer.isBuffer(req.body)) throw new AppError(415, 'UNSUPPORTED', 'Send a JPEG or PNG photo.');
  const today = Number((await pool.query(`SELECT COUNT(*) AS n FROM receipt_scans WHERE user_id=$1 AND created_at > now() - interval '1 day'`, [req.user.id])).rows[0].n);
  if (today >= 20) throw new AppError(429, 'TOO_MANY', 'You have scanned a lot today. Type this one in, or try tomorrow.');
  let img;
  try { img = inspectImage(req.body, { minSide: 200 }); } catch (e) { throw new AppError(422, 'BAD_IMAGE', e.message); }
  await pool.query('INSERT INTO receipt_scans(user_id) VALUES ($1)', [req.user.id]);
  try { res.json({ draft: await readReceipt(img.clean, img.mime) }); }
  catch (e) { throw new AppError(422, 'UNREADABLE', e.message || 'We could not read that receipt. Type the details in.'); }
}));

router.post('/receipts', wrap(async (req, res) => {
  let r;
  try { r = parseReceipt(req.body || {}); } catch (e) { throw new AppError(422, 'INVALID_RECEIPT', e.message); }
  if (!r.date) throw new AppError(422, 'INVALID_DATE', 'Choose the date on the receipt.');
  const have = Number((await pool.query('SELECT COUNT(*) AS n FROM receipts WHERE user_id=$1', [req.user.id])).rows[0].n);
  if (have >= 500) throw new AppError(422, 'TOO_MANY', 'You have 500 receipts saved. Delete some first.');
  // If a completed payment of exactly this amount happened within 3 days, link them.
  const m = (await pool.query(
    `SELECT id, reference FROM transactions WHERE initiator_user_id=$1 AND state='completed' AND amount_minor=$2
       AND type IN ('bill_payment','external_transfer','card_payment') AND created_at::date BETWEEN $3::date - 3 AND $3::date + 3
     ORDER BY created_at DESC LIMIT 1`, [req.user.id, r.totalMinor, r.date])).rows[0];
  const row = (await pool.query(
    `INSERT INTO receipts(user_id, merchant, total_minor, spent_on, category, note, txn_id) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
    [req.user.id, r.merchant, r.totalMinor, r.date, r.category, typeof req.body.note === 'string' ? req.body.note.slice(0, 140) : null, m?.id || null])).rows[0];
  res.status(201).json({ id: row.id, matchedReference: m?.reference || null });
}));

router.get('/receipts', wrap(async (req, res) => {
  const rows = (await pool.query(
    `SELECT r.id, r.merchant, r.total_minor, r.spent_on, r.category, r.note, t.reference FROM receipts r LEFT JOIN transactions t ON t.id=r.txn_id
     WHERE r.user_id=$1 ORDER BY r.spent_on DESC, r.created_at DESC LIMIT 100`, [req.user.id])).rows;
  const month = new Date().toISOString().slice(0, 7);
  const byCategory = {};
  for (const r of rows) if (String(r.spent_on).startsWith(month)) byCategory[r.category] = (byCategory[r.category] || 0) + Number(r.total_minor);
  res.json({ receipts: rows.map((r) => ({ id: r.id, merchant: r.merchant, totalMinor: r.total_minor, date: r.spent_on, category: r.category, note: r.note, matched: !!r.reference })), month, byCategory });
}));

router.delete('/receipts/:id', wrap(async (req, res) => {
  await pool.query('DELETE FROM receipts WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id]);
  res.json({ ok: true });
}));

export default router;
