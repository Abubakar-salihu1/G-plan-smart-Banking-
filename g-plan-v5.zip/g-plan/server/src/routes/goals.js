import { Router } from 'express';
import { pool, withTx } from '../db.js';
import { AppError, wrap } from '../errors.js';
import { requireAuth } from '../middleware/auth.js';
import { createAccount, walletOf } from '../services/ledger.js';
import { transfer, hashRequest, assertAmount } from '../services/transfers.js';
import { config } from '../config.js';
import { STEPS } from '../services/savings.js';

const router = Router();
router.use(requireAuth);

function recommend(targetMinor, currentMinor, deadline) {
  const remaining = Math.max(0, targetMinor - currentMinor);
  if (!deadline || remaining === 0) return { remainingMinor: remaining, recommendedMonthlyMinor: null };
  const days = Math.ceil((new Date(deadline + 'T00:00:00Z') - new Date()) / 86_400_000);
  const months = Math.max(1, Math.ceil(days / 30));
  return { remainingMinor: remaining, recommendedMonthlyMinor: Math.ceil(remaining / months) };
}

router.get('/goals', wrap(async (req, res) => {
  const r = await pool.query(
    `SELECT g.id, g.name, g.target_minor, g.currency, g.deadline, g.account_id,
            COALESCE(SUM(CASE WHEN p.direction='credit' THEN p.amount_minor ELSE -p.amount_minor END),0) AS current_minor
     FROM goals g LEFT JOIN postings p ON p.account_id = g.account_id
     WHERE g.user_id=$1 GROUP BY g.id ORDER BY g.created_at`, [req.user.id]);
  const rules = (await pool.query(
    `SELECT id, goal_id, amount_minor, frequency, next_run_on, status, last_status FROM savings_rules
     WHERE user_id=$1 AND status IN ('active','paused') ORDER BY created_at`, [req.user.id])).rows;
  res.json({
    demoInterestApr: config.demoFunding && config.savingsDemoApr > 0 ? config.savingsDemoApr : null,
    goals: r.rows.map((g) => ({
      id: g.id, name: g.name, currency: g.currency, deadline: g.deadline,
      targetMinor: g.target_minor, currentMinor: g.current_minor,
      ...recommend(g.target_minor, g.current_minor, g.deadline),
      rules: rules.filter((x) => x.goal_id === g.id),
    })),
  });
}));

// Round-ups: spare change from payments moves into one goal.
router.get('/goals/roundup', wrap(async (req, res) => {
  const s = (await pool.query('SELECT goal_id, step_minor, enabled FROM roundup_settings WHERE user_id=$1', [req.user.id])).rows[0] || null;
  const tot = (await pool.query(`SELECT COALESCE(SUM(amount_minor) FILTER (WHERE saved),0) AS saved, COUNT(*) FILTER (WHERE saved) AS n FROM roundup_log WHERE user_id=$1`, [req.user.id])).rows[0];
  res.json({ roundup: s && { goalId: s.goal_id, stepMinor: s.step_minor, enabled: s.enabled }, savedMinor: tot.saved, count: tot.n, steps: STEPS });
}));

router.put('/goals/roundup', wrap(async (req, res) => {
  const { enabled, goalId, stepMinor } = req.body || {};
  if (!enabled) {
    await pool.query('UPDATE roundup_settings SET enabled=FALSE, updated_at=now() WHERE user_id=$1', [req.user.id]);
    return res.json({ ok: true });
  }
  if (!STEPS.includes(stepMinor)) throw new AppError(422, 'INVALID_STEP', 'Choose to round up to the next ₦100, ₦500 or ₦1,000.');
  const g = (await pool.query('SELECT id FROM goals WHERE id=$1 AND user_id=$2', [goalId, req.user.id])).rows[0];
  if (!g) throw new AppError(404, 'GOAL_NOT_FOUND', 'Choose one of your goals.');
  // "since" restarts whenever it is switched on, so old payments are never swept up retroactively.
  await pool.query(
    `INSERT INTO roundup_settings(user_id, goal_id, step_minor, enabled, since) VALUES ($1,$2,$3,TRUE,now())
     ON CONFLICT (user_id) DO UPDATE SET goal_id=EXCLUDED.goal_id, step_minor=EXCLUDED.step_minor, enabled=TRUE,
       since = CASE WHEN roundup_settings.enabled THEN roundup_settings.since ELSE now() END, updated_at=now()`,
    [req.user.id, g.id, stepMinor]);
  res.json({ ok: true });
}));

router.post('/goals', wrap(async (req, res) => {
  const { name, targetMinor, deadline } = req.body || {};
  if (typeof name !== 'string' || name.trim().length < 2) throw new AppError(422, 'INVALID_NAME', 'Give your goal a name.');
  assertAmount(targetMinor);
  if (deadline && (isNaN(Date.parse(deadline)) || new Date(deadline) <= new Date())) {
    throw new AppError(422, 'INVALID_DEADLINE', 'Pick a deadline in the future.');
  }
  const count = (await pool.query('SELECT COUNT(*) AS n FROM goals WHERE user_id=$1', [req.user.id])).rows[0].n;
  if (count >= 20) throw new AppError(422, 'TOO_MANY', 'You can have up to 20 goals.');
  const goal = await withTx(async (c) => {
    const accountId = await createAccount(c, {
      userId: req.user.id, type: 'goal_pot', currency: 'NGN', name: name.trim().slice(0, 60) });
    return (await c.query(
      `INSERT INTO goals(user_id, account_id, name, target_minor, currency, deadline)
       VALUES ($1,$2,$3,$4,'NGN',$5) RETURNING id`,
      [req.user.id, accountId, name.trim().slice(0, 60), targetMinor, deadline || null])).rows[0];
  });
  res.status(201).json({ id: goal.id });
}));

async function move(req, res, direction) {
  const { amountMinor } = req.body || {};
  assertAmount(amountMinor);
  const g = (await pool.query('SELECT account_id, name FROM goals WHERE id=$1 AND user_id=$2',
    [req.params.id, req.user.id])).rows[0];
  if (!g) throw new AppError(404, 'GOAL_NOT_FOUND', 'Goal not found.');
  const wallet = await walletOf(pool, req.user.id, 'NGN');
  const [from, to] = direction === 'in' ? [wallet, g.account_id] : [g.account_id, wallet];
  const receipt = await transfer({
    userId: req.user.id, fromAccountId: from, toAccountId: to, amountMinor,
    type: 'goal_contribution', category: 'savings',
    description: direction === 'in' ? `Saved to ${g.name}` : `Withdrawn from ${g.name}`,
    idemKey: req.get('Idempotency-Key'),
    requestHash: hashRequest({ goal: req.params.id, amountMinor, direction }),
  });
  res.status(receipt.replayed ? 200 : 201).json({ receipt });
}

router.post('/goals/:id/contribute', wrap((req, res) => move(req, res, 'in')));
router.post('/goals/:id/withdraw', wrap((req, res) => move(req, res, 'out')));

// ---- Auto-save rules ----
router.post('/goals/:id/rules', wrap(async (req, res) => {
  const { amountMinor, frequency, startDate } = req.body || {};
  assertAmount(amountMinor);
  if (!['weekly', 'monthly'].includes(frequency)) throw new AppError(422, 'INVALID_FREQUENCY', 'Choose weekly or monthly.');
  const g = (await pool.query('SELECT id FROM goals WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id])).rows[0];
  if (!g) throw new AppError(404, 'GOAL_NOT_FOUND', 'Goal not found.');
  const today = new Date().toISOString().slice(0, 10);
  const start = startDate && /^\d{4}-\d{2}-\d{2}$/.test(startDate) && startDate >= today ? startDate : today;
  const r = await pool.query(
    `INSERT INTO savings_rules(user_id, goal_id, amount_minor, frequency, next_run_on) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
    [req.user.id, g.id, amountMinor, frequency, start]);
  res.status(201).json({ id: r.rows[0].id });
}));

router.patch('/goals/rules/:ruleId', wrap(async (req, res) => {
  const status = req.body?.status;
  if (!['active', 'paused', 'cancelled'].includes(status)) throw new AppError(422, 'INVALID_STATUS', 'Invalid status.');
  await pool.query('UPDATE savings_rules SET status=$3 WHERE id=$1 AND user_id=$2', [req.params.ruleId, req.user.id, status]);
  res.json({ ok: true });
}));

export default router;
