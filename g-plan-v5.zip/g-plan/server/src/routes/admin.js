import { Router } from 'express';
import { pool, withTx } from '../db.js';
import { AppError, wrap } from '../errors.js';
import { requireAuth } from '../middleware/auth.js';
import { requireStaff, can, PERMS } from '../middleware/rbac.js';
import { notify } from '../services/notify.js';
import { fundWalletDemo } from '../services/transfers.js';
import { walletOf } from '../services/ledger.js';
import { executeReversal } from '../services/reversal.js';
import { completeHeldTransfer } from '../services/transfers.js';
import { approveHeldExternal, rejectHeld } from '../services/payments.js';
import { integrityCheck, recheckPayment } from '../services/jobs.js';
import { opsSnapshot } from '../services/opsSnapshot.js';
import { evaluateOps } from '../utils/opsRules.js';
import { fmt } from '../utils/format.js';
import { markDecided, countsBySubmission } from '../services/kycDocs.js';

const router = Router();
router.use(requireAuth, requireStaff);

const SECTIONS = {
  overview: { title: 'Overview', perm: null },
  customers: { title: 'Customers', perm: 'customers.read' },
  transactions: { title: 'Transactions', perm: 'transactions.read' },
  risk: { title: 'Fraud alerts', perm: 'risk.read' },
  held: { title: 'Held payments', perm: 'payments.review' },
  stuck: { title: 'Stuck and failed money', perm: 'ops.read' },
  chat: { title: 'Customer chat', perm: 'support.chat' },   // has its own screen: see AdminChat in the client
  aml: { title: 'AML cases', perm: 'risk.read' },
  kyc: { title: 'KYC', perm: 'kyc.review' },
  cheques: { title: 'Cheques', perm: 'cheques.review' },
  services: { title: 'Service requests', perm: 'service.handle' },
  disputes: { title: 'Disputes', perm: 'disputes.handle' },
  reversals: { title: 'Reversals', perm: 'reversals.read' },
  audit: { title: 'Audit log', perm: 'audit.read' },
};
const allowed = (role) => Object.entries(SECTIONS).filter(([, s]) => !s.perm || can(role, s.perm)).map(([id, s]) => ({ id, title: s.title }));
const short = (id) => String(id).slice(0, 8);
const when = (d) => new Date(d).toLocaleString('en-NG');
const audit = (req, action, target, meta = {}) =>
  pool.query(`INSERT INTO audit_log(actor_type, actor_id, action, target_id, ip_address, metadata) VALUES ('admin',$1,$2,$3,$4,$5)`,
    [req.user.id, action, target || null, req.ip, JSON.stringify(meta)]);

router.get('/admin/me', (req, res) => res.json({ role: req.user.role, sections: allowed(req.user.role) }));

router.get('/admin/section/:id', wrap(async (req, res) => {
  const s = SECTIONS[req.params.id];
  if (!s) throw new AppError(404, 'NOT_FOUND', 'Unknown section.');
  if (s.perm && !can(req.user.role, s.perm)) throw new AppError(403, 'FORBIDDEN', 'Your role cannot open this section.');
  const role = req.user.role;
  await audit(req, 'admin.view', req.params.id);
  const out = { title: s.title, columns: [], rows: [] };
  const q = req.query.q ? `%${String(req.query.q).slice(0, 40)}%` : null;

  if (req.params.id === 'overview') {
    const n = async (sql) => (await pool.query(sql)).rows[0].n;
    const integ = await integrityCheck();
    out.columns = ['Measure', 'Value'];
    const rows = [
      ['Customers', await n(`SELECT COUNT(*) AS n FROM users WHERE role='customer'`)],
      ['Transactions today', await n(`SELECT COUNT(*) AS n FROM transactions WHERE created_at > date_trunc('day', now())`)],
      ['Unreviewed fraud alerts', await n(`SELECT COUNT(*) AS n FROM risk_events WHERE reviewed_by IS NULL`)],
      ['Payments held for review', await n(`SELECT COUNT(*) AS n FROM transactions WHERE state='under_review'`)],
      ['Open AML cases', await n(`SELECT COUNT(*) AS n FROM aml_cases WHERE status='open'`)],
      ['KYC waiting', await n(`SELECT COUNT(*) AS n FROM kyc_submissions WHERE status='pending'`)],
      ['Cheques waiting', await n(`SELECT COUNT(*) AS n FROM cheque_deposits WHERE status='pending'`)],
      ['Open disputes', await n(`SELECT COUNT(*) AS n FROM disputes WHERE status='open'`)],
      ['Reversals waiting', await n(`SELECT COUNT(*) AS n FROM reversal_requests WHERE status='pending'`)],
      ['Ledger and audit integrity', integ.ok ? 'Intact' : 'PROBLEM: see alerts'],
    ];
    out.rows = rows.map(([a, b], i) => ({ id: String(i), cells: [a, String(b)], actions: [] }));
  } else if (req.params.id === 'customers') {
    const r = await pool.query(
      `SELECT id, full_name, email, kyc_tier, status, role FROM users WHERE ($1::text IS NULL OR full_name ILIKE $1 OR email ILIKE $1)
       ORDER BY created_at DESC LIMIT 50`, [q]);
    out.search = true; out.columns = ['Name', 'Email', 'Tier', 'Status'];
    out.rows = r.rows.map((u) => ({ id: u.id, cells: [u.full_name, u.email, `T${u.kyc_tier}`, u.status + (u.role !== 'customer' ? ` (${u.role})` : '')],
      actions: can(role, 'customers.restrict') && u.role === 'customer' && u.id !== req.user.id
        ? [u.status === 'active' ? { label: 'Restrict', action: 'restrict', danger: true } : u.status === 'restricted' ? { label: 'Unrestrict', action: 'unrestrict' } : null].filter(Boolean) : [] }));
  } else if (req.params.id === 'transactions') {
    const r = await pool.query(
      `SELECT t.id, t.reference, t.type, t.state, t.amount_minor, t.currency, t.risk_level, u.email FROM transactions t
       LEFT JOIN users u ON u.id=t.initiator_user_id WHERE ($1::text IS NULL OR t.reference ILIKE $1 OR u.email ILIKE $1)
       ORDER BY t.created_at DESC LIMIT 60`, [q]);
    out.search = true; out.columns = ['Ref', 'Type', 'State', 'Amount', 'Customer', 'Risk'];
    out.rows = r.rows.map((t) => ({ id: t.id, cells: [t.reference, t.type.replace(/_/g, ' '), t.state.replace(/_/g, ' '), fmt(t.amount_minor, t.currency), t.email || 'system', t.risk_level],
      actions: can(role, 'reversals.request') && t.state === 'completed' ? [{ label: 'Request reversal', action: 'request_reversal' }] : [] }));
  } else if (req.params.id === 'risk') {
    const r = await pool.query(`SELECT e.id, e.level, e.reasons, e.created_at, u.email FROM risk_events e LEFT JOIN users u ON u.id=e.user_id WHERE e.reviewed_by IS NULL ORDER BY e.created_at DESC LIMIT 50`);
    out.columns = ['Level', 'Why', 'Customer', 'When'];
    out.rows = r.rows.map((e) => ({ id: String(e.id), cells: [e.level.replace(/_/g, ' '), (e.reasons || []).join(', '), e.email || '', when(e.created_at)], actions: [{ label: 'Mark reviewed', action: 'review' }] }));
  } else if (req.params.id === 'held') {
    const r = await pool.query(
      `SELECT t.id, t.reference, t.type, t.amount_minor, t.currency, t.created_at, u.email,
              (SELECT e.reasons FROM risk_events e WHERE e.transaction_id=t.id ORDER BY e.id DESC LIMIT 1) AS reasons
       FROM transactions t LEFT JOIN users u ON u.id=t.initiator_user_id WHERE t.state='under_review' ORDER BY t.created_at LIMIT 50`);
    out.note = 'Money is reserved, not sent. Approve to send it, or decline to give it back to the customer.';
    out.columns = ['Ref', 'Type', 'Amount', 'Customer', 'Why flagged'];
    out.rows = r.rows.map((t) => ({ id: t.id, cells: [t.reference, t.type.replace(/_/g, ' '), fmt(t.amount_minor, t.currency), t.email || '', (t.reasons || []).join(', ') || 'Risk rules'],
      actions: [{ label: 'Approve and send', action: 'approve' }, { label: 'Decline', action: 'reject', danger: true }] }));
  } else if (req.params.id === 'stuck') {
    // Everything that means "money may be stuck or someone is waiting", oldest first. Nothing here is a guess:
    // each row says what it is, how long it has waited and what to do.
    const age = (d) => { const m = Math.round((Date.now() - new Date(d).getTime()) / 60000); return m < 90 ? `${m} min` : m < 2880 ? `${Math.round(m / 60)} h` : `${Math.round(m / 1440)} days`; };
    const issues = evaluateOps({ ...(await opsSnapshot()), integrityOk: true, jobsStaleMinutes: null });
    out.note = issues.length ? `Needs attention: ${issues.map((i) => i.text.split('.')[0]).join('. ')}.` : 'Nothing is stuck right now.';
    out.columns = ['What', 'Ref or batch', 'Who', 'Waiting', 'Detail'];
    const rows = [];
    for (const t of (await pool.query(
      `SELECT t.id, t.reference, t.state, t.type, t.amount_minor, t.currency, t.updated_at, u.email FROM transactions t LEFT JOIN users u ON u.id=t.initiator_user_id
       WHERE t.state IN ('processing','processing_unconfirmed') AND t.updated_at < now() - interval '5 minutes' ORDER BY t.updated_at LIMIT 40`)).rows) {
      rows.push({ id: t.id, at: t.updated_at, cells: [t.state === 'processing' ? 'Stuck mid-way' : 'No answer from provider', t.reference, t.email || 'system', age(t.updated_at), `${fmt(t.amount_minor, t.currency)} reserved. Ask the provider again.`],
        actions: can(role, 'ops.act') ? [{ label: 'Recheck now', action: 'recheck' }] : [] });
    }
    for (const t of (await pool.query(
      `SELECT t.id, t.reference, t.amount_minor, t.currency, t.created_at, u.email FROM transactions t LEFT JOIN users u ON u.id=t.initiator_user_id
       WHERE t.state='under_review' AND t.created_at < now() - interval '4 hours' ORDER BY t.created_at LIMIT 20`)).rows) {
      rows.push({ id: 'h' + t.id, at: t.created_at, cells: ['Held for review', t.reference, t.email || '', age(t.created_at), `${fmt(t.amount_minor, t.currency)}. Compliance must approve or decline in Held payments.`], actions: [] });
    }
    for (const i of (await pool.query(
      `SELECT i.id, i.name, i.error, i.amount_minor, b.label, bz.name AS business, b.decided_at FROM bulk_items i JOIN bulk_batches b ON b.id=i.batch_id JOIN businesses bz ON bz.id=b.business_id
       WHERE i.status='failed' AND b.decided_at > now() - interval '3 days' ORDER BY b.decided_at DESC LIMIT 30`)).rows) {
      rows.push({ id: 'b' + i.id, at: i.decided_at, cells: ['Payroll or bulk item failed', i.label, i.business, age(i.decided_at), `${i.name}, ${fmt(i.amount_minor)}: ${i.error || 'no reason recorded'}`], actions: [] });
    }
    for (const b of (await pool.query(
      `SELECT b.id, b.label, b.status, b.created_at, bz.name AS business, b.total_minor FROM bulk_batches b JOIN businesses bz ON bz.id=b.business_id
       WHERE (b.status='running' AND b.decided_at < now() - interval '2 hours') OR (b.status='pending_approval' AND b.created_at < now() - interval '24 hours') ORDER BY b.created_at LIMIT 20`)).rows) {
      rows.push({ id: 'p' + b.id, at: b.created_at, cells: [b.status === 'running' ? 'Batch not finishing' : 'Batch waiting for owner', b.label, b.business, age(b.created_at), fmt(b.total_minor)], actions: [] });
    }
    out.rows = rows.sort((a, b) => new Date(a.at) - new Date(b.at)).map(({ at, ...r }) => r);
  } else if (req.params.id === 'aml') {
    const r = await pool.query(`SELECT c.id, c.kind, c.details, c.created_at, u.email FROM aml_cases c LEFT JOIN users u ON u.id=c.user_id WHERE c.status='open' ORDER BY c.created_at DESC LIMIT 50`);
    out.columns = ['Case', 'Customer', 'Detail', 'When'];
    out.rows = r.rows.map((c) => ({ id: c.id, cells: [c.kind.replace(/_/g, ' '), c.email || '', c.details?.note || '', when(c.created_at)],
      actions: [{ label: 'Clear', action: 'clear' }, { label: 'Escalate', action: 'escalate', danger: true }] }));
  } else if (req.params.id === 'kyc') {
    const r = await pool.query(`SELECT k.id, k.tier_requested, k.id_type, k.id_last4, k.created_at, u.email FROM kyc_submissions k JOIN users u ON u.id=k.user_id WHERE k.status='pending' ORDER BY k.created_at LIMIT 50`);
    const photoCounts = await countsBySubmission(r.rows.map((k) => k.id));
    out.columns = ['Customer', 'Tier', 'ID', 'Photos', 'When'];
    out.rows = r.rows.map((k) => ({ id: k.id, kycPhotos: (photoCounts[k.id] || 0) > 0, cells: [k.email, `T${k.tier_requested}`, `${k.id_type.toUpperCase()} ••••${k.id_last4}`, String(photoCounts[k.id] || 0), when(k.created_at)], actions: [{ label: 'Approve', action: 'approve' }, { label: 'Reject', action: 'reject', danger: true }] }));
  } else if (req.params.id === 'cheques') {
    const r = await pool.query(`SELECT c.id, c.amount_minor, c.payer_name, c.created_at, u.email FROM cheque_deposits c JOIN users u ON u.id=c.user_id WHERE c.status='pending' ORDER BY c.created_at LIMIT 50`);
    out.columns = ['Customer', 'Amount', 'Payer', 'When'];
    out.rows = r.rows.map((c) => ({ id: c.id, cells: [c.email, fmt(c.amount_minor), c.payer_name, when(c.created_at)], actions: [{ label: 'Approve and credit', action: 'approve' }, { label: 'Reject', action: 'reject', danger: true }] }));
  } else if (req.params.id === 'services') {
    const r = await pool.query(`SELECT s.id, s.type, s.status, s.created_at, u.email FROM service_requests s JOIN users u ON u.id=s.user_id WHERE s.status IN ('received','in_progress') ORDER BY s.created_at LIMIT 50`);
    out.columns = ['Customer', 'Request', 'Status', 'When'];
    out.rows = r.rows.map((s) => ({ id: s.id, cells: [s.email, s.type.replace(/_/g, ' '), s.status.replace(/_/g, ' '), when(s.created_at)], actions: [{ label: 'Mark done', action: 'done' }, { label: 'Reject', action: 'reject', danger: true }] }));
  } else if (req.params.id === 'disputes') {
    const r = await pool.query(`SELECT d.id, d.reason, d.created_at, u.email, t.reference FROM disputes d JOIN users u ON u.id=d.user_id JOIN transactions t ON t.id=d.transaction_id WHERE d.status='open' ORDER BY d.created_at LIMIT 50`);
    out.columns = ['Customer', 'Ref', 'Reason', 'When'];
    out.rows = r.rows.map((d) => ({ id: d.id, cells: [d.email, d.reference, d.reason.slice(0, 60), when(d.created_at)], actions: [{ label: 'Resolve', action: 'resolve' }, { label: 'Reject', action: 'reject', danger: true }] }));
  } else if (req.params.id === 'reversals') {
    const r = await pool.query(`SELECT r.id, r.requested_by, r.created_at, t.reference, t.amount_minor, t.currency, u.email AS requester FROM reversal_requests r JOIN transactions t ON t.id=r.transaction_id JOIN users u ON u.id=r.requested_by WHERE r.status='pending' ORDER BY r.created_at`);
    out.note = 'Maker-checker: you cannot approve a reversal you requested yourself.';
    out.columns = ['Ref', 'Amount', 'Requested by', 'When'];
    out.rows = r.rows.map((x) => ({ id: x.id, cells: [x.reference, fmt(x.amount_minor, x.currency), x.requester, when(x.created_at)],
      actions: can(role, 'reversals.approve') && x.requested_by !== req.user.id ? [{ label: 'Approve', action: 'approve' }, { label: 'Reject', action: 'reject', danger: true }] : [] }));
  } else if (req.params.id === 'audit') {
    const r = await pool.query(`SELECT id, actor_type, actor_id, action, target_id, created_at FROM audit_log ORDER BY id DESC LIMIT 80`);
    out.columns = ['When', 'Actor', 'Action', 'Target'];
    out.rows = r.rows.map((a) => ({ id: String(a.id), cells: [when(a.created_at), `${a.actor_type} ${a.actor_id ? short(a.actor_id) : ''}`, a.action, a.target_id ? short(a.target_id) : ''], actions: [] }));
  }
  res.json(out);
}));

router.post('/admin/action', wrap(async (req, res) => {
  const { section, id, action } = req.body || {};
  const s = SECTIONS[section];
  if (!s) throw new AppError(404, 'NOT_FOUND', 'Unknown section.');
  const perm = section === 'transactions' ? 'reversals.request'
    : section === 'customers' ? 'customers.restrict'
    : section === 'reversals' ? 'reversals.approve'
    : section === 'stuck' ? 'ops.act' : s.perm;
  if (!can(req.user.role, perm)) throw new AppError(403, 'FORBIDDEN', 'Your role cannot do this.');
  const me = req.user.id;
  const key = `${section}.${action}`;

  switch (key) {
    case 'customers.restrict':
    case 'customers.unrestrict': {
      const target = (await pool.query('SELECT id, role FROM users WHERE id=$1', [id])).rows[0];
      if (!target || target.role !== 'customer' || target.id === me) throw new AppError(403, 'FORBIDDEN', 'You cannot change this account.');
      await pool.query('UPDATE users SET status=$2 WHERE id=$1', [id, action === 'restrict' ? 'restricted' : 'active']);
      await notify(pool, id, action === 'restrict' ? 'Account restricted' : 'Account restored', action === 'restrict' ? 'Contact support for help.' : 'You can use your account again.', 'security');
      break;
    }
    case 'transactions.request_reversal': {
      const t = (await pool.query(`SELECT id, state FROM transactions WHERE id=$1`, [id])).rows[0];
      if (!t || t.state !== 'completed') throw new AppError(422, 'NOT_REVERSIBLE', 'Only completed transactions can be reversed.');
      const dup = await pool.query(`SELECT 1 FROM reversal_requests WHERE transaction_id=$1 AND status='pending'`, [id]);
      if (dup.rowCount) throw new AppError(409, 'ALREADY_REQUESTED', 'A reversal is already waiting for approval.');
      await pool.query(`INSERT INTO reversal_requests(transaction_id, requested_by, reason) VALUES ($1,$2,'Requested in admin console')`, [id, me]);
      break;
    }
    case 'held.approve': {
      const t = (await pool.query('SELECT type FROM transactions WHERE id=$1', [id])).rows[0];
      if (!t) throw new AppError(404, 'NOT_FOUND', 'Not found.');
      if (t.type === 'internal_transfer') await completeHeldTransfer(id, me); else await approveHeldExternal(id, me);
      break;
    }
    case 'held.reject':
      await rejectHeld(id, me); break;
    case 'stuck.recheck': {
      try { await recheckPayment(id); } catch (e) { throw new AppError(409, 'NOT_WAITING', e.message); }
      break;
    }
    case 'risk.review':
      await pool.query('UPDATE risk_events SET reviewed_by=$2 WHERE id=$1', [id, me]); break;
    case 'aml.clear':
    case 'aml.escalate':
      await pool.query(`UPDATE aml_cases SET status=$2, reviewed_by=$3, reviewed_at=now() WHERE id=$1`, [id, action === 'clear' ? 'cleared' : 'escalated', me]); break;
    case 'kyc.approve':
    case 'kyc.reject': {
      const k = (await pool.query(`SELECT user_id, tier_requested FROM kyc_submissions WHERE id=$1 AND status='pending'`, [id])).rows[0];
      if (!k) throw new AppError(404, 'NOT_FOUND', 'Already handled.');
      await pool.query(`UPDATE kyc_submissions SET status=$2, reviewed_by=$3, reviewed_at=now() WHERE id=$1`, [id, action === 'approve' ? 'approved' : 'rejected', me]);
      if (action === 'approve') await pool.query('UPDATE users SET kyc_tier=GREATEST(kyc_tier,$2) WHERE id=$1', [k.user_id, k.tier_requested]);
      await markDecided(pool, id);
      await notify(pool, k.user_id, `Verification ${action === 'approve' ? 'approved' : 'declined'}`, action === 'approve' ? `Your limits were raised (tier ${k.tier_requested}).` : 'Contact support for details.', 'security');
      break;
    }
    case 'cheques.approve':
    case 'cheques.reject': {
      const c = (await pool.query(`SELECT * FROM cheque_deposits WHERE id=$1 AND status='pending'`, [id])).rows[0];
      if (!c) throw new AppError(404, 'NOT_FOUND', 'Already handled.');
      if (action === 'approve') {
        const wallet = await walletOf(pool, c.user_id);
        const receipt = await fundWalletDemo({ userId: c.user_id, walletId: wallet, amountMinor: c.amount_minor, idemKey: `cheque:${c.id}`,
          description: `Cheque deposit from ${c.payer_name} (demo)`, type: 'cheque_deposit', category: 'income' });
        await pool.query(`UPDATE cheque_deposits SET status='approved', reviewed_by=$2, reviewed_at=now(), txn_id=$3 WHERE id=$1`, [id, me, receipt.transactionId]);
        await notify(pool, c.user_id, 'Cheque credited', `${fmt(c.amount_minor)} added to your wallet (demo).`, 'credit');
      } else {
        await pool.query(`UPDATE cheque_deposits SET status='rejected', reviewed_by=$2, reviewed_at=now() WHERE id=$1`, [id, me]);
        await notify(pool, c.user_id, 'Cheque not accepted', 'The deposit was rejected in review (demo).', 'failed');
      }
      break;
    }
    case 'services.done':
    case 'services.reject':
      await pool.query(`UPDATE service_requests SET status=$2, handled_by=$3 WHERE id=$1`, [id, action === 'done' ? 'done' : 'rejected', me]); break;
    case 'disputes.resolve':
    case 'disputes.reject': {
      const d = (await pool.query(`UPDATE disputes SET status=$2, handled_by=$3, resolution_note=$4 WHERE id=$1 AND status='open' RETURNING user_id`,
        [id, action === 'resolve' ? 'resolved' : 'rejected', me, action === 'resolve' ? 'Reviewed and resolved by support.' : 'Reviewed. No error found.'])).rows[0];
      if (d) await notify(pool, d.user_id, 'Problem report updated', action === 'resolve' ? 'Resolved by support.' : 'Reviewed. No error found.', 'info');
      break;
    }
    case 'reversals.approve': {
      const r = (await pool.query(`SELECT * FROM reversal_requests WHERE id=$1 AND status='pending'`, [id])).rows[0];
      if (!r) throw new AppError(404, 'NOT_FOUND', 'Already handled.');
      if (r.requested_by === me) throw new AppError(403, 'SAME_PERSON', 'A different administrator must approve this reversal.');
      await executeReversal(r.transaction_id, me);
      await pool.query(`UPDATE reversal_requests SET status='approved', approved_by=$2, decided_at=now() WHERE id=$1`, [id, me]);
      break;
    }
    case 'reversals.reject':
      await pool.query(`UPDATE reversal_requests SET status='rejected', approved_by=$2, decided_at=now() WHERE id=$1 AND status='pending'`, [id, me]); break;
    default:
      throw new AppError(400, 'UNKNOWN_ACTION', 'Unknown action.');
  }
  await audit(req, `admin.${key}`, id);
  res.json({ ok: true });
}));

export default router;
