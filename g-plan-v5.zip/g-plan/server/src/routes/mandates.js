// Direct debits. Business side (owner and finance manager): ask a customer for a mandate and schedule collections.
// Customer side: approve, pause, resume or cancel. The customer can always cancel, with no password and no reason.
import { Router } from 'express';
import { pool } from '../db.js';
import { config } from '../config.js';
import { AppError, wrap } from '../errors.js';
import { requireAuth } from '../middleware/auth.js';
import { isEmail, fmt } from '../utils/format.js';
import { notify } from '../services/notify.js';
import { authorisePayment } from '../services/guard.js';
import { requireBizPerm, notifyMembers } from '../services/businessAccess.js';
import { FREQUENCIES, checkSchedule, validDate, addDays } from '../utils/mandateRules.js';
import { scheduleFirst } from '../services/mandates.js';

const router = Router();
router.use(requireAuth);
const today = () => new Date().toISOString().slice(0, 10);
const d10 = (d) => (d ? (typeof d === 'string' ? d.slice(0, 10) : d.toISOString().slice(0, 10)) : null);
const audit = (req, action, target, meta = {}) =>
  pool.query(`INSERT INTO audit_log(actor_type, actor_id, action, target_type, target_id, ip_address, metadata) VALUES ('user',$1,$2,'mandate',$3,$4,$5)`,
    [req.user.id, action, target || null, req.ip, JSON.stringify(meta)]);

// ---------------------------------------------------------------- business side
router.get('/business/mandates', requireBizPerm('mandates.read'), wrap(async (req, res) => {
  const rows = (await pool.query(
    `SELECT m.id, m.label, m.status, m.max_amount_minor, m.fixed_amount_minor, m.frequency, m.start_on, m.end_on, m.failures_in_a_row, u.full_name AS payer,
            (SELECT json_agg(x ORDER BY x.due_on DESC) FROM (SELECT c.id, c.due_on, c.amount_minor, c.status, c.error FROM mandate_collections c WHERE c.mandate_id=m.id ORDER BY c.due_on DESC LIMIT 5) x) AS collections
     FROM mandates m JOIN users u ON u.id=m.payer_id WHERE m.business_id=$1 ORDER BY m.created_at DESC LIMIT 50`, [req.biz.business_id])).rows;
  res.json({ mandates: rows.map((m) => ({ id: m.id, label: m.label, status: m.status, payer: m.payer, maxAmountMinor: m.max_amount_minor, fixedAmountMinor: m.fixed_amount_minor,
    frequency: m.frequency, startOn: d10(m.start_on), endOn: d10(m.end_on), failuresInARow: m.failures_in_a_row,
    collections: (m.collections || []).map((c) => ({ id: c.id, dueOn: d10(c.due_on), amountMinor: c.amount_minor, status: c.status, error: c.error })) })) });
}));

// The reply never says whether the email has an account (no account probing).
router.post('/business/mandates', requireBizPerm('mandates.manage'), wrap(async (req, res) => {
  const b = req.body || {};
  const label = typeof b.label === 'string' ? b.label.trim() : '';
  if (label.length < 2 || label.length > 60) throw new AppError(422, 'INVALID_LABEL', 'Say what this is for, like "Gym membership".');
  if (!isEmail(b.email)) throw new AppError(422, 'INVALID_EMAIL', 'Enter a valid email.');
  const max = Number(b.maxAmountMinor);
  if (!Number.isSafeInteger(max) || max <= 0 || max > config.maxAmountMinor) throw new AppError(422, 'INVALID_AMOUNT', 'Enter the most you may collect each time.');
  const fixed = b.fixedAmountMinor === undefined || b.fixedAmountMinor === null || b.fixedAmountMinor === '' ? null : Number(b.fixedAmountMinor);
  if (fixed !== null && (!Number.isSafeInteger(fixed) || fixed <= 0 || fixed > max)) throw new AppError(422, 'INVALID_AMOUNT', 'A fixed amount cannot be more than the limit.');
  if (!FREQUENCIES.includes(b.frequency)) throw new AppError(422, 'INVALID_FREQUENCY', 'Choose weekly, monthly or quarterly.');
  if (!validDate(b.startDate) || b.startDate < today()) throw new AppError(422, 'INVALID_DATE', 'Choose a start date from today onwards.');
  if (b.endDate && (!validDate(b.endDate) || b.endDate < b.startDate)) throw new AppError(422, 'INVALID_DATE', 'The end date must be after the start date.');
  const notice = [2, 3, 5, 7, 14].includes(Number(b.noticeDays)) ? Number(b.noticeDays) : 3;
  const recent = Number((await pool.query(`SELECT COUNT(*) AS n FROM mandates WHERE business_id=$1 AND created_at > now() - interval '1 day'`, [req.biz.business_id])).rows[0].n);
  if (recent >= 20) throw new AppError(429, 'TOO_MANY', 'Too many requests today. Try again tomorrow.');

  const payer = (await pool.query(`SELECT id FROM users WHERE email=$1 AND status='active' AND email_verified_at IS NOT NULL`, [b.email.toLowerCase()])).rows[0];
  const onTeam = payer && (await pool.query(`SELECT 1 FROM business_members WHERE business_id=$1 AND user_id=$2 AND status='active'`, [req.biz.business_id, payer.id])).rowCount;
  if (payer && payer.id !== req.user.id && !onTeam) {
    const m = (await pool.query(
      `INSERT INTO mandates(business_id, payer_id, created_by, label, max_amount_minor, fixed_amount_minor, frequency, notice_days, start_on, end_on)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
      [req.biz.business_id, payer.id, req.user.id, label, max, fixed, b.frequency, notice, b.startDate, b.endDate || null])).rows[0];
    await notify(pool, payer.id, 'Direct debit request', `${req.biz.name} asks to collect up to ${fmt(max)} ${b.frequency} for ${label}. Open Direct debits to review. Nothing is taken unless you approve.`, 'pending');
    await audit(req, 'mandate.requested', m.id, { max, frequency: b.frequency });
  }
  res.status(202).json({ ok: true, note: 'If that person has a verified G-Plan account, they will see your request in Direct debits. Nothing is collected until they approve.' });
}));

router.post('/business/mandates/:id/collections', requireBizPerm('mandates.manage'), wrap(async (req, res) => {
  const m = (await pool.query(`SELECT * FROM mandates WHERE id=$1 AND business_id=$2`, [req.params.id, req.biz.business_id])).rows[0];
  if (!m) throw new AppError(404, 'NOT_FOUND', 'Direct debit not found.');
  const last = (await pool.query(`SELECT due_on, status FROM mandate_collections WHERE mandate_id=$1 AND status<>'cancelled' ORDER BY due_on DESC LIMIT 1`, [m.id])).rows[0];
  const amountMinor = Number(req.body?.amountMinor);
  const dueOn = String(req.body?.dueOn || '');
  const problem = checkSchedule({ mandate: { ...m, start_on: d10(m.start_on), end_on: d10(m.end_on) }, amountMinor, dueOn, today: today(), lastCollection: last && { ...last, due_on: d10(last.due_on) } });
  if (problem) throw new AppError(422, 'NOT_ALLOWED', problem);
  try {
    await pool.query(`INSERT INTO mandate_collections(mandate_id, due_on, amount_minor, created_by) VALUES ($1,$2,$3,$4)`, [m.id, dueOn, amountMinor, req.user.id]);
  } catch (e) { if (e.code === '23505') throw new AppError(409, 'ALREADY_SCHEDULED', 'There is already a collection on that date.'); throw e; }
  await notify(pool, m.payer_id, 'Direct debit scheduled', `${req.biz.name} will collect ${fmt(amountMinor)} on ${dueOn} for ${m.label}. You can cancel any time in Direct debits.`, 'pending');
  await audit(req, 'mandate.collection_scheduled', m.id, { amountMinor, dueOn });
  res.status(201).json({ ok: true });
}));

router.post('/business/mandates/:id/cancel', requireBizPerm('mandates.manage'), wrap(async (req, res) => {
  const r = await pool.query(`UPDATE mandates SET status='cancelled', cancelled_at=now(), cancelled_by=$3 WHERE id=$1 AND business_id=$2 AND status IN ('pending','active','paused') RETURNING payer_id, label`, [req.params.id, req.biz.business_id, req.user.id]);
  if (!r.rows[0]) throw new AppError(404, 'NOT_FOUND', 'Direct debit not found.');
  await pool.query(`UPDATE mandate_collections SET status='cancelled', error='Cancelled by the business.' WHERE mandate_id=$1 AND status='scheduled'`, [req.params.id]);
  await notify(pool, r.rows[0].payer_id, 'Direct debit cancelled', `${req.biz.name} cancelled the ${r.rows[0].label} direct debit. Nothing more will be collected.`, 'info');
  await audit(req, 'mandate.cancelled_by_business', req.params.id);
  res.json({ ok: true });
}));

// ---------------------------------------------------------------- customer side
router.get('/mandates', wrap(async (req, res) => {
  const rows = (await pool.query(
    `SELECT m.id, m.label, m.status, m.max_amount_minor, m.fixed_amount_minor, m.frequency, m.notice_days, m.start_on, m.end_on, m.expires_at, b.name AS business,
            (SELECT json_agg(x ORDER BY x.due_on DESC) FROM (SELECT c.due_on, c.amount_minor, c.status, c.error FROM mandate_collections c WHERE c.mandate_id=m.id ORDER BY c.due_on DESC LIMIT 6) x) AS collections
     FROM mandates m JOIN businesses b ON b.id=m.business_id WHERE m.payer_id=$1 AND m.status IN ('pending','active','paused') ORDER BY m.created_at DESC`, [req.user.id])).rows;
  res.json({ mandates: rows.map((m) => ({ id: m.id, label: m.label, status: m.status, business: m.business, maxAmountMinor: m.max_amount_minor, fixedAmountMinor: m.fixed_amount_minor,
    frequency: m.frequency, noticeDays: m.notice_days, startOn: d10(m.start_on), endOn: d10(m.end_on), expiresAt: m.expires_at,
    collections: (m.collections || []).map((c) => ({ dueOn: d10(c.due_on), amountMinor: c.amount_minor, status: c.status, error: c.error })) })) });
}));

async function mine(req, statuses) {
  const m = (await pool.query(
    `SELECT m.*, b.name AS business FROM mandates m JOIN businesses b ON b.id=m.business_id WHERE m.id=$1 AND m.payer_id=$2 AND m.status = ANY($3)`, [req.params.id, req.user.id, statuses])).rows[0];
  if (!m) throw new AppError(404, 'NOT_FOUND', 'Direct debit not found.');
  return m;
}

router.post('/mandates/:id/approve', wrap(async (req, res) => {
  const m = await mine(req, ['pending']);
  if (new Date(m.expires_at) < new Date()) { await pool.query(`UPDATE mandates SET status='expired' WHERE id=$1`, [m.id]); throw new AppError(410, 'EXPIRED', 'This request has expired. Ask the business to send a new one.'); }
  // Allowing someone to pull money from your wallet is a big decision: password (and a code if you use two-step).
  await authorisePayment(req, { password: req.body?.password, otp: req.body?.otp, amountMinor: Number(m.max_amount_minor) });
  const r = await pool.query(`UPDATE mandates SET status='active', approved_at=now() WHERE id=$1 AND status='pending' RETURNING *`, [m.id]);
  if (!r.rows[0]) throw new AppError(409, 'NOT_PENDING', 'This request was already handled.');
  const first = await scheduleFirst(pool, { ...r.rows[0], start_on: d10(r.rows[0].start_on), end_on: d10(r.rows[0].end_on) }, today());
  await audit(req, 'mandate.approved', m.id, { max: Number(m.max_amount_minor) });
  await notifyMembers(pool, m.business_id, 'mandates.read', 'Direct debit approved', `A customer approved the ${m.label} direct debit.`, 'info');
  res.json({ ok: true, firstCollection: first ? d10(first) : null });
}));

router.post('/mandates/:id/decline', wrap(async (req, res) => {
  const m = await mine(req, ['pending']);
  await pool.query(`UPDATE mandates SET status='declined' WHERE id=$1`, [m.id]);
  await notifyMembers(pool, m.business_id, 'mandates.read', 'Direct debit declined', `A customer declined the ${m.label} request.`, 'info');
  res.json({ ok: true });
}));

// Cancelling needs no password: protecting your money should never be hard.
router.post('/mandates/:id/cancel', wrap(async (req, res) => {
  const m = await mine(req, ['pending', 'active', 'paused']);
  await pool.query(`UPDATE mandates SET status='cancelled', cancelled_at=now(), cancelled_by=$2 WHERE id=$1`, [m.id, req.user.id]);
  await pool.query(`UPDATE mandate_collections SET status='cancelled', error='Cancelled by the customer.' WHERE mandate_id=$1 AND status='scheduled'`, [m.id]);
  await audit(req, 'mandate.cancelled_by_customer', m.id);
  await notifyMembers(pool, m.business_id, 'mandates.read', 'Direct debit cancelled', `A customer cancelled the ${m.label} direct debit. Nothing more can be collected.`, 'failed');
  res.json({ ok: true });
}));

router.post('/mandates/:id/pause', wrap(async (req, res) => {
  const m = await mine(req, ['active']);
  await pool.query(`UPDATE mandates SET status='paused' WHERE id=$1`, [m.id]);
  res.json({ ok: true });
}));

router.post('/mandates/:id/resume', wrap(async (req, res) => {
  const m = await mine(req, ['paused']);
  await authorisePayment(req, { password: req.body?.password, otp: req.body?.otp, amountMinor: Number(m.max_amount_minor) });
  await pool.query(`UPDATE mandates SET status='active', failures_in_a_row=0 WHERE id=$1 AND status='paused'`, [m.id]);
  const has = (await pool.query(`SELECT 1 FROM mandate_collections WHERE mandate_id=$1 AND status='scheduled'`, [m.id])).rowCount;
  if (!has) await scheduleFirst(pool, { ...m, start_on: d10(m.start_on), end_on: d10(m.end_on) }, today());
  res.json({ ok: true });
}));

export default router;
