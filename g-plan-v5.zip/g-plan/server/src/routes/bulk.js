// Bulk payouts and payroll from the business wallet. Same roles as the rest of Business:
// owner and finance manager can prepare and send; a finance manager's batch above the approval limit waits for the owner.
import { Router } from 'express';
import { pool, withTx } from '../db.js';
import { config } from '../config.js';
import { AppError, wrap } from '../errors.js';
import { requireAuth } from '../middleware/auth.js';
import { isEmail, fmt } from '../utils/format.js';
import { notify } from '../services/notify.js';
import { businessWalletOf, availableBalance } from '../services/ledger.js';
import { authorisePayment } from '../services/guard.js';
import { BANKS } from '../services/catalog.js';
import { requireBizPerm, payoutNeedsApproval, userName } from '../services/businessAccess.js';
import { checkBulk, MAX_ROWS } from '../utils/bulkParse.js';

const router = Router();
router.use(requireAuth);
const CODES = BANKS.map((b) => b.code);
const audit = (req, action, target, meta = {}) =>
  pool.query(`INSERT INTO audit_log(actor_type, actor_id, action, target_type, target_id, ip_address, metadata) VALUES ('user',$1,$2,'business',$3,$4,$5)`,
    [req.user.id, action, target || null, req.ip, JSON.stringify(meta)]);

const view = (b) => ({ id: b.id, label: b.label, source: b.source, totalMinor: b.total_minor, count: b.item_count, status: b.status, createdBy: b.created_by_name, createdAt: b.created_at,
  sent: b.sent !== undefined ? Number(b.sent) : undefined, failed: b.failed !== undefined ? Number(b.failed) : undefined });

async function loadBatch(id, businessId) {
  return (await pool.query(`SELECT b.*, u.full_name AS created_by_name FROM bulk_batches b JOIN users u ON u.id=b.created_by WHERE b.id=$1 AND b.business_id=$2`, [id, businessId])).rows[0];
}

async function createBatch(req, { label, source, runKey, items, totalMinor }) {
  try {
    return await withTx(async (c) => {
      const b = (await c.query(
        `INSERT INTO bulk_batches(business_id, created_by, label, source, run_key, total_minor, item_count) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
        [req.biz.business_id, req.user.id, label, source, runKey || null, totalMinor, items.length])).rows[0];
      for (const [k, it] of items.entries()) {
        await c.query(
          `INSERT INTO bulk_items(batch_id, line, kind, name, bank_code, account_number, email, amount_minor, note) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
          [b.id, it.line ?? k + 1, it.kind, it.name, it.bankCode, it.accountNumber, it.email, it.amountMinor, it.note]);
      }
      return b;
    });
  } catch (e) {
    if (e.code === '23505') throw new AppError(409, 'ALREADY_RUN', 'This payroll has already been run for that month. Cancel or reject the earlier one first.');
    throw e;
  }
}

// ---------------------------------------------------------------- batches
router.get('/business/bulk', requireBizPerm('payouts.read'), wrap(async (req, res) => {
  const r = await pool.query(
    `SELECT b.*, u.full_name AS created_by_name,
            (SELECT COUNT(*) FROM bulk_items i WHERE i.batch_id=b.id AND i.status='sent') AS sent,
            (SELECT COUNT(*) FROM bulk_items i WHERE i.batch_id=b.id AND i.status IN ('failed','skipped')) AS failed
     FROM bulk_batches b JOIN users u ON u.id=b.created_by WHERE b.business_id=$1 ORDER BY b.created_at DESC LIMIT 30`, [req.biz.business_id]);
  res.json({ batches: r.rows.map(view), maxRows: MAX_ROWS });
}));

router.get('/business/bulk/:id', requireBizPerm('payouts.read'), wrap(async (req, res) => {
  const b = await loadBatch(req.params.id, req.biz.business_id);
  if (!b) throw new AppError(404, 'NOT_FOUND', 'Batch not found.');
  const items = (await pool.query(`SELECT line, kind, name, bank_code, account_number, email, amount_minor, status, error FROM bulk_items WHERE batch_id=$1 ORDER BY line`, [b.id])).rows;
  res.json({ batch: view(b), items: items.map((i) => ({ line: i.line, name: i.name, amountMinor: i.amount_minor, status: i.status, error: i.error,
    to: i.kind === 'bank' ? `${BANKS.find((x) => x.code === i.bank_code)?.name || i.bank_code} ••••${String(i.account_number).slice(-4)}` : i.email })) });
}));

// Step 1: check the file. Nothing is sent. Any wrong row refuses the whole file.
router.post('/business/bulk/prepare', requireBizPerm('payouts.create'), wrap(async (req, res) => {
  const { csv, label } = req.body || {};
  const lab = typeof label === 'string' ? label.trim().slice(0, 60) : '';
  if (lab.length < 2) throw new AppError(422, 'INVALID_LABEL', 'Give this batch a name, like "October suppliers".');
  const { items, problems, totalMinor } = checkBulk(csv, CODES);
  if (problems.length) {
    const first = problems.slice(0, 5).map((p) => (p.line ? `Line ${p.line}: ${p.message}` : p.message)).join(' ');
    throw new AppError(422, 'CSV_INVALID', `${problems.length} problem${problems.length > 1 ? 's' : ''} found, nothing was saved. ${first}${problems.length > 5 ? ' …' : ''}`);
  }
  const b = await createBatch(req, { label: lab, source: 'csv', items, totalMinor });
  await audit(req, 'business.bulk_prepared', req.biz.business_id, { batchId: b.id, count: items.length, totalMinor });
  res.status(201).json({ batch: view({ ...b, created_by_name: await userName(pool, req.user.id) }) });
}));

// Step 2: the creator confirms with their password. Large batches from a finance manager go to the owner.
router.post('/business/bulk/:id/send', requireBizPerm('payouts.create'), wrap(async (req, res) => {
  const b = await loadBatch(req.params.id, req.biz.business_id);
  if (!b || b.status !== 'draft') throw new AppError(404, 'NOT_FOUND', 'Batch not found, or it was already sent.');
  if (b.created_by !== req.user.id) throw new AppError(403, 'FORBIDDEN', 'Only the person who prepared this batch can send it.');
  const wid = await businessWalletOf(pool, req.biz.business_id);
  const { level } = await authorisePayment(req, { password: req.body?.password, otp: req.body?.otp, amountMinor: Number(b.total_minor), walletId: wid });
  if (payoutNeedsApproval(req.biz.role, b.total_minor, req.biz.approval_threshold_minor)) {
    await pool.query(`UPDATE bulk_batches SET status='pending_approval', risk_level=$2 WHERE id=$1 AND status='draft'`, [b.id, level]);
    await notify(pool, req.biz.owner_id, 'Batch waiting for approval', `${b.label}: ${fmt(Number(b.total_minor))} to ${b.item_count} people needs your approval. Open Business.`, 'pending');
    return res.status(202).json({ needsApproval: true });
  }
  await start(req, b, level);
  res.json({ started: true });
}));

router.post('/business/bulk/:id/approve', requireBizPerm('payouts.approve'), wrap(async (req, res) => {
  const b = await loadBatch(req.params.id, req.biz.business_id);
  if (!b || b.status !== 'pending_approval') throw new AppError(404, 'NOT_FOUND', 'Batch not found, or it was already handled.');
  if (b.created_by === req.user.id) throw new AppError(403, 'SAME_PERSON', 'Someone else must approve a batch you prepared.');
  const wid = await businessWalletOf(pool, req.biz.business_id);
  const { level } = await authorisePayment(req, { password: req.body?.password, otp: req.body?.otp, amountMinor: Number(b.total_minor), walletId: wid });
  await start(req, b, level, 'pending_approval');
  await notify(pool, b.created_by, 'Batch approved', `${b.label} was approved and is being sent.`, 'info');
  await audit(req, 'business.bulk_approved', req.biz.business_id, { batchId: b.id });
  res.json({ started: true });
}));

// Flip to running only if the wallet can cover it and nobody else got there first.
async function start(req, b, level, from = 'draft') {
  const wid = await businessWalletOf(pool, b.business_id);
  const need = Number(b.total_minor) + Number(b.item_count) * config.fees.externalTransferMinor;
  if ((await availableBalance(pool, wid)) < need) throw new AppError(422, 'INSUFFICIENT_FUNDS', `The business wallet needs ${fmt(need)} (including fees) to send this batch.`);
  const r = await pool.query(`UPDATE bulk_batches SET status='running', executed_by=$2, risk_level=$3, decided_at=now() WHERE id=$1 AND status=$4 RETURNING id`, [b.id, req.user.id, level, from]);
  if (!r.rows[0]) throw new AppError(409, 'NOT_PENDING', 'This batch was already handled.');
  await audit(req, 'business.bulk_started', b.business_id, { batchId: b.id, totalMinor: Number(b.total_minor) });
}

router.post('/business/bulk/:id/reject', requireBizPerm('payouts.approve'), wrap(async (req, res) => {
  const r = await pool.query(`UPDATE bulk_batches SET status='rejected', run_key=NULL, decided_at=now() WHERE id=$1 AND business_id=$2 AND status='pending_approval' RETURNING created_by, label`, [req.params.id, req.biz.business_id]);
  if (!r.rows[0]) throw new AppError(404, 'NOT_FOUND', 'Batch not found, or it was already handled.');
  await notify(pool, r.rows[0].created_by, 'Batch rejected', `${r.rows[0].label} was rejected. No money moved.`, 'failed');
  res.json({ ok: true });
}));

router.post('/business/bulk/:id/cancel', requireBizPerm('payouts.create'), wrap(async (req, res) => {
  const r = await pool.query(`UPDATE bulk_batches SET status='cancelled', run_key=NULL, decided_at=now() WHERE id=$1 AND business_id=$2 AND created_by=$3 AND status IN ('draft','pending_approval') RETURNING id`, [req.params.id, req.biz.business_id, req.user.id]);
  if (!r.rows[0]) throw new AppError(404, 'NOT_FOUND', 'Batch not found, or it can no longer be cancelled.');
  res.json({ ok: true });
}));

// ---------------------------------------------------------------- payroll
router.get('/business/payroll/employees', requireBizPerm('payouts.read'), wrap(async (req, res) => {
  const r = await pool.query(`SELECT id, name, kind, bank_code, account_number, email, salary_minor FROM payroll_employees WHERE business_id=$1 AND active ORDER BY name`, [req.biz.business_id]);
  res.json({ employees: r.rows.map((e) => ({ id: e.id, name: e.name, salaryMinor: e.salary_minor,
    to: e.kind === 'bank' ? `${BANKS.find((x) => x.code === e.bank_code)?.name || e.bank_code} ••••${String(e.account_number).slice(-4)}` : e.email })) });
}));

router.post('/business/payroll/employees', requireBizPerm('payouts.create'), wrap(async (req, res) => {
  const { name, kind, bankCode, accountNumber, email, salaryMinor } = req.body || {};
  if (typeof name !== 'string' || name.trim().length < 2 || name.length > 80) throw new AppError(422, 'INVALID_NAME', 'Enter the employee name.');
  const pay = Number(salaryMinor);
  if (!Number.isSafeInteger(pay) || pay <= 0 || pay > config.maxAmountMinor) throw new AppError(422, 'INVALID_AMOUNT', 'Enter a valid salary.');
  const count = Number((await pool.query('SELECT COUNT(*) AS n FROM payroll_employees WHERE business_id=$1 AND active', [req.biz.business_id])).rows[0].n);
  if (count >= MAX_ROWS) throw new AppError(422, 'TOO_MANY', `A payroll list can have up to ${MAX_ROWS} people.`);
  if (kind === 'bank') {
    if (!CODES.includes(bankCode)) throw new AppError(422, 'INVALID_BANK', 'Choose a bank.');
    if (!/^\d{10}$/.test(String(accountNumber || ''))) throw new AppError(422, 'INVALID_ACCOUNT', 'Account numbers have 10 digits.');
  } else if (kind === 'internal') {
    if (!isEmail(email)) throw new AppError(422, 'INVALID_EMAIL', 'Enter a valid email.');
  } else throw new AppError(422, 'INVALID_KIND', 'Choose bank account or G-Plan account.');
  await pool.query(
    `INSERT INTO payroll_employees(business_id, name, kind, bank_code, account_number, email, salary_minor) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [req.biz.business_id, name.trim(), kind, kind === 'bank' ? bankCode : null, kind === 'bank' ? String(accountNumber) : null, kind === 'internal' ? String(email).toLowerCase() : null, pay]);
  res.status(201).json({ ok: true });
}));

router.delete('/business/payroll/employees/:id', requireBizPerm('payouts.create'), wrap(async (req, res) => {
  await pool.query(`UPDATE payroll_employees SET active=FALSE WHERE id=$1 AND business_id=$2`, [req.params.id, req.biz.business_id]);
  res.json({ ok: true });
}));

// Builds a draft batch from the payroll list. One run per month: a second one is refused until the first is cancelled or rejected.
router.post('/business/payroll/run', requireBizPerm('payouts.create'), wrap(async (req, res) => {
  const month = String(req.body?.month || '');
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) throw new AppError(422, 'INVALID_MONTH', 'Choose a month.');
  const emps = (await pool.query(`SELECT * FROM payroll_employees WHERE business_id=$1 AND active ORDER BY name`, [req.biz.business_id])).rows;
  if (!emps.length) throw new AppError(422, 'NO_EMPLOYEES', 'Add people to your payroll list first.');
  const items = emps.map((e, k) => ({ line: k + 1, kind: e.kind, name: e.name, bankCode: e.bank_code, accountNumber: e.account_number, email: e.email, amountMinor: Number(e.salary_minor), note: `Salary ${month}` }));
  const totalMinor = items.reduce((s, i) => s + i.amountMinor, 0);
  const b = await createBatch(req, { label: `Payroll ${month}`, source: 'payroll', runKey: `payroll:${month}`, items, totalMinor });
  await audit(req, 'business.payroll_prepared', req.biz.business_id, { batchId: b.id, month, count: items.length });
  res.status(201).json({ batch: view({ ...b, created_by_name: await userName(pool, req.user.id) }) });
}));

export default router;
