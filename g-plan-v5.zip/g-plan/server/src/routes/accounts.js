import { Router } from 'express';
import { pool, withTx } from '../db.js';
import { config } from '../config.js';
import { AppError, wrap } from '../errors.js';
import { requireAuth } from '../middleware/auth.js';
import { availableBalance, ledgerBalance, walletOf } from '../services/ledger.js';
import { walletRows, pendingRows, statement, monthRange } from '../services/queries.js';
import { taxSummary } from '../services/statements.js';
import { assertPassword } from '../services/passwords.js';
import { quote, convert, ensureWallet, currencies } from '../services/fx.js';
import { assertAmount } from '../services/transfers.js';
import { normalisePhone, fmt } from '../utils/format.js';

const router = Router();
router.use(requireAuth);

router.get('/accounts', wrap(async (req, res) => {
  const ws = (await pool.query(
    `SELECT id, currency, name FROM accounts WHERE user_id=$1 AND type='customer_wallet' AND business_id IS NULL AND pocket_id IS NULL ORDER BY currency`, [req.user.id])).rows;
  const wallets = [];
  for (const w of ws) {
    wallets.push({ ...w, availableMinor: await availableBalance(pool, w.id), ledgerMinor: await ledgerBalance(pool, w.id) });
  }
  const saved = (await pool.query(
    `SELECT COALESCE(SUM(CASE WHEN p.direction='credit' THEN p.amount_minor ELSE -p.amount_minor END),0) AS saved
     FROM accounts a LEFT JOIN postings p ON p.account_id=a.id
     WHERE a.user_id=$1 AND a.type='goal_pot'`, [req.user.id])).rows[0].saved;
  res.json({ wallet: wallets.find((w) => w.currency === 'NGN'), wallets, savedMinor: saved });
}));

const isoDate = (v, plusDays = 0) => {
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) throw new AppError(422, 'INVALID_DATE', 'Check the dates you entered.');
  return new Date(d.getTime() + plusDays * 86400000).toISOString();
};

router.get('/transactions', wrap(async (req, res) => {
  const q = req.query;
  const num = (v) => (v === undefined || v === '' ? undefined : Math.round(Number(v) * 100));
  const filters = {
    q: q.q ? String(q.q).slice(0, 60) : undefined, type: q.type || undefined, category: q.category || undefined,
    dir: ['in', 'out'].includes(q.dir) ? q.dir : undefined, currency: q.currency || 'NGN',
    from: q.from ? isoDate(q.from) : undefined,
    to: q.to ? isoDate(q.to, 1) : undefined,
    min: Number.isFinite(num(q.min)) ? num(q.min) : undefined, max: Number.isFinite(num(q.max)) ? num(q.max) : undefined,
    limit: Math.min(Number(q.limit) || 50, 200), offset: Number(q.offset) || 0,
  };
  const rows = await walletRows(pool, req.user.id, filters);
  const filtered = Object.keys(q).some((k) => ['q', 'type', 'category', 'dir', 'from', 'to', 'min', 'max'].includes(k));
  const pending = !filtered && filters.offset === 0 ? await pendingRows(pool, req.user.id) : [];
  res.json({ transactions: [...pending, ...rows] });
}));

router.get('/transactions/:reference', wrap(async (req, res) => {
  const t = (await pool.query(
    `SELECT t.* FROM transactions t WHERE t.reference=$1 AND (t.initiator_user_id=$2 OR EXISTS (
       SELECT 1 FROM journal_entries je JOIN postings p ON p.entry_id=je.id JOIN accounts a ON a.id=p.account_id
       WHERE je.transaction_id=t.id AND a.user_id=$2))`, [req.params.reference.toUpperCase(), req.user.id])).rows[0];
  if (!t) throw new AppError(404, 'NOT_FOUND', 'Transaction not found.');
  const history = (await pool.query(
    'SELECT from_state, to_state, created_at FROM transaction_state_history WHERE transaction_id=$1 ORDER BY id', [t.id])).rows;
  res.json({ transaction: { id: t.id, reference: t.reference, type: t.type, state: t.state, amountMinor: t.amount_minor,
    feeMinor: t.fee_minor, currency: t.currency, description: t.description, category: t.category, isDemo: t.is_demo,
    failureReason: t.failure_reason, createdAt: t.created_at, riskLevel: t.risk_level, meta: t.meta }, history });
}));

// ----- Profile -----
router.get('/profile', wrap(async (req, res) => {
  const u = (await pool.query(
    `SELECT id, email, full_name, phone, kyc_tier, role, mfa_method, email_verified_at, phone_verified_at, created_at
     FROM users WHERE id=$1`, [req.user.id])).rows[0];
  res.json({ profile: { ...u, email_verified: !!u.email_verified_at, phone_verified: !!u.phone_verified_at } });
}));

router.patch('/profile', wrap(async (req, res) => {
  const { fullName, phone } = req.body || {};
  const sets = [], params = [];
  if (fullName !== undefined) {
    if (typeof fullName !== 'string' || fullName.trim().length < 2 || fullName.length > 80) throw new AppError(422, 'INVALID_NAME', 'Enter your full name.');
    params.push(fullName.trim()); sets.push(`full_name=$${params.length}`);
  }
  if (phone !== undefined) {
    const p = phone === '' ? null : normalisePhone(phone);
    if (phone !== '' && !p) throw new AppError(422, 'INVALID_PHONE', 'Enter a valid Nigerian phone number.');
    params.push(p); sets.push(`phone=$${params.length}`, 'phone_verified_at=NULL');
  }
  if (!sets.length) return res.json({ ok: true });
  params.push(req.user.id);
  try { await pool.query(`UPDATE users SET ${sets.join(', ')} WHERE id=$${params.length}`, params); }
  catch (e) { if (e.code === '23505') throw new AppError(409, 'PHONE_TAKEN', 'That phone number is already in use.'); throw e; }
  await pool.query(`INSERT INTO audit_log(actor_type, actor_id, action) VALUES ('user',$1,'profile.update')`, [req.user.id]);
  res.json({ ok: true });
}));

// ----- Multi-currency (indicative demo rates) -----
router.get('/fx/rates', (_req, res) => {
  res.json({ indicative: true, note: 'Demo rates for illustration. Real conversions use the rate at the time of the transaction.',
    base: 'NGN', rates: config.fxRatesToNgn, feePercent: config.fees.fxPercent, internationalFeePercent: config.fees.internationalPercent });
});
router.post('/fx/quote', wrap(async (req, res) => {
  const { from, to, amountMinor } = req.body || {};
  res.json({ quote: quote(from, to, amountMinor) });
}));
router.post('/wallets', wrap(async (req, res) => {
  const { currency } = req.body || {};
  if (!currencies().includes(currency)) throw new AppError(422, 'UNSUPPORTED_CURRENCY', 'That currency is not supported yet.');
  await ensureWallet(req.user.id, currency);
  res.status(201).json({ ok: true });
}));
router.post('/fx/convert', wrap(async (req, res) => {
  const { from, to, amountMinor } = req.body || {};
  res.status(201).json({ receipt: await convert({ userId: req.user.id, from, to, amountMinor, idemKey: req.get('Idempotency-Key') }) });
}));

// ----- Statements -----
// Yearly summary of activity. Not tax advice (the reply says so).
const yearOf = (v) => { const y = Number(v); const now = new Date().getUTCFullYear(); if (!Number.isInteger(y) || y < 2000 || y > now) throw new AppError(422, 'INVALID_YEAR', 'Choose a year.'); return y; };
router.get('/statements/tax-summary/:year', wrap(async (req, res) => {
  res.json({ summary: await taxSummary(pool, req.user.id, yearOf(req.params.year), req.query.currency || 'NGN') });
}));
router.get('/statements/tax-summary/:year/csv', wrap(async (req, res) => {
  const s = await taxSummary(pool, req.user.id, yearOf(req.params.year), req.query.currency || 'NGN');
  const n = (v) => (v / 100).toFixed(2);
  const lines = [['G-Plan yearly summary', s.year], ['Note', s.note.replace(/,/g, ' ')], [],
    ['Total', 'Amount'], ['Received from other people', n(s.totals.receivedFromPeople)], ['Added to wallet', n(s.totals.addedToWallet)], ['Demo interest', n(s.totals.interest)],
    ['Other money in', n(s.totals.otherIn)], ['Spent', n(s.totals.spent)], ['Put into savings goals', n(s.totals.saved)], [],
    ['Month', 'Received', 'Spent', 'Saved', 'Interest'], ...s.months.map((m, i) => [i + 1, n(m.received), n(m.spent), n(m.saved), n(m.interest)]), [],
    ['Spending category', 'Amount'], ...s.categories.map((c) => [c.category.replace(/,/g, ' '), n(c.totalMinor)])];
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename="gplan-summary-${s.year}.csv"`);
  res.send(lines.map((l) => l.join(',')).join('\n'));
}));

router.get('/statements/:month', wrap(async (req, res) => {
  res.json({ statement: await statement(pool, req.user.id, req.params.month, req.query.currency || 'NGN') });
}));

router.get('/statements/:month/csv', wrap(async (req, res) => {
  const s = await statement(pool, req.user.id, req.params.month, req.query.currency || 'NGN');
  const esc = (v) => { const t = String(v ?? ''); return /^[=+\-@]/.test(t) ? `"'${t.replace(/"/g, '""')}"` : `"${t.replace(/"/g, '""')}"`; };
  const rows = [['Date', 'Reference', 'Description', 'Category', 'Amount', 'Balance'].join(',')];
  for (const l of s.lines) rows.push([new Date(l.created_at).toISOString().slice(0, 10), l.reference, esc(l.description), esc(l.category), (l.net_minor / 100).toFixed(2), (l.balance_minor / 100).toFixed(2)].join(','));
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename="gplan-statement-${s.month}.csv"`);
  res.send(rows.join('\n'));
}));

router.get('/statements/:month/pdf', wrap(async (req, res) => {
  let PDFDocument;
  try { ({ default: PDFDocument } = await import('pdfkit')); }
  catch { throw new AppError(501, 'PDF_UNAVAILABLE', 'PDF export needs npm install on the server. CSV is available.'); }
  const s = await statement(pool, req.user.id, req.params.month, req.query.currency || 'NGN');
  const u = (await pool.query('SELECT full_name, email FROM users WHERE id=$1', [req.user.id])).rows[0];
  const money = (m) => (m / 100).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const doc = new PDFDocument({ margin: 40, size: 'A4' });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="gplan-statement-${s.month}.pdf"`);
  doc.pipe(res);
  doc.fontSize(18).text('G-Plan account statement');
  doc.fontSize(9).fillColor('#a33').text('DEMO STATEMENT. Prototype only. Not a bank statement and no real money is involved.').fillColor('#000');
  doc.moveDown(0.5).fontSize(10).text(`${u.full_name} (${u.email})`).text(`Period: ${s.month}   Currency: ${s.currency}`);
  doc.text(`Opening balance: ${s.currency} ${money(s.openingMinor)}   Closing balance: ${s.currency} ${money(s.closingMinor)}`);
  doc.moveDown();
  let y = doc.y;
  const head = () => { doc.fontSize(8).font('Helvetica-Bold');
    doc.text('Date', 40, y, { width: 55 }); doc.text('Reference', 95, y, { width: 90 }); doc.text('Description', 185, y, { width: 170 });
    doc.text('Amount', 355, y, { width: 90, align: 'right' }); doc.text('Balance', 450, y, { width: 100, align: 'right' }); doc.font('Helvetica'); y += 14; };
  head();
  for (const l of s.lines) {
    if (y > 770) { doc.addPage(); y = 40; head(); }
    doc.fontSize(8);
    doc.text(new Date(l.created_at).toISOString().slice(0, 10), 40, y, { width: 55, lineBreak: false });
    doc.text(l.reference, 95, y, { width: 90, lineBreak: false });
    doc.text(String(l.description || l.type).slice(0, 40), 185, y, { width: 170, lineBreak: false });
    doc.text(`${l.net_minor < 0 ? '-' : '+'}${money(Math.abs(l.net_minor))}`, 355, y, { width: 90, align: 'right', lineBreak: false });
    doc.text(money(l.balance_minor), 450, y, { width: 100, align: 'right', lineBreak: false });
    y += 13;
  }
  if (!s.lines.length) doc.fontSize(9).text('No transactions in this period.', 40, y);
  doc.end();
}));

// ----- Privacy: export and close -----
router.get('/privacy/export', wrap(async (req, res) => {
  const id = req.user.id;
  const q = async (sql) => (await pool.query(sql, [id])).rows;
  const data = {
    exportedAt: new Date().toISOString(),
    profile: (await q('SELECT id,email,full_name,phone,kyc_tier,role,created_at FROM users WHERE id=$1'))[0],
    transactions: await walletRows(pool, id, { limit: 5000 }),
    goals: await q('SELECT name,target_minor,currency,deadline,created_at FROM goals WHERE user_id=$1'),
    recipients: await q('SELECT kind,name,email,phone,bank_name,created_at FROM beneficiaries WHERE user_id=$1'),
    cards: await q('SELECT label,kind,last4,status,monthly_limit_minor,created_at FROM cards WHERE user_id=$1'),
    budgets: await q('SELECT category,monthly_limit_minor FROM budgets WHERE user_id=$1'),
    notifications: await q('SELECT title,body,created_at FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 500'),
    loginHistory: await q('SELECT success,method,ip,user_agent,created_at FROM login_events WHERE user_id=$1 ORDER BY created_at DESC LIMIT 500'),
    consents: await q('SELECT kind,version,granted,created_at FROM consents WHERE user_id=$1'),
  };
  await pool.query(`INSERT INTO audit_log(actor_type, actor_id, action) VALUES ('user',$1,'privacy.export')`, [id]);
  res.setHeader('Content-Disposition', 'attachment; filename="gplan-my-data.json"');
  res.json(data);
}));

router.post('/privacy/close', wrap(async (req, res) => {
  await assertPassword(req.user.id, req.body?.password);
  await withTx(async (c) => {
    const bal = (await c.query(
      `SELECT COALESCE(SUM(CASE WHEN p.direction='credit' THEN p.amount_minor ELSE -p.amount_minor END),0) AS b
       FROM accounts a LEFT JOIN postings p ON p.account_id=a.id WHERE a.user_id=$1`, [req.user.id])).rows[0].b;
    if (bal !== 0) throw new AppError(422, 'BALANCE_REMAINS', 'Move or withdraw all money, including goals and other currencies, before closing your account.');
    const pend = (await c.query(
      `SELECT COUNT(*) AS n FROM transactions WHERE initiator_user_id=$1 AND state IN ('processing','processing_unconfirmed','under_review')`, [req.user.id])).rows[0].n;
    if (pend > 0) throw new AppError(422, 'PENDING_PAYMENTS', 'Wait for pending payments to finish first.');
    const others = (await c.query(
      `SELECT COUNT(*) AS n FROM business_members m JOIN business_members me ON me.business_id=m.business_id AND me.user_id=$1 AND me.role='owner' AND me.status='active'
       WHERE m.status IN ('active','invited') AND m.user_id<>$1`, [req.user.id])).rows[0].n;
    if (others > 0) throw new AppError(422, 'BUSINESS_HAS_MEMBERS', 'Remove the people on your business team first, because closing your account closes the business wallet.');
    const shared = (await c.query(
      `SELECT COUNT(*) AS n FROM pockets p JOIN pocket_members me ON me.pocket_id=p.id AND me.user_id=$1 AND me.role='owner' AND me.status='active'
       JOIN pocket_members o ON o.pocket_id=p.id AND o.user_id<>$1 AND o.status IN ('active','invited')`, [req.user.id])).rows[0].n;
    if (shared > 0) throw new AppError(422, 'POCKET_HAS_MEMBERS', 'Remove the people from your joint or child pockets first, because closing your account closes them.');
    await c.query(`UPDATE pocket_members SET status='removed', updated_at=now() WHERE user_id=$1 AND status IN ('active','invited')`, [req.user.id]);
    await c.query(`UPDATE business_members SET status='removed', updated_at=now() WHERE user_id=$1 AND status IN ('active','invited')`, [req.user.id]);
    await c.query(`UPDATE users SET status='closed' WHERE id=$1`, [req.user.id]);
    await c.query(`UPDATE accounts SET status='closed' WHERE user_id=$1`, [req.user.id]);
    await c.query(`UPDATE sessions SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL`, [req.user.id]);
    await c.query(`UPDATE scheduled_payments SET status='cancelled' WHERE user_id=$1`, [req.user.id]);
    await c.query(`UPDATE savings_rules SET status='cancelled' WHERE user_id=$1`, [req.user.id]);
    await c.query(`INSERT INTO audit_log(actor_type, actor_id, action) VALUES ('user',$1,'account.closed')`, [req.user.id]);
  });
  res.json({ ok: true, note: 'Your account is closed. Financial records are kept for the period the law requires.' });
}));

export default router;
