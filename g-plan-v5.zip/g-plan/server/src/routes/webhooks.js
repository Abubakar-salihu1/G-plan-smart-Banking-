// Provider webhooks. Signature is verified against the RAW body. Only active when a real provider is configured.
import { pool } from '../db.js';
import { finalize } from '../services/payments.js';
import { verifyWebhook } from '../services/paystack.js';
import * as flutterwave from '../services/flutterwave.js';

export async function paystackWebhook(req, res) {
  const raw = req.body;   // Buffer (express.raw)
  if (!Buffer.isBuffer(raw) || !verifyWebhook(raw, req.get('x-paystack-signature'))) return res.status(401).end();
  let event;
  try { event = JSON.parse(raw.toString('utf8')); } catch { return res.status(400).end(); }
  try {
    const ref = String(event?.data?.reference || '').toUpperCase();
    const t = (await pool.query('SELECT id FROM transactions WHERE reference=$1', [ref])).rows[0];
    if (t) {
      if (event.event === 'transfer.success') await finalize(t.id, { ok: true, providerRef: event.data.transfer_code });
      else if (event.event === 'transfer.failed' || event.event === 'transfer.reversed') await finalize(t.id, { ok: false, reason: 'The transfer failed at the bank.' });
    }
  } catch (e) { console.error('webhook error', e.message); }
  res.status(200).end();
}

// Flutterwave: authenticated by the shared `verif-hash` secret. The payload is never trusted for the result:
// we ask Flutterwave's API what happened to that reference and settle only on a definite answer.
export async function flutterwaveWebhook(req, res) {
  if (!flutterwave.verifyWebhook(req.get('verif-hash'))) return res.status(401).end();
  let event;
  try { event = JSON.parse(Buffer.isBuffer(req.body) ? req.body.toString('utf8') : '{}'); } catch { return res.status(400).end(); }
  try {
    const ref = String(event?.data?.reference || '').toUpperCase();
    if (event?.event === 'transfer.completed' && ref) {
      const t = (await pool.query('SELECT id, reference FROM transactions WHERE reference=$1', [ref])).rows[0];
      if (t) {
        const outcome = await flutterwave.statusCheck(t.reference);
        if (!outcome.unconfirmed) await finalize(t.id, outcome);
      }
    }
  } catch (e) { console.error('webhook error', e.message); }
  res.status(200).end();
}
