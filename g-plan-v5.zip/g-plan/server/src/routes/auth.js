import { Router } from 'express';
import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import { pool, withTx } from '../db.js';
import { config } from '../config.js';
import { AppError, wrap } from '../errors.js';
import {
  requireAuth, createSession, signToken, sha256, safeEqual,
  setRefreshCookie, clearRefreshCookie, readRefreshCookie, REFRESH_DAYS, SESSION_MAX_DAYS,
} from '../middleware/auth.js';
import { createAccount } from '../services/ledger.js';
import { notify } from '../services/notify.js';
import { normalisePhone, isEmail } from '../utils/format.js';
import { checkSecondFactor, sendChallenge } from '../services/mfa.js';
import { registerFailure, passwordProblem } from '../services/passwords.js';
import { hashPassword, verifyPassword, needsRehash, dummyHash } from '../utils/password.js';
import * as passkeys from '../services/webauthn.js';
import { inc, alert } from '../services/monitor.js';
import { sendOtp, verifyOtp } from '../services/otp.js';
import { verifyTotp } from '../utils/totp.js';
import { consumeCode } from '../services/recovery.js';
import { looksLikeRecovery } from '../utils/recoveryCodes.js';
import { decrypt } from '../utils/crypto.js';

const router = Router();
export const TERMS_VERSION = '2026-10';
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export const publicUser = (u) => ({
  id: u.id, email: u.email, full_name: u.full_name, phone: u.phone, kyc_tier: u.kyc_tier, role: u.role,
  mfa_method: u.mfa_method || null, email_verified: !!u.email_verified_at, phone_verified: !!u.phone_verified_at,
});
const COLS = `id, email, phone, full_name, kyc_tier, role, status, password_hash, mfa_method, totp_secret,
              failed_logins, locked_until, email_verified_at, phone_verified_at, registration_pending`;

async function logEvent(req, u, email, success, method, reason) {
  await pool.query(
    `INSERT INTO login_events(user_id, email, success, method, reason, ip, user_agent, device_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
    [u?.id || null, String(email || '').slice(0, 254), success, method, reason || null, req.ip,
      (req.get('user-agent') || '').slice(0, 200), (req.get('x-device-id') || '').slice(0, 64) || null]);
}

async function finishLogin(req, res, u, method) {
  const token = await createSession(pool, u.id, req, method, res);
  await pool.query('UPDATE users SET failed_logins=0, locked_until=NULL, last_login_at=now() WHERE id=$1', [u.id]);
  await logEvent(req, u, u.email, true, method);
  await pool.query(`INSERT INTO audit_log(actor_type, actor_id, action, ip_address) VALUES ('user',$1,'auth.login',$2)`, [u.id, req.ip]);
  await notify(pool, u.id, 'New sign-in', `Signed in with ${method}. If this was not you, change your password and sign out other devices in Security.`, 'security');
  inc('gplan_logins_total', { method });
  res.json({ token, user: publicUser(u) });
}

// ---------- Sign-up: email is verified first, and the reply never reveals whether an email is already in use ----------
const REGISTER_REPLY = {
  ok: true, pending: true,
  message: 'If these details are new, we sent a 6-digit code to your email. Enter it to finish creating your account.',
};

router.post('/register', wrap(async (req, res) => {
  const { email, password, fullName, phone, acceptTerms } = req.body || {};
  if (!isEmail(email)) throw new AppError(422, 'INVALID_EMAIL', 'Enter a valid email address.');
  const pwProblem = passwordProblem(password);
  if (pwProblem) throw new AppError(422, 'WEAK_PASSWORD', pwProblem);
  if (typeof fullName !== 'string' || fullName.trim().length < 2 || fullName.length > 80) {
    throw new AppError(422, 'INVALID_NAME', 'Enter your full name.');
  }
  const ph = phone ? normalisePhone(phone) : null;
  if (phone && !ph) throw new AppError(422, 'INVALID_PHONE', 'Enter a valid Nigerian phone number, like 08031234567.');
  if (acceptTerms !== true) throw new AppError(422, 'TERMS_REQUIRED', 'Please accept the terms and privacy notice to continue.');

  const em = email.toLowerCase();
  const hash = await hashPassword(password);
  const dup = (await pool.query(
    'SELECT id, email, phone, registration_pending FROM users WHERE email=$1 OR ($2::text IS NOT NULL AND phone=$2)', [em, ph])).rows[0];
  if (dup) {
    let demoCode;
    if (dup.registration_pending && dup.email === em) {
      // Latest sign-up wins until the email is proven, so nobody can pre-register someone else's email
      // with a password they know and have it activated later.
      await pool.query('UPDATE users SET password_hash=$2, full_name=$3 WHERE id=$1 AND registration_pending', [dup.id, hash, fullName.trim()]);
      try { demoCode = (await sendOtp(dup, 'register', 'email')).demoCode; } catch { /* throttled or provider down */ }
    }
    return res.json({ ...REGISTER_REPLY, demoCode });
  }
  try {
    const user = await withTx(async (c) => {
      const u = (await c.query(
        `INSERT INTO users(email, password_hash, full_name, phone, country_code, terms_accepted_at, registration_pending)
         VALUES ($1,$2,$3,$4,'NG', now(), TRUE) RETURNING ${COLS}`,
        [em, hash, fullName.trim(), ph])).rows[0];
      await createAccount(c, { userId: u.id, type: 'customer_wallet', currency: 'NGN', name: 'Main wallet' });
      await c.query(`INSERT INTO consents(user_id, kind, version) VALUES ($1,'terms',$2),($1,'privacy',$2)`, [u.id, TERMS_VERSION]);
      await c.query(`INSERT INTO audit_log(actor_type, actor_id, action, ip_address) VALUES ('user',$1,'auth.register',$2)`, [u.id, req.ip]);
      return u;
    });
    let demoCode;
    try { demoCode = (await sendOtp(user, 'register', 'email')).demoCode; } catch { /* they can ask for a new code */ }
    return res.json({ ...REGISTER_REPLY, demoCode });
  } catch (err) {
    if (err.code === '23505') return res.json(REGISTER_REPLY);   // lost a race with another sign-up
    throw err;
  }
}));

router.post('/register/verify', wrap(async (req, res) => {
  const { email, code } = req.body || {};
  const bad = new AppError(401, 'BAD_CODE', 'That code is not right or has expired.');
  const u = (await pool.query(`SELECT ${COLS} FROM users WHERE email=$1 AND registration_pending`, [String(email || '').toLowerCase()])).rows[0];
  if (!u) throw bad;
  if (!(await verifyOtp(u.id, 'register', code))) { await registerFailure(u.id); throw bad; }
  await pool.query('UPDATE users SET registration_pending=FALSE, email_verified_at=now() WHERE id=$1', [u.id]);
  u.registration_pending = false;
  u.email_verified_at = new Date();
  await finishLogin(req, res, u, 'register');
}));

router.post('/register/resend', wrap(async (req, res) => {
  const u = (await pool.query(`SELECT id, email, phone FROM users WHERE email=$1 AND registration_pending`, [String(req.body?.email || '').toLowerCase()])).rows[0];
  let demoCode;
  if (u) { try { demoCode = (await sendOtp(u, 'register', 'email')).demoCode; } catch { /* throttled */ } }
  res.json({ ...REGISTER_REPLY, demoCode });
}));

// ---------- Sign-in ----------
router.post('/login', wrap(async (req, res) => {
  const { email, password } = req.body || {};
  const u = (await pool.query(`SELECT ${COLS} FROM users WHERE email=$1`, [String(email || '').toLowerCase()])).rows[0];
  if (u?.locked_until && new Date(u.locked_until) > new Date()) {
    await logEvent(req, u, email, false, 'password', 'locked');
    throw new AppError(423, 'LOCKED', 'Too many wrong attempts. Try again in 15 minutes.');
  }
  // Always run a full hash check so timing does not reveal whether an email exists.
  const ok = await verifyPassword(String(password || ''), u?.password_hash || (await dummyHash()));
  if (!u || !ok) {
    if (u) await registerFailure(u.id);
    await logEvent(req, u, email, false, 'password', 'bad_credentials');
    inc('gplan_login_failures_total');
    throw new AppError(401, 'BAD_CREDENTIALS', 'Email or password is incorrect.');
  }
  if (u.status === 'closed') throw new AppError(403, 'ACCOUNT_CLOSED', 'This account is closed.');
  if (u.registration_pending) {
    try { await sendOtp(u, 'register', 'email'); } catch { /* throttled */ }
    throw new AppError(403, 'EMAIL_NOT_VERIFIED', 'Please confirm your email first. We sent you a new code.');
  }
  if (needsRehash(u.password_hash)) {
    await pool.query('UPDATE users SET password_hash=$2 WHERE id=$1', [u.id, await hashPassword(password)]);
  }
  if (u.mfa_method) {
    const mfaToken = jwt.sign({ sub: u.id, purpose: 'mfa' }, config.jwtSecret, { expiresIn: '5m' });
    const ch = await sendChallenge(u, 'login');
    return res.json({ mfaRequired: true, method: u.mfa_method, mfaToken, demoCode: ch.demoCode });
  }
  await finishLogin(req, res, u, 'password');
}));

router.post('/login/mfa', wrap(async (req, res) => {
  const { mfaToken, code } = req.body || {};
  let p;
  try { p = jwt.verify(String(mfaToken || ''), config.jwtSecret, { algorithms: ['HS256'] }); } catch { throw new AppError(401, 'SESSION_EXPIRED', 'Start sign-in again.'); }
  if (p.purpose !== 'mfa') throw new AppError(401, 'SESSION_EXPIRED', 'Start sign-in again.');
  const u = (await pool.query(`SELECT ${COLS} FROM users WHERE id=$1`, [p.sub])).rows[0];
  if (!u || u.status === 'closed') throw new AppError(401, 'SESSION_EXPIRED', 'Start sign-in again.');
  if (u.locked_until && new Date(u.locked_until) > new Date()) throw new AppError(423, 'LOCKED', 'Too many wrong attempts. Try again later.');
  // A recovery code can stand in for the phone or authenticator when it is lost. Wrong tries count towards the lockout.
  const ok = looksLikeRecovery(code) ? await consumeCode(u.id, code, req.ip) : await checkSecondFactor(u, code, 'login');
  if (!ok) {
    await registerFailure(u.id);
    await logEvent(req, u, u.email, false, 'mfa', 'bad_code');
    throw new AppError(401, 'BAD_CODE', 'That code is not right. Try again.');
  }
  await finishLogin(req, res, u, 'password+mfa');
}));

router.post('/login/resend', wrap(async (req, res) => {
  let p;
  try { p = jwt.verify(String(req.body?.mfaToken || ''), config.jwtSecret, { algorithms: ['HS256'] }); } catch { throw new AppError(401, 'SESSION_EXPIRED', 'Start sign-in again.'); }
  const u = (await pool.query(`SELECT ${COLS} FROM users WHERE id=$1`, [p.sub])).rows[0];
  const ch = await sendChallenge(u, 'login');
  res.json({ sent: ch.sent, demoCode: ch.demoCode });
}));

// Passkey sign-in (fingerprint / face / device PIN).
router.post('/login/passkey/options', wrap(async (req, res) => {
  const u = (await pool.query(`SELECT ${COLS} FROM users WHERE email=$1`, [String(req.body?.email || '').toLowerCase()])).rows[0];
  if (!u) throw new AppError(404, 'NO_PASSKEY', 'No passkey is set up for this account.');
  res.json(await passkeys.authOptions(req, u));
}));
router.post('/login/passkey/verify', wrap(async (req, res) => {
  const u = (await pool.query(`SELECT ${COLS} FROM users WHERE email=$1`, [String(req.body?.email || '').toLowerCase()])).rows[0];
  if (!u || u.status === 'closed' || u.registration_pending) throw new AppError(401, 'PASSKEY_FAILED', 'Passkey check failed.');
  await passkeys.authVerify(req, u, req.body.response);
  await finishLogin(req, res, u, 'passkey');
}));

// ---------- Session refresh (cookie based, rotating, with stolen-token detection) ----------
router.post('/refresh', wrap(async (req, res) => {
  // A custom header cannot be sent by a plain cross-site form or image, so this blocks cross-site forgery.
  if (req.get('x-gplan-client') !== 'web') throw new AppError(403, 'CSRF_BLOCKED', 'Request blocked.');
  const c = readRefreshCookie(req);
  const fail = (code = 'NO_SESSION') => { clearRefreshCookie(res); return new AppError(401, code, 'Please sign in.'); };
  if (!c || !UUID.test(c.sid)) throw fail();
  const s = (await pool.query(
    `SELECT s.id, s.user_id, s.refresh_hash, s.prev_refresh_hash, s.refresh_expires_at, s.rotated_at, s.created_at, s.revoked_at, u.status
     FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id=$1`, [c.sid])).rows[0];
  if (!s || s.revoked_at || s.status === 'closed') throw fail();

  const h = sha256(c.secret);
  if (safeEqual(h, s.prev_refresh_hash)) {
    // The previous token was used again. Two tabs refreshing at once is normal (short grace period);
    // anything later means a copy of the old token exists somewhere else, so end the session.
    if (s.rotated_at && Date.now() - new Date(s.rotated_at).getTime() < 15_000) {
      const u = (await pool.query(`SELECT ${COLS} FROM users WHERE id=$1`, [s.user_id])).rows[0];
      return res.json({ token: signToken(s.user_id, s.id), user: publicUser(u) });
    }
    await pool.query('UPDATE sessions SET revoked_at=now() WHERE id=$1', [s.id]);
    await notify(pool, s.user_id, 'Session ended for your safety', 'An old sign-in token was reused, so we signed that device out. If this was not you, change your password.', 'security');
    await alert(`Refresh-token reuse detected for session ${s.id}`);
    throw fail('SESSION_ENDED');
  }
  const tooOld = Date.now() - new Date(s.created_at).getTime() > SESSION_MAX_DAYS * 86400 * 1000;
  if (!safeEqual(h, s.refresh_hash) || new Date(s.refresh_expires_at) < new Date() || tooOld) throw fail('SESSION_EXPIRED');

  const next = crypto.randomBytes(32).toString('base64url');
  const upd = await pool.query(
    `UPDATE sessions SET prev_refresh_hash=refresh_hash, refresh_hash=$2, rotated_at=now(), last_seen_at=now(),
       refresh_expires_at = now() + interval '${REFRESH_DAYS} days'
     WHERE id=$1 AND refresh_hash=$3 RETURNING id`, [s.id, sha256(next), h]);
  if (!upd.rows[0]) throw fail('SESSION_EXPIRED');   // lost a race; the other tab holds the new cookie
  setRefreshCookie(res, s.id, next);
  const u = (await pool.query(`SELECT ${COLS} FROM users WHERE id=$1`, [s.user_id])).rows[0];
  res.json({ token: signToken(s.user_id, s.id), user: publicUser(u) });
}));

// ---------- Forgot password ----------
router.post('/password/forgot', wrap(async (req, res) => {
  const email = String(req.body?.email || '').toLowerCase();
  const generic = { ok: true, message: 'If that email has a G-Plan account, we sent a 6-digit code to it.' };
  if (!isEmail(email)) return res.json(generic);
  const u = (await pool.query(`SELECT id, email, phone, status, registration_pending FROM users WHERE email=$1`, [email])).rows[0];
  if (!u || u.status === 'closed' || u.registration_pending) return res.json(generic);
  try {
    const r = await sendOtp(u, 'password-reset', 'email');
    return res.json({ ...generic, demoCode: r.demoCode });   // demoCode only exists in demo mode with mock email
  } catch (e) {
    if (e.code === 'OTP_THROTTLED') throw e;
    return res.json(generic);
  }
}));

router.post('/password/reset', wrap(async (req, res) => {
  const { email, code, newPassword, mfaCode } = req.body || {};
  const bad = new AppError(401, 'BAD_CODE', 'That code is not right or has expired.');
  const u = (await pool.query(`SELECT ${COLS} FROM users WHERE email=$1`, [String(email || '').toLowerCase()])).rows[0];
  if (!u || u.status === 'closed' || u.registration_pending) throw bad;
  const problem = passwordProblem(newPassword);
  if (problem) throw new AppError(422, 'WEAK_PASSWORD', problem);
  if (!(await verifyOtp(u.id, 'password-reset', code))) { await registerFailure(u.id); throw bad; }
  // An authenticator app is a second lock: an email code alone is not enough for those accounts.
  if (u.mfa_method === 'totp') {
    const second = looksLikeRecovery(mfaCode) ? await consumeCode(u.id, mfaCode, req.ip) : verifyTotp(decrypt(u.totp_secret), mfaCode);
    if (!second) throw new AppError(401, 'MFA_REQUIRED', 'Also enter the 6-digit code from your authenticator app, or one of your recovery codes.');
  }
  const hash = await hashPassword(newPassword);
  await withTx(async (c) => {
    await c.query('UPDATE users SET password_hash=$2, failed_logins=0, locked_until=NULL WHERE id=$1', [u.id, hash]);
    await c.query('UPDATE sessions SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL', [u.id]);
    await c.query(`INSERT INTO audit_log(actor_type, actor_id, action, ip_address) VALUES ('user',$1,'auth.password_reset',$2)`, [u.id, req.ip]);
    await notify(c, u.id, 'Password changed', 'Your password was reset and every device was signed out. If this was not you, contact support now.', 'security');
  });
  res.json({ ok: true });
}));

router.post('/logout', requireAuth, wrap(async (req, res) => {
  await pool.query('UPDATE sessions SET revoked_at=now() WHERE id=$1', [req.session.id]);
  clearRefreshCookie(res);
  res.json({ ok: true });
}));

router.get('/me', requireAuth, wrap(async (req, res) => {
  const r = await pool.query(`SELECT ${COLS} FROM users WHERE id=$1`, [req.user.id]);
  res.json({ user: publicUser(r.rows[0]) });
}));

export default router;
