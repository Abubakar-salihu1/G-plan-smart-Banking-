import { Router } from 'express';
import { wrap, AppError } from '../errors.js';
import { requireAuth } from '../middleware/auth.js';
import { requireStaff, can } from '../middleware/rbac.js';
import { config } from '../config.js';
import * as docs from '../services/kycDocs.js';

const router = Router();

// ---- The customer's side ----
router.get('/kyc/documents/config', requireAuth, (_req, res) => res.json({
  enabled: config.kycDocs, maxBytes: config.kycDocMaxBytes,
  required: { 2: docs.requiredKinds(2), 3: docs.requiredKinds(3) }, retentionDays: config.kycDocRetentionDays,
}));

router.get('/kyc/documents', requireAuth, wrap(async (req, res) => {
  docs.assertEnabled();
  res.json({ documents: await docs.listOwn(req.user.id) });
}));

// Body is the raw image (Content-Type image/jpeg or image/png), parsed in app.js. Nothing is ever returned to the browser.
router.post('/kyc/documents/:kind', requireAuth, wrap(async (req, res) => {
  docs.assertEnabled();
  if (!Buffer.isBuffer(req.body)) throw new AppError(415, 'UNSUPPORTED', 'Send a JPEG or PNG photo.');
  const d = await docs.storeDocument(req.user.id, req.params.kind, req.body, req.get('content-type'));
  res.status(201).json({ document: { id: d.id, kind: d.kind } });
}));

router.delete('/kyc/documents/:id', requireAuth, wrap(async (req, res) => {
  docs.assertEnabled();
  await docs.deleteOwn(req.user.id, req.params.id);
  res.json({ ok: true });
}));

// ---- Reviewer side: needs the kyc.review permission ----
const reviewer = [requireAuth, requireStaff, (req, _res, next) => (can(req.user.role, 'kyc.review') ? next() : next(new AppError(403, 'FORBIDDEN', 'Only KYC reviewers can open ID photos.')))];

router.get('/admin/kyc/:submissionId/documents', reviewer, wrap(async (req, res) => {
  docs.assertEnabled();
  res.json({ documents: await docs.listForReview(req.params.submissionId) });
}));

router.get('/admin/kyc-documents/:id', reviewer, wrap(async (req, res) => {
  docs.assertEnabled();
  const { mime, bytes } = await docs.readForReview(req.params.id, req.user.id, req.ip);
  res.set({ 'Content-Type': mime, 'Cache-Control': 'no-store, private', 'Content-Disposition': 'inline', 'X-Content-Type-Options': 'nosniff' });
  res.send(bytes);
}));

export default router;
