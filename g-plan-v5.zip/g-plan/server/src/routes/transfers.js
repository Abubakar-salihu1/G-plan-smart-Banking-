import { Router } from 'express';
import { pool } from '../db.js';
import { config } from '../config.js';
import { AppError, wrap } from '../errors.js';
import { requireAuth } from '../middleware/auth.js';
import { walletOf } from '../services/ledger.js';
import { transfer, hashRequest, assertAmount, fundWalletDemo } from '../services/transfers.js';
import { payExternal } from '../services/payments.js';
import { mockBank, mockInternational } from '../services/providers.js';
import { bankProvider, resolveName, isLive } from '../services/bankProvider.js';
import { BANKS, categorise } from '../services/catalog.js';
import { authorisePayment, previewRisk } from '../services/guard.js';
import { recordRisk, assertNotSanctioned, monitorAml, openAmlCase, screenName } from '../services/risk.js';
import { sendChallenge, getUserRow } from '../services/mfa.js';
import { feeOf } from '../services/fx.js';
import { loadSampleData } from '../services/sample.js';
import { runDueJobs } from '../services/jobs.js';
import { normalisePhone, maskName, isEmail } from '../utils/format.js';

const router = Router();
router.use(requireAuth);

async function findRecipient(identifier, senderId) {
  const id = String(identifier || '').trim();
  let r;
  if (id.includes('@')) {
    r = await pool.query(`SELECT u.id, u.full_name, u.email, u.phone FROM users u WHERE u.email=$1 AND u.status='active'`, [id.toLowerCase()]);
  } else {
    const ph = normalisePhone(id);
    if (!ph) throw new AppError(422, 'INVALID_RECIPIENT', 'Enter a G-Plan email or a Nigerian phone number.');
    r = await pool.query(`SELECT u.id, u.full_name, u.email, u.phone FROM users u WHERE u.phone=$1 AND u.status='active'`, [ph]);
  }
  const rec = r.rows[0];
  if (!rec) throw new AppError(404, 'RECIPIENT_NOT_FOUND', 'No G-Plan account found for that email or phone.');
  if (rec.id === senderId) throw new AppError(422, 'SELF_TRANSFER', 'You cannot send money to yourself.');
  rec.wallet_id = await walletOf(pool, rec.id, 'NGN');
  return rec;
}

async function nameEnquiry(bankCode, accountNumber) {
  if (!BANKS.some((b) => b.code === bankCode)) throw new AppError(422, 'INVALID_BANK', 'Choose a bank.');
  if (!/^\d{10}$/.test(String(accountNumber || ''))) throw new AppError(422, 'INVALID_ACCOUNT', 'Account numbers have 10 digits.');
  return resolveName(bankCode, accountNumber);
}

async function maybeSaveRecipient(userId, kind, fields) {
  const dup = await pool.query(
    `SELECT 1 FROM beneficiaries WHERE user_id=$1 AND kind=$2 AND COALESCE(email,'')=$3 AND COALESCE(account_number,'')=$4 AND COALESCE(bank_code,'')=$5`,
    [userId, kind, fields.email || '', fields.account_number || '', fields.bank_code || '']);
  if (dup.rowCount) return;
  await pool.query(
    `INSERT INTO beneficiaries(user_id, kind, name, email, phone, bank_code, bank_name, account_number, country, currency)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
    [userId, kind, fields.name, fields.email || null, fields.phone || null, fields.bank_code || null,
      fields.bank_name || null, fields.account_number || null, fields.country || null, fields.currency || null]);
}

const afterPayment = (userId, risk, receipt) => {
  if (receipt && !receipt.replayed && ['completed', 'under_review'].includes(receipt.state)) {
    recordRisk(userId, risk, receipt.transactionId).catch(() => {});
    if (receipt.state === 'completed') monitorAml(userId, receipt).catch(() => {});
  }
};

// ---- Step-up challenge for SMS/email verification users ----
router.post('/security/challenge', wrap(async (req, res) => {
  const u = await getUserRow(req.user.id);
  if (!u.mfa_method) throw new AppError(422, 'NO_MFA', 'Two-step verification is not turned on.');
  const ch = await sendChallenge(u, 'stepup');
  res.json({ sent: ch.sent, method: u.mfa_method, demoCode: ch.demoCode });
}));

// ---- Internal (G-Plan to G-Plan) ----
router.post('/transfers/review', wrap(async (req, res) => {
  const { recipient, amountMinor } = req.body || {};
  assertAmount(amountMinor);
  const rec = await findRecipient(recipient, req.user.id);
  res.json({ recipientName: maskName(rec.full_name), amountMinor, feeMinor: 0, currency: 'NGN', isDemo: true,
    verification: await previewRisk(req, amountMinor, 'NGN') });
}));

router.post('/transfers', wrap(async (req, res) => {
  const { recipient, amountMinor, description, password, otp, saveRecipient } = req.body || {};
  assertAmount(amountMinor);
  const rec = await findRecipient(recipient, req.user.id);
  assertNotSanctioned(rec.full_name);
  const { risk, level } = await authorisePayment(req, { password, otp, amountMinor });
  const mine = await walletOf(pool, req.user.id, 'NGN');
  const note = typeof description === 'string' ? description.slice(0, 140) : null;
  const receipt = await transfer({
    userId: req.user.id, fromAccountId: mine, toAccountId: rec.wallet_id, amountMinor, type: 'internal_transfer',
    description: note, category: categorise({ description: note || '' }), riskLevel: level,
    meta: { payee: maskName(rec.full_name) }, idemKey: req.get('Idempotency-Key'),
    requestHash: hashRequest({ r: String(recipient).toLowerCase(), amountMinor, note }),
  });
  if (saveRecipient) await maybeSaveRecipient(req.user.id, 'internal', { name: rec.full_name, email: rec.email, phone: rec.phone });
  afterPayment(req.user.id, risk, receipt);
  res.status(receipt.replayed ? 200 : 201).json({ receipt, recipientName: maskName(rec.full_name) });
}));

// ---- External bank transfer (mock bank unless a real provider is configured) ----
router.get('/banks', (_req, res) => res.json({ banks: BANKS }));

router.post('/transfers/name-enquiry', wrap(async (req, res) => {
  const { bankCode, accountNumber } = req.body || {};
  const name = await nameEnquiry(bankCode, accountNumber);
  res.json({ accountName: name, demo: !isLive() });
}));

router.post('/transfers/external/review', wrap(async (req, res) => {
  const { amountMinor } = req.body || {};
  assertAmount(amountMinor);
  res.json({ feeMinor: config.fees.externalTransferMinor, currency: 'NGN', isDemo: !isLive(),
    verification: await previewRisk(req, amountMinor, 'NGN') });
}));

router.post('/transfers/external', wrap(async (req, res) => {
  const { bankCode, accountNumber, amountMinor, description, password, otp, saveRecipient } = req.body || {};
  assertAmount(amountMinor);
  const accountName = await nameEnquiry(bankCode, accountNumber);   // never trust a name sent by the client
  assertNotSanctioned(accountName);
  const bank = BANKS.find((b) => b.code === bankCode);
  const { risk, level } = await authorisePayment(req, { password, otp, amountMinor });
  const note = typeof description === 'string' ? description.slice(0, 140) : null;
  const wallet = await walletOf(pool, req.user.id, 'NGN');
  const receipt = await payExternal({
    userId: req.user.id, walletId: wallet, amountMinor, feeMinor: config.fees.externalTransferMinor, type: 'external_transfer',
    description: `Transfer to ${accountName}${note ? ' · ' + note : ''}`, category: categorise({ description: note || '' }),
    riskLevel: level, meta: { bankCode, bankName: bank.name, accountNumber, accountName, payee: accountName },
    idemKey: req.get('Idempotency-Key'), requestHash: hashRequest({ bankCode, accountNumber, amountMinor, note }),
    provider: bankProvider(),
  });
  if (saveRecipient) await maybeSaveRecipient(req.user.id, 'external', { name: accountName, bank_code: bankCode, bank_name: bank.name, account_number: accountNumber });
  afterPayment(req.user.id, risk, receipt);
  res.status(receipt.replayed ? 200 : 201).json({ receipt, accountName });
}));

// ---- International (demo) ----
router.post('/transfers/international', wrap(async (req, res) => {
  const { currency, amountMinor, beneficiaryName, country, accountNumber, description, password, otp } = req.body || {};
  assertAmount(amountMinor);
  if (!['USD', 'GBP', 'EUR'].includes(currency)) throw new AppError(422, 'UNSUPPORTED_CURRENCY', 'Choose USD, GBP or EUR.');
  if (typeof beneficiaryName !== 'string' || beneficiaryName.trim().length < 2) throw new AppError(422, 'INVALID_NAME', 'Enter the recipient name.');
  if (typeof accountNumber !== 'string' || accountNumber.length < 6 || accountNumber.length > 34) throw new AppError(422, 'INVALID_ACCOUNT', 'Enter a valid account number or IBAN.');
  assertNotSanctioned(beneficiaryName);
  const wallet = await walletOf(pool, req.user.id, currency);
  if (!wallet) throw new AppError(422, 'WALLET_MISSING', `Create a ${currency} wallet first in Global.`);
  const feeMinor = feeOf(amountMinor, config.fees.internationalPercent);
  const { risk, level } = await authorisePayment(req, { password, otp, amountMinor, currency });
  const receipt = await payExternal({
    userId: req.user.id, walletId: wallet, amountMinor, feeMinor, currency, type: 'international_transfer',
    description: `International transfer to ${beneficiaryName.trim()}`, category: 'transfers', riskLevel: level,
    meta: { country: String(country || '').slice(0, 40), accountNumber, payee: beneficiaryName.trim(), accountLast4: accountNumber.slice(-4), estimate: true },
    idemKey: req.get('Idempotency-Key'), requestHash: hashRequest({ currency, amountMinor, accountNumber }), provider: mockInternational,
  });
  afterPayment(req.user.id, risk, receipt);
  res.status(receipt.replayed ? 200 : 201).json({ receipt });
}));

// ---- Saved recipients ----
router.get('/recipients', wrap(async (req, res) => {
  const r = await pool.query(
    `SELECT id, kind, name, email, phone, bank_name, bank_code, account_number, country, currency
     FROM beneficiaries WHERE user_id=$1 ORDER BY created_at DESC`, [req.user.id]);
  res.json({ recipients: r.rows.map((b) => ({ ...b, account_number: b.account_number ? '••••' + b.account_number.slice(-4) : null, _full: undefined })) });
}));

router.get('/recipients/:id/use', wrap(async (req, res) => {
  const b = (await pool.query('SELECT * FROM beneficiaries WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id])).rows[0];
  if (!b) throw new AppError(404, 'NOT_FOUND', 'Recipient not found.');
  res.json({ kind: b.kind, email: b.email, phone: b.phone, bankCode: b.bank_code, accountNumber: b.account_number, name: b.name });
}));

router.delete('/recipients/:id', wrap(async (req, res) => {
  await pool.query('DELETE FROM beneficiaries WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id]);
  res.json({ ok: true });
}));

// ---- Demo helpers (only when ENABLE_DEMO_FUNDING=true) ----
const demoOnly = (_req, _res, next) => (config.demoFunding ? next() : next(new AppError(404, 'NOT_FOUND', 'Not found.')));

router.post('/demo/fund', demoOnly, wrap(async (req, res) => {
  const { amountMinor } = req.body || {};
  assertAmount(amountMinor);
  if (amountMinor > 50_000_000) throw new AppError(422, 'DEMO_LIMIT', 'Demo funding is limited to ₦500,000 per request.');
  const mine = await walletOf(pool, req.user.id, 'NGN');
  const receipt = await fundWalletDemo({ userId: req.user.id, walletId: mine, amountMinor, idemKey: req.get('Idempotency-Key') });
  res.status(201).json({ receipt });
}));

router.post('/demo/sample-data', demoOnly, wrap(async (req, res) => {
  await loadSampleData(req.user.id);
  res.status(201).json({ ok: true });
}));

router.post('/demo/run-jobs', demoOnly, wrap(async (_req, res) => {
  res.json({ result: await runDueJobs() });
}));

export default router;
