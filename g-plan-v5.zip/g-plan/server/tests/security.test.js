// HTTP-level security checks against the real app. Use a throwaway database.
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

// Many sign-ups in a few seconds would trip the real rate limits, so loosen them for this test run only.
process.env.RATE_LIMIT_MULTIPLIER = process.env.RATE_LIMIT_MULTIPLIER || '50';
const { app } = await import('../src/app.js');
const { pool } = await import('../src/db.js');

let server, base;
before(async () => { await new Promise((r) => { server = app.listen(0, r); }); base = `http://127.0.0.1:${server.address().port}`; });
after(async () => { server.close(); await pool.end(); });

const call = (path, { method = 'GET', body, token, headers = {} } = {}) => fetch(base + path, {
  method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...headers },
  body: body ? JSON.stringify(body) : undefined });
const cookieOf = (res) => { const raw = res.headers.get('set-cookie'); return raw ? raw.split(';')[0] : null; };
let n = 0;
async function signup(label) {
  const email = `${label}-${Date.now()}-${n++}@test.local`;
  const r = await call('/api/auth/register', { method: 'POST', body: { email, password: 'Str0ngPass1', fullName: `Test ${label}`, acceptTerms: true } });
  // Skip the email step in tests that are about something else.
  await pool.query('UPDATE users SET registration_pending=false, email_verified_at=now() WHERE email=$1', [email]);
  const l = await call('/api/auth/login', { method: 'POST', body: { email, password: 'Str0ngPass1' } });
  const d = await l.json();
  return { email, token: d.token, id: d.user?.id, status: r.status, cookie: cookieOf(l) };
}

test('protected routes need a login', async () => {
  assert.equal((await call('/api/accounts')).status, 401);
  assert.equal((await call('/api/transactions')).status, 401);
  assert.equal((await call('/api/cards')).status, 401);
});

test('weak passwords and missing consent are rejected', async () => {
  const weak = await call('/api/auth/register', { method: 'POST', body: { email: `w${Date.now()}@test.local`, password: 'short', fullName: 'Weak Pw', acceptTerms: true } });
  assert.equal(weak.status, 422);
  const noTerms = await call('/api/auth/register', { method: 'POST', body: { email: `t${Date.now()}@test.local`, password: 'Str0ngPass1', fullName: 'No Terms' } });
  assert.equal(noTerms.status, 422);
});

test('responses never contain password hashes', async () => {
  const u = await signup('leak');
  const me = await (await call('/api/auth/me', { token: u.token })).text();
  assert.ok(!/password/i.test(me));
});

test('five wrong passwords lock the account', async () => {
  const u = await signup('lock');
  let last;
  for (let i = 0; i < 6; i++) last = await call('/api/auth/login', { method: 'POST', body: { email: u.email, password: 'WrongPass9' } });
  assert.equal(last.status, 423);
  const right = await call('/api/auth/login', { method: 'POST', body: { email: u.email, password: 'Str0ngPass1' } });
  assert.equal(right.status, 423);
});

test('a token signed with the wrong secret is rejected', async () => {
  const u = await signup('forge');
  const forged = jwt.sign({ sub: u.id, sid: '00000000-0000-0000-0000-000000000000' }, 'not-the-secret');
  assert.equal((await call('/api/accounts', { token: forged })).status, 401);
});

test('a signed-out session cannot be reused', async () => {
  const u = await signup('logout');
  assert.equal((await call('/api/accounts', { token: u.token })).status, 200);
  await call('/api/auth/logout', { method: 'POST', token: u.token });
  assert.equal((await call('/api/accounts', { token: u.token })).status, 401);
});

test('customers cannot open the admin console', async () => {
  const u = await signup('notstaff');
  assert.equal((await call('/api/admin/me', { token: u.token })).status, 403);
  assert.equal((await call('/api/admin/section/audit', { token: u.token })).status, 403);
});

test('one customer cannot read another customer\'s transaction', async () => {
  const a = await signup('owner'), b = await signup('snoop');
  const fund = await call('/api/demo/fund', { method: 'POST', token: a.token, body: { amountMinor: 100000 } });
  if (fund.status !== 201) return;   // demo funding is off: nothing to read
  const ref = (await fund.json()).receipt.reference;
  assert.equal((await call(`/api/transactions/${ref}`, { token: a.token })).status, 200);
  assert.equal((await call(`/api/transactions/${ref}`, { token: b.token })).status, 404);
});

test('search input is treated as data, not SQL', async () => {
  const u = await signup('sqli');
  const r = await call(`/api/transactions?q=${encodeURIComponent("' OR 1=1; DROP TABLE users; --")}`, { token: u.token });
  assert.equal(r.status, 200);
  assert.equal((await pool.query('SELECT 1 FROM users LIMIT 1')).rowCount, 1);
});

test('security headers are set', async () => {
  const r = await call('/api/health');
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  assert.ok(r.headers.get('content-security-policy'));
  assert.equal(r.headers.get('x-powered-by'), null);
});

test('paying a payment request twice only pays once', async () => {
  const a = await signup('req-a'), b = await signup('req-b');
  const f = await call('/api/demo/fund', { method: 'POST', token: b.token, body: { amountMinor: 500000 } });
  if (f.status !== 201) return;
  const made = await (await call('/api/requests', { method: 'POST', token: a.token, body: { amountMinor: 100000, payerEmail: b.email } })).json();
  const token = made.link;
  const pay = () => call('/api/requests/pay', { method: 'POST', token: b.token, body: { token, password: 'Str0ngPass1' } });
  const rs = await Promise.all([pay(), pay()]);
  assert.equal(rs.filter((r) => r.status === 201).length, 1);   // the other call is a harmless replay (200)
  const bal = await (await call('/api/accounts', { token: b.token })).json();
  assert.equal(bal.wallet.availableMinor, 400000);               // 500000 - 100000, charged once
});

test('forgot-password gives the same reply for unknown emails (no account probing)', async () => {
  const known = await signup('reset-known');
  const a = await (await call('/api/auth/password/forgot', { method: 'POST', body: { email: known.email } })).json();
  const b = await (await call('/api/auth/password/forgot', { method: 'POST', body: { email: 'nobody-' + Date.now() + '@test.local' } })).json();
  assert.equal(a.message, b.message);
});

test('password reset: code needed, old password stops working, old sessions end', async () => {
  const u = await signup('reset-flow');
  const f = await (await call('/api/auth/password/forgot', { method: 'POST', body: { email: u.email } })).json();
  if (!f.demoCode) return;   // real or hidden delivery: the code is not visible here
  const wrong = await call('/api/auth/password/reset', { method: 'POST', body: { email: u.email, code: '000000', newPassword: 'N3wStrongPass' } });
  assert.equal(wrong.status, 401);
  const ok = await call('/api/auth/password/reset', { method: 'POST', body: { email: u.email, code: f.demoCode, newPassword: 'N3wStrongPass' } });
  assert.equal(ok.status, 200);
  assert.equal((await call('/api/accounts', { token: u.token })).status, 401);                  // old session revoked
  assert.equal((await call('/api/auth/login', { method: 'POST', body: { email: u.email, password: 'Str0ngPass1' } })).status, 401);
  assert.equal((await call('/api/auth/login', { method: 'POST', body: { email: u.email, password: 'N3wStrongPass' } })).status, 200);
});

test('a reset code cannot be reused', async () => {
  const u = await signup('reset-once');
  const f = await (await call('/api/auth/password/forgot', { method: 'POST', body: { email: u.email } })).json();
  if (!f.demoCode) return;
  await call('/api/auth/password/reset', { method: 'POST', body: { email: u.email, code: f.demoCode, newPassword: 'N3wStrongPass' } });
  const again = await call('/api/auth/password/reset', { method: 'POST', body: { email: u.email, code: f.demoCode, newPassword: 'An0therStrong1' } });
  assert.equal(again.status, 401);
});

test('an MFA-step token cannot be used as an access token', async () => {
  const u = await signup('mfa-token');
  const t = jwt.sign({ sub: u.id, purpose: 'mfa' }, process.env.JWT_SECRET || 'dev-only-secret-change-me', { expiresIn: '5m' });
  assert.equal((await call('/api/accounts', { token: t })).status, 401);
});

// ---------- sign-up ----------
test('sign-up never reveals whether an email is already in use', async () => {
  const email = `dup-${Date.now()}@test.local`;
  const body = { email, password: 'Str0ngPass1', fullName: 'Dup Test', acceptTerms: true };
  const r1 = await call('/api/auth/register', { method: 'POST', body });
  const r2 = await call('/api/auth/register', { method: 'POST', body });
  await pool.query('UPDATE users SET registration_pending=false WHERE email=$1', [email]);   // now a real, active account
  const r3 = await call('/api/auth/register', { method: 'POST', body });
  assert.deepEqual([r1.status, r2.status, r3.status], [200, 200, 200]);
  const [a, b, c] = await Promise.all([r1.json(), r2.json(), r3.json()]);
  assert.equal(a.message, b.message);
  assert.equal(b.message, c.message);
  assert.equal(c.token, undefined);          // sign-up never hands out a session
});

test('sign-in is blocked until the email is confirmed', async () => {
  const email = `unverified-${Date.now()}@test.local`;
  await call('/api/auth/register', { method: 'POST', body: { email, password: 'Str0ngPass1', fullName: 'Not Yet', acceptTerms: true } });
  const l = await call('/api/auth/login', { method: 'POST', body: { email, password: 'Str0ngPass1' } });
  assert.equal(l.status, 403);
  assert.equal((await l.json()).error.code, 'EMAIL_NOT_VERIFIED');
});

test('sign-up finishes with the emailed code, and a wrong code fails', async () => {
  const email = `finish-${Date.now()}@test.local`;
  const reg = await (await call('/api/auth/register', { method: 'POST', body: { email, password: 'Str0ngPass1', fullName: 'Finish Up', acceptTerms: true } })).json();
  if (!reg.demoCode) return;                 // real delivery: the code is not visible here
  assert.equal((await call('/api/auth/register/verify', { method: 'POST', body: { email, code: '000000' } })).status, 401);
  const ok = await call('/api/auth/register/verify', { method: 'POST', body: { email, code: reg.demoCode } });
  assert.equal(ok.status, 200);
  assert.ok((await ok.json()).token);
});

test('pre-registering someone else\'s email with your own password does not work', async () => {
  const email = `victim-${Date.now()}@test.local`;
  await call('/api/auth/register', { method: 'POST', body: { email, password: 'Attack3rPass1', fullName: 'Attacker', acceptTerms: true } });
  await call('/api/auth/register', { method: 'POST', body: { email, password: 'Victim0wnPass1', fullName: 'Real Owner', acceptTerms: true } });
  await pool.query('UPDATE users SET registration_pending=false WHERE email=$1', [email]);   // the real owner proved the email
  assert.equal((await call('/api/auth/login', { method: 'POST', body: { email, password: 'Attack3rPass1' } })).status, 401);
  assert.equal((await call('/api/auth/login', { method: 'POST', body: { email, password: 'Victim0wnPass1' } })).status, 200);
});

// ---------- password storage ----------
test('new passwords are stored with scrypt, and old bcrypt hashes upgrade on sign-in', async () => {
  const u = await signup('hashcheck');
  assert.match((await pool.query('SELECT password_hash FROM users WHERE id=$1', [u.id])).rows[0].password_hash, /^scrypt\$/);
  const email = `legacy-${Date.now()}@test.local`;
  const legacy = await bcrypt.hash('Str0ngPass1', 10);
  await pool.query(`INSERT INTO users(email,password_hash,full_name,country_code) VALUES ($1,$2,'Legacy','NG')`, [email, legacy]);
  assert.equal((await call('/api/auth/login', { method: 'POST', body: { email, password: 'Str0ngPass1' } })).status, 200);
  assert.match((await pool.query('SELECT password_hash FROM users WHERE email=$1', [email])).rows[0].password_hash, /^scrypt\$/);
});

// ---------- sessions and refresh ----------
test('the refresh cookie is httpOnly and strict, and refresh needs the custom header', async () => {
  const u = await signup('cookieflags');
  const login = await call('/api/auth/login', { method: 'POST', body: { email: u.email, password: 'Str0ngPass1' } });
  const raw = login.headers.get('set-cookie');
  assert.match(raw, /HttpOnly/i);
  assert.match(raw, /SameSite=Strict/i);
  assert.match(raw, /Path=\/api\/auth/i);
  assert.equal((await call('/api/auth/refresh', { method: 'POST', headers: { Cookie: cookieOf(login) } })).status, 403);   // no X-GPlan-Client
  assert.equal((await call('/api/auth/refresh', { method: 'POST', headers: { 'X-GPlan-Client': 'web' } })).status, 401);   // no cookie
});

test('refresh rotates the cookie, tolerates a double tap, and kills the session when an old token is replayed later', async () => {
  const u = await signup('rotate');
  const web = { 'X-GPlan-Client': 'web' };
  const first = await call('/api/auth/refresh', { method: 'POST', headers: { ...web, Cookie: u.cookie } });
  assert.equal(first.status, 200);
  const second = cookieOf(first);
  assert.ok(second && second !== u.cookie);
  const accessToken = (await first.json()).token;
  assert.equal((await call('/api/accounts', { token: accessToken })).status, 200);
  // Same old cookie again within seconds (two tabs): allowed, no new cookie.
  assert.equal((await call('/api/auth/refresh', { method: 'POST', headers: { ...web, Cookie: u.cookie } })).status, 200);
  // Replayed after the grace window: treated as theft.
  await pool.query(`UPDATE sessions SET rotated_at = now() - interval '5 minutes' WHERE user_id=$1`, [u.id]);
  assert.equal((await call('/api/auth/refresh', { method: 'POST', headers: { ...web, Cookie: u.cookie } })).status, 401);
  assert.equal((await call('/api/accounts', { token: accessToken })).status, 401);                 // session revoked
  assert.equal((await call('/api/auth/refresh', { method: 'POST', headers: { ...web, Cookie: second } })).status, 401);
});

// ---------- business mode ----------
test('business invoices: identity check first, server computes the total, only the owner can cancel', async () => {
  const a = await signup('biz-owner'), b = await signup('biz-other');
  assert.equal((await call('/api/business', { method: 'POST', token: a.token, body: { name: 'Ada Stores' } })).status, 403);
  await pool.query('UPDATE users SET kyc_tier=1 WHERE id=$1', [a.id]);
  assert.equal((await call('/api/business', { method: 'POST', token: a.token, body: { name: 'Ada Stores' } })).status, 201);
  const inv = await call('/api/business/invoices', { method: 'POST', token: a.token, body: {
    customerName: 'Chidi', totalMinor: 1, items: [{ description: 'Chair', qty: 2, unitMinor: 150000 }, { description: 'Table', qty: 1, unitMinor: 500000 }] } });
  assert.equal(inv.status, 201);
  const made = (await inv.json()).invoice;
  assert.equal(made.totalMinor, 800000);                     // 2 x 150000 + 500000, not the 1 the client sent
  assert.match(made.number, /^INV-\d{4}-0001$/);
  assert.equal((await call(`/api/business/invoices/${made.id}/cancel`, { method: 'POST', token: b.token })).status, 404);
  assert.equal((await call(`/api/business/invoices/${made.id}/cancel`, { method: 'POST', token: a.token })).status, 200);
  const bad = await call('/api/business/invoices', { method: 'POST', token: a.token, body: { customerName: 'X Y', items: [{ description: 'Bad', qty: -1, unitMinor: 100 }] } });
  assert.equal(bad.status, 422);
});

test('a customer can pay an invoice once, and the business report counts it', async () => {
  const a = await signup('inv-owner'), b = await signup('inv-payer');
  await pool.query('UPDATE users SET kyc_tier=1 WHERE id=$1', [a.id]);
  await call('/api/business', { method: 'POST', token: a.token, body: { name: 'Pay Me Ltd' } });
  const f = await call('/api/demo/fund', { method: 'POST', token: b.token, body: { amountMinor: 500000 } });
  if (f.status !== 201) return;                              // demo funding is off: nothing to pay with
  const made = (await (await call('/api/business/invoices', { method: 'POST', token: a.token, body: {
    customerName: 'Payer', items: [{ description: 'Service', qty: 1, unitMinor: 200000 }] } })).json()).invoice;
  const pay = () => call('/api/requests/pay', { method: 'POST', token: b.token, body: { token: made.token, password: 'Str0ngPass1' } });
  const rs = await Promise.all([pay(), pay()]);
  assert.equal(rs.filter((r) => r.status === 201).length, 1);
  const rep = (await (await call('/api/business/report', { token: a.token })).json()).report;
  assert.equal(rep.paidMinor, 200000);
  assert.equal(rep.paidCount, 1);
});
