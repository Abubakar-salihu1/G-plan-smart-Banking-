import test from 'node:test';
import assert from 'node:assert/strict';
import { parseAction, amountFrom } from '../src/services/assistantActions.js';

test('amounts in everyday wording', () => {
  assert.equal(amountFrom('₦5,000'), 500000);
  assert.equal(amountFrom('5k'), 500000);
  assert.equal(amountFrom('2.5 million'), 250000000);
  assert.equal(amountFrom('1250.50'), 125050);
  assert.equal(amountFrom('nothing here'), null);
  assert.equal(amountFrom('0'), null);
  assert.equal(amountFrom('99999999999999999'), null);
});

test('a send request becomes a draft, never an action', () => {
  assert.deepEqual(parseAction('Send ₦5,000 to Ada@Example.com for lunch'), { type: 'send', recipient: 'ada@example.com', amountMinor: 500000, note: 'lunch' });
  assert.deepEqual(parseAction('pay 2k to 08012345678'), { type: 'send', recipient: '08012345678', amountMinor: 200000, note: '' });
  assert.equal(parseAction('please transfer 10k to +2348012345678').amountMinor, 1000000);
});

test('unclear or non-payment questions create no draft', () => {
  assert.equal(parseAction('How much did I spend this month?'), null);
  assert.equal(parseAction('send 5000'), null);                       // no recipient
  assert.equal(parseAction('send money to ada@example.com'), null);   // no amount
  assert.equal(parseAction('can I afford to send 5000 to ada@example.com'), null);   // a question, not an instruction
  assert.equal(parseAction(undefined), null);
});
