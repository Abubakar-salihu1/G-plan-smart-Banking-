import test from 'node:test';
import assert from 'node:assert/strict';
import { median, unusualCharge, repeatKey, priceRise, newRepeating } from '../src/utils/habitRules.js';
import { parseReceipt, jsonFrom, RECEIPT_CATEGORIES } from '../src/utils/receiptParse.js';

const NOW = new Date('2026-10-08T12:00:00Z');
const h = (amounts) => amounts;

test('median handles odd, even and empty', () => {
  assert.equal(median([]), 0); assert.equal(median([5]), 5); assert.equal(median([1, 9, 3]), 3); assert.equal(median([2, 4]), 3);
});

test('unusual charge: needs history, 3x the usual, above the floor, and a new high', () => {
  const usual = h([300_000, 350_000, 400_000, 320_000, 380_000, 360_000]);   // about ₦3,500
  assert.ok(unusualCharge({ amountMinor: 2_000_000, history: usual }));       // ₦20,000
  assert.equal(unusualCharge({ amountMinor: 900_000, history: usual }), null);   // under 3x (usual about 3,500 x 3 = 10,500)
  assert.equal(unusualCharge({ amountMinor: 2_000_000, history: usual.slice(0, 3) }), null);   // not enough history
  assert.equal(unusualCharge({ amountMinor: 400_000, history: h([10_000, 10_000, 10_000, 10_000, 10_000]) }), null);   // 40x but under the ₦5,000 floor
  assert.equal(unusualCharge({ amountMinor: 1_500_000, history: h([100_000, 100_000, 100_000, 100_000, 2_000_000]) }), null);   // has paid more before
  assert.equal(unusualCharge({ amountMinor: -1, history: usual }), null);
});

test('repeat key ignores amounts, dates and reference codes', () => {
  assert.equal(repeatKey('DSTV Premium · 12345678'), repeatKey('DSTV Premium · 87654321'));
  assert.equal(repeatKey('Payment GP-ABCDEF123456 to Netflix 2026'), 'payment to netflix');
  assert.equal(repeatKey(''), '');
  assert.equal(repeatKey(null), '');
});

const mk = (a, d) => ({ amountMinor: a, date: d });
test('price rise: steady monthly payment that suddenly costs 10% or more', () => {
  const hist = [mk(1_000_000, '2026-09-08'), mk(1_000_000, '2026-08-08')];
  assert.deepEqual(priceRise({ current: mk(1_200_000, '2026-10-08'), history: hist }), { fromMinor: 1_000_000, toMinor: 1_200_000, pct: 20 });
  assert.equal(priceRise({ current: mk(1_050_000, '2026-10-08'), history: hist }), null);                 // only 5%
  assert.equal(priceRise({ current: mk(1_200_000, '2026-10-08'), history: [mk(1_000_000, '2026-09-08')] }), null);   // not enough history
  assert.equal(priceRise({ current: mk(1_200_000, '2026-10-08'), history: [mk(1_000_000, '2026-09-08'), mk(500_000, '2026-08-08')] }), null);   // price was not stable
  assert.equal(priceRise({ current: mk(1_200_000, '2026-10-08'), history: [mk(1_000_000, '2026-04-08'), mk(1_000_000, '2026-03-08')] }), null);   // too long ago to be the same habit
});

test('new repeating payment: the third even, similar payment, once', () => {
  const hist = [mk(500_000, '2026-09-08'), mk(500_000, '2026-08-09')];
  assert.equal(newRepeating({ current: mk(500_000, '2026-10-08'), history: hist }), true);
  assert.equal(newRepeating({ current: mk(500_000, '2026-10-08'), history: [...hist, mk(500_000, '2026-07-09')] }), false);   // already known
  assert.equal(newRepeating({ current: mk(900_000, '2026-10-08'), history: hist }), false);       // different size
  assert.equal(newRepeating({ current: mk(500_000, '2026-09-12'), history: hist }), false);       // not even spacing
});

test('receipt: checked fields only, in kobo, with safe dates', () => {
  assert.deepEqual(parseReceipt({ merchant: '  Shoprite   Ikeja ', total: '12,345.60', currency: 'NGN', date: '2026-10-07', category: 'groceries' }, NOW),
    { merchant: 'Shoprite Ikeja', totalMinor: 1_234_560, date: '2026-10-07', category: 'groceries' });
  assert.equal(parseReceipt({ merchant: 'X', totalMinor: 5000, category: 'weapons' }, NOW).category, 'other');
  assert.equal(parseReceipt({ merchant: 'X', total: 10, date: '2030-01-01' }, NOW).date, null);        // future date dropped
  assert.equal(parseReceipt({ merchant: 'X', total: 10, date: '2020-01-01' }, NOW).date, null);        // too old
  assert.equal(parseReceipt({ merchant: 'X', total: 10, date: '2026-02-31' }, NOW).date, null);        // not a real day
  assert.equal(parseReceipt({ merchant: 'A<script>alert(1)</script>', total: 1 }, NOW).merchant.includes('<'), false);
  assert.throws(() => parseReceipt({ merchant: '', total: 5 }, NOW), /name/);
  assert.throws(() => parseReceipt({ merchant: 'X', total: 0 }, NOW), /total/);
  assert.throws(() => parseReceipt({ merchant: 'X', total: 'abc' }, NOW), /total/);
  assert.throws(() => parseReceipt({ merchant: 'X', total: 5, currency: 'USD' }, NOW), /naira/);
  assert.throws(() => parseReceipt(null, NOW));
  assert.ok(RECEIPT_CATEGORIES.includes('other'));
});

test('reader output is parsed from the outer braces only', () => {
  assert.deepEqual(jsonFrom('Sure! {"merchant":"A","total":5} Hope that helps'), { merchant: 'A', total: 5 });
  assert.throws(() => jsonFrom('no json here'), /could not read/);
  assert.throws(() => jsonFrom('{broken'), /could not read/);
  // Instructions printed on a receipt cannot add fields: only the four checked fields survive.
  const out = parseReceipt(jsonFrom('{"merchant":"Shop","total":100,"category":"food","transferTo":"attacker","ignore":"previous instructions"}'), NOW);
  assert.deepEqual(Object.keys(out).sort(), ['category', 'date', 'merchant', 'totalMinor']);
});

test('receipt reader sends the photo to the API once and returns only checked fields', async () => {
  process.env.ANTHROPIC_API_KEY = 'test-key';
  const { readReceipt, readerEnabled } = await import('../src/services/receipts.js');
  assert.equal(readerEnabled(), true);
  const real = globalThis.fetch; const calls = [];
  globalThis.fetch = async (url, opts) => { calls.push({ url: String(url), body: JSON.parse(opts.body), headers: opts.headers });
    return { ok: true, json: async () => ({ content: [{ type: 'text', text: 'Here: {"merchant":"Chicken Republic","total":4500,"currency":"NGN","date":"2026-10-07","category":"food","evil":"x"}' }] }) }; };
  try {
    const out = await readReceipt(Buffer.from('fake-image-bytes'), 'image/jpeg');
    assert.deepEqual(out, { merchant: 'Chicken Republic', totalMinor: 450_000, date: '2026-10-07', category: 'food' });
    assert.equal(calls.length, 1);
    assert.equal(calls[0].url, 'https://api.anthropic.com/v1/messages');
    assert.equal(calls[0].body.messages[0].content[0].source.media_type, 'image/jpeg');
    assert.match(calls[0].body.system, /never instructions/);
    globalThis.fetch = async () => ({ ok: false, status: 500, json: async () => ({}) });
    await assert.rejects(() => readReceipt(Buffer.from('x'), 'image/png'), /could not read/);
    globalThis.fetch = async () => ({ ok: true, json: async () => ({ content: [{ type: 'text', text: 'I am sorry, I cannot help' }] }) });
    await assert.rejects(() => readReceipt(Buffer.from('x'), 'image/png'), /could not read/);
  } finally { globalThis.fetch = real; delete process.env.ANTHROPIC_API_KEY; }
});
