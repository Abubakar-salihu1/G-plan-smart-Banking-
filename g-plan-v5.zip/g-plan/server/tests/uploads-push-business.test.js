// Pure tests: no database needed.
import test from 'node:test';
import assert from 'node:assert/strict';
import { sniff, parseJpeg, parsePng, inspectImage } from '../src/utils/image.js';
import { endpointAllowed, validKey } from '../src/utils/pushEndpoint.js';
import { bizCan, BIZ_PERMS, payoutNeedsApproval, INVITABLE } from '../src/services/businessRules.js';
import { encryptBuffer, decryptBuffer } from '../src/utils/crypto.js';

// ---------- helpers that build tiny valid-looking images ----------
const seg = (marker, payload) => Buffer.concat([Buffer.from([0xff, marker]), Buffer.from([(payload.length + 2) >> 8, (payload.length + 2) & 255]), payload]);
function jpeg({ w = 640, h = 480, exif = true, comment = true } = {}) {
  const sof = Buffer.from([8, h >> 8, h & 255, w >> 8, w & 255, 1, 1, 0x11, 0]);
  return Buffer.concat([
    Buffer.from([0xff, 0xd8]),
    seg(0xe0, Buffer.from('JFIF\0\x01\x01\0\0\x01\0\x01\0\0')),
    exif ? seg(0xe1, Buffer.from('Exif\0\0GPS-LAT-6.5244-LON-3.3792-SERIAL-12345')) : Buffer.alloc(0),
    comment ? seg(0xfe, Buffer.from('secret comment')) : Buffer.alloc(0),
    seg(0xc0, sof),
    seg(0xda, Buffer.from([1, 1, 0, 0, 63, 0])),
    Buffer.from([1, 2, 3, 4, 5, 6, 7, 8]),           // scan data
    Buffer.from([0xff, 0xd9]),
  ]);
}
const chunk = (type, data) => { const b = Buffer.alloc(12 + data.length); b.writeUInt32BE(data.length, 0); b.write(type, 4, 'latin1'); data.copy(b, 8); return b; };
function png({ w = 640, h = 480, text = true } = {}) {
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr),
    text ? chunk('tEXt', Buffer.from('Author\0Ada Obi GPS 6.5,3.3')) : Buffer.alloc(0), chunk('eXIf', Buffer.from('exifdata')),
    chunk('IDAT', Buffer.from([1, 2, 3])), chunk('IEND', Buffer.alloc(0))]);
}

test('file type comes from the bytes, not the name or header', () => {
  assert.equal(sniff(jpeg()), 'image/jpeg');
  assert.equal(sniff(png()), 'image/png');
  assert.equal(sniff(Buffer.from('<svg onload=alert(1)></svg>')), null);
  assert.equal(sniff(Buffer.from('%PDF-1.7 hello world')), null);
  assert.equal(sniff(Buffer.alloc(3)), null);
});

test('JPEG: Exif, GPS and comments are removed; picture data and size survive', () => {
  const { width, height, clean } = parseJpeg(jpeg());
  assert.deepEqual([width, height], [640, 480]);
  const text = clean.toString('latin1');
  assert.ok(!text.includes('GPS-LAT'), 'Exif must be gone');
  assert.ok(!text.includes('secret comment'), 'comment must be gone');
  assert.ok(text.includes('JFIF'), 'JFIF header is kept');
  assert.ok(clean.subarray(-10, -2).equals(Buffer.from([1, 2, 3, 4, 5, 6, 7, 8])), 'scan data is untouched');
  assert.equal(clean.subarray(-2).toString('hex'), 'ffd9');
  assert.ok(clean.length < jpeg().length);
});

test('PNG: text and Exif chunks are removed, image chunks stay', () => {
  const { width, height, clean } = parsePng(png());
  assert.deepEqual([width, height], [640, 480]);
  const s = clean.toString('latin1');
  assert.ok(!s.includes('tEXt') && !s.includes('eXIf') && !s.includes('Ada Obi'));
  assert.ok(s.includes('IHDR') && s.includes('IDAT') && s.includes('IEND'));
});

test('damaged, tiny and oversized pictures are refused with a plain message', () => {
  assert.throws(() => inspectImage(Buffer.from('not an image at all, just text')), /JPEG or PNG/);
  assert.throws(() => inspectImage(jpeg().subarray(0, 40)), /damaged/);
  assert.throws(() => inspectImage(jpeg({ w: 100, h: 100 })), /too small/);
  assert.throws(() => inspectImage(jpeg({ w: 9000, h: 9000 })), /too large/);
  assert.throws(() => inspectImage(png().subarray(0, 30)), /damaged/);
  const ok = inspectImage(jpeg());
  assert.equal(ok.mime, 'image/jpeg');
});

test('stored photos are encrypted, tamper-evident and round-trip', () => {
  const photo = parseJpeg(jpeg()).clean;
  const { keyVersion, data } = encryptBuffer(photo);
  assert.ok(!data.includes(Buffer.from('JFIF')), 'ciphertext must not contain plaintext');
  assert.ok(decryptBuffer(data, keyVersion).equals(photo));
  const bad = Buffer.from(data); bad[bad.length - 1] ^= 1;
  assert.throws(() => decryptBuffer(bad, keyVersion));
  assert.throws(() => decryptBuffer(data, '99'), /Unknown encryption key/);
  assert.notDeepEqual(encryptBuffer(photo).data, data, 'fresh IV every time');
});

test('push endpoints: only known push services over https (no SSRF)', () => {
  const ok = ['https://fcm.googleapis.com/fcm/send/abc', 'https://updates.push.services.mozilla.com/wpush/v2/xyz',
    'https://web.push.apple.com/QWERT', 'https://wns2-par02p.notify.windows.com/w/?token=abc'];
  for (const u of ok) assert.equal(endpointAllowed(u), true, u);
  const bad = ['http://fcm.googleapis.com/x', 'https://169.254.169.254/latest/meta-data', 'https://localhost/x', 'https://127.0.0.1/x',
    'https://evil.example/x', 'https://fcm.googleapis.com.evil.example/x', 'https://user:pw@fcm.googleapis.com/x',
    'https://fcm.googleapis.com:8443/x', 'https://[::1]/x', 'ftp://fcm.googleapis.com/x', 'not a url', '', undefined,
    'https://notify.windows.com.attacker.io/x', 'https://evilpush.apple.com.attacker.io/x'];
  for (const u of bad) assert.equal(endpointAllowed(u), false, String(u));
  assert.equal(endpointAllowed('https://push.mycompany.example/x', ['push.mycompany.example']), true);
});

test('push keys must look like base64url of the right size', () => {
  assert.equal(validKey('BKfWTk2iuK_7Aox_Mu85FVWi5m0ZD4l_9mCjy6p5yOPAfNKrgK7IRIL58IcNgKsFMATvD81II8IU04PGs3DFM0w', 80, 100), true);
  assert.equal(validKey('short', 80, 100), false);
  assert.equal(validKey('has spaces and / slashes ........................................................................', 80, 100), false);
  assert.equal(validKey(12345, 1, 10), false);
});

test('business roles: nobody gets more than they should', () => {
  // Staff can invoice but never see or move money.
  assert.equal(bizCan('staff', 'invoices.create'), true);
  for (const p of ['wallet.read', 'payouts.create', 'payouts.approve', 'team.manage', 'wallet.topup']) assert.equal(bizCan('staff', p), false, p);
  // Auditors read everything money-related and change nothing.
  for (const p of ['invoices.read', 'report.read', 'wallet.read', 'payouts.read', 'team.read']) assert.equal(bizCan('auditor', p), true, p);
  for (const p of ['invoices.create', 'invoices.cancel', 'payouts.create', 'payouts.approve', 'team.manage', 'wallet.topup', 'settings.manage']) assert.equal(bizCan('auditor', p), false, p);
  // Finance sends payouts but cannot approve them, manage people, or change the threshold.
  assert.equal(bizCan('finance', 'payouts.create'), true);
  for (const p of ['payouts.approve', 'team.manage', 'settings.manage', 'wallet.topup']) assert.equal(bizCan('finance', p), false, p);
  // Only the owner approves.
  for (const r of Object.keys(BIZ_PERMS)) assert.equal(bizCan(r, 'payouts.approve'), r === 'owner', r);
  // Unknown roles get nothing, and "owner" cannot be handed out by invitation.
  assert.equal(bizCan('admin', 'wallet.read'), false);
  assert.equal(bizCan(undefined, 'wallet.read'), false);
  assert.deepEqual(INVITABLE.sort(), ['auditor', 'finance', 'staff']);
});

test('payouts: owner is paid out at once, finance above the threshold waits', () => {
  const T = 5_000_000;
  assert.equal(payoutNeedsApproval('owner', 999_999_999, T), false);
  assert.equal(payoutNeedsApproval('finance', T, T), false);       // at the threshold: allowed
  assert.equal(payoutNeedsApproval('finance', T + 1, T), true);    // one kobo above: waits
  assert.equal(payoutNeedsApproval('finance', 1, 0), true);        // threshold 0: everything waits
  assert.equal(payoutNeedsApproval('staff', 1, T), false);         // staff cannot create payouts at all (blocked by permission, not here)
  assert.equal(payoutNeedsApproval('finance', '6000000', '5000000'), true);
});
