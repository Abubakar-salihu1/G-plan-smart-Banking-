// Run with: DATABASE_URL=... npm test   (use a throwaway database, never production)
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { pool, withTx } from '../src/db.js';
import { createAccount, availableBalance, ledgerBalance, postEntry, newReference } from '../src/services/ledger.js';
import { transfer, hashRequest, fundWalletDemo, completeHeldTransfer } from '../src/services/transfers.js';
import { payExternal, finalize, approveHeldExternal, rejectHeld } from '../src/services/payments.js';
import { mockBank } from '../src/services/providers.js';
import { executeReversal } from '../src/services/reversal.js';
import { convert, ensureWallet } from '../src/services/fx.js';

after(() => pool.end());

async function makeUser(label) {
  return withTx(async (c) => {
    const u = (await c.query(
      `INSERT INTO users(email,password_hash,full_name,country_code)
       VALUES ($1,'x',$2,'NG') RETURNING id`,
      [`${label}-${crypto.randomUUID()}@test.local`, label])).rows[0];
    const walletId = await createAccount(c, { userId: u.id, type: 'customer_wallet', currency: 'NGN', name: 'w' });
    return { userId: u.id, walletId };
  });
}
const key = () => crypto.randomUUID();
const send = (a, b, amountMinor, idemKey = key()) => transfer({
  userId: a.userId, fromAccountId: a.walletId, toAccountId: b.walletId, amountMinor,
  type: 'internal_transfer', idemKey, requestHash: hashRequest({ amountMinor, to: b.walletId }),
});
const fund = (u, amountMinor) => fundWalletDemo({ userId: u.userId, walletId: u.walletId, amountMinor, idemKey: key() });
const payOut = (u, accountNumber, amountMinor, feeMinor = 1000) => payExternal({
  userId: u.userId, walletId: u.walletId, amountMinor, feeMinor, type: 'external_transfer', description: 'test',
  meta: { accountNumber }, idemKey: key(), requestHash: hashRequest({ accountNumber, amountMinor, k: key() }), provider: mockBank,
});

test('transfer moves money and balances reconcile', async () => {
  const a = await makeUser('a'), b = await makeUser('b');
  await fund(a, 10_000);
  await send(a, b, 4_000);
  assert.equal(await availableBalance(pool, a.walletId), 6_000);
  assert.equal(await availableBalance(pool, b.walletId), 4_000);
  assert.equal((await pool.query('SELECT * FROM balance_cache_mismatches')).rowCount, 0);
});

test('insufficient funds is rejected and moves nothing', async () => {
  const a = await makeUser('a'), b = await makeUser('b');
  await fund(a, 1_000);
  await assert.rejects(send(a, b, 2_000), { code: 'INSUFFICIENT_FUNDS' });
  assert.equal(await availableBalance(pool, a.walletId), 1_000);
});

test('same idempotency key replays without moving money twice', async () => {
  const a = await makeUser('a'), b = await makeUser('b');
  await fund(a, 10_000);
  const k = key();
  const first = await send(a, b, 3_000, k);
  const second = await send(a, b, 3_000, k);
  assert.equal(second.replayed, true);
  assert.equal(second.reference, first.reference);
  assert.equal(await availableBalance(pool, b.walletId), 3_000);
});

test('same key with a different body is rejected', async () => {
  const a = await makeUser('a'), b = await makeUser('b');
  await fund(a, 10_000);
  const k = key();
  await send(a, b, 1_000, k);
  await assert.rejects(send(a, b, 2_000, k), { code: 'IDEMPOTENCY_MISMATCH' });
});

test('concurrent spends cannot overdraw (double-spend protection)', async () => {
  const a = await makeUser('a'), b = await makeUser('b');
  await fund(a, 10_000);
  const results = await Promise.allSettled(Array.from({ length: 5 }, () => send(a, b, 6_000)));
  assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
  assert.equal(await availableBalance(pool, a.walletId), 4_000);
  assert.equal(await availableBalance(pool, b.walletId), 6_000);
});

test('you cannot send from someone else\'s wallet', async () => {
  const a = await makeUser('a'), b = await makeUser('b');
  await fund(a, 10_000);
  await assert.rejects(
    transfer({ userId: b.userId, fromAccountId: a.walletId, toAccountId: b.walletId, amountMinor: 1_000, type: 'internal_transfer',
      idemKey: key(), requestHash: 'x' }), { code: 'FORBIDDEN' });
  assert.equal(await availableBalance(pool, a.walletId), 10_000);
});

test('unbalanced journal entries are rejected at commit', async () => {
  const a = await makeUser('a');
  await assert.rejects(withTx(async (c) => {
    const t = (await c.query(
      `INSERT INTO transactions(reference,type,amount_minor,currency) VALUES ($1,'deposit',100,'NGN') RETURNING id`,
      [newReference()])).rows[0];
    await postEntry(c, { transactionId: t.id, postings: [
      { accountId: a.walletId, direction: 'credit', amountMinor: 100, currency: 'NGN' }] });
  }), /unbalanced/);
});

test('ledger rows are immutable', async () => {
  const a = await makeUser('a');
  await fund(a, 500);
  await assert.rejects(pool.query('UPDATE postings SET amount_minor = 1'), /append-only/);
  await assert.rejects(pool.query('DELETE FROM journal_entries'), /append-only/);
});

test('illegal state transitions are rejected', async () => {
  const a = await makeUser('a');
  const r = await fund(a, 500);
  await assert.rejects(
    pool.query(`UPDATE transactions SET state='created' WHERE id=$1`, [r.transactionId]),
    /Illegal transaction transition/);
});

test('state history is recorded for every transition', async () => {
  const a = await makeUser('a');
  const r = await fund(a, 500);
  const h = await pool.query('SELECT to_state FROM transaction_state_history WHERE transaction_id=$1 ORDER BY id', [r.transactionId]);
  assert.deepEqual(h.rows.map((x) => x.to_state),
    ['created', 'pending_authorisation', 'authorised', 'processing', 'completed']);
});

test('bank transfer success posts amount and fee, and captures the hold', async () => {
  const a = await makeUser('a');
  await fund(a, 10_000);
  const r = await payOut(a, '0123456789', 5_000);
  assert.equal(r.state, 'completed');
  assert.equal(await ledgerBalance(pool, a.walletId), 10_000 - 5_000 - 1_000);
  assert.equal(await availableBalance(pool, a.walletId), 4_000);
});

test('provider decline fails the payment and releases the hold', async () => {
  const a = await makeUser('a');
  await fund(a, 10_000);
  const r = await payOut(a, '0123450000', 5_000);
  assert.equal(r.state, 'failed');
  assert.equal(await availableBalance(pool, a.walletId), 10_000);
});

test('provider timeout is never assumed: stays unconfirmed with money reserved, then resolves', async () => {
  const a = await makeUser('a');
  await fund(a, 10_000);
  const r = await payOut(a, '0123459999', 5_000);
  assert.equal(r.state, 'processing_unconfirmed');
  assert.equal(await ledgerBalance(pool, a.walletId), 10_000);          // not posted yet
  assert.equal(await availableBalance(pool, a.walletId), 4_000);        // but reserved
  const done = await finalize(r.transactionId, { ok: true, providerRef: 'T' });
  assert.equal(done.state, 'completed');
  assert.equal(await ledgerBalance(pool, a.walletId), 4_000);
});

test('cannot spend money that is on hold', async () => {
  const a = await makeUser('a'), b = await makeUser('b');
  await fund(a, 10_000);
  await payOut(a, '0123459999', 8_000, 0);   // unconfirmed, 8000 reserved
  await assert.rejects(send(a, b, 5_000), { code: 'INSUFFICIENT_FUNDS' });
});

test('reversal posts compensating entries and keeps the ledger balanced', async () => {
  const a = await makeUser('a'), b = await makeUser('b');
  await fund(a, 10_000);
  const r = await send(a, b, 4_000);
  const admin = (await pool.query(`INSERT INTO users(email,password_hash,full_name,country_code,role)
    VALUES ($1,'x','Admin','NG','admin') RETURNING id`, [`adm-${crypto.randomUUID()}@test.local`])).rows[0];
  await executeReversal(r.transactionId, admin.id);
  assert.equal(await availableBalance(pool, a.walletId), 10_000);
  assert.equal(await availableBalance(pool, b.walletId), 0);
  const t = (await pool.query('SELECT state FROM transactions WHERE id=$1', [r.transactionId])).rows[0];
  assert.equal(t.state, 'reversed');
});

test('reversal is refused when the recipient already spent the money', async () => {
  const a = await makeUser('a'), b = await makeUser('b'), c = await makeUser('c');
  await fund(a, 10_000);
  const r = await send(a, b, 4_000);
  await send(b, c, 4_000);
  const admin = (await pool.query(`INSERT INTO users(email,password_hash,full_name,country_code,role)
    VALUES ($1,'x','Admin','NG','admin') RETURNING id`, [`adm-${crypto.randomUUID()}@test.local`])).rows[0];
  await assert.rejects(executeReversal(r.transactionId, admin.id), { code: 'RECIPIENT_FUNDS_SPENT' });
});

test('currency conversion keeps every entry balanced and charges the stated fee', async () => {
  const a = await makeUser('a');
  await fund(a, 1_000_000);
  await ensureWallet(a.userId, 'USD');
  const r = await convert({ userId: a.userId, from: 'NGN', to: 'USD', amountMinor: 155_000, idemKey: key() });
  assert.equal(r.state, 'completed');
  assert.equal(r.feeMinor, 775);
  assert.ok(r.extra.receiveMinor > 0);
  assert.equal((await pool.query('SELECT * FROM balance_cache_mismatches')).rowCount, 0);
});

test('hash chains verify as intact', async () => {
  const a = await makeUser('a');
  await fund(a, 1_000);
  const r = (await pool.query('SELECT verify_ledger_chain() AS l, verify_audit_chain() AS a')).rows[0];
  assert.equal(r.l, null);
  assert.equal(r.a, null);
});

test('daily sending limit is enforced across several payments', async () => {
  const a = await makeUser('a'), b = await makeUser('b');
  await fund(a, 30_000_000);
  await send(a, b, 5_000_000);          // tier 0: each payment up to 5,000,000, 10,000,000 a day
  await send(a, b, 5_000_000);
  await assert.rejects(send(a, b, 1_000_000), { code: 'DAILY_LIMIT' });
  assert.equal(await availableBalance(pool, b.walletId), 10_000_000);
});

test('daily limit also counts bank payments and cannot be dodged with parallel requests', async () => {
  const a = await makeUser('a');
  await fund(a, 30_000_000);
  const rs = await Promise.allSettled(Array.from({ length: 4 }, () => payOut(a, '0123456789', 4_000_000, 0)));
  assert.equal(rs.filter((r) => r.status === 'fulfilled').length, 2);   // 2 x 4,000,000 fits in 10,000,000, a third would not
});

const staff = async () => (await pool.query(
  `INSERT INTO users(email,password_hash,full_name,country_code,role) VALUES ($1,'x','Reviewer','NG','compliance') RETURNING id`,
  [`rev-${crypto.randomUUID()}@test.local`])).rows[0].id;
const sendFlagged = (a, b, amountMinor) => transfer({
  userId: a.userId, fromAccountId: a.walletId, toAccountId: b.walletId, amountMinor, type: 'internal_transfer',
  idemKey: key(), requestHash: hashRequest({ amountMinor, k: key() }), riskLevel: 'review',
});

test('a flagged transfer is held: money reserved, nothing posted, recipient not credited', async () => {
  const a = await makeUser('a'), b = await makeUser('b');
  await fund(a, 10_000);
  const r = await sendFlagged(a, b, 4_000);
  assert.equal(r.state, 'under_review');
  assert.equal(await ledgerBalance(pool, a.walletId), 10_000);
  assert.equal(await availableBalance(pool, a.walletId), 6_000);
  assert.equal(await availableBalance(pool, b.walletId), 0);
});

test('approving a held transfer sends it, and it cannot be approved twice', async () => {
  const a = await makeUser('a'), b = await makeUser('b');
  await fund(a, 10_000);
  const r = await sendFlagged(a, b, 4_000);
  const who = await staff();
  const done = await completeHeldTransfer(r.transactionId, who);
  assert.equal(done.state, 'completed');
  assert.equal(await availableBalance(pool, a.walletId), 6_000);
  assert.equal(await availableBalance(pool, b.walletId), 4_000);
  await assert.rejects(completeHeldTransfer(r.transactionId, who), { code: 'NOT_HELD' });
  assert.equal((await pool.query('SELECT * FROM balance_cache_mismatches')).rowCount, 0);
});

test('declining a held transfer gives the money back and the payment fails', async () => {
  const a = await makeUser('a'), b = await makeUser('b');
  await fund(a, 10_000);
  const r = await sendFlagged(a, b, 4_000);
  const out = await rejectHeld(r.transactionId, await staff());
  assert.equal(out.state, 'failed');
  assert.equal(await availableBalance(pool, a.walletId), 10_000);
  assert.equal(await availableBalance(pool, b.walletId), 0);
  await assert.rejects(rejectHeld(r.transactionId, await staff()), { code: 'NOT_HELD' });
});

test('a flagged bank payment waits for review and the provider is not called until approval', async () => {
  const a = await makeUser('a');
  await fund(a, 10_000);
  let calls = 0;
  const spy = async () => { calls++; return { ok: true, providerRef: 'X' }; };
  const r = await payExternal({
    userId: a.userId, walletId: a.walletId, amountMinor: 5_000, feeMinor: 1_000, type: 'external_transfer', description: 'flagged',
    meta: { accountNumber: '0123456789' }, riskLevel: 'review', idemKey: key(), requestHash: hashRequest({ k: key() }), provider: spy,
  });
  assert.equal(r.state, 'under_review');
  assert.equal(calls, 0);
  assert.equal(await availableBalance(pool, a.walletId), 4_000);
  const done = await approveHeldExternal(r.transactionId, await staff());
  assert.equal(done.state, 'completed');
  assert.equal(await ledgerBalance(pool, a.walletId), 4_000);
});

test('replaying a held payment returns the held receipt instead of paying twice', async () => {
  const a = await makeUser('a'), b = await makeUser('b');
  await fund(a, 10_000);
  const k = key();
  const make = () => transfer({ userId: a.userId, fromAccountId: a.walletId, toAccountId: b.walletId, amountMinor: 3_000,
    type: 'internal_transfer', idemKey: k, requestHash: hashRequest({ same: 1 }), riskLevel: 'review' });
  const first = await make();
  const again = await make();
  assert.equal(again.replayed, true);
  assert.equal(again.state, 'under_review');
  assert.equal(again.reference, first.reference);
  assert.equal(await availableBalance(pool, a.walletId), 7_000);
});
