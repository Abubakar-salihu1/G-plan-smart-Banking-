import test from 'node:test';
import assert from 'node:assert/strict';
import { effectiveDailyLimit, overDailyLimit, remainingToday } from '../src/utils/limitMath.js';

test('business daily limit: the owner cap can only lower the tier limit, never raise it', () => {
  assert.equal(effectiveDailyLimit(500_000_000, null), 500_000_000);
  assert.equal(effectiveDailyLimit(500_000_000, undefined), 500_000_000);
  assert.equal(effectiveDailyLimit(500_000_000, 100_000_000), 100_000_000);
  assert.equal(effectiveDailyLimit(500_000_000, 900_000_000), 500_000_000);   // a cap above the tier limit changes nothing
  assert.equal(effectiveDailyLimit(500_000_000, 0), 0);                        // 0 freezes outgoing money
});

test('over the limit means strictly over', () => {
  assert.equal(overDailyLimit(400, 100, 500), false);   // exactly the limit is allowed
  assert.equal(overDailyLimit(400, 101, 500), true);
  assert.equal(overDailyLimit(0, 501, 500), true);
  assert.equal(overDailyLimit('400', '100', '500'), false);
});

test('remaining today never goes negative', () => {
  assert.equal(remainingToday(100, 500), 400);
  assert.equal(remainingToday(500, 500), 0);
  assert.equal(remainingToday(700, 500), 0);
});
