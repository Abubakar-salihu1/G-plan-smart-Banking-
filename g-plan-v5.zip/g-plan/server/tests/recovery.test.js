import test from 'node:test';
import assert from 'node:assert/strict';
import { generateCodes, normalize, looksLikeRecovery, format, CODE_COUNT } from '../src/utils/recoveryCodes.js';
import { fingerprint } from '../src/utils/crypto.js';

test('ten unique codes, 16 characters, no look-alike characters', () => {
  const codes = generateCodes();
  assert.equal(codes.length, CODE_COUNT);
  assert.equal(new Set(codes).size, CODE_COUNT);
  for (const c of codes) { assert.match(c, /^[A-HJKMNP-Z2-9]{16}$/); assert.ok(!/[01ILO]/.test(c)); }
  assert.notDeepEqual(generateCodes(), codes, 'every set is different');
});

test('codes are shown in groups of four and typed back in any style', () => {
  const raw = 'ABCD2345EFGH6789';
  assert.equal(format(raw), 'ABCD-2345-EFGH-6789');
  for (const typed of ['ABCD-2345-EFGH-6789', 'abcd 2345 efgh 6789', ' abcd23 45efgh6789 ', 'ABCD2345EFGH6789']) assert.equal(normalize(typed), raw, typed);
});

test('six-digit sign-in codes and junk are never mistaken for recovery codes', () => {
  for (const bad of ['123456', '', null, undefined, 'ABCD-2345-EFGH', 'ABCD-2345-EFGH-67890', 'ABCD-2345-EFGH-678O', 'ILIL-ILIL-ILIL-ILIL', 'abc-def-ghi-jkl-mno']) assert.equal(looksLikeRecovery(bad), false, String(bad));
  assert.equal(looksLikeRecovery('ABCD-2345-EFGH-6789'), true);
});

test('stored hashes are keyed, repeatable, and differ per code and per purpose', () => {
  const a = fingerprint('ABCD2345EFGH6789', undefined, 'recovery');
  assert.equal(fingerprint('ABCD2345EFGH6789', a.version, 'recovery').hash, a.hash);
  assert.notEqual(fingerprint('ABCD2345EFGH678A', a.version, 'recovery').hash, a.hash);
  assert.notEqual(fingerprint('ABCD2345EFGH6789', a.version, 'other').hash, a.hash);
  assert.ok(!a.hash.includes('ABCD'));
  assert.equal(a.hash.length, 64);
  assert.throws(() => fingerprint('x', '99', 'recovery'), /Unknown encryption key/);
});

test('generation is unbiased enough: every character of the alphabet appears', () => {
  const seen = new Set(); for (let i = 0; i < 30; i++) for (const c of generateCodes()) for (const ch of c) seen.add(ch);
  assert.equal(seen.size, 31);
});
