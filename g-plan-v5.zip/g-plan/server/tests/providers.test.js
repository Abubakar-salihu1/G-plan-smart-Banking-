// Pure tests: no database. Flutterwave runs against a stubbed fetch.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as fw from '../src/services/flutterwave.js';

const realFetch = globalThis.fetch;
const reply = (status, body) => async (url, opts) => { calls.push({ url: String(url), opts }); return { ok: status < 300, status, json: async () => body }; };
let calls = [];
const env = (o) => Object.assign(process.env, { PAYMENT_PROVIDER: 'flutterwave', FLUTTERWAVE_SECRET_KEY: 'FLWSECK_TEST-x', FLUTTERWAVE_WEBHOOK_HASH: 'h'.repeat(40), ...o });
test.beforeEach(() => { calls = []; env({}); });
test.afterEach(() => { globalThis.fetch = realFetch; });

test('kobo become naira exactly, with integer maths', () => {
  assert.equal(fw.toMajor(250000), 2500);
  assert.equal(fw.toMajor(1), 0.01);
  assert.equal(fw.toMajor(1005), 10.05);
  assert.equal(fw.toMajor(99), 0.99);
  assert.throws(() => fw.toMajor(0));
  assert.throws(() => fw.toMajor(1.5));
});

test('enabled only when selected AND keyed', () => {
  assert.equal(fw.enabled(), true);
  delete process.env.FLUTTERWAVE_SECRET_KEY;
  assert.equal(fw.enabled(), false);
  env({ PAYMENT_PROVIDER: 'mock' });
  assert.equal(fw.enabled(), false);
});

test('transfer request is shaped the way Flutterwave expects and carries our reference', async () => {
  globalThis.fetch = reply(200, { status: 'success', data: { id: 777, status: 'NEW' } });
  const out = await fw.transferProvider({ reference: 'GP-ABC123', amountMinor: 1_050_000, meta: { bankCode: '058', accountNumber: '0123456789', accountName: 'Ada Obi' } });
  assert.deepEqual(out, { unconfirmed: true });          // NEW is not a result yet
  const sent = JSON.parse(calls[0].opts.body);
  assert.equal(calls[0].url, 'https://api.flutterwave.com/v3/transfers');
  assert.equal(sent.amount, 10500);                       // naira, not kobo
  assert.equal(sent.reference, 'GP-ABC123');
  assert.equal(sent.account_bank, '058');
  assert.equal(sent.currency, 'NGN');
  assert.match(calls[0].opts.headers.Authorization, /^Bearer FLWSECK_TEST-x$/);
});

test('definite outcomes map correctly, and unknowns are never treated as failure', async () => {
  globalThis.fetch = reply(200, { status: 'success', data: { id: 5, status: 'SUCCESSFUL' } });
  assert.deepEqual(await fw.transferProvider({ reference: 'R', amountMinor: 100, meta: {} }), { ok: true, providerRef: '5' });
  globalThis.fetch = reply(200, { status: 'success', data: { id: 5, status: 'FAILED' } });
  assert.equal((await fw.transferProvider({ reference: 'R', amountMinor: 100, meta: {} })).ok, false);
  globalThis.fetch = reply(400, { status: 'error', message: 'Insufficient balance' });
  const refused = await fw.transferProvider({ reference: 'R', amountMinor: 100, meta: {} });
  assert.equal(refused.ok, false);
  assert.equal(refused.reason, 'Insufficient balance');
  globalThis.fetch = reply(503, {});
  assert.deepEqual(await fw.transferProvider({ reference: 'R', amountMinor: 100, meta: {} }), { unconfirmed: true });
  globalThis.fetch = async () => { throw new Error('socket hang up'); };
  await assert.rejects(() => fw.transferProvider({ reference: 'R', amountMinor: 100, meta: {} }));   // payExternal turns a throw into "unconfirmed"
});

test('status check finds our reference in the list and ignores others', async () => {
  globalThis.fetch = reply(200, { data: [{ reference: 'OTHER', status: 'FAILED' }, { reference: 'GP-1', status: 'SUCCESSFUL', id: 9 }] });
  assert.deepEqual(await fw.statusCheck('GP-1'), { ok: true, providerRef: '9' });
  globalThis.fetch = reply(200, { data: [] });
  assert.deepEqual(await fw.statusCheck('GP-1'), { unconfirmed: true });
});

test('name enquiry returns the bank name or a safe error', async () => {
  globalThis.fetch = reply(200, { status: 'success', data: { account_name: 'ADA OBI' } });
  assert.equal(await fw.resolveAccount('0123456789', '058'), 'ADA OBI');
  globalThis.fetch = reply(400, { status: 'error' });
  await assert.rejects(() => fw.resolveAccount('0123456789', '058'), /Could not verify/);
});

test('webhook secret is checked in constant time and rejects when unset', () => {
  assert.equal(fw.verifyWebhook('h'.repeat(40)), true);
  assert.equal(fw.verifyWebhook('h'.repeat(39)), false);
  assert.equal(fw.verifyWebhook('x'.repeat(40)), false);
  assert.equal(fw.verifyWebhook(undefined), false);
  delete process.env.FLUTTERWAVE_WEBHOOK_HASH;
  assert.equal(fw.verifyWebhook('h'.repeat(40)), false);   // never accepts when the secret is missing
  assert.equal(fw.verifyWebhook(''), false);
});
