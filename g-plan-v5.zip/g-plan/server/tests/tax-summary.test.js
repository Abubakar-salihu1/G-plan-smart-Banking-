import test from 'node:test';
import assert from 'node:assert/strict';
import { summariseYear, TAX_NOTE } from '../src/utils/taxSummary.js';

const r = (month, type, net, extra = {}) => ({ created_at: `2026-${String(month).padStart(2, '0')}-10T10:00:00Z`, type, net_minor: net, description: '', category: null, ...extra });

test('a year is added up into received, spent by category, saved and interest', () => {
  const s = summariseYear([
    r(1, 'deposit', 5_000_000, { description: 'Demo top-up' }),
    r(1, 'internal_transfer', 1_000_000, { description: 'From Bola' }),
    r(2, 'bill_payment', -200_000, { category: 'bills' }),
    r(2, 'bill_payment', -300_000, { category: 'bills' }),
    r(3, 'card_payment', -450_000, { category: 'shopping' }),
    r(3, 'external_transfer', -700_000),
    r(3, 'goal_contribution', -250_000),
    r(4, 'goal_contribution', 100_000),
    r(5, 'deposit', 6_000, { description: 'Demo interest on Rent' }),
    r(6, 'fx_conversion', -999_999),
    r(7, 'internal_transfer', -123_000, { category: 'transfers' }),
  ]);
  assert.equal(s.totals.addedToWallet, 5_000_000);
  assert.equal(s.totals.receivedFromPeople, 1_000_000);
  assert.equal(s.totals.interest, 6_000);
  assert.equal(s.totals.saved, 250_000); assert.equal(s.totals.savedBack, 100_000);
  assert.equal(s.totals.spent, 200_000 + 300_000 + 450_000 + 700_000 + 123_000);
  assert.deepEqual(s.categories.map((c) => c.category), ['other', 'bills', 'transfers', 'shopping'].sort((a, b) => ({ other: 700_000, bills: 500_000, shopping: 450_000, transfers: 123_000 }[b] - { other: 700_000, bills: 500_000, shopping: 450_000, transfers: 123_000 }[a])));   // biggest first
  assert.deepEqual(s.categories.find((c) => c.category === 'bills'), { category: 'bills', totalMinor: 500_000 });
  assert.ok(s.categories.some((c) => c.category === 'other' && c.totalMinor === 700_000));
  assert.equal(s.months[1].spent, 500_000); assert.equal(s.months[0].received, 1_000_000); assert.equal(s.months[4].interest, 6_000);
  assert.ok(!JSON.stringify(s).includes('999999'), 'currency swaps are neither income nor spending');
});

test('an empty year is all zeros, with twelve months', () => {
  const s = summariseYear([]);
  assert.equal(s.months.length, 12); assert.deepEqual(s.categories, []);
  assert.ok(Object.values(s.totals).every((v) => v === 0));
});

test('the note says plainly that this is not tax advice', () => assert.match(TAX_NOTE, /not tax advice/i));
