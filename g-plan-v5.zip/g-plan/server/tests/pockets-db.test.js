// Needs a database. NOT YET RUN: written without a live PostgreSQL.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { pool, withTx } from '../src/db.js';
import { createAccount, availableBalance, walletOf, pocketWalletOf } from '../src/services/ledger.js';
import { fundWalletDemo, transfer } from '../src/services/transfers.js';
import { payExternal } from '../src/services/payments.js';
import { mockBank } from '../src/services/providers.js';

after(() => pool.end());
const key = () => crypto.randomUUID();
const user = (label) => withTx(async (c) => {
  const u = (await c.query(`INSERT INTO users(email,password_hash,full_name,country_code,kyc_tier) VALUES ($1,'x',$2,'NG',2) RETURNING id`, [`${label}-${key()}@test.local`, label])).rows[0];
  return { userId: u.id, walletId: await createAccount(c, { userId: u.id, type: 'customer_wallet', currency: 'NGN', name: 'w' }) };
});
const pocket = (owner, kind = 'joint') => withTx(async (c) => {
  const p = (await c.query(`INSERT INTO pockets(kind,name,owner_id) VALUES ($1,'Test pocket',$2) RETURNING id`, [kind, owner.userId])).rows[0];
  await c.query(`INSERT INTO pocket_members(pocket_id,user_id,role,status) VALUES ($1,$2,'owner','active')`, [p.id, owner.userId]);
  const wid = await createAccount(c, { userId: owner.userId, type: 'customer_wallet', currency: 'NGN', name: 'Test pocket' });
  await c.query('UPDATE accounts SET pocket_id=$2 WHERE id=$1', [wid, p.id]);
  return { pocketId: p.id, walletId: wid };
});

test('the personal wallet lookup never returns a pocket wallet', async () => {
  const o = await user('owner'); const p = await pocket(o);
  assert.equal(await walletOf(pool, o.userId), o.walletId);
  assert.equal(await pocketWalletOf(pool, p.pocketId), p.walletId);
});

test('personal paths cannot spend from a pocket; the right pocketId can; a wrong one cannot', async () => {
  const o = await user('owner'); const p = await pocket(o); const p2 = await pocket(await user('other')); const dest = await user('dest');
  await fundWalletDemo({ userId: o.userId, walletId: o.walletId, amountMinor: 100_000, idemKey: key() });
  await transfer({ userId: o.userId, fromAccountId: o.walletId, toAccountId: p.walletId, amountMinor: 60_000, type: 'internal_transfer', idemKey: key(), requestHash: 'a' });
  await assert.rejects(() => transfer({ userId: o.userId, fromAccountId: p.walletId, toAccountId: o.walletId, amountMinor: 1, type: 'internal_transfer', idemKey: key(), requestHash: 'b' }), /only send from your own/);
  await assert.rejects(() => payExternal({ userId: o.userId, walletId: p.walletId, amountMinor: 1_000, type: 'external_transfer', meta: { accountNumber: '0123456789' }, idemKey: key(), requestHash: 'c', provider: mockBank }), /own wallet/);
  await assert.rejects(() => transfer({ userId: o.userId, pocketId: p2.pocketId, fromAccountId: p.walletId, toAccountId: dest.walletId, amountMinor: 1, type: 'internal_transfer', idemKey: key(), requestHash: 'd' }), /not this pocket/);
  const r = await transfer({ userId: o.userId, pocketId: p.pocketId, fromAccountId: p.walletId, toAccountId: dest.walletId, amountMinor: 20_000, type: 'internal_transfer', idemKey: key(), requestHash: 'e' });
  assert.equal(r.state, 'completed');
  assert.equal(await availableBalance(pool, p.walletId), 40_000);
});

test('membership rules: one partner, one child pocket per child, one owner', async () => {
  const o = await user('o'); const a = await user('a'); const b = await user('b'); const kid = await user('kid'); const p = await pocket(o);
  await pool.query(`INSERT INTO pocket_members(pocket_id,user_id,role,status) VALUES ($1,$2,'partner','invited')`, [p.pocketId, a.userId]);
  await assert.rejects(() => pool.query(`INSERT INTO pocket_members(pocket_id,user_id,role,status) VALUES ($1,$2,'partner','invited')`, [p.pocketId, b.userId]), /uniq_one_pocket_partner/);
  const c1 = await pocket(o, 'child'); const c2 = await pocket(await user('o2'), 'child');
  await pool.query(`INSERT INTO pocket_members(pocket_id,user_id,role,status) VALUES ($1,$2,'child','active')`, [c1.pocketId, kid.userId]);
  await assert.rejects(() => pool.query(`INSERT INTO pocket_members(pocket_id,user_id,role,status) VALUES ($1,$2,'child','active')`, [c2.pocketId, kid.userId]), /uniq_one_child_pocket/);
  await assert.rejects(() => pool.query(`INSERT INTO pocket_members(pocket_id,user_id,role,status) VALUES ($1,$2,'owner','active')`, [p.pocketId, b.userId]), /uniq_one_pocket_owner/);
});

test('one payment idempotency key makes one payment, and only one approver wins', async () => {
  const o = await user('o'); const other = await user('x'); const p = await pocket(o); const ck = key();
  const ins = () => pool.query(`INSERT INTO pocket_payments(pocket_id,created_by,client_key,to_user_id,amount_minor) VALUES ($1,$2,$3,$4,100) ON CONFLICT (created_by, client_key) DO NOTHING RETURNING id`, [p.pocketId, o.userId, ck, other.userId]);
  const first = await ins(); assert.equal(first.rowCount, 1); assert.equal((await ins()).rowCount, 0);
  const claim = () => pool.query(`UPDATE pocket_payments SET status='executed' WHERE id=$1 AND status='pending_approval' RETURNING id`, [first.rows[0].id]);
  const res = await Promise.all([claim(), claim(), claim()]);
  assert.equal(res.filter((r) => r.rowCount === 1).length, 1);
});
