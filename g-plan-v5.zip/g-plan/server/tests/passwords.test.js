import test from 'node:test';
import assert from 'node:assert/strict';
import { parseArgon, needsRehashFor, ARGON } from '../src/utils/passwordRules.js';

const argonHash = (m = ARGON.memoryCost, t = ARGON.timeCost, p = ARGON.parallelism) => `$argon2id$v=19$m=${m},t=${t},p=${p}$c29tZXNhbHQ$aGFzaGhhc2g`;

test('argon2id parameters are read from the stored text', () => {
  assert.deepEqual(parseArgon(argonHash()), { m: 19456, t: 2, p: 1 });
  assert.equal(parseArgon('scrypt$65536$8$2$x$y'), null);
  assert.equal(parseArgon('$argon2i$v=19$m=1,t=1,p=1$a$b'), null);   // only argon2id counts
  assert.equal(parseArgon(undefined), null);
});

test('with the add-on: upgrade scrypt and bcrypt, keep argon2id that is strong enough', () => {
  const a = { argon: true };
  assert.equal(needsRehashFor('scrypt$65536$8$2$c2FsdA==$a2V5', a), true);
  assert.equal(needsRehashFor('$2b$12$abcdefghijklmnopqrstuuabcdefghijklmnopqrstuvwxyz0123', a), true);
  assert.equal(needsRehashFor(argonHash(), a), false);
  assert.equal(needsRehashFor(argonHash(65536, 3, 4), a), false);       // stronger is fine
  assert.equal(needsRehashFor(argonHash(4096, 2, 1), a), true);          // weaker memory is upgraded
  assert.equal(needsRehashFor(argonHash(19456, 1, 1), a), true);         // weaker passes is upgraded
  assert.equal(needsRehashFor('', a), true);
  assert.equal(needsRehashFor(null, a), true);
});

test('without the add-on: current scrypt is kept, bcrypt is upgraded, argon2id is never downgraded', () => {
  const n = { argon: false };
  assert.equal(needsRehashFor('scrypt$65536$8$2$c2FsdA==$a2V5', n), false);
  assert.equal(needsRehashFor('scrypt$16384$8$1$c2FsdA==$a2V5', n), true);
  assert.equal(needsRehashFor('$2a$10$abcdefghijklmnopqrstuuabcdefghijklmnopqrstuvwxyz0123', n), true);
  assert.equal(needsRehashFor(argonHash(), n), false);                    // keep it; sign-in will log that the add-on is missing
});

// Real hashing: only runs where the dependencies are installed (CI), skipped in a bare checkout.
let pw = null; try { pw = await import('../src/utils/password.js'); } catch { /* dependencies not installed */ }
test('hash, verify and upgrade round trip', { skip: !pw && 'bcryptjs not installed' }, async () => {
  const h = await pw.hashPassword('Correct-Horse-9');
  assert.equal(await pw.verifyPassword('Correct-Horse-9', h), true);
  assert.equal(await pw.verifyPassword('correct-horse-9', h), false);
  assert.equal(pw.needsRehash(h), false, 'a fresh hash is already current');
  assert.notEqual(await pw.hashPassword('Correct-Horse-9'), h, 'every hash has its own salt');
  if (pw.hashingScheme() === 'argon2id') {
    assert.ok(h.startsWith('$argon2id$'));
    assert.equal(pw.needsRehash('scrypt$65536$8$2$c2FsdA==$a2V5'), true);
  } else assert.ok(h.startsWith('scrypt$'));
});
