// Needs a database: DATABASE_URL=... npm test   (throwaway database only)
// NOT YET RUN: written without a live PostgreSQL. Run it before relying on the business wallet.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { pool, withTx } from '../src/db.js';
import { createAccount, availableBalance, walletOf, businessWalletOf } from '../src/services/ledger.js';
import { transfer, hashRequest, fundWalletDemo } from '../src/services/transfers.js';
import { payExternal } from '../src/services/payments.js';
import { mockBank } from '../src/services/providers.js';

after(() => pool.end());
const key = () => crypto.randomUUID();

async function makeUser(label) {
  return withTx(async (c) => {
    const u = (await c.query(`INSERT INTO users(email,password_hash,full_name,country_code,kyc_tier) VALUES ($1,'x',$2,'NG',2) RETURNING id`,
      [`${label}-${crypto.randomUUID()}@test.local`, label])).rows[0];
    const walletId = await createAccount(c, { userId: u.id, type: 'customer_wallet', currency: 'NGN', name: 'w' });
    return { userId: u.id, walletId };
  });
}
async function makeBusiness(owner) {
  return withTx(async (c) => {
    const b = (await c.query(`INSERT INTO businesses(owner_id,name) VALUES ($1,'Test Co') RETURNING id`, [owner.userId])).rows[0];
    await c.query(`INSERT INTO business_members(business_id,user_id,role,status) VALUES ($1,$2,'owner','active')`, [b.id, owner.userId]);
    const wid = await createAccount(c, { userId: owner.userId, type: 'customer_wallet', currency: 'NGN', name: 'Business wallet' });
    await c.query('UPDATE accounts SET business_id=$2 WHERE id=$1', [wid, b.id]);
    return { businessId: b.id, walletId: wid };
  });
}
test('the personal wallet lookup never returns the business wallet', async () => {
  const o = await makeUser('owner'); const biz = await makeBusiness(o);
  assert.equal(await walletOf(pool, o.userId), o.walletId);
  assert.equal(await businessWalletOf(pool, biz.businessId), biz.walletId);
  assert.notEqual(o.walletId, biz.walletId);
});

test('a customer paying into the business wallet increases its balance', async () => {
  const o = await makeUser('owner'); const biz = await makeBusiness(o); const cust = await makeUser('cust');
  await fundWalletDemo({ userId: cust.userId, walletId: cust.walletId, amountMinor: 50_000, idemKey: key() });
  await transfer({ userId: cust.userId, fromAccountId: cust.walletId, toAccountId: biz.walletId, amountMinor: 20_000, type: 'internal_transfer', idemKey: key(), requestHash: 'a' });
  assert.equal(await availableBalance(pool, biz.walletId), 20_000);
  assert.equal(await availableBalance(pool, cust.walletId), 30_000);
});

test('personal code paths cannot spend from the business wallet, even for the owner', async () => {
  const o = await makeUser('owner'); const biz = await makeBusiness(o); const other = await makeUser('other');
  await fundWalletDemo({ userId: other.userId, walletId: other.walletId, amountMinor: 50_000, idemKey: key() });
  await transfer({ userId: other.userId, fromAccountId: other.walletId, toAccountId: biz.walletId, amountMinor: 30_000, type: 'internal_transfer', idemKey: key(), requestHash: 'b' });
  await assert.rejects(() => transfer({ userId: o.userId, fromAccountId: biz.walletId, toAccountId: o.walletId, amountMinor: 1_000, type: 'internal_transfer', idemKey: key(), requestHash: 'c' }), /only send from your own/);
  await assert.rejects(() => payExternal({ userId: o.userId, walletId: biz.walletId, amountMinor: 1_000, type: 'external_transfer', meta: { accountNumber: '0123456789' }, idemKey: key(), requestHash: 'd', provider: mockBank }), /own wallet/);
  assert.equal(await availableBalance(pool, biz.walletId), 30_000);
});

test('with the right businessId the business wallet can pay out, and a wrong businessId cannot', async () => {
  const o = await makeUser('owner'); const biz = await makeBusiness(o); const biz2 = await makeBusiness(await makeUser('owner2'));
  const src = await makeUser('src'); const dest = await makeUser('dest');
  await fundWalletDemo({ userId: src.userId, walletId: src.walletId, amountMinor: 100_000, idemKey: key() });
  await transfer({ userId: src.userId, fromAccountId: src.walletId, toAccountId: biz.walletId, amountMinor: 80_000, type: 'internal_transfer', idemKey: key(), requestHash: 'e' });
  const r = await transfer({ userId: o.userId, businessId: biz.businessId, fromAccountId: biz.walletId, toAccountId: dest.walletId, amountMinor: 25_000, type: 'internal_transfer', idemKey: key(), requestHash: 'f' });
  assert.equal(r.state, 'completed');
  assert.equal(await availableBalance(pool, biz.walletId), 55_000);
  assert.equal(await availableBalance(pool, dest.walletId), 25_000);
  await assert.rejects(() => transfer({ userId: o.userId, businessId: biz2.businessId, fromAccountId: biz.walletId, toAccountId: dest.walletId, amountMinor: 1, type: 'internal_transfer', idemKey: key(), requestHash: 'g' }), /not this business wallet/);
  // A business payout to a bank, from the business wallet.
  const k = key();
  const ext = await payExternal({ userId: o.userId, businessId: biz.businessId, walletId: biz.walletId, amountMinor: 10_000, feeMinor: 1000, type: 'external_transfer', description: 't', meta: { accountNumber: '0123456789' }, idemKey: k, requestHash: 'h', provider: mockBank });
  assert.equal(ext.state, 'completed');
  assert.equal(await availableBalance(pool, biz.walletId), 55_000 - 11_000);
  // The same key again is a replay, not a second payout.
  const again = await payExternal({ userId: o.userId, businessId: biz.businessId, walletId: biz.walletId, amountMinor: 10_000, feeMinor: 1000, type: 'external_transfer', description: 't', meta: { accountNumber: '0123456789' }, idemKey: k, requestHash: 'h', provider: mockBank });
  assert.equal(again.replayed, true);
  assert.equal(await availableBalance(pool, biz.walletId), 55_000 - 11_000);
});

test('a person can be an active member of only one business, and a business has one owner', async () => {
  const a = await makeUser('a'); const b = await makeUser('b'); const staff = await makeUser('staff');
  const biz1 = await makeBusiness(a); const biz2 = await makeBusiness(b);
  await pool.query(`INSERT INTO business_members(business_id,user_id,role,status) VALUES ($1,$2,'staff','active')`, [biz1.businessId, staff.userId]);
  await assert.rejects(() => pool.query(`INSERT INTO business_members(business_id,user_id,role,status) VALUES ($1,$2,'staff','active')`, [biz2.businessId, staff.userId]), /uniq_one_active_membership/);
  // Invitations may wait side by side.
  await pool.query(`INSERT INTO business_members(business_id,user_id,role,status) VALUES ($1,$2,'finance','invited')`, [biz2.businessId, staff.userId]);
  await assert.rejects(() => pool.query(`INSERT INTO business_members(business_id,user_id,role,status) VALUES ($1,$2,'owner','active')`, [biz1.businessId, staff.userId]), /uniq_one_owner|uniq_one_active_membership/);
  const x = await makeUser('x');
  await assert.rejects(() => pool.query(`INSERT INTO business_members(business_id,user_id,role,status) VALUES ($1,$2,'admin','invited')`, [biz1.businessId, x.userId]), /check/i);
});

test('the same payout idempotency key cannot create two payouts', async () => {
  const o = await makeUser('o'); const biz = await makeBusiness(o); const ck = key();
  const ins = () => pool.query(`INSERT INTO business_payouts(business_id,created_by,client_key,kind,amount_minor,recipient) VALUES ($1,$2,$3,'bank',100,'{}') ON CONFLICT (created_by, client_key) DO NOTHING RETURNING id`, [biz.businessId, o.userId, ck]);
  assert.equal((await ins()).rowCount, 1);
  assert.equal((await ins()).rowCount, 0);
});

test('two approvers racing: exactly one claim wins', async () => {
  const o = await makeUser('o'); const biz = await makeBusiness(o); const f = await makeUser('f');
  const p = (await pool.query(`INSERT INTO business_payouts(business_id,created_by,client_key,kind,amount_minor,recipient) VALUES ($1,$2,$3,'bank',100,'{}') RETURNING id`, [biz.businessId, f.userId, key()])).rows[0];
  const claim = () => pool.query(`UPDATE business_payouts SET status='executed', decided_by=$2, decided_at=now() WHERE id=$1 AND status='pending_approval' RETURNING id`, [p.id, o.userId]);
  const results = await Promise.all([claim(), claim(), claim()]);
  assert.equal(results.filter((r) => r.rowCount === 1).length, 1);
});

test('KYC photos: stored encrypted, one waiting photo per kind, purged after the window', async () => {
  const { encryptBuffer, decryptBuffer } = await import('../src/utils/crypto.js');
  const u = await makeUser('kyc'); const bytes = Buffer.from('fake-jpeg-bytes'); const e = encryptBuffer(bytes);
  const add = () => pool.query(`INSERT INTO kyc_documents(user_id,kind,mime,size_bytes,sha256,key_version,ciphertext) VALUES ($1,'id_front','image/jpeg',$2,'x',$3,$4) RETURNING id`, [u.userId, bytes.length, e.keyVersion, e.data]);
  const first = (await add()).rows[0];
  const stored = (await pool.query('SELECT ciphertext, key_version FROM kyc_documents WHERE id=$1', [first.id])).rows[0];
  assert.ok(!stored.ciphertext.includes(bytes));
  assert.ok(decryptBuffer(stored.ciphertext, stored.key_version).equals(bytes));
  await pool.query(`UPDATE kyc_documents SET purge_after = now() - interval '1 minute' WHERE id=$1`, [first.id]);
  const { purgeExpired } = await import('../src/services/kycDocs.js');
  await purgeExpired();
  assert.equal((await pool.query('SELECT 1 FROM kyc_documents WHERE id=$1', [first.id])).rowCount, 0);
});

// ---------- business-wide limits and handing over ownership (added later) ----------
import { assertBusinessLimits, businessUsedToday } from '../src/services/limits.js';
import { config } from '../src/config.js';

async function setTier(userId, tier) { await pool.query('UPDATE users SET kyc_tier=$2 WHERE id=$1', [userId, tier]); }
async function fundBusiness(biz, amount) {
  const src = await makeUser('src2');
  await fundWalletDemo({ userId: src.userId, walletId: src.walletId, amountMinor: amount, idemKey: key() });
  await transfer({ userId: src.userId, fromAccountId: src.walletId, toAccountId: biz.walletId, amountMinor: amount, type: 'internal_transfer', idemKey: key(), requestHash: 'bf' });
}

test('the business daily limit is shared by everyone on the team, and follows the owner\'s tier', async () => {
  const o = await makeUser('owner'); const biz = await makeBusiness(o); const member = await makeUser('fin'); const dest = await makeUser('dest');
  await setTier(o.userId, 1); await setTier(member.userId, 3);                       // the member's own high tier must not matter
  const daily = config.dailyLimitsMinor[1];
  await fundBusiness(biz, Math.min(daily * 2, 900_000_000));
  await pool.query('UPDATE businesses SET daily_cap_minor=$2 WHERE id=$1', [biz.businessId, 300_000]);   // owner sets a lower cap: ₦3,000
  const pay = (userId, amountMinor) => transfer({ userId, businessId: biz.businessId, fromAccountId: biz.walletId, toAccountId: dest.walletId, amountMinor, type: 'internal_transfer', idemKey: key(), requestHash: key() });
  await pay(o.userId, 200_000);                                                      // ₦2,000 by the owner
  await assert.rejects(() => pay(member.userId, 150_000), /daily limit for everyone/);   // ₦1,500 more by someone else: over the shared ₦3,000
  await pay(member.userId, 100_000);                                                  // exactly ₦3,000 in total is allowed
  assert.equal(await businessUsedToday(pool, biz.walletId), 300_000);
  await assert.rejects(() => pay(o.userId, 1), /daily limit/);
});

test('personal spending does not use up the business limit, and the cap can be lifted', async () => {
  const o = await makeUser('owner'); const biz = await makeBusiness(o); const dest = await makeUser('dest');
  await setTier(o.userId, 1);
  await fundBusiness(biz, 5_000_000);
  await fundWalletDemo({ userId: o.userId, walletId: o.walletId, amountMinor: 1_000_000, idemKey: key() });
  await transfer({ userId: o.userId, fromAccountId: o.walletId, toAccountId: dest.walletId, amountMinor: 900_000, type: 'internal_transfer', idemKey: key(), requestHash: 'p' });
  assert.equal(await businessUsedToday(pool, biz.walletId), 0);
  await pool.query('UPDATE businesses SET daily_cap_minor=0 WHERE id=$1', [biz.businessId]);
  await assert.rejects(() => assertBusinessLimits(pool, { businessId: biz.businessId, walletId: biz.walletId, amountMinor: 1, currency: 'NGN' }), /daily limit/);
  await pool.query('UPDATE businesses SET daily_cap_minor=NULL WHERE id=$1', [biz.businessId]);
  await assertBusinessLimits(pool, { businessId: biz.businessId, walletId: biz.walletId, amountMinor: 1, currency: 'NGN' });
});

test('ownership: one pending offer at a time, and the swap keeps exactly one owner', async () => {
  const a = await makeUser('old'); const b = await makeUser('new'); const c = await makeUser('other');
  const biz = await makeBusiness(a);
  for (const u of [b, c]) await pool.query(`INSERT INTO business_members(business_id,user_id,role,status) VALUES ($1,$2,'finance','active')`, [biz.businessId, u.userId]);
  const offer = (to) => pool.query(`INSERT INTO business_transfers(business_id,from_user,to_user) VALUES ($1,$2,$3)`, [biz.businessId, a.userId, to.userId]);
  await offer(b);
  await assert.rejects(() => offer(c), /uniq_pending_transfer/);
  await assert.rejects(() => pool.query(`INSERT INTO business_transfers(business_id,from_user,to_user,status) VALUES ($1,$2,$2,'cancelled')`, [biz.businessId, a.userId]), /check/i);
  // The swap, in the order the route uses it.
  await withTx(async (cl) => {
    await cl.query(`UPDATE business_members SET role='finance' WHERE business_id=$1 AND user_id=$2`, [biz.businessId, a.userId]);
    await cl.query(`UPDATE business_members SET role='owner' WHERE business_id=$1 AND user_id=$2`, [biz.businessId, b.userId]);
    await cl.query(`UPDATE businesses SET owner_id=$2 WHERE id=$1`, [biz.businessId, b.userId]);
    await cl.query(`UPDATE accounts SET user_id=$2 WHERE business_id=$1`, [biz.businessId, b.userId]);
  });
  assert.equal((await pool.query(`SELECT COUNT(*) AS n FROM business_members WHERE business_id=$1 AND role='owner' AND status='active'`, [biz.businessId])).rows[0].n, 1);
  assert.equal((await pool.query('SELECT user_id FROM accounts WHERE id=$1', [biz.walletId])).rows[0].user_id, b.userId);
  assert.equal(await walletOf(pool, a.userId), a.walletId);   // the old owner's personal wallet is untouched
});
