import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateOps, shouldSend, T } from '../src/utils/opsRules.js';

const calm = { supportOld: 0, integrityOk: true, processingOld: 0, unconfirmedOld: 0, heldOld: 0, bulkStuck: 0, failedBulkItems24h: 0, approvalsOld: 0, reversalsOld: 0, kycOld: 0, jobsStaleMinutes: 1 };
const keys = (s) => evaluateOps({ ...calm, ...s }).map((i) => i.key);

test('a calm system raises nothing', () => assert.deepEqual(evaluateOps(calm), []));

test('money problems page someone, queue problems only warn', () => {
  const sev = (s) => Object.fromEntries(evaluateOps({ ...calm, ...s }).map((i) => [i.key, i.severity]));
  assert.deepEqual(sev({ processingOld: 2, unconfirmedOld: 1, integrityOk: false, jobsStaleMinutes: 30 }),
    { integrity: 'page', processing_stuck: 'page', unconfirmed: 'page', jobs_stale: 'page' });
  assert.deepEqual(sev({ heldOld: 1, bulkStuck: 1, failedBulkItems24h: 3, approvalsOld: 1, reversalsOld: 1, kycOld: 1 }),
    { held_old: 'warn', bulk_stuck: 'warn', bulk_failed: 'warn', approvals_old: 'warn', reversals_old: 'warn', kyc_old: 'warn' });
});

test('unanswered customer chats only warn', () => {
  assert.deepEqual(evaluateOps({ ...calm, supportOld: 2 }).map((i) => [i.key, i.severity]), [['support_old', 'warn']]);
  assert.match(evaluateOps({ ...calm, supportOld: 1 })[0].text, /^1 customer chat has/);
});

test('job staleness: only judged when jobs are meant to be running, and only past the limit', () => {
  assert.deepEqual(keys({ jobsStaleMinutes: null }), []);                    // jobs switched off on purpose
  assert.deepEqual(keys({ jobsStaleMinutes: T.jobsStaleMin }), []);          // exactly at the limit is fine
  assert.deepEqual(keys({ jobsStaleMinutes: T.jobsStaleMin + 0.5 }), ['jobs_stale']);
});

test('messages are plain and say what to do, with correct singular and plural', () => {
  const one = evaluateOps({ ...calm, unconfirmedOld: 1 })[0].text;
  const many = evaluateOps({ ...calm, unconfirmedOld: 3 })[0].text;
  assert.match(one, /^1 bank transfer has/); assert.match(many, /^3 bank transfers have/);
  assert.match(one, /Recheck/);
  assert.match(evaluateOps({ ...calm, failedBulkItems24h: 1 })[0].text, /waiting for their salary/);
});

test('alert timing: new and returning problems are sent at once, then reminders by severity', () => {
  const now = Date.parse('2026-10-09T12:00:00Z'); const ago = (m) => new Date(now - m * 60_000).toISOString();
  assert.equal(shouldSend(undefined, 'page', now), true);                                              // new
  assert.equal(shouldSend({ last_sent_at: ago(5), resolved_at: ago(1) }, 'warn', now), true);          // came back after being resolved
  assert.equal(shouldSend({ last_sent_at: ago(30), resolved_at: null }, 'page', now), false);          // too soon
  assert.equal(shouldSend({ last_sent_at: ago(61), resolved_at: null }, 'page', now), true);           // hourly reminder
  assert.equal(shouldSend({ last_sent_at: ago(61), resolved_at: null }, 'warn', now), false);          // warnings are quieter
  assert.equal(shouldSend({ last_sent_at: ago(12 * 60 + 1), resolved_at: null }, 'warn', now), true);
});
