import test from 'node:test';
import assert from 'node:assert/strict';
import { paymentDecision, pocketCan, weekStart, canApprove, POCKET_PERMS } from '../src/services/pocketRules.js';

const joint = { kind: 'joint', soloLimitMinor: 5_000_000, weeklyLimitMinor: 0, frozen: false };
const child = { kind: 'child', soloLimitMinor: 0, weeklyLimitMinor: 500_000, frozen: false };

test('joint: up to the limit goes now, above it needs the other person', () => {
  assert.equal(paymentDecision({ ...joint, role: 'partner', amountMinor: 5_000_000 }).outcome, 'now');
  assert.equal(paymentDecision({ ...joint, role: 'partner', amountMinor: 5_000_001 }).outcome, 'approval');
  assert.equal(paymentDecision({ ...joint, role: 'owner', amountMinor: 5_000_001 }).outcome, 'approval');   // the creator has no extra power
  assert.equal(paymentDecision({ ...joint, soloLimitMinor: 0, role: 'owner', amountMinor: 1 }).outcome, 'approval');
});

test('child: only approved people, only within the weekly limit', () => {
  assert.equal(paymentDecision({ ...child, role: 'child', amountMinor: 100_000, recipientApproved: true }).outcome, 'now');
  assert.equal(paymentDecision({ ...child, role: 'child', amountMinor: 100_000, recipientApproved: false }).outcome, 'deny');
  assert.equal(paymentDecision({ ...child, role: 'child', amountMinor: 200_000, spentThisWeekMinor: 300_001, recipientApproved: true }).outcome, 'deny');
  assert.equal(paymentDecision({ ...child, role: 'child', amountMinor: 200_000, spentThisWeekMinor: 300_000, recipientApproved: true }).outcome, 'now');   // exactly the limit
  assert.equal(paymentDecision({ ...child, role: 'owner', amountMinor: 99_999_999, recipientApproved: false }).outcome, 'now');   // the parent is not restricted
});

test('frozen pockets stop everyone but the owner', () => {
  assert.equal(paymentDecision({ ...child, frozen: true, role: 'child', amountMinor: 1, recipientApproved: true }).outcome, 'deny');
  assert.equal(paymentDecision({ ...joint, frozen: true, role: 'partner', amountMinor: 1 }).outcome, 'deny');
  assert.equal(paymentDecision({ ...child, frozen: true, role: 'owner', amountMinor: 1 }).outcome, 'now');
});

test('permissions: a child can look and pay within rules, never manage, fund or approve', () => {
  for (const p of ['manage', 'fund', 'approve']) assert.equal(pocketCan('child', p), false, p);
  assert.equal(pocketCan('child', 'view'), true);
  assert.equal(pocketCan('partner', 'manage'), false);
  assert.equal(pocketCan('stranger', 'view'), false);
  assert.equal(paymentDecision({ ...joint, role: 'stranger', amountMinor: 1 }).outcome, 'deny');
  assert.ok(Object.keys(POCKET_PERMS).every((r) => ['owner', 'partner', 'child'].includes(r)));
});

test('approval: never the person who made the payment', () => {
  assert.equal(canApprove('partner', 'a', 'b'), true);
  assert.equal(canApprove('owner', 'a', 'a'), false);
  assert.equal(canApprove('child', 'a', 'b'), false);
});

test('the spending week starts on Monday (UTC)', () => {
  assert.equal(weekStart(new Date('2026-10-08T15:00:00Z')).toISOString(), '2026-10-05T00:00:00.000Z');   // Thursday -> Monday
  assert.equal(weekStart(new Date('2026-10-05T00:00:00Z')).toISOString(), '2026-10-05T00:00:00.000Z');   // Monday stays
  assert.equal(weekStart(new Date('2026-10-11T23:59:59Z')).toISOString(), '2026-10-05T00:00:00.000Z');   // Sunday -> Monday before
});
