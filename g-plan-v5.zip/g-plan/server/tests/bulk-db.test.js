// Needs a database. NOT YET RUN: written without a live PostgreSQL.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { pool, withTx } from '../src/db.js';
import { createAccount, availableBalance } from '../src/services/ledger.js';
import { fundWalletDemo, transfer } from '../src/services/transfers.js';
import { runBulk } from '../src/services/bulk.js';

after(() => pool.end());
const key = () => crypto.randomUUID();
const user = (label) => withTx(async (c) => {
  const u = (await c.query(`INSERT INTO users(email,password_hash,full_name,country_code,kyc_tier) VALUES ($1,'x',$2,'NG',2) RETURNING id, email`, [`${label}-${key()}@test.local`, label])).rows[0];
  return { userId: u.id, email: u.email, walletId: await createAccount(c, { userId: u.id, type: 'customer_wallet', currency: 'NGN', name: 'w' }) };
});
async function business(funds = 5_000_000) {
  const o = await user('owner');
  const biz = await withTx(async (c) => {
    const b = (await c.query(`INSERT INTO businesses(owner_id,name) VALUES ($1,'Test Co') RETURNING id`, [o.userId])).rows[0];
    await c.query(`INSERT INTO business_members(business_id,user_id,role,status) VALUES ($1,$2,'owner','active')`, [b.id, o.userId]);
    const wid = await createAccount(c, { userId: o.userId, type: 'customer_wallet', currency: 'NGN', name: 'Business wallet' });
    await c.query('UPDATE accounts SET business_id=$2 WHERE id=$1', [wid, b.id]);
    return { businessId: b.id, walletId: wid };
  });
  const src = await user('src');
  await fundWalletDemo({ userId: src.userId, walletId: src.walletId, amountMinor: funds, idemKey: key() });
  await transfer({ userId: src.userId, fromAccountId: src.walletId, toAccountId: biz.walletId, amountMinor: funds, type: 'internal_transfer', idemKey: key(), requestHash: 'f' });
  return { o, ...biz };
}
async function batch(b, items) {
  const total = items.reduce((s, i) => s + i.amount, 0);
  const bb = (await pool.query(`INSERT INTO bulk_batches(business_id,created_by,label,source,total_minor,item_count,status,executed_by) VALUES ($1,$2,'Test','csv',$3,$4,'running',$2) RETURNING id`, [b.businessId, b.o.userId, total, items.length])).rows[0];
  for (const [k, i] of items.entries()) await pool.query(
    `INSERT INTO bulk_items(batch_id,line,kind,name,bank_code,account_number,email,amount_minor) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
    [bb.id, k + 1, i.kind, i.name, i.kind === 'bank' ? '058' : null, i.kind === 'bank' ? '0123456789' : null, i.email || null, i.amount]);
  return bb.id;
}
const statuses = async (id) => (await pool.query('SELECT status FROM bulk_items WHERE batch_id=$1 ORDER BY line', [id])).rows.map((r) => r.status);

test('a batch pays every item once, from the business wallet, and never twice', async () => {
  const b = await business(); const dest = await user('dest');
  const id = await batch(b, [{ kind: 'bank', name: 'Ada Obi', amount: 100_000 }, { kind: 'internal', name: 'Dest', email: dest.email, amount: 50_000 }, { kind: 'bank', name: 'Chi Eze', amount: 70_000 }]);
  await runBulk(10);
  assert.deepEqual(await statuses(id), ['sent', 'sent', 'sent']);
  const after1 = await availableBalance(pool, b.walletId);
  assert.ok(after1 <= 5_000_000 - 220_000);
  assert.equal(await availableBalance(pool, dest.walletId), 50_000);
  assert.equal(await runBulk(10), 0);                                   // nothing left to do
  assert.equal(await availableBalance(pool, b.walletId), after1);       // and nothing was paid again
  assert.equal((await pool.query('SELECT status FROM bulk_batches WHERE id=$1', [id])).rows[0].status, 'done');
});

test('one bad item fails alone; the others still go', async () => {
  const b = await business();
  const id = await batch(b, [{ kind: 'internal', name: 'Nobody', email: 'nobody@nowhere.test', amount: 10_000 }, { kind: 'bank', name: 'Ada Obi', amount: 20_000 }]);
  await runBulk(10);
  assert.deepEqual(await statuses(id), ['failed', 'sent']);
});

test('items the wallet cannot afford fail with a reason, without breaking the run', async () => {
  const b = await business(100_000);
  const id = await batch(b, [{ kind: 'bank', name: 'Ada Obi', amount: 90_000 }, { kind: 'bank', name: 'Chi Eze', amount: 90_000 }]);
  await runBulk(10);
  const s = await statuses(id);
  assert.equal(s.filter((x) => x === 'sent').length, 1);
  assert.equal(s.filter((x) => x === 'failed').length, 1);
});

test('if the person who started the batch loses their role, the rest is skipped', async () => {
  const b = await business();
  const id = await batch(b, [{ kind: 'bank', name: 'Ada Obi', amount: 10_000 }, { kind: 'bank', name: 'Chi Eze', amount: 10_000 }]);
  await pool.query(`UPDATE business_members SET status='removed' WHERE business_id=$1`, [b.businessId]);
  await runBulk(10);
  assert.deepEqual(await statuses(id), ['skipped', 'skipped']);
});

test('payroll for a month can only be prepared once', async () => {
  const b = await business();
  const ins = () => pool.query(`INSERT INTO bulk_batches(business_id,created_by,label,source,run_key,total_minor,item_count) VALUES ($1,$2,'Payroll','payroll','payroll:2026-10',100,1)`, [b.businessId, b.o.userId]);
  await ins();
  await assert.rejects(ins, /uniq_bulk_run_key/);
});

// ---------- operations: the watchdog and the stuck-money snapshot (added later) ----------
import { opsSnapshot } from '../src/services/opsSnapshot.js';
import { runBulkFor } from '../src/services/bulk.js';

test('the snapshot counts only things that have waited long enough', async () => {
  const base = await opsSnapshot();
  const u = await user('ops');
  const mk = (state, mins) => pool.query(
    `INSERT INTO transactions(reference,type,state,initiator_user_id,amount_minor,fee_minor,currency,is_demo,meta,updated_at,created_at)
     VALUES ($1,'external_transfer',$2,$3,1000,0,'NGN',TRUE,'{}', now() - ($4 || ' minutes')::interval, now() - ($4 || ' minutes')::interval)`,
    [`GP-${crypto.randomBytes(6).toString('hex').toUpperCase()}`, state, u.userId, String(mins)]);
  await mk('processing_unconfirmed', 5);        // too recent to count
  await mk('processing_unconfirmed', 45);       // counts
  await mk('processing', 20);                   // counts: stuck mid-way
  await mk('under_review', 300);                // counts: held more than 4 hours
  const s = await opsSnapshot();
  assert.equal(s.unconfirmedOld - base.unconfirmedOld, 1);
  assert.equal(s.processingOld - base.processingOld, 1);
  assert.equal(s.heldOld - base.heldOld, 1);
});

test('a large batch is finished within one time budget instead of ten items a minute', async () => {
  const b = await business(50_000_000);
  const items = Array.from({ length: 35 }, (_, i) => ({ kind: 'bank', name: `Person ${i}`, amount: 10_000 + i }));
  const id = await batch(b, items);
  await runBulkFor(20_000);
  const s = await statuses(id);
  assert.equal(s.length, 35);
  assert.ok(s.every((x) => x === 'sent' || x === 'failed'), 'nothing left waiting');
  assert.ok(s.filter((x) => x === 'sent').length >= 30);
});
