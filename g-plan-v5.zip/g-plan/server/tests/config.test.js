import test from 'node:test';
import assert from 'node:assert/strict';
import { isWeakSecret, assertProductionSafe } from '../src/config.js';

test('placeholder and short secrets are treated as weak', () => {
  for (const v of [undefined, '', 'short', 'change-me-to-a-long-random-string-xxxxxxxx', 'dev-only-secret-change-me-aaaaaaaaaaaa',
    '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef']) assert.equal(isWeakSecret(v), true, String(v));
  assert.equal(isWeakSecret('b3f1c2a9d8e7f60514233241a0b9c8d7e6f50413'), false);
});

test('production refuses to start with unsafe settings', () => {
  const keep = { ...process.env };
  try {
    process.env.NODE_ENV = 'production';
    process.env.JWT_SECRET = 'change-me-to-a-long-random-string-xxxxxxxx';
    delete process.env.DATA_KEYS;
    assert.throws(() => assertProductionSafe(), /Unsafe production configuration/);
  } finally {
    for (const k of Object.keys(process.env)) if (!(k in keep)) delete process.env[k];
    Object.assign(process.env, keep);
  }
});

test('development never blocks startup', () => {
  const keep = process.env.NODE_ENV;
  process.env.NODE_ENV = 'development';
  assert.doesNotThrow(() => assertProductionSafe());
  if (keep === undefined) delete process.env.NODE_ENV; else process.env.NODE_ENV = keep;
});

test('production refuses unsafe payment provider settings', () => {
  const keep = { ...process.env };
  const good = { NODE_ENV: 'production', JWT_SECRET: 'b3f1c2a9d8e7f60514233241a0b9c8d7e6f50413aa', DATA_KEYS: '1:' + 'ab12'.repeat(16), SMS_PROVIDER: 'termii', EMAIL_PROVIDER: 'resend' };
  const run = (extra) => { for (const k of Object.keys(process.env)) if (!(k in keep)) delete process.env[k]; Object.assign(process.env, keep, good, extra); return () => assertProductionSafe(); };
  try {
    assert.doesNotThrow(run({}));
    assert.throws(run({ PAYMENT_PROVIDER: 'flutterwave' }), /FLUTTERWAVE_SECRET_KEY/);
    assert.throws(run({ PAYMENT_PROVIDER: 'flutterwave', FLUTTERWAVE_SECRET_KEY: 'k', FLUTTERWAVE_WEBHOOK_HASH: 'short' }), /FLUTTERWAVE_WEBHOOK_HASH/);
    assert.doesNotThrow(run({ PAYMENT_PROVIDER: 'flutterwave', FLUTTERWAVE_SECRET_KEY: 'k', FLUTTERWAVE_WEBHOOK_HASH: 'c9d8e7f60514233241a0b9c8d7e6f50413b3f1c2' }));
    assert.throws(run({ PAYMENT_PROVIDER: 'stripe' }), /PAYMENT_PROVIDER must be/);
    assert.throws(run({ PAYMENT_PROVIDER: 'paystack' }), /PAYSTACK_SECRET_KEY/);
  } finally {
    for (const k of Object.keys(process.env)) if (!(k in keep)) delete process.env[k];
    Object.assign(process.env, keep);
  }
});
