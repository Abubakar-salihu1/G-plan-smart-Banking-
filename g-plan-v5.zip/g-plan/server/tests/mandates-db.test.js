// Needs a database. NOT YET RUN: written without a live PostgreSQL.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { pool, withTx } from '../src/db.js';
import { createAccount, availableBalance } from '../src/services/ledger.js';
import { fundWalletDemo } from '../src/services/transfers.js';
import { runMandates } from '../src/services/mandates.js';

after(() => pool.end());
const key = () => crypto.randomUUID();
const user = (label, tier = 2) => withTx(async (c) => {
  const u = (await c.query(`INSERT INTO users(email,password_hash,full_name,country_code,kyc_tier) VALUES ($1,'x',$2,'NG',$3) RETURNING id`, [`${label}-${key()}@test.local`, label, tier])).rows[0];
  return { userId: u.id, walletId: await createAccount(c, { userId: u.id, type: 'customer_wallet', currency: 'NGN', name: 'w' }) };
});
const business = (owner) => withTx(async (c) => {
  const b = (await c.query(`INSERT INTO businesses(owner_id,name) VALUES ($1,'Gym Co') RETURNING id`, [owner.userId])).rows[0];
  await c.query(`INSERT INTO business_members(business_id,user_id,role,status) VALUES ($1,$2,'owner','active')`, [b.id, owner.userId]);
  const wid = await createAccount(c, { userId: owner.userId, type: 'customer_wallet', currency: 'NGN', name: 'Business wallet' });
  await c.query('UPDATE accounts SET business_id=$2 WHERE id=$1', [wid, b.id]);
  return { businessId: b.id, walletId: wid };
});
const today = () => new Date().toISOString().slice(0, 10);
const mandate = async (biz, payer, o = {}) => (await pool.query(
  `INSERT INTO mandates(business_id,payer_id,created_by,label,status,max_amount_minor,fixed_amount_minor,frequency,start_on,approved_at)
   VALUES ($1,$2,$3,'Gym membership',$4,$5,$6,'monthly',$7,now()) RETURNING id`,
  [biz.businessId, payer.userId, biz.ownerId, o.status || 'active', o.max || 1_000_000, o.fixed || null, o.start || today()])).rows[0].id;
const due = async (mid, amount, dueOn = today()) => (await pool.query(`INSERT INTO mandate_collections(mandate_id,due_on,amount_minor) VALUES ($1,$2,$3) RETURNING id`, [mid, dueOn, amount])).rows[0].id;
const setup = async (funds = 5_000_000) => {
  const owner = await user('owner'); const biz = { ...(await business(owner)), ownerId: owner.userId };
  const payer = await user('payer'); await fundWalletDemo({ userId: payer.userId, walletId: payer.walletId, amountMinor: funds, idemKey: key() });
  return { owner, biz, payer };
};
const status = async (cid) => (await pool.query('SELECT status, error FROM mandate_collections WHERE id=$1', [cid])).rows[0];

test('a due collection moves money from the customer to the business wallet, once', async () => {
  const { biz, payer } = await setup(); const mid = await mandate(biz, payer); const cid = await due(mid, 300_000);
  await runMandates();
  assert.equal((await status(cid)).status, 'paid');
  assert.equal(await availableBalance(pool, biz.walletId), 300_000);
  assert.equal(await availableBalance(pool, payer.walletId), 5_000_000 - 300_000);
  await runMandates(); await runMandates();
  assert.equal(await availableBalance(pool, biz.walletId), 300_000, 'never collected twice');
});

test('not enough money: nothing is taken, the customer is told, and three failures pause it', async () => {
  const { biz, payer } = await setup(1_000); const mid = await mandate(biz, payer);
  for (let i = 0; i < 3; i++) {
    const cid = await due(mid, 300_000, addDay(i));
    await runMandates(new Date(Date.parse(addDay(i) + 'T08:00:00Z')));
    assert.equal((await status(cid)).status, 'failed');
  }
  assert.equal(await availableBalance(pool, payer.walletId), 1_000);
  assert.equal((await pool.query('SELECT status FROM mandates WHERE id=$1', [mid])).rows[0].status, 'paused');
  assert.ok((await pool.query(`SELECT 1 FROM notifications WHERE user_id=$1 AND title='Direct debit failed'`, [payer.userId])).rowCount >= 1);
});
function addDay(n) { return new Date(Date.UTC(2030, 0, 1 + n)).toISOString().slice(0, 10); }

test('cancelled, paused or unapproved mandates are never collected', async () => {
  const { biz, payer } = await setup();
  for (const st of ['cancelled', 'pending', 'declined']) {
    const mid = await mandate(biz, payer, { status: st }); const cid = await due(mid, 100_000);
    await runMandates();
    assert.notEqual((await status(cid)).status, 'paid', st);
  }
  assert.equal(await availableBalance(pool, biz.walletId), 0);
});

test('a fixed-amount mandate schedules its own next collection, on the same day next month', async () => {
  const { biz, payer } = await setup(); const mid = await mandate(biz, payer, { fixed: 200_000, start: today() });
  await due(mid, 200_000);
  await runMandates();
  const rows = (await pool.query(`SELECT due_on, status, amount_minor FROM mandate_collections WHERE mandate_id=$1 ORDER BY due_on`, [mid])).rows;
  assert.equal(rows.length, 2);
  assert.equal(rows[0].status, 'paid'); assert.equal(rows[1].status, 'scheduled'); assert.equal(Number(rows[1].amount_minor), 200_000);
  assert.ok(String(rows[1].due_on.toISOString ? rows[1].due_on.toISOString() : rows[1].due_on).slice(0, 10) > today());
});

test('the day-before reminder is sent once, and only for active mandates', async () => {
  const { biz, payer } = await setup(); const mid = await mandate(biz, payer);
  const tomorrow = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  await due(mid, 100_000, tomorrow);
  await runMandates(); await runMandates();
  assert.equal(Number((await pool.query(`SELECT COUNT(*) AS n FROM notifications WHERE user_id=$1 AND title='Direct debit tomorrow'`, [payer.userId])).rows[0].n), 1);
});
