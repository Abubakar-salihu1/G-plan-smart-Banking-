import test from 'node:test';
import assert from 'node:assert/strict';
import { suggestFaq, findSecret, FAQ } from '../src/utils/supportRules.js';

test('FAQ: the right answer comes up for everyday wording, and nothing for noise', () => {
  assert.equal(suggestFaq('I lost my phone and cannot get my code')[0].id, 'lost-phone');
  assert.equal(suggestFaq('forgot my password cannot login')[0].id, 'forgot-password');
  assert.equal(suggestFaq('how do I cancel a direct debit')[0].id, 'debit');
  assert.equal(suggestFaq('someone hacked my account, unauthorised payments')[0].id, 'fraud');
  assert.deepEqual(suggestFaq('hello'), []);
  assert.deepEqual(suggestFaq(''), []);
  assert.deepEqual(suggestFaq(undefined), []);
  assert.ok(suggestFaq('transfer pending delay', 2).length <= 2);
  assert.ok(FAQ.every((f) => f.q && f.a && f.words.length >= 3), 'every answer is complete');
});

test('secrets: card numbers, passwords, PINs, codes and recovery codes are caught', () => {
  assert.equal(findSecret('my card is 4111 1111 1111 1111 please help'), 'a card number');
  assert.equal(findSecret('4111-1111-1111-1111'), 'a card number');
  assert.equal(findSecret('my password is Hunter2!'), 'a password or PIN');
  assert.equal(findSecret('PIN: 1234'), 'a password or PIN');
  assert.equal(findSecret('the code is 482913'), 'a verification code');
  assert.equal(findSecret('my recovery code is ABCD-2345-EFGH-6789'), 'a recovery code');
});

test('ordinary messages pass, including references and amounts', () => {
  for (const ok of ['My transfer GP-1A2B3C4D5E6F is stuck since this morning', 'I sent ₦25,000 and it has not arrived', 'Phone number 08012345678 is wrong on my profile',
    'Please explain the password reset email', 'The order number is 4111111111111112', 'I need help with my code screen']) assert.equal(findSecret(ok), null, ok);
});
