// Needs a database. NOT YET RUN: written without a live PostgreSQL.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { pool } from '../src/db.js';
import { issueCodes, consumeCode, codesLeft, deleteCodes } from '../src/services/recovery.js';

after(() => pool.end());
const user = async () => (await pool.query(`INSERT INTO users(email,password_hash,full_name,country_code) VALUES ($1,'x','R','NG') RETURNING id`, [`r-${crypto.randomUUID()}@test.local`])).rows[0].id;

test('a recovery code works once, and the others keep working', async () => {
  const u = await user(); const codes = await issueCodes(pool, u);
  assert.equal(codes.length, 10); assert.equal(await codesLeft(pool, u), 10);
  assert.equal(await consumeCode(u, codes[0]), true);
  assert.equal(await consumeCode(u, codes[0]), false);                    // used up
  assert.equal(await consumeCode(u, codes[1].toLowerCase().replace(/-/g, ' ')), true);   // typed loosely
  assert.equal(await codesLeft(pool, u), 8);
  assert.equal((await pool.query(`SELECT COUNT(*) AS n FROM notifications WHERE user_id=$1 AND title='A recovery code was used'`, [u])).rows[0].n, 2);
});

test('a wrong code, a six-digit code, or someone else\'s code never works', async () => {
  const a = await user(); const b = await user(); const ca = await issueCodes(pool, a); await issueCodes(pool, b);
  assert.equal(await consumeCode(a, 'ABCD-2345-EFGH-6789'), false);
  assert.equal(await consumeCode(a, '123456'), false);
  assert.equal(await consumeCode(b, ca[0]), false);
  assert.equal(await codesLeft(pool, a), 10);
});

test('the same code used twice at the same moment succeeds only once', async () => {
  const u = await user(); const codes = await issueCodes(pool, u);
  const r = await Promise.all([consumeCode(u, codes[2]), consumeCode(u, codes[2]), consumeCode(u, codes[2])]);
  assert.equal(r.filter(Boolean).length, 1);
});

test('a new set replaces the old one, and turning two-step off deletes them', async () => {
  const u = await user(); const old = await issueCodes(pool, u); const fresh = await issueCodes(pool, u);
  assert.equal(await consumeCode(u, old[0]), false);
  assert.equal(await consumeCode(u, fresh[0]), true);
  await deleteCodes(pool, u);
  assert.equal(await codesLeft(pool, u), 0);
  assert.equal(await consumeCode(u, fresh[1]), false);
});

test('codes are stored hashed: the database never holds a usable code', async () => {
  const u = await user(); const [c] = await issueCodes(pool, u);
  const rows = (await pool.query('SELECT code_hash FROM recovery_codes WHERE user_id=$1', [u])).rows;
  assert.ok(rows.every((r) => !r.code_hash.includes(c.replace(/-/g, ''))));
});
