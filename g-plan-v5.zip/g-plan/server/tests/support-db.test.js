// Needs a database. NOT YET RUN: written without a live PostgreSQL.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { pool } from '../src/db.js';

after(() => pool.end());
const user = async () => (await pool.query(`INSERT INTO users(email,password_hash,full_name,country_code) VALUES ($1,'x','C','NG') RETURNING id`, [`c-${crypto.randomUUID()}@test.local`])).rows[0].id;

test('a thread keeps messages in order, and the status follows who spoke last', async () => {
  const u = await user();
  const t = (await pool.query(`INSERT INTO support_threads(user_id, subject) VALUES ($1,'Help') RETURNING id, status, last_sender`, [u])).rows[0];
  assert.equal(t.status, 'open'); assert.equal(t.last_sender, 'customer');
  for (const [s, b] of [['customer', 'one'], ['staff', 'two'], ['customer', 'three']]) await pool.query(`INSERT INTO support_messages(thread_id, sender, body) VALUES ($1,$2,$3)`, [t.id, s, b]);
  assert.deepEqual((await pool.query('SELECT body FROM support_messages WHERE thread_id=$1 ORDER BY id', [t.id])).rows.map((r) => r.body), ['one', 'two', 'three']);
});

test('empty and oversized messages and unknown senders are refused by the database itself', async () => {
  const u = await user();
  const t = (await pool.query(`INSERT INTO support_threads(user_id, subject) VALUES ($1,'x') RETURNING id`, [u])).rows[0];
  await assert.rejects(() => pool.query(`INSERT INTO support_messages(thread_id, sender, body) VALUES ($1,'customer','')`, [t.id]), /check/i);
  await assert.rejects(() => pool.query(`INSERT INTO support_messages(thread_id, sender, body) VALUES ($1,'customer',$2)`, [t.id, 'x'.repeat(2001)]), /check/i);
  await assert.rejects(() => pool.query(`INSERT INTO support_messages(thread_id, sender, body) VALUES ($1,'bot','hi')`, [t.id]), /check/i);
});
