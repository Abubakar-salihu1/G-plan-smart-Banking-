// Needs a database. NOT YET RUN: written without a live PostgreSQL.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { pool, withTx } from '../src/db.js';
import { createAccount, availableBalance } from '../src/services/ledger.js';
import { fundWalletDemo, transfer } from '../src/services/transfers.js';
import { runRoundups } from '../src/services/savings.js';

after(() => pool.end());
const key = () => crypto.randomUUID();

async function setup(balance = 1_000_000) {
  const u = await withTx(async (c) => {
    const user = (await c.query(`INSERT INTO users(email,password_hash,full_name,country_code,kyc_tier) VALUES ($1,'x','Saver','NG',2) RETURNING id`, [`s-${key()}@test.local`])).rows[0];
    const wallet = await createAccount(c, { userId: user.id, type: 'customer_wallet', currency: 'NGN', name: 'w' });
    const pot = await createAccount(c, { userId: user.id, type: 'goal_pot', currency: 'NGN', name: 'Rent' });
    const goal = (await c.query(`INSERT INTO goals(user_id, account_id, name, target_minor, currency) VALUES ($1,$2,'Rent',5000000,'NGN') RETURNING id`, [user.id, pot])).rows[0];
    return { userId: user.id, wallet, pot, goalId: goal.id };
  });
  await fundWalletDemo({ userId: u.userId, walletId: u.wallet, amountMinor: balance, idemKey: key() });
  return u;
}
// A completed bill payment of a given size, recorded the way the app does (balance moves from wallet to a system sink).
async function completedPayment(u, amountMinor, createdAt = new Date()) {
  return withTx(async (c) => (await c.query(
    `INSERT INTO transactions(reference, type, state, initiator_user_id, amount_minor, fee_minor, currency, description, is_demo, category, meta)
     VALUES ($1,'bill_payment','completed',$2,$3,0,'NGN','test bill',TRUE,'bills','{}') RETURNING id`,
    [`GP-${crypto.randomBytes(6).toString('hex').toUpperCase()}`, u.userId, amountMinor])).rows[0].id);
}

test('a round-up moves only the spare change into the goal, once', async () => {
  const u = await setup();
  await pool.query(`INSERT INTO roundup_settings(user_id, goal_id, step_minor, since) VALUES ($1,$2,10000, now() - interval '1 hour')`, [u.userId, u.goalId]);
  await completedPayment(u, 127_500);                       // ₦1,275 -> saves ₦25
  assert.equal(await runRoundups(), 1);
  assert.equal(await availableBalance(pool, u.pot), 2_500);
  assert.equal(await availableBalance(pool, u.wallet), 1_000_000 - 2_500);
  assert.equal(await runRoundups(), 0);                     // the same payment is never rounded twice
  assert.equal(await availableBalance(pool, u.pot), 2_500);
});

test('payments from before the switch-on, and exact multiples, add nothing', async () => {
  const u = await setup();
  await completedPayment(u, 127_500);
  await pool.query(`INSERT INTO roundup_settings(user_id, goal_id, step_minor, since) VALUES ($1,$2,10000, now() + interval '1 minute')`, [u.userId, u.goalId]);
  await runRoundups();
  assert.equal(await availableBalance(pool, u.pot), 0);
  await pool.query(`UPDATE roundup_settings SET since = now() - interval '1 hour' WHERE user_id=$1`, [u.userId]);
  await completedPayment(u, 130_000);
  await runRoundups();
  assert.equal(await availableBalance(pool, u.pot), 2_500);   // only the older ₦1,275 payment, now in range; ₦1,300 adds 0
});

test('a round-up the wallet cannot afford is skipped, not retried', async () => {
  const u = await setup(1_000);
  await pool.query(`INSERT INTO roundup_settings(user_id, goal_id, step_minor, since) VALUES ($1,$2,100000, now() - interval '1 hour')`, [u.userId, u.goalId]);
  await completedPayment(u, 150_000);                       // would need ₦500 more, wallet has ₦10
  await runRoundups();
  assert.equal(await availableBalance(pool, u.pot), 0);
  await fundWalletDemo({ userId: u.userId, walletId: u.wallet, amountMinor: 1_000_000, idemKey: key() });
  assert.equal(await runRoundups(), 0);
  assert.equal(await availableBalance(pool, u.pot), 0);
});
