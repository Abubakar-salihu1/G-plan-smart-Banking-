// Needs a database. NOT YET RUN: written without a live PostgreSQL.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { pool, withTx } from '../src/db.js';
import { createAccount } from '../src/services/ledger.js';
import { runHabitAlerts } from '../src/services/habits.js';

after(() => pool.end());
const key = () => crypto.randomUUID();
const user = () => withTx(async (c) => {
  const u = (await c.query(`INSERT INTO users(email,password_hash,full_name,country_code,kyc_tier) VALUES ($1,'x','H','NG',2) RETURNING id`, [`h-${key()}@test.local`])).rows[0];
  await createAccount(c, { userId: u.id, type: 'customer_wallet', currency: 'NGN', name: 'w' });
  return u.id;
});
const pay = (userId, amount, description, ageDays, category = 'bills') => pool.query(
  `INSERT INTO transactions(reference,type,state,initiator_user_id,amount_minor,fee_minor,currency,description,is_demo,category,meta,created_at)
   VALUES ($1,'bill_payment','completed',$2,$3,0,'NGN',$4,TRUE,$5,'{}', now() - ($6 || ' days')::interval) RETURNING id`,
  [`GP-${crypto.randomBytes(6).toString('hex').toUpperCase()}`, userId, amount, description, category, String(ageDays)]);
const titles = async (u) => (await pool.query('SELECT title FROM notifications WHERE user_id=$1 ORDER BY id', [u])).rows.map((r) => r.title);

test('a price rise on a regular payment raises one alert, and only once', async () => {
  const u = await user();
  await pay(u, 1_000_000, 'DSTV Premium 111', 61); await pay(u, 1_000_000, 'DSTV Premium 222', 31);
  await pool.query(`INSERT INTO habit_alert_log SELECT id FROM transactions WHERE initiator_user_id=$1`, [u]);   // history is not re-judged
  await pay(u, 1_300_000, 'DSTV Premium 333', 0);
  await runHabitAlerts();
  assert.deepEqual(await titles(u), ['A regular payment went up']);
  await runHabitAlerts();
  assert.equal((await titles(u)).length, 1);
});

test('an unusually large payment raises an alert; a normal one does not', async () => {
  const u = await user();
  for (let i = 0; i < 6; i++) await pay(u, 300_000 + i * 10_000, `Airtime ${i}`, 20 + i, 'bills');
  await pool.query(`INSERT INTO habit_alert_log SELECT id FROM transactions WHERE initiator_user_id=$1`, [u]);
  await pay(u, 320_000, 'Airtime normal', 1, 'bills');
  await runHabitAlerts();
  assert.deepEqual(await titles(u), []);
  await pay(u, 3_000_000, 'Something big', 0, 'bills');
  await runHabitAlerts();
  assert.deepEqual(await titles(u), ['Unusual payment']);
});

test('switching habit alerts off silences them', async () => {
  const u = await user();
  await pool.query('INSERT INTO alert_prefs(user_id, habit_alerts) VALUES ($1, FALSE)', [u]);
  for (let i = 0; i < 6; i++) await pay(u, 300_000, `Airtime ${i}`, 20 + i);
  await pool.query(`INSERT INTO habit_alert_log SELECT id FROM transactions WHERE initiator_user_id=$1`, [u]);
  await pay(u, 5_000_000, 'Big', 0);
  await runHabitAlerts();
  assert.deepEqual(await titles(u), []);
});
