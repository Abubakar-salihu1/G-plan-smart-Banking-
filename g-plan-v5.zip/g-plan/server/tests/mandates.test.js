import test from 'node:test';
import assert from 'node:assert/strict';
import { nextDueOn, firstDueFrom, checkSchedule, shouldPause, isDue, needsReminder, validDate, addDays } from '../src/utils/mandateRules.js';

const m = (o = {}) => ({ status: 'active', max_amount_minor: 1_000_000, fixed_amount_minor: null, frequency: 'monthly', notice_days: 3, start_on: '2026-10-01', end_on: null, ...o });
const TODAY = '2026-10-10';

test('rhythm: weekly adds seven days; monthly keeps the day and clamps to short months', () => {
  assert.equal(nextDueOn('2026-10-10', 'weekly'), '2026-10-17');
  assert.equal(nextDueOn('2026-10-15', 'monthly'), '2026-11-15');
  assert.equal(nextDueOn('2026-01-31', 'monthly'), '2026-02-28');
  assert.equal(nextDueOn('2026-02-28', 'monthly', 31), '2026-03-31');   // the original day is remembered
  assert.equal(nextDueOn('2026-11-30', 'monthly'), '2026-12-30');
  assert.equal(nextDueOn('2026-12-15', 'monthly'), '2027-01-15');
  assert.equal(nextDueOn('2026-10-15', 'quarterly'), '2027-01-15');
  assert.equal(nextDueOn('2024-11-30', 'quarterly'), '2025-02-28');
});

test('catching up after downtime never collects for missed periods', () => {
  assert.equal(firstDueFrom('2026-07-15', 'monthly', '2026-10-13', 15), '2026-10-15');
  assert.equal(firstDueFrom('2026-10-15', 'monthly', '2026-10-13', 15), '2026-10-15');
  assert.equal(firstDueFrom('2026-09-01', 'weekly', '2026-10-13'), '2026-10-13');
});

test('scheduling: cap, fixed amount, notice, end date, start date', () => {
  const ok = { mandate: m(), amountMinor: 500_000, dueOn: '2026-10-20', today: TODAY, lastCollection: null };
  assert.equal(checkSchedule(ok), null);
  assert.match(checkSchedule({ ...ok, amountMinor: 1_000_001 }), /more than the customer agreed/);
  assert.equal(checkSchedule({ ...ok, amountMinor: 1_000_000 }), null);                         // exactly the cap is allowed
  assert.match(checkSchedule({ ...ok, mandate: m({ fixed_amount_minor: 400_000 }) }), /fixed amount/);
  assert.equal(checkSchedule({ ...ok, mandate: m({ fixed_amount_minor: 500_000 }) }), null);
  assert.match(checkSchedule({ ...ok, dueOn: '2026-10-12' }), /3 days notice/);                  // only 2 days ahead
  assert.equal(checkSchedule({ ...ok, dueOn: '2026-10-13' }), null);                              // exactly the notice period
  assert.match(checkSchedule({ ...ok, mandate: m({ end_on: '2026-10-19' }) }), /after the end date/);
  assert.match(checkSchedule({ ...ok, mandate: m({ start_on: '2026-10-25' }) }), /before the start date/);
  assert.match(checkSchedule({ ...ok, amountMinor: 0 }), /valid amount/);
  assert.match(checkSchedule({ ...ok, dueOn: 'tomorrow' }), /valid collection date/);
});

test('scheduling: only active mandates, and one collection per period', () => {
  const base = { amountMinor: 100_000, today: TODAY };
  for (const status of ['pending', 'paused', 'cancelled', 'declined', 'expired']) assert.match(checkSchedule({ ...base, mandate: m({ status }), dueOn: '2026-10-20', lastCollection: null }), /not active/, status);
  const last = { due_on: '2026-10-15', status: 'paid' };
  assert.match(checkSchedule({ ...base, mandate: m(), dueOn: '2026-11-10', lastCollection: last }), /Only one collection is allowed per month/);
  assert.equal(checkSchedule({ ...base, mandate: m(), dueOn: '2026-11-15', lastCollection: last }), null);
  assert.match(checkSchedule({ ...base, mandate: m({ frequency: 'weekly' }), dueOn: '2026-10-20', lastCollection: last }), /per week/);
  assert.equal(checkSchedule({ ...base, mandate: m(), dueOn: '2026-10-20', lastCollection: { due_on: '2026-10-15', status: 'cancelled' } }), null);   // a cancelled one does not count
});

test('failures pause the mandate; due and reminder dates are exact', () => {
  assert.equal(shouldPause(2), false); assert.equal(shouldPause(3), true);
  assert.equal(isDue({ status: 'scheduled', due_on: '2026-10-10' }, TODAY), true);
  assert.equal(isDue({ status: 'scheduled', due_on: '2026-10-11' }, TODAY), false);
  assert.equal(isDue({ status: 'cancelled', due_on: '2026-10-01' }, TODAY), false);
  assert.equal(needsReminder({ status: 'scheduled', due_on: '2026-10-11', notice_sent_at: null }, TODAY), true);
  assert.equal(needsReminder({ status: 'scheduled', due_on: '2026-10-11', notice_sent_at: 'x' }, TODAY), false);
  assert.equal(needsReminder({ status: 'scheduled', due_on: '2026-10-12', notice_sent_at: null }, TODAY), false);
});

test('dates are strict', () => {
  assert.equal(validDate('2026-02-29'), false); assert.equal(validDate('2026-02-28'), true); assert.equal(validDate('26-02-28'), false); assert.equal(addDays('2026-12-31', 1), '2027-01-01');
});
