import test from 'node:test';
import assert from 'node:assert/strict';
import { roundUpMinor, monthlyInterestMinor, STEPS } from '../src/utils/savingsMath.js';

test('round-up reaches the next step and never more', () => {
  assert.equal(roundUpMinor(127_500, 10000), 2_500);           // ₦1,275 -> ₦1,300
  assert.equal(roundUpMinor(130_000, 10000), 0);               // exact multiple adds nothing
  assert.equal(roundUpMinor(130_001, 10000), 9_999);           // one kobo over: nearly a full step
  assert.equal(roundUpMinor(127_500, 50000), 22_500);          // to ₦1,500
  assert.equal(roundUpMinor(127_500, 100000), 72_500);         // to ₦2,000
  for (const step of STEPS) for (const a of [1, 99, 10_000, 54_321, 9_999_999]) {
    const r = roundUpMinor(a, step);
    assert.ok(r >= 0 && r < step, `${a}/${step}`);
    assert.equal((a + r) % step, 0);
  }
});

test('round-up refuses odd input', () => {
  assert.equal(roundUpMinor(0, 10000), 0);
  assert.equal(roundUpMinor(-5, 10000), 0);
  assert.equal(roundUpMinor(1.5, 10000), 0);
  assert.equal(roundUpMinor(5000, 777), 0);       // only the allowed steps
  assert.equal(roundUpMinor('5000', 10000), 0);
});

test('demo interest: monthly, whole kobo, rounded down, sane limits', () => {
  assert.equal(monthlyInterestMinor(1_200_000, 0.12), 12_000);   // ₦12,000 at 12% a year = ₦120 a month
  assert.equal(monthlyInterestMinor(100, 0.08), 0);              // too small to earn a whole kobo
  assert.equal(monthlyInterestMinor(1_000_001, 0.08), 6666);     // rounds down, never up
  assert.equal(monthlyInterestMinor(0, 0.08), 0);
  assert.equal(monthlyInterestMinor(-500, 0.08), 0);
  assert.equal(monthlyInterestMinor(1_000_000, 0), 0);
  assert.equal(monthlyInterestMinor(1_000_000, 5), 0);           // a rate above 100% is a config mistake, pay nothing
});
