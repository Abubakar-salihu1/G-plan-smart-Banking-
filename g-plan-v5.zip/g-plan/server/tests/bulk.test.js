import test from 'node:test';
import assert from 'node:assert/strict';
import { parseCsv, amountToMinor, checkBulk, namesMatch, MAX_ROWS } from '../src/utils/bulkParse.js';

const BANKS = ['058', '044', '011'];
const head = 'name,bank_code,account_number,email,amount,note';

test('csv: quotes, commas inside quotes, CRLF, BOM, blank lines', () => {
  const rows = parseCsv('\uFEFFname,note\r\n"Ade, Bola","said ""hi"""\r\n\r\nChi,plain\r\n');
  assert.deepEqual(rows, [['name', 'note'], ['Ade, Bola', 'said "hi"'], ['Chi', 'plain']]);
  assert.throws(() => parseCsv('a,"unclosed'), /quote/);
});

test('amounts: plain numbers only, whole kobo', () => {
  assert.equal(amountToMinor('25000'), 2_500_000);
  assert.equal(amountToMinor('₦25,000.50'), 2_500_050);
  assert.equal(amountToMinor('0.5'), 50);
  for (const bad of ['', '0', '-5', '1e5', '12.345', 'abc', '12,34.5.6', '=1+1', '99999999999999']) assert.equal(amountToMinor(bad), null, bad);
});

test('a clean file becomes items and a total', () => {
  const r = checkBulk(`${head}\nAda Obi,058,0123456789,,150000,Oct salary\nChidi Eze,,,chidi@example.com,"95,000.50",`, BANKS);
  assert.deepEqual(r.problems, []);
  assert.equal(r.totalMinor, 15_000_000 + 9_500_050);
  assert.deepEqual(r.items.map((i) => [i.line, i.kind, i.amountMinor]), [[2, 'bank', 15_000_000], [3, 'internal', 9_500_050]]);
});

test('every kind of wrong row is named by line, and one wrong row refuses the lot', () => {
  const r = checkBulk(`${head}
,058,0123456789,,100,
Ada,999,0123456789,,100,
Ada,058,12345,,100,
Ada,058,0123456789,a@b.com,100,
Ada,,,,100,
Ada,,,not-an-email,100,
Ada,058,0123456789,,abc,
Ada,058,0123456789,,500,x
Ada,058,0123456789,,500,x
Ada,058,0123456789,,500,y`, BANKS);
  const byLine = Object.fromEntries(r.problems.map((p) => [p.line, p.message]));
  assert.match(byLine[2], /Name/); assert.match(byLine[3], /bank code/); assert.match(byLine[4], /10 digits/);
  assert.match(byLine[5], /either an email/); assert.match(byLine[6], /either an email/); assert.match(byLine[7], /email/);
  assert.match(byLine[8], /Amount/); assert.match(byLine[10], /duplicate/);
  assert.equal(byLine[9], undefined); assert.equal(byLine[11], undefined);   // same account and amount but a different note is allowed
});

test('headers and size limits', () => {
  assert.match(checkBulk('name,money\nAda,5', BANKS).problems[0].message, /column names/);
  assert.match(checkBulk('name,amount', BANKS).problems[0].message, /at least one/);
  assert.match(checkBulk('', BANKS).problems[0].message, /at least one/);
  const big = `${head}\n` + Array.from({ length: MAX_ROWS + 1 }, (_, i) => `P${i} Name,058,${String(1000000000 + i)},,100,`).join('\n');
  assert.match(checkBulk(big, BANKS).problems[0].message, /at most/);
  assert.match(checkBulk('x'.repeat(50_000), BANKS).problems[0].message, /too big/);
  assert.match(checkBulk(`${head}\nAda,058,0123456789,,100,a,b,c`, BANKS).problems[0].message, /Too many columns/);
});

test('hostile text in names is neutralised, not rejected', () => {
  const r = checkBulk(`${head}\n"<img src=x onerror=alert(1)>",058,0123456789,,100,`, BANKS);
  assert.equal(r.problems.length, 0);
  assert.ok(!r.items[0].name.includes('<'));
});

test('name check: any shared word of 3+ letters, any order', () => {
  assert.equal(namesMatch('Ada Obi', 'OBI ADAEZE CHINWE'), true);
  assert.equal(namesMatch('Ada Obi', 'EZE CHIDI'), false);
  assert.equal(namesMatch('Jo Li', 'JO LI'), false);   // too short to compare: refuse rather than guess
  assert.equal(namesMatch('', 'OBI'), false);
});
