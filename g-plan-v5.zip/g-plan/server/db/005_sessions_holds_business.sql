-- G-Plan: Step 5 - verified sign-up, refresh sessions, held payments, business invoices
ALTER TABLE users ADD COLUMN registration_pending BOOLEAN NOT NULL DEFAULT FALSE;

-- Refresh tokens live in an httpOnly cookie. Only a hash is stored, and the previous hash is kept
-- so a stolen, already-used token can be detected.
ALTER TABLE sessions
  ADD COLUMN refresh_hash TEXT,
  ADD COLUMN prev_refresh_hash TEXT,
  ADD COLUMN refresh_expires_at TIMESTAMPTZ,
  ADD COLUMN rotated_at TIMESTAMPTZ;

CREATE TABLE businesses (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id   UUID NOT NULL UNIQUE REFERENCES users(id),
  name       TEXT NOT NULL,
  category   TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE payment_requests
  ADD COLUMN business_id    UUID REFERENCES businesses(id),
  ADD COLUMN invoice_number TEXT,
  ADD COLUMN customer_name  TEXT,
  ADD COLUMN items          JSONB;
CREATE UNIQUE INDEX uniq_invoice_number ON payment_requests(business_id, invoice_number) WHERE invoice_number IS NOT NULL;
CREATE INDEX idx_requests_business ON payment_requests(business_id, created_at DESC);
