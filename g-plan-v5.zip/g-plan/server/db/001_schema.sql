-- G-Plan: Step 1 - Core schema (PostgreSQL 14+)
-- Prototype / sandbox. All provider integrations are MOCK until real partners are connected.
-- Money is always stored in minor units (kobo, cents) as BIGINT. Never use floats.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------------
-- ENUMS
-- ---------------------------------------------------------------
CREATE TYPE account_type AS ENUM (
  'customer_wallet', 'goal_pot', 'fee', 'settlement', 'suspense', 'fx_position'
);
CREATE TYPE posting_direction AS ENUM ('debit', 'credit');
CREATE TYPE txn_state AS ENUM (
  'created', 'pending_authorisation', 'authorised', 'processing',
  'processing_unconfirmed', 'under_review', 'completed',
  'failed', 'cancelled', 'expired', 'reversed'
);
CREATE TYPE txn_type AS ENUM (
  'internal_transfer', 'external_transfer', 'bill_payment', 'deposit',
  'withdrawal', 'goal_contribution', 'fx_conversion', 'fee', 'reversal'
);
CREATE TYPE hold_status AS ENUM ('active', 'released', 'captured');

-- ---------------------------------------------------------------
-- REFERENCE DATA
-- ---------------------------------------------------------------
CREATE TABLE currencies (
  code        CHAR(3) PRIMARY KEY,
  name        TEXT NOT NULL,
  minor_unit  SMALLINT NOT NULL CHECK (minor_unit BETWEEN 0 AND 4)
);

INSERT INTO currencies (code, name, minor_unit) VALUES
  ('NGN', 'Nigerian Naira', 2),
  ('USD', 'US Dollar', 2),
  ('GBP', 'Pound Sterling', 2),
  ('EUR', 'Euro', 2);

-- Country profile: configurable per launch market (assumption: NGN first).
CREATE TABLE country_profiles (
  country_code       CHAR(2) PRIMARY KEY,
  name               TEXT NOT NULL,
  default_currency   CHAR(3) NOT NULL REFERENCES currencies(code),
  default_language   TEXT NOT NULL DEFAULT 'en',
  timezone           TEXT NOT NULL,
  kyc_config         JSONB NOT NULL DEFAULT '{}'::jsonb,   -- placeholder tiers/limits
  compliance_config  JSONB NOT NULL DEFAULT '{}'::jsonb,   -- placeholders only, not legal claims
  is_enabled         BOOLEAN NOT NULL DEFAULT FALSE
);

INSERT INTO country_profiles (country_code, name, default_currency, timezone, is_enabled)
VALUES ('NG', 'Nigeria', 'NGN', 'Africa/Lagos', TRUE);

-- ---------------------------------------------------------------
-- USERS
-- ---------------------------------------------------------------
CREATE TABLE users (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email          TEXT NOT NULL UNIQUE,
  phone          TEXT UNIQUE,
  password_hash  TEXT NOT NULL,
  full_name      TEXT NOT NULL,
  country_code   CHAR(2) NOT NULL REFERENCES country_profiles(country_code),
  kyc_tier       SMALLINT NOT NULL DEFAULT 0 CHECK (kyc_tier BETWEEN 0 AND 3),
  status         TEXT NOT NULL DEFAULT 'active'
                 CHECK (status IN ('active', 'restricted', 'closed')),
  mfa_enabled    BOOLEAN NOT NULL DEFAULT FALSE,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------
-- ACCOUNTS (ledger accounts)
-- ---------------------------------------------------------------
CREATE TABLE accounts (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID REFERENCES users(id),            -- NULL for system accounts
  type        account_type NOT NULL,
  currency    CHAR(3) NOT NULL REFERENCES currencies(code),
  name        TEXT NOT NULL,
  status      TEXT NOT NULL DEFAULT 'active'
              CHECK (status IN ('active', 'frozen', 'closed')),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK ( (type IN ('customer_wallet', 'goal_pot') AND user_id IS NOT NULL)
       OR (type NOT IN ('customer_wallet', 'goal_pot')) )
);
CREATE INDEX idx_accounts_user ON accounts(user_id);

-- Cached balances: performance layer ONLY. Source of truth is postings.
-- The reconciliation job must compare this table against account_balances_derived.
CREATE TABLE account_balance_cache (
  account_id      UUID PRIMARY KEY REFERENCES accounts(id),
  ledger_balance  BIGINT NOT NULL DEFAULT 0,   -- credits minus debits
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------
-- TRANSACTIONS (business-level record + state machine)
-- ---------------------------------------------------------------
CREATE TABLE transactions (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference          TEXT NOT NULL UNIQUE,          -- unique human-visible reference
  type               txn_type NOT NULL,
  state              txn_state NOT NULL DEFAULT 'created',
  initiator_user_id  UUID REFERENCES users(id),
  amount_minor       BIGINT NOT NULL CHECK (amount_minor > 0),
  currency           CHAR(3) NOT NULL REFERENCES currencies(code),
  fee_minor          BIGINT NOT NULL DEFAULT 0 CHECK (fee_minor >= 0),
  description        TEXT,
  provider           TEXT,                          -- e.g. 'mock_bank'
  provider_reference TEXT,
  is_demo            BOOLEAN NOT NULL DEFAULT TRUE, -- receipts must say "Demo" when true
  reverses_txn_id    UUID REFERENCES transactions(id),
  failure_reason     TEXT,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_txn_initiator ON transactions(initiator_user_id, created_at DESC);
CREATE INDEX idx_txn_state ON transactions(state);

-- Allowed transitions: the only legal state changes.
CREATE TABLE allowed_transitions (
  from_state txn_state NOT NULL,
  to_state   txn_state NOT NULL,
  PRIMARY KEY (from_state, to_state)
);

INSERT INTO allowed_transitions (from_state, to_state) VALUES
  ('created', 'pending_authorisation'),
  ('created', 'cancelled'),
  ('created', 'expired'),
  ('pending_authorisation', 'authorised'),
  ('pending_authorisation', 'cancelled'),
  ('pending_authorisation', 'expired'),
  ('pending_authorisation', 'failed'),
  ('authorised', 'processing'),
  ('authorised', 'cancelled'),
  ('processing', 'completed'),
  ('processing', 'failed'),
  ('processing', 'under_review'),
  ('processing', 'processing_unconfirmed'),
  ('processing_unconfirmed', 'completed'),
  ('processing_unconfirmed', 'failed'),
  ('under_review', 'processing'),
  ('under_review', 'failed'),
  ('completed', 'reversed');

CREATE TABLE transaction_state_history (
  id              BIGSERIAL PRIMARY KEY,
  transaction_id  UUID NOT NULL REFERENCES transactions(id),
  from_state      txn_state,
  to_state        txn_state NOT NULL,
  actor           TEXT NOT NULL DEFAULT 'system',   -- user id, 'system', or admin id
  note            TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_state_hist_txn ON transaction_state_history(transaction_id);

-- Enforce legal transitions and log every change automatically.
CREATE OR REPLACE FUNCTION enforce_txn_transition() RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO transaction_state_history (transaction_id, from_state, to_state)
    VALUES (NEW.id, NULL, NEW.state);
    RETURN NEW;
  END IF;

  IF NEW.state IS DISTINCT FROM OLD.state THEN
    IF NOT EXISTS (
      SELECT 1 FROM allowed_transitions
      WHERE from_state = OLD.state AND to_state = NEW.state
    ) THEN
      RAISE EXCEPTION 'Illegal transaction transition: % -> %', OLD.state, NEW.state;
    END IF;
    INSERT INTO transaction_state_history (transaction_id, from_state, to_state)
    VALUES (NEW.id, OLD.state, NEW.state);
  END IF;
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_txn_transition
  BEFORE INSERT OR UPDATE ON transactions
  FOR EACH ROW EXECUTE FUNCTION enforce_txn_transition();

-- ---------------------------------------------------------------
-- JOURNAL ENTRIES + POSTINGS (double-entry, append-only)
-- ---------------------------------------------------------------
CREATE TABLE journal_entries (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seq                 BIGSERIAL UNIQUE,              -- global ordering for hash chain
  transaction_id      UUID NOT NULL REFERENCES transactions(id),
  description         TEXT,
  reverses_entry_id   UUID REFERENCES journal_entries(id),
  prev_hash           TEXT,
  entry_hash          TEXT,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_je_txn ON journal_entries(transaction_id);

CREATE TABLE postings (
  id            BIGSERIAL PRIMARY KEY,
  entry_id      UUID NOT NULL REFERENCES journal_entries(id),
  account_id    UUID NOT NULL REFERENCES accounts(id),
  direction     posting_direction NOT NULL,
  amount_minor  BIGINT NOT NULL CHECK (amount_minor > 0),
  currency      CHAR(3) NOT NULL REFERENCES currencies(code),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_postings_account ON postings(account_id);
CREATE INDEX idx_postings_entry ON postings(entry_id);

-- Currency of a posting must match the account currency.
CREATE OR REPLACE FUNCTION check_posting_currency() RETURNS TRIGGER AS $$
DECLARE acct_currency CHAR(3);
BEGIN
  SELECT currency INTO acct_currency FROM accounts WHERE id = NEW.account_id;
  IF acct_currency IS DISTINCT FROM NEW.currency THEN
    RAISE EXCEPTION 'Posting currency % does not match account currency %',
      NEW.currency, acct_currency;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_posting_currency
  BEFORE INSERT ON postings
  FOR EACH ROW EXECUTE FUNCTION check_posting_currency();

-- Every journal entry must balance: debits = credits (checked at commit).
-- Each entry must be single-currency. FX uses two entries linked to one transaction.
CREATE OR REPLACE FUNCTION check_entry_balanced() RETURNS TRIGGER AS $$
DECLARE
  debits  BIGINT;
  credits BIGINT;
  ccy_count INT;
BEGIN
  SELECT
    COALESCE(SUM(amount_minor) FILTER (WHERE direction = 'debit'), 0),
    COALESCE(SUM(amount_minor) FILTER (WHERE direction = 'credit'), 0),
    COUNT(DISTINCT currency)
  INTO debits, credits, ccy_count
  FROM postings WHERE entry_id = NEW.entry_id;

  IF debits <> credits THEN
    RAISE EXCEPTION 'Journal entry % unbalanced: debits % credits %',
      NEW.entry_id, debits, credits;
  END IF;
  IF ccy_count > 1 THEN
    RAISE EXCEPTION 'Journal entry % mixes currencies', NEW.entry_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE CONSTRAINT TRIGGER trg_entry_balanced
  AFTER INSERT ON postings
  DEFERRABLE INITIALLY DEFERRED
  FOR EACH ROW EXECUTE FUNCTION check_entry_balanced();

-- Tamper-evident hash chain: each entry hashes its content plus the previous hash.
CREATE OR REPLACE FUNCTION chain_journal_entry() RETURNS TRIGGER AS $$
DECLARE last_hash TEXT;
BEGIN
  PERFORM pg_advisory_xact_lock(777001);   -- serialise chain writes
  SELECT entry_hash INTO last_hash FROM journal_entries ORDER BY seq DESC LIMIT 1;
  NEW.prev_hash := COALESCE(last_hash, 'GENESIS');
  NEW.entry_hash := encode(
    digest(
      NEW.prev_hash || NEW.id::text || NEW.transaction_id::text ||
      COALESCE(NEW.description, '') || NEW.created_at::text,
      'sha256'),
    'hex');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_chain_entry
  BEFORE INSERT ON journal_entries
  FOR EACH ROW EXECUTE FUNCTION chain_journal_entry();

-- Append-only: block UPDATE and DELETE on ledger tables.
CREATE OR REPLACE FUNCTION block_ledger_mutation() RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION 'Ledger is append-only. Use a compensating entry (reversal).';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_je_immutable
  BEFORE UPDATE OR DELETE ON journal_entries
  FOR EACH ROW EXECUTE FUNCTION block_ledger_mutation();

CREATE TRIGGER trg_postings_immutable
  BEFORE UPDATE OR DELETE ON postings
  FOR EACH ROW EXECUTE FUNCTION block_ledger_mutation();

-- Keep the balance cache in step with postings (reconcilable against the view below).
CREATE OR REPLACE FUNCTION update_balance_cache() RETURNS TRIGGER AS $$
DECLARE delta BIGINT;
BEGIN
  delta := CASE WHEN NEW.direction = 'credit' THEN NEW.amount_minor
                ELSE -NEW.amount_minor END;
  INSERT INTO account_balance_cache (account_id, ledger_balance)
  VALUES (NEW.account_id, delta)
  ON CONFLICT (account_id) DO UPDATE
    SET ledger_balance = account_balance_cache.ledger_balance + delta,
        updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_balance_cache
  AFTER INSERT ON postings
  FOR EACH ROW EXECUTE FUNCTION update_balance_cache();

-- ---------------------------------------------------------------
-- HOLDS (reduce available balance, not ledger balance)
-- ---------------------------------------------------------------
CREATE TABLE holds (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id      UUID NOT NULL REFERENCES accounts(id),
  transaction_id  UUID NOT NULL REFERENCES transactions(id),
  amount_minor    BIGINT NOT NULL CHECK (amount_minor > 0),
  status          hold_status NOT NULL DEFAULT 'active',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at     TIMESTAMPTZ
);
CREATE INDEX idx_holds_account_active ON holds(account_id) WHERE status = 'active';

-- ---------------------------------------------------------------
-- IDEMPOTENCY
-- ---------------------------------------------------------------
CREATE TABLE idempotency_keys (
  id              BIGSERIAL PRIMARY KEY,
  user_id         UUID NOT NULL REFERENCES users(id),
  idem_key        TEXT NOT NULL,
  request_hash    TEXT NOT NULL,           -- same key + different body = rejected
  transaction_id  UUID REFERENCES transactions(id),
  response_body   JSONB,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, idem_key)
);

-- ---------------------------------------------------------------
-- AUDIT LOG
-- ---------------------------------------------------------------
CREATE TABLE audit_log (
  id          BIGSERIAL PRIMARY KEY,
  actor_type  TEXT NOT NULL CHECK (actor_type IN ('user', 'admin', 'system')),
  actor_id    TEXT,
  action      TEXT NOT NULL,
  target_type TEXT,
  target_id   TEXT,
  ip_address  INET,
  metadata    JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_actor ON audit_log(actor_type, actor_id, created_at DESC);

CREATE TRIGGER trg_audit_immutable
  BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION block_ledger_mutation();

-- ---------------------------------------------------------------
-- VIEWS
-- ---------------------------------------------------------------
-- Source-of-truth balance derived from postings.
CREATE VIEW account_balances_derived AS
SELECT
  a.id AS account_id,
  a.currency,
  COALESCE(SUM(CASE WHEN p.direction = 'credit' THEN p.amount_minor
                    ELSE -p.amount_minor END), 0) AS ledger_balance
FROM accounts a
LEFT JOIN postings p ON p.account_id = a.id
GROUP BY a.id, a.currency;

-- Available = ledger balance minus active holds.
CREATE VIEW account_available_balance AS
SELECT
  d.account_id,
  d.currency,
  d.ledger_balance,
  d.ledger_balance - COALESCE(h.held, 0) AS available_balance
FROM account_balances_derived d
LEFT JOIN (
  SELECT account_id, SUM(amount_minor) AS held
  FROM holds WHERE status = 'active' GROUP BY account_id
) h ON h.account_id = d.account_id;

-- Reconciliation helper: any rows returned here mean cache and ledger disagree.
CREATE VIEW balance_cache_mismatches AS
SELECT d.account_id, d.ledger_balance AS derived, c.ledger_balance AS cached
FROM account_balances_derived d
LEFT JOIN account_balance_cache c ON c.account_id = d.account_id
WHERE d.ledger_balance <> COALESCE(c.ledger_balance, 0);
