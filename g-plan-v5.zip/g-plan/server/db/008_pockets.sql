-- G-Plan: Step 8 - shared "pockets": joint wallets (two people, big payments need both) and child wallets (parent controls)
CREATE TABLE pockets (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  kind               TEXT NOT NULL CHECK (kind IN ('joint','child')),
  name               TEXT NOT NULL,
  owner_id           UUID NOT NULL REFERENCES users(id),
  solo_limit_minor   BIGINT NOT NULL DEFAULT 5000000 CHECK (solo_limit_minor >= 0),   -- joint: above this the other person must approve
  weekly_limit_minor BIGINT NOT NULL DEFAULT 500000  CHECK (weekly_limit_minor >= 0), -- child: most the child can spend per week
  frozen             BOOLEAN NOT NULL DEFAULT FALSE,
  allowance_minor    BIGINT NOT NULL DEFAULT 0 CHECK (allowance_minor >= 0),          -- child: weekly top-up from the parent
  allowance_next_on  DATE,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE accounts ADD COLUMN pocket_id UUID REFERENCES pockets(id);
CREATE UNIQUE INDEX uniq_pocket_wallet ON accounts(pocket_id, currency) WHERE pocket_id IS NOT NULL;

CREATE TABLE pocket_members (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pocket_id  UUID NOT NULL REFERENCES pockets(id),
  user_id    UUID NOT NULL REFERENCES users(id),
  role       TEXT NOT NULL CHECK (role IN ('owner','partner','child')),
  status     TEXT NOT NULL DEFAULT 'invited' CHECK (status IN ('invited','active','removed','declined')),
  invited_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (pocket_id, user_id)
);
CREATE UNIQUE INDEX uniq_one_pocket_owner ON pocket_members(pocket_id) WHERE role='owner' AND status='active';
CREATE UNIQUE INDEX uniq_one_pocket_partner ON pocket_members(pocket_id) WHERE role='partner' AND status IN ('active','invited');
CREATE UNIQUE INDEX uniq_one_child_pocket ON pocket_members(user_id) WHERE role='child' AND status='active';

-- Who a child may send money to. Set only by the parent.
CREATE TABLE pocket_recipients (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pocket_id  UUID NOT NULL REFERENCES pockets(id),
  user_id    UUID NOT NULL REFERENCES users(id),
  added_by   UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (pocket_id, user_id)
);

-- Payments out of a pocket. A joint payment above the limit waits for the OTHER person.
CREATE TABLE pocket_payments (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pocket_id    UUID NOT NULL REFERENCES pockets(id),
  created_by   UUID NOT NULL REFERENCES users(id),
  client_key   TEXT NOT NULL,
  to_user_id   UUID NOT NULL REFERENCES users(id),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  note         TEXT,
  status       TEXT NOT NULL DEFAULT 'pending_approval' CHECK (status IN ('pending_approval','rejected','cancelled','executed')),
  decided_by   UUID REFERENCES users(id),
  decided_at   TIMESTAMPTZ,
  txn_id       UUID REFERENCES transactions(id),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (created_by, client_key)
);
CREATE INDEX idx_pocket_payments ON pocket_payments(pocket_id, created_at DESC);
