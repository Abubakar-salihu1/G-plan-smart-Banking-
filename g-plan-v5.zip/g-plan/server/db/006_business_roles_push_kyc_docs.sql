-- G-Plan: Step 6 - business staff roles with a shared wallet, push subscriptions, encrypted KYC documents

-- ---------- Business: members, roles, shared wallet ----------
ALTER TABLE accounts ADD COLUMN business_id UUID REFERENCES businesses(id);
CREATE UNIQUE INDEX uniq_business_wallet ON accounts(business_id, currency) WHERE business_id IS NOT NULL;

ALTER TABLE businesses ADD COLUMN approval_threshold_minor BIGINT NOT NULL DEFAULT 5000000 CHECK (approval_threshold_minor >= 0);

CREATE TABLE business_members (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id),
  user_id     UUID NOT NULL REFERENCES users(id),
  role        TEXT NOT NULL CHECK (role IN ('owner','finance','staff','auditor')),
  status      TEXT NOT NULL DEFAULT 'invited' CHECK (status IN ('invited','active','removed','declined')),
  invited_by  UUID REFERENCES users(id),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (business_id, user_id)
);
-- A person works for at most one business at a time; invitations can wait in parallel.
CREATE UNIQUE INDEX uniq_one_active_membership ON business_members(user_id) WHERE status = 'active';
CREATE UNIQUE INDEX uniq_one_owner ON business_members(business_id) WHERE role = 'owner' AND status = 'active';

-- Existing businesses: owner becomes the owner member, and the business gets its own wallet.
INSERT INTO business_members(business_id, user_id, role, status)
  SELECT id, owner_id, 'owner', 'active' FROM businesses;
INSERT INTO accounts(user_id, type, currency, name, business_id)
  SELECT owner_id, 'customer_wallet', 'NGN', 'Business wallet', id FROM businesses;

-- Payouts out of the business wallet. Large ones made by a finance manager wait for the owner.
CREATE TABLE business_payouts (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id   UUID NOT NULL REFERENCES businesses(id),
  created_by    UUID NOT NULL REFERENCES users(id),
  client_key    TEXT NOT NULL,
  kind          TEXT NOT NULL CHECK (kind IN ('internal','bank')),
  amount_minor  BIGINT NOT NULL CHECK (amount_minor > 0),
  recipient     JSONB NOT NULL,
  note          TEXT,
  status        TEXT NOT NULL DEFAULT 'pending_approval' CHECK (status IN ('pending_approval','rejected','cancelled','executed')),
  decided_by    UUID REFERENCES users(id),
  decided_at    TIMESTAMPTZ,
  txn_id        UUID REFERENCES transactions(id),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (created_by, client_key)
);
CREATE INDEX idx_payouts_business ON business_payouts(business_id, created_at DESC);

-- ---------- Push notifications ----------
CREATE TABLE push_subscriptions (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID NOT NULL REFERENCES users(id),
  session_id UUID REFERENCES sessions(id) ON DELETE CASCADE,
  endpoint   TEXT NOT NULL UNIQUE,
  p256dh     TEXT NOT NULL,
  auth       TEXT NOT NULL,
  user_agent TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_ok_at TIMESTAMPTZ
);
CREATE INDEX idx_push_user ON push_subscriptions(user_id);
ALTER TABLE notifications ADD COLUMN pushed_at TIMESTAMPTZ;
-- Anything already in the table predates push; do not send it.
UPDATE notifications SET pushed_at = now();
CREATE INDEX idx_notifications_unpushed ON notifications(created_at) WHERE pushed_at IS NULL;

-- ---------- KYC documents (encrypted at rest, reviewer access is logged, purged after retention) ----------
CREATE TABLE kyc_documents (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID NOT NULL REFERENCES users(id),
  submission_id UUID REFERENCES kyc_submissions(id),
  kind          TEXT NOT NULL CHECK (kind IN ('id_front','id_back','selfie')),
  mime          TEXT NOT NULL CHECK (mime IN ('image/jpeg','image/png')),
  size_bytes    INTEGER NOT NULL,
  sha256        TEXT NOT NULL,
  key_version   TEXT NOT NULL,
  ciphertext    BYTEA NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  purge_after   TIMESTAMPTZ
);
CREATE INDEX idx_kyc_docs_user ON kyc_documents(user_id, created_at DESC);
CREATE INDEX idx_kyc_docs_submission ON kyc_documents(submission_id);
CREATE INDEX idx_kyc_docs_purge ON kyc_documents(purge_after) WHERE purge_after IS NOT NULL;
