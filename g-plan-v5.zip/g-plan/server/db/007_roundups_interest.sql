-- G-Plan: Step 7 - round-ups into a savings goal, and DEMO savings interest
CREATE TABLE roundup_settings (
  user_id    UUID PRIMARY KEY REFERENCES users(id),
  goal_id    UUID NOT NULL REFERENCES goals(id),
  step_minor INTEGER NOT NULL DEFAULT 10000 CHECK (step_minor IN (10000, 50000, 100000)),
  enabled    BOOLEAN NOT NULL DEFAULT TRUE,
  since      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- One row per payment that has been looked at, so a payment is never rounded up twice.
CREATE TABLE roundup_log (
  txn_id       UUID PRIMARY KEY REFERENCES transactions(id),
  user_id      UUID NOT NULL REFERENCES users(id),
  amount_minor BIGINT NOT NULL CHECK (amount_minor >= 0),
  saved        BOOLEAN NOT NULL DEFAULT FALSE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_roundup_log_user ON roundup_log(user_id);
-- One interest credit per goal per month.
CREATE TABLE interest_log (
  goal_id      UUID NOT NULL REFERENCES goals(id),
  month_start  DATE NOT NULL,
  amount_minor BIGINT NOT NULL CHECK (amount_minor >= 0),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (goal_id, month_start)
);
