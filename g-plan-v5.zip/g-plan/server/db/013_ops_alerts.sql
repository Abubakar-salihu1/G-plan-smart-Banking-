-- G-Plan: Step 13 - remembers which operational problems have already been reported, so people are not spammed
CREATE TABLE ops_alerts (
  issue_key    TEXT PRIMARY KEY,
  severity     TEXT NOT NULL CHECK (severity IN ('page','warn')),
  text         TEXT NOT NULL,
  first_seen   TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_sent_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at  TIMESTAMPTZ
);
