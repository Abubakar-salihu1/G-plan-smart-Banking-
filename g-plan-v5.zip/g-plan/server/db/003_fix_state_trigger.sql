-- Fix: log state changes AFTER the transaction row exists.
DROP TRIGGER IF EXISTS trg_txn_transition ON transactions;

CREATE OR REPLACE FUNCTION enforce_txn_transition() RETURNS TRIGGER AS $$
BEGIN
  IF NEW.state IS DISTINCT FROM OLD.state THEN
    IF NOT EXISTS (
      SELECT 1 FROM allowed_transitions
      WHERE from_state = OLD.state AND to_state = NEW.state
    ) THEN
      RAISE EXCEPTION 'Illegal transaction transition: % -> %', OLD.state, NEW.state;
    END IF;
  END IF;
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_txn_transition
  BEFORE UPDATE ON transactions
  FOR EACH ROW EXECUTE FUNCTION enforce_txn_transition();

CREATE OR REPLACE FUNCTION log_txn_state() RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO transaction_state_history (transaction_id, from_state, to_state)
    VALUES (NEW.id, NULL, NEW.state);
  ELSIF NEW.state IS DISTINCT FROM OLD.state THEN
    INSERT INTO transaction_state_history (transaction_id, from_state, to_state)
    VALUES (NEW.id, OLD.state, NEW.state);
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_txn_log
  AFTER INSERT OR UPDATE ON transactions
  FOR EACH ROW EXECUTE FUNCTION log_txn_state();
