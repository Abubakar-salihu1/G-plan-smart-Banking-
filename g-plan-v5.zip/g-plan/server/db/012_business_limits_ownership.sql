-- G-Plan: Step 12 - business-wide daily limit and handing the business to a new owner
ALTER TABLE businesses ADD COLUMN daily_cap_minor BIGINT CHECK (daily_cap_minor IS NULL OR daily_cap_minor >= 0);

CREATE TABLE business_transfers (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id),
  from_user   UUID NOT NULL REFERENCES users(id),
  to_user     UUID NOT NULL REFERENCES users(id),
  keep_access BOOLEAN NOT NULL DEFAULT TRUE,     -- the old owner stays on as a finance manager
  status      TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','accepted','declined','cancelled','expired')),
  expires_at  TIMESTAMPTZ NOT NULL DEFAULT now() + interval '3 days',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  decided_at  TIMESTAMPTZ,
  CHECK (from_user <> to_user)
);
-- One offer at a time per business.
CREATE UNIQUE INDEX uniq_pending_transfer ON business_transfers(business_id) WHERE status = 'pending';
