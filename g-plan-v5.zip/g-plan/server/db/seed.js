import 'dotenv/config';
import pg from 'pg';

const client = new pg.Client({ connectionString: process.env.DATABASE_URL });
await client.connect();
const types = ['settlement', 'fee', 'suspense', 'fx_position'];
const currencies = (await client.query('SELECT code FROM currencies')).rows;
for (const { code } of currencies) {
  for (const type of types) {
    await client.query(
      `INSERT INTO accounts(type, currency, name) VALUES ($1,$2,$3)
       ON CONFLICT DO NOTHING`, [type, code, `${type} ${code}`]);
  }
}
console.log('System accounts ready.');
await client.end();
