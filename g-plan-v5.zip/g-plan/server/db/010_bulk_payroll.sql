-- G-Plan: Step 10 - bulk payouts and payroll from the business wallet
CREATE TABLE payroll_employees (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id    UUID NOT NULL REFERENCES businesses(id),
  name           TEXT NOT NULL,
  kind           TEXT NOT NULL CHECK (kind IN ('bank','internal')),
  bank_code      TEXT,
  account_number TEXT,
  email          TEXT,
  salary_minor   BIGINT NOT NULL CHECK (salary_minor > 0),
  active         BOOLEAN NOT NULL DEFAULT TRUE,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK ((kind='bank' AND bank_code IS NOT NULL AND account_number IS NOT NULL) OR (kind='internal' AND email IS NOT NULL))
);
CREATE INDEX idx_payroll_employees ON payroll_employees(business_id) WHERE active;

CREATE TABLE bulk_batches (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id  UUID NOT NULL REFERENCES businesses(id),
  created_by   UUID NOT NULL REFERENCES users(id),
  label        TEXT NOT NULL,
  source       TEXT NOT NULL CHECK (source IN ('csv','payroll')),
  run_key      TEXT,                              -- e.g. payroll:2026-10, so a month is never paid twice
  total_minor  BIGINT NOT NULL CHECK (total_minor > 0),
  item_count   INTEGER NOT NULL CHECK (item_count > 0),
  status       TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','pending_approval','running','done','rejected','cancelled')),
  executed_by  UUID REFERENCES users(id),
  risk_level   TEXT NOT NULL DEFAULT 'normal',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  decided_at   TIMESTAMPTZ
);
CREATE UNIQUE INDEX uniq_bulk_run_key ON bulk_batches(business_id, run_key) WHERE run_key IS NOT NULL;
CREATE INDEX idx_bulk_business ON bulk_batches(business_id, created_at DESC);

CREATE TABLE bulk_items (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_id       UUID NOT NULL REFERENCES bulk_batches(id),
  line           INTEGER NOT NULL,
  kind           TEXT NOT NULL CHECK (kind IN ('bank','internal')),
  name           TEXT NOT NULL,
  bank_code      TEXT,
  account_number TEXT,
  email          TEXT,
  amount_minor   BIGINT NOT NULL CHECK (amount_minor > 0),
  note           TEXT,
  status         TEXT NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','sending','sent','failed','skipped')),
  claimed_at     TIMESTAMPTZ,
  txn_id         UUID REFERENCES transactions(id),
  error          TEXT,
  UNIQUE (batch_id, line)
);
CREATE INDEX idx_bulk_items_queue ON bulk_items(batch_id, status);
