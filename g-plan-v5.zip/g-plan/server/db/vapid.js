// Prints a VAPID key pair for Web Push. Put the three values in your environment (never commit the private key).
import crypto from 'node:crypto';
const { privateKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
const jwk = privateKey.export({ format: 'jwk' });
const raw = (b64) => b64;   // JWK already uses base64url, which is what VAPID wants
const pub = Buffer.concat([Buffer.from([4]), Buffer.from(jwk.x, 'base64url'), Buffer.from(jwk.y, 'base64url')]).toString('base64url');
console.log(`VAPID_PUBLIC_KEY=${pub}`);
console.log(`VAPID_PRIVATE_KEY=${raw(jwk.d)}`);
console.log('VAPID_SUBJECT=mailto:you@your-domain.example');
