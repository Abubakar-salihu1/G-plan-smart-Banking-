-- G-Plan: Step 16 - in-app support chat between a customer and G-Plan staff
CREATE TABLE support_threads (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id          UUID NOT NULL REFERENCES users(id),
  subject          TEXT NOT NULL,
  status           TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','waiting_customer','closed')),
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_message_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_sender      TEXT NOT NULL DEFAULT 'customer' CHECK (last_sender IN ('customer','staff')),
  customer_read_at TIMESTAMPTZ,
  closed_at        TIMESTAMPTZ
);
CREATE INDEX idx_support_user ON support_threads(user_id, last_message_at DESC);
CREATE INDEX idx_support_queue ON support_threads(last_message_at) WHERE status = 'open';

CREATE TABLE support_messages (
  id         BIGSERIAL PRIMARY KEY,
  thread_id  UUID NOT NULL REFERENCES support_threads(id),
  sender     TEXT NOT NULL CHECK (sender IN ('customer','staff')),
  staff_id   UUID REFERENCES users(id),
  body       TEXT NOT NULL CHECK (char_length(body) BETWEEN 1 AND 2000),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_support_messages ON support_messages(thread_id, id);
