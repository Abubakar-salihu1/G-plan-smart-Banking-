-- G-Plan: Step 11 - one-time recovery codes for when the second factor (phone or authenticator) is lost
CREATE TABLE recovery_codes (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id),
  code_hash   TEXT NOT NULL,          -- HMAC of the code, never the code itself
  key_version TEXT NOT NULL,
  used_at     TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_recovery_user ON recovery_codes(user_id) WHERE used_at IS NULL;
