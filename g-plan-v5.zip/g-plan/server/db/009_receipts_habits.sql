-- G-Plan: Step 9 - receipts (only the typed-up details are kept, never the photo) and habit alerts
CREATE TABLE receipts (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id),
  merchant    TEXT NOT NULL,
  total_minor BIGINT NOT NULL CHECK (total_minor > 0),
  spent_on    DATE NOT NULL,
  category    TEXT NOT NULL,
  note        TEXT,
  txn_id      UUID REFERENCES transactions(id),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_receipts_user ON receipts(user_id, spent_on DESC);
-- Only to rate-limit reading photos with the AI reader. No image or text is kept.
CREATE TABLE receipt_scans (
  id         BIGSERIAL PRIMARY KEY,
  user_id    UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_receipt_scans ON receipt_scans(user_id, created_at DESC);

-- Habit alerts: each payment is looked at once.
CREATE TABLE habit_alert_log (
  txn_id     UUID PRIMARY KEY REFERENCES transactions(id),
  alerted    TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE alert_prefs (
  user_id      UUID PRIMARY KEY REFERENCES users(id),
  habit_alerts BOOLEAN NOT NULL DEFAULT TRUE,
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
