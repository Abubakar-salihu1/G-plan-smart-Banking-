// Usage: node db/make-admin.js you@example.com admin|support|ops|compliance|customer
import 'dotenv/config';
import pg from 'pg';

const [email, role] = process.argv.slice(2);
const roles = ['customer', 'support', 'ops', 'compliance', 'admin'];
if (!email || !roles.includes(role)) {
  console.error('Usage: npm run make-admin -- you@example.com admin|support|ops|compliance|customer');
  process.exit(1);
}
const client = new pg.Client({ connectionString: process.env.DATABASE_URL });
await client.connect();
const r = await client.query('UPDATE users SET role=$1 WHERE email=$2 RETURNING email, role', [role, email.toLowerCase()]);
console.log(r.rowCount ? `Done: ${r.rows[0].email} is now ${r.rows[0].role}` : 'No user found with that email.');
await client.end();
