-- G-Plan: Step 15 - direct debits: a business collects from a customer's wallet under a mandate the customer approved
CREATE TABLE mandates (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id        UUID NOT NULL REFERENCES businesses(id),
  payer_id           UUID NOT NULL REFERENCES users(id),
  created_by         UUID NOT NULL REFERENCES users(id),
  label              TEXT NOT NULL,                       -- what the customer sees: "Gym membership"
  status             TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','paused','cancelled','declined','expired')),
  max_amount_minor   BIGINT NOT NULL CHECK (max_amount_minor > 0),
  fixed_amount_minor BIGINT CHECK (fixed_amount_minor IS NULL OR (fixed_amount_minor > 0 AND fixed_amount_minor <= max_amount_minor)),
  frequency          TEXT NOT NULL CHECK (frequency IN ('weekly','monthly','quarterly')),
  notice_days        INTEGER NOT NULL DEFAULT 3 CHECK (notice_days BETWEEN 2 AND 14),
  start_on           DATE NOT NULL,
  end_on             DATE,
  failures_in_a_row  INTEGER NOT NULL DEFAULT 0,
  approved_at        TIMESTAMPTZ,
  cancelled_at       TIMESTAMPTZ,
  cancelled_by       UUID REFERENCES users(id),
  expires_at         TIMESTAMPTZ NOT NULL DEFAULT now() + interval '14 days',   -- an unanswered request lapses
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (business_id IS NOT NULL AND payer_id <> created_by)
);
CREATE INDEX idx_mandates_payer ON mandates(payer_id, status);
CREATE INDEX idx_mandates_business ON mandates(business_id, created_at DESC);

CREATE TABLE mandate_collections (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  mandate_id     UUID NOT NULL REFERENCES mandates(id),
  due_on         DATE NOT NULL,
  amount_minor   BIGINT NOT NULL CHECK (amount_minor > 0),
  status         TEXT NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled','collecting','paid','failed','cancelled')),
  notice_sent_at TIMESTAMPTZ,
  claimed_at     TIMESTAMPTZ,
  txn_id         UUID REFERENCES transactions(id),
  error          TEXT,
  created_by     UUID REFERENCES users(id),             -- null when scheduled automatically from a fixed-amount mandate
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (mandate_id, due_on)
);
CREATE INDEX idx_collections_due ON mandate_collections(due_on) WHERE status = 'scheduled';
