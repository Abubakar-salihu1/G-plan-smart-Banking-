-- G-Plan: Step 2 - savings goals + system account uniqueness

-- Only one system account per (type, currency).
CREATE UNIQUE INDEX uniq_system_account
  ON accounts (type, currency) WHERE user_id IS NULL;

CREATE TABLE goals (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID NOT NULL REFERENCES users(id),
  account_id    UUID NOT NULL UNIQUE REFERENCES accounts(id),  -- the goal_pot ledger account
  name          TEXT NOT NULL,
  target_minor  BIGINT NOT NULL CHECK (target_minor > 0),
  currency      CHAR(3) NOT NULL REFERENCES currencies(code),
  deadline      DATE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_goals_user ON goals(user_id);
