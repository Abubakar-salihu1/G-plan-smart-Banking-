-- G-Plan: Step 14 - optional monthly "your statement is ready" email
ALTER TABLE alert_prefs ADD COLUMN statement_email BOOLEAN NOT NULL DEFAULT FALSE;   -- opt-in: email is not a private channel
CREATE TABLE statement_mail_log (
  user_id UUID NOT NULL REFERENCES users(id),
  month   TEXT NOT NULL,                       -- the statement month, YYYY-MM
  sent_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, month)
);
