// Re-encrypts stored secrets with the CURRENT key version.
// Steps: add the new key to DATA_KEYS, set DATA_KEY_CURRENT to it (keep old keys listed), run this,
// then remove old keys only after it reports 0 remaining.
import 'dotenv/config';
import pg from 'pg';
import { encrypt, decrypt, keyVersionOf, currentKeyVersion } from '../src/utils/crypto.js';

const client = new pg.Client({ connectionString: process.env.DATABASE_URL });
await client.connect();
let rotated = 0;
for (const col of ['totp_secret', 'totp_pending']) {
  const rows = (await client.query(`SELECT id, ${col} AS v FROM users WHERE ${col} IS NOT NULL`)).rows;
  for (const r of rows) {
    if (keyVersionOf(r.v) === currentKeyVersion()) continue;
    await client.query(`UPDATE users SET ${col}=$1 WHERE id=$2`, [encrypt(decrypt(r.v)), r.id]);
    rotated++;
  }
}
console.log(`Rotated ${rotated} secret(s) to key version ${currentKeyVersion()}.`);
await client.end();
