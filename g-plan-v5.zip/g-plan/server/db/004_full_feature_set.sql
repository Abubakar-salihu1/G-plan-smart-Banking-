-- G-Plan: Step 4 - full feature set (sessions, MFA, passkeys, bills, requests, cards,
-- budgets, KYC, cheques, services, disputes, reversals, risk, notifications, RBAC)
-- Runs inside one transaction: if anything fails, nothing is applied.

ALTER TYPE txn_type ADD VALUE IF NOT EXISTS 'card_payment';
ALTER TYPE txn_type ADD VALUE IF NOT EXISTS 'international_transfer';
ALTER TYPE txn_type ADD VALUE IF NOT EXISTS 'cheque_deposit';

ALTER TABLE users
  ADD COLUMN role TEXT NOT NULL DEFAULT 'customer'
    CHECK (role IN ('customer','support','ops','compliance','admin')),
  ADD COLUMN totp_secret TEXT,
  ADD COLUMN totp_pending TEXT,
  ADD COLUMN mfa_method TEXT CHECK (mfa_method IN ('totp','sms','email')),
  ADD COLUMN email_verified_at TIMESTAMPTZ,
  ADD COLUMN phone_verified_at TIMESTAMPTZ,
  ADD COLUMN terms_accepted_at TIMESTAMPTZ,
  ADD COLUMN failed_logins INT NOT NULL DEFAULT 0,
  ADD COLUMN locked_until TIMESTAMPTZ,
  ADD COLUMN last_login_at TIMESTAMPTZ;

ALTER TABLE transactions
  ADD COLUMN category TEXT,
  ADD COLUMN meta JSONB NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN risk_level TEXT NOT NULL DEFAULT 'normal';
CREATE INDEX idx_txn_category ON transactions(category);

CREATE TABLE sessions (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID NOT NULL REFERENCES users(id),
  device_id    TEXT,
  user_agent   TEXT,
  ip           TEXT,
  method       TEXT NOT NULL DEFAULT 'password',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  revoked_at   TIMESTAMPTZ
);
CREATE INDEX idx_sessions_user ON sessions(user_id, created_at DESC);

CREATE TABLE login_events (
  id          BIGSERIAL PRIMARY KEY,
  user_id     UUID REFERENCES users(id),
  email       TEXT,
  success     BOOLEAN NOT NULL,
  method      TEXT,
  reason      TEXT,
  ip          TEXT,
  user_agent  TEXT,
  device_id   TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_login_events_user ON login_events(user_id, created_at DESC);

CREATE TABLE passkeys (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID NOT NULL REFERENCES users(id),
  credential_id TEXT NOT NULL UNIQUE,
  public_key    TEXT NOT NULL,
  counter       BIGINT NOT NULL DEFAULT 0,
  transports    TEXT[],
  label         TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_used_at  TIMESTAMPTZ
);

CREATE TABLE auth_challenges (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id),
  challenge   TEXT NOT NULL,
  purpose     TEXT NOT NULL,
  expires_at  TIMESTAMPTZ NOT NULL
);

CREATE TABLE beneficiaries (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        UUID NOT NULL REFERENCES users(id),
  kind           TEXT NOT NULL CHECK (kind IN ('internal','external','international')),
  name           TEXT NOT NULL,
  email          TEXT,
  phone          TEXT,
  bank_code      TEXT,
  bank_name      TEXT,
  account_number TEXT,
  country        TEXT,
  currency       CHAR(3),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_beneficiaries_user ON beneficiaries(user_id);

CREATE TABLE scheduled_payments (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID NOT NULL REFERENCES users(id),
  biller_code  TEXT NOT NULL,
  payee_ref    TEXT NOT NULL,
  payee_name   TEXT,
  bundle_id    TEXT,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  frequency    TEXT NOT NULL CHECK (frequency IN ('once','weekly','monthly')),
  next_run_on  DATE NOT NULL,
  status       TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','paused','cancelled','completed')),
  last_status  TEXT,
  last_run_at  TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_sched_due ON scheduled_payments(status, next_run_on);

CREATE TABLE savings_rules (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID NOT NULL REFERENCES users(id),
  goal_id      UUID NOT NULL REFERENCES goals(id),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  frequency    TEXT NOT NULL CHECK (frequency IN ('weekly','monthly')),
  next_run_on  DATE NOT NULL,
  status       TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','paused','cancelled')),
  last_status  TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_rules_due ON savings_rules(status, next_run_on);

CREATE TABLE payment_requests (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id  UUID NOT NULL REFERENCES users(id),
  payer_id      UUID REFERENCES users(id),
  payer_email   TEXT,
  amount_minor  BIGINT NOT NULL CHECK (amount_minor > 0),
  currency      CHAR(3) NOT NULL DEFAULT 'NGN',
  note          TEXT,
  token         TEXT NOT NULL UNIQUE,
  status        TEXT NOT NULL DEFAULT 'pending'
                CHECK (status IN ('pending','paying','paid','declined','cancelled','expired')),
  split_group   UUID,
  paid_txn_id   UUID REFERENCES transactions(id),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at    TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '14 days')
);
CREATE INDEX idx_requests_requester ON payment_requests(requester_id);
CREATE INDEX idx_requests_payer ON payment_requests(payer_id);

CREATE TABLE cards (
  id                     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                UUID NOT NULL REFERENCES users(id),
  label                  TEXT NOT NULL,
  kind                   TEXT NOT NULL DEFAULT 'virtual' CHECK (kind IN ('virtual','physical')),
  last4                  CHAR(4) NOT NULL,
  expiry                 TEXT NOT NULL,
  status                 TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','frozen','cancelled')),
  physical_status        TEXT,
  monthly_limit_minor    BIGINT NOT NULL DEFAULT 20000000 CHECK (monthly_limit_minor > 0),
  online_enabled         BOOLEAN NOT NULL DEFAULT TRUE,
  international_enabled  BOOLEAN NOT NULL DEFAULT FALSE,
  blocked_categories     TEXT[] NOT NULL DEFAULT '{}',
  created_at             TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_cards_user ON cards(user_id);

CREATE TABLE notifications (
  id         BIGSERIAL PRIMARY KEY,
  user_id    UUID NOT NULL REFERENCES users(id),
  title      TEXT NOT NULL,
  body       TEXT,
  kind       TEXT,
  read_at    TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_notifications_user ON notifications(user_id, created_at DESC);

CREATE TABLE budgets (
  user_id             UUID NOT NULL REFERENCES users(id),
  category            TEXT NOT NULL,
  monthly_limit_minor BIGINT NOT NULL CHECK (monthly_limit_minor > 0),
  PRIMARY KEY (user_id, category)
);

CREATE TABLE kyc_submissions (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        UUID NOT NULL REFERENCES users(id),
  tier_requested SMALLINT NOT NULL CHECK (tier_requested BETWEEN 1 AND 3),
  id_type        TEXT NOT NULL,
  id_last4       CHAR(4) NOT NULL,          -- full ID numbers are never stored
  status         TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  reviewed_by    UUID REFERENCES users(id),
  reviewed_at    TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE cheque_deposits (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID NOT NULL REFERENCES users(id),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  payer_name   TEXT NOT NULL,
  cheque_last4 CHAR(4),
  status       TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  reviewed_by  UUID REFERENCES users(id),
  reviewed_at  TIMESTAMPTZ,
  txn_id       UUID REFERENCES transactions(id),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE service_requests (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID NOT NULL REFERENCES users(id),
  type       TEXT NOT NULL,
  details    JSONB NOT NULL DEFAULT '{}'::jsonb,
  status     TEXT NOT NULL DEFAULT 'received' CHECK (status IN ('received','in_progress','done','rejected')),
  handled_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE disputes (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL REFERENCES users(id),
  transaction_id  UUID NOT NULL REFERENCES transactions(id),
  reason          TEXT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','resolved','rejected')),
  resolution_note TEXT,
  handled_by      UUID REFERENCES users(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Maker-checker: one staff member requests a reversal, a DIFFERENT admin approves it.
CREATE TABLE reversal_requests (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id UUID NOT NULL REFERENCES transactions(id),
  requested_by   UUID NOT NULL REFERENCES users(id),
  approved_by    UUID REFERENCES users(id),
  status         TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  reason         TEXT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  decided_at     TIMESTAMPTZ
);

CREATE TABLE risk_events (
  id             BIGSERIAL PRIMARY KEY,
  user_id        UUID REFERENCES users(id),
  transaction_id UUID REFERENCES transactions(id),
  level          TEXT NOT NULL,
  reasons        JSONB NOT NULL DEFAULT '[]'::jsonb,
  reviewed_by    UUID REFERENCES users(id),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_risk_unreviewed ON risk_events(reviewed_by, created_at DESC);

-- One-time codes delivered by SMS or email (only a hash of the code is stored).
CREATE TABLE otp_codes (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id),
  purpose     TEXT NOT NULL,
  channel     TEXT NOT NULL CHECK (channel IN ('sms','email')),
  code_hash   TEXT NOT NULL,
  attempts    INT NOT NULL DEFAULT 0,
  expires_at  TIMESTAMPTZ NOT NULL,
  consumed_at TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_otp_user ON otp_codes(user_id, purpose, created_at DESC);

-- Consent records (privacy / terms) with the version the user accepted.
CREATE TABLE consents (
  id         BIGSERIAL PRIMARY KEY,
  user_id    UUID NOT NULL REFERENCES users(id),
  kind       TEXT NOT NULL,
  version    TEXT NOT NULL,
  granted    BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- AML cases raised by transaction monitoring and name screening. Reviewed by compliance staff.
CREATE TABLE aml_cases (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        UUID REFERENCES users(id),
  transaction_id UUID REFERENCES transactions(id),
  kind           TEXT NOT NULL,
  details        JSONB NOT NULL DEFAULT '{}'::jsonb,
  status         TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','cleared','escalated')),
  reviewed_by    UUID REFERENCES users(id),
  reviewed_at    TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_aml_open ON aml_cases(status, created_at DESC);

-- Tamper-evident ordering for the ledger chain. chain_no is assigned under a lock,
-- so the order is exactly the order rows were committed in.
ALTER TABLE journal_entries ADD COLUMN chain_no BIGINT;
CREATE UNIQUE INDEX uniq_journal_chain_no ON journal_entries(chain_no) WHERE chain_no IS NOT NULL;

CREATE OR REPLACE FUNCTION chain_journal_entry() RETURNS TRIGGER AS $$
DECLARE last_hash TEXT; last_no BIGINT;
BEGIN
  PERFORM pg_advisory_xact_lock(777001);
  SELECT entry_hash, chain_no INTO last_hash, last_no
    FROM journal_entries WHERE chain_no IS NOT NULL ORDER BY chain_no DESC LIMIT 1;
  NEW.chain_no := COALESCE(last_no, 0) + 1;
  NEW.prev_hash := COALESCE(last_hash, 'GENESIS');
  NEW.entry_hash := encode(
    digest(
      NEW.prev_hash || NEW.id::text || NEW.transaction_id::text ||
      COALESCE(NEW.description, '') || NEW.created_at::text,
      'sha256'),
    'hex');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Audit log gets the same hash chain.
ALTER TABLE audit_log
  ADD COLUMN chain_no BIGINT,
  ADD COLUMN prev_hash TEXT,
  ADD COLUMN entry_hash TEXT;

CREATE OR REPLACE FUNCTION chain_audit_entry() RETURNS TRIGGER AS $$
DECLARE last_hash TEXT; last_no BIGINT;
BEGIN
  PERFORM pg_advisory_xact_lock(777002);
  SELECT entry_hash, chain_no INTO last_hash, last_no
    FROM audit_log WHERE chain_no IS NOT NULL ORDER BY chain_no DESC LIMIT 1;
  NEW.chain_no := COALESCE(last_no, 0) + 1;
  NEW.prev_hash := COALESCE(last_hash, 'GENESIS');
  NEW.entry_hash := encode(
    digest(
      NEW.prev_hash || NEW.id::text || NEW.actor_type || COALESCE(NEW.actor_id, '') ||
      NEW.action || COALESCE(NEW.target_id, '') || NEW.created_at::text,
      'sha256'),
    'hex');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_audit_chain
  BEFORE INSERT ON audit_log
  FOR EACH ROW EXECUTE FUNCTION chain_audit_entry();

-- Integrity checks: return the first broken chain position, or NULL when intact.
CREATE OR REPLACE FUNCTION verify_ledger_chain() RETURNS BIGINT AS $$
DECLARE r RECORD; prev TEXT := 'GENESIS'; calc TEXT;
BEGIN
  FOR r IN SELECT * FROM journal_entries WHERE chain_no IS NOT NULL ORDER BY chain_no LOOP
    calc := encode(digest(prev || r.id::text || r.transaction_id::text ||
            COALESCE(r.description, '') || r.created_at::text, 'sha256'), 'hex');
    IF r.prev_hash IS DISTINCT FROM prev OR r.entry_hash IS DISTINCT FROM calc THEN
      RETURN r.chain_no;
    END IF;
    prev := r.entry_hash;
  END LOOP;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION verify_audit_chain() RETURNS BIGINT AS $$
DECLARE r RECORD; prev TEXT := 'GENESIS'; calc TEXT;
BEGIN
  FOR r IN SELECT * FROM audit_log WHERE chain_no IS NOT NULL ORDER BY chain_no LOOP
    calc := encode(digest(prev || r.id::text || r.actor_type || COALESCE(r.actor_id, '') ||
            r.action || COALESCE(r.target_id, '') || r.created_at::text, 'sha256'), 'hex');
    IF r.prev_hash IS DISTINCT FROM prev OR r.entry_hash IS DISTINCT FROM calc THEN
      RETURN r.chain_no;
    END IF;
    prev := r.entry_hash;
  END LOOP;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;
