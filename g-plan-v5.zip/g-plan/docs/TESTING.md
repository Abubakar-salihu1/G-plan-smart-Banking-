# Testing and penetration testing

## What runs automatically
`cd server && npm test` (use a throwaway database). It covers:
- **Ledger:** double-spend under concurrency, idempotent replays, insufficient funds, holds, provider decline, provider timeout then resolution, reversals (and refusal when funds are spent), currency conversion, immutability, state history, hash-chain integrity.
- **Held payments:** reserved but not posted, approve once, decline returns the money, replays do not double-pay, provider is not called before approval.
- **Sign-up and sessions:** same reply for existing emails, email confirmation needed, pre-registration hijack fails, scrypt storage and bcrypt upgrade, cookie flags, refresh rotation and replay detection.
- **Business:** identity check first, server-computed invoice totals, only the owner can cancel, an invoice is paid once.
- **Security (over HTTP):** unauthenticated access, weak passwords, missing consent, no password hashes in responses, account lockout, forged and revoked tokens, customer blocked from admin, cross-customer data access, SQL-injection-style input, security headers, a payment request that cannot be paid twice.

GitHub Actions (`.github/workflows/ci.yml`) runs the tests plus `npm audit` on every push.

## What a penetration test is, and what this project cannot do for you
A penetration test is a **human expert, with your written permission, trying to break the system**. No script or AI can replace it, and nobody can honestly claim "pen tested" without one. Before launch, hire a reputable independent firm.

### Prepare
1. A staging copy with test data (never real customer data).
2. Written scope and permission: which URLs, accounts and test types are allowed.
3. Accounts for each role: customer (two of them), support, ops, compliance, admin.
4. This repository and `docs/SECURITY.md`, so testers can focus on real risk.

### Ask them to cover (OWASP ASVS and Top 10)
Authentication and session handling, broken access control (IDOR between customers, role escalation, maker-checker bypass), injection, race conditions on payments and request payments, idempotency abuse, business-logic abuse (limit evasion, structuring), OTP and passkey flows, rate-limit bypass, file and export features, CSP and headers, dependency vulnerabilities, secrets handling, infrastructure and database exposure.

### After the test
Fix findings by severity, re-test the fixes, keep the report, and repeat at least yearly and after major changes.

## Manual checks you can do now
- Try a second customer's transaction reference while signed in as someone else (expect not found).
- Sign out on one device and reuse the old session (expect rejected).
- Send the same payment twice with one idempotency key (expect one payment).
- Run `SELECT verify_ledger_chain(), verify_audit_chain();` (expect two NULLs).

## Restore drill (new)
`scripts/restore-drill.sh` backs up a database, restores it into a throwaway database, compares row counts and runs the ledger and audit checks. The `restore-drill` CI job runs it on every change. It has not been run yet: pg_dump and PostgreSQL were not available when it was written, so expect to fix small things the first time.

## Browser tests (new)
`e2e/` holds Playwright tests that click through the real app: sign-up, turning on two-step and using a recovery code, sending money, the skip link and language switch, and automated accessibility scans (axe) of the main screens. Run locally: build the client, migrate a database, then `cd e2e && npm install && npx playwright install --with-deps chromium && npm test`. CI runs them after the server tests (`.github/workflows/ci.yml`). **They have not been run yet**: they were written without a browser or database. Expect to fix selectors the first time. Automated accessibility scans catch only part of the problems, so still test with a screen reader.

## Added in v5
- Client checks (no browser needed): `npm run check:i18n` and `npm run check:a11y` in `client`.
- Pure tests (no database): `tests/providers.test.js` (Flutterwave against a stubbed network), `tests/uploads-push-business.test.js` (image checks and metadata removal, photo encryption, push endpoint safety, role rules, payout approval rule), `tests/config.test.js`.
- Pure tests also: `tests/passwords.test.js`, `tests/tax-summary.test.js`, `tests/mandates.test.js`, `tests/support.test.js`, `tests/ops.test.js`, `tests/limits.test.js`, `tests/recovery.test.js`, `tests/bulk.test.js`, `tests/habits-receipts.test.js`, `tests/pockets.test.js`, `tests/savings.test.js`, `tests/assistant-actions.test.js`.
- Database tests: `tests/mandates-db.test.js` (direct debits), `tests/support-db.test.js` (support chat), the end of `tests/bulk-db.test.js` covers the stuck-money snapshot and finishing a large batch in one time budget (written, not run); the end of `tests/business.test.js` now covers the shared business limit and ownership handover (written, not run), `tests/recovery-db.test.js` (recovery codes), `tests/bulk-db.test.js` (bulk and payroll sending), `tests/habits-db.test.js` (habit alerts), `tests/pockets-db.test.js` (pocket isolation and membership), `tests/savings-db.test.js` (round-ups), `tests/business.test.js` (shared wallet isolation, payouts, membership rules, concurrent approval, photo storage and purge). Written but not yet run.
