# Security: what is built, what is not

G-Plan is a **prototype**. This page is honest about both columns. Nothing here is a certification.

## Built into the code
| Area | What exists |
|---|---|
| Sign-up and sign-in | Email is confirmed with a code before an account can be used. Sign-up replies are identical whether or not the email exists. Passwords use scrypt (OWASP parameters), old bcrypt hashes upgrade on sign-in, strength rule, consent record, timing equalised for unknown emails, lock after 5 wrong attempts for 15 minutes, login history for every attempt, forgot-password by emailed code that signs out every device |
| Sessions | A 15-minute access token held in memory only (never in browser storage), renewed from an httpOnly, SameSite=Strict refresh cookie that rotates on every use. Replaying an old refresh token ends the session. Tokens are pinned to algorithm, issuer and audience. Sessions can be revoked, and a signed-out token stops working immediately |
| Two-step verification | Authenticator app (RFC 6238 TOTP), or one-time codes by SMS or email. Codes are stored hashed, expire in 5 minutes, allow 5 tries. TOTP secrets are encrypted at rest |
| Passkeys | WebAuthn (fingerprint, face, device PIN) verified server-side |
| Payment authorisation | Review, then password re-entry, then a verification code when the risk rules ask for it, then process, then receipt. Always checked on the server |
| Held payments | A payment the risk rules flag as `review` is held: the money is reserved, nothing is sent, and a compliance reviewer approves or declines it from the admin console. Declining returns the money. Set `REVIEW_HOLD=false` to only flag instead of hold |
| Fraud rules | Explainable rules: new device, large amount, rapid payments, most of balance. States: normal, review, additional verification. Each decision lists its reasons. Compliance staff can review them |
| AML monitoring | Possible structuring and rapid in-and-out patterns open cases. Name screening runs against a **demo placeholder list** only |
| Ledger integrity | Double-entry, append-only, balanced at commit, hash-chained. `verify_ledger_chain()` and `verify_audit_chain()` detect tampering. A job checks them every 6 hours and raises an alert |
| Money safety | Server-side validation, row locks, idempotency keys, holds, unique references, state machine enforced in the database |
| Access control | Roles with a permission matrix. No role can do everything. Reversals need a second, different administrator (maker-checker). Every admin view and action is audit-logged |
| Data protection | Field encryption with versioned keys and a rotation script. Full ID numbers and card numbers are never stored. Data export and account closure |
| Web hardening | Helmet and a strict Content-Security-Policy, rate limits, request size limits, parameterised SQL only, CSV formula-injection guard |
| Monitoring | Health and readiness endpoints, Prometheus-style metrics (token protected), structured request logs without bodies, alert webhook |
| Backups | Encrypted backup and restore scripts with retention (`scripts/`) |

## NOT built, and cannot be built by code alone
- **Real payment, bank, card and KYC integrations.** The code has adapter points. A Paystack adapter exists but is untested and disabled by default. Real providers need contracts, credentials, and a licensed entity.
- **Licences and approvals.** A business that holds or moves customers' money needs the proper regulatory authorisation. G-Plan has none and must not claim any.
- **A real sanctions or PEP screening source.** The bundled list is a placeholder.
- **Independent penetration testing, a security audit, PCI DSS assessment.** These are done by qualified people. `docs/TESTING.md` explains how to prepare and what to ask for.
- **Managed key storage (HSM or cloud KMS), WAF, DDoS protection, 24/7 monitoring staff, an incident-response team.**

## Production start-up guard
With `NODE_ENV=production` the server refuses to start if `JWT_SECRET` is a placeholder or shorter than 32 characters, if `DATA_KEYS` is missing, or if SMS and email are still mock while demo mode is off (otherwise login codes would go to the logs). Behind a proxy, set `TRUST_PROXY=1`, otherwise rate limits see every user as one IP.

## Known limitations of this prototype (fix before real use)
1. Cookie sessions only work when the app and the API share one origin (as in this setup). Putting them on different domains needs extra CSRF work.
2. TOTP codes can be reused inside their 30-second window.
3. Rate limits and counters live in server memory, so they reset on restart and are per instance. Use a shared store (Redis).
4. Encryption keys come from environment variables. Use a secrets manager or KMS and rotate on a schedule.
5. No device fingerprinting beyond a random device id, no IP reputation, no behavioural biometrics.
6. No email or SMS provider is verified end to end. In mock mode, codes are shown on screen in demo mode only.
7. Recovery codes and account recovery flows are not built yet.
8. Staff accounts do not require two-step verification unless `ADMIN_REQUIRE_MFA=true` (turn it on).
9. Placeholder thresholds in `server/src/config.js` (limits, step-up amounts) are not regulatory figures.
10. A few non-money audit writes are best-effort and could be lost if the database is briefly unavailable.
11. scrypt is strong but Argon2id is the usual first choice. It needs a native add-on, so scrypt was chosen to keep installs simple.
12. Business roles, the shared wallet and approvals have database tests (`tests/business.test.js`) that were written but not run, because no PostgreSQL was available when they were written. Run them before relying on them.
13. Provider adapters for real money (Paystack, Flutterwave) are untested against the live APIs. Passkeys have not been tried on a real device.
See `docs/V2-REVIEW.md` for a line-by-line comparison with the reviewed v2 archive.

14. ID photos, if you switch them on (`KYC_DOCUMENTS=on`), are personal data of the most sensitive kind. They are encrypted with your `DATA_KEYS` key ring, stripped of location data, readable only by KYC reviewers (each view is audit-logged) and deleted `KYC_DOC_RETENTION_DAYS` (default 30) days after a decision. Whether 30 days is legal for you is a decision for your compliance officer, since some rules require keeping KYC records for years. Prefer a KYC provider that holds them for you.
15. Push alerts send only the alert title, over the browser vendor's push service, which sees that a message was sent. Subscriptions stop when the session is signed out or revoked. Only known push-service hosts are accepted, to stop a user pointing the server at an internal address.
16. Photos upload as raw bytes with a size limit, a pixel limit, a file-signature check and a rate limit. There is no antivirus scan.

17. Child wallets: the child is an ordinary verified G-Plan user who joins the parent's pocket. G-Plan does not check anyone's age, and a child's own personal wallet is outside the pocket and outside parental control. Whether a minor may hold an account, and what consent is needed, is a legal question for your lawyer before launch.
18. Joint and child pockets have database tests (`tests/pockets-db.test.js`) that were written but not run.

19. Receipt scanning sends the photo to Anthropic's API (only with the person's agreement, only when `ANTHROPIC_API_KEY` is set). The photo is metadata-stripped, never stored by G-Plan, and the reply is reduced to four checked fields. Check Anthropic's data terms for your own compliance needs. Receipts hold what was bought, which can be personal.
20. Habit alerts are simple rules on the person's own payments, not a fraud system. They can miss things and can raise false alarms. Fraud checks stay in `services/risk.js`.

21. Bulk and payroll send each item as its own payment under the starting person's limits. The daily limits are per person, not per business, so a large payroll can hit the limit and leave some items unpaid (they are listed with the reason). Raise the business owner's KYC tier and limits through the normal process, and test your real payroll size in the provider's sandbox first.
22. With a live provider, each bank account name is compared with the name in the file and a mismatch is not paid. The comparison is deliberately loose (one shared word) and is a safeguard against typos, not against fraud. Payroll account numbers are stored as typed so the next month can be prepared.
23. Bulk sending has database tests (`tests/bulk-db.test.js`) that were written but not run.

24. Recovery codes let someone past two-step verification at sign-in and password reset, so they must be kept as carefully as the phone: offline, on paper. Each works once, is stored only as a keyed hash, and every use alerts the person and is audit-logged. They are not accepted for approving payments. Anyone who has the password AND a code can get in, which is the intended trade-off against being locked out forever. People who turned on two-step before this version have no codes until they make a set in Security. If someone loses both the phone and the codes, recovery is a support process (identity checks by a person) that is not built yet.
25. The browser tests (`e2e/`) and the recovery-code database tests were written but not run.

26. Business limits now follow the OWNER's verification level, not the sender's. This also means payouts no longer count against the sender's personal daily limit. Handing the business to a new owner changes the limits to the new owner's level, and moves the business wallet's account record to them. Transferring ownership needs two-step verification on for both people, and the old owner can stay as a finance manager or leave. A business still has exactly one owner, and the offer expires after 3 days. This is not a legal transfer of the business itself, only of control of the G-Plan account.
27. A bulk or payroll batch that started under the old rules finishes under the new limits, so some items may be refused for exceeding the shared daily total.

28. The watchdog sends alerts to a webhook. If nobody is reading that channel, or the webhook URL is unset, problems are only logged. It runs inside the app server, so if the whole server is down it cannot tell you: keep an EXTERNAL uptime monitor on `/api/ready`. With more than one server instance an alert may be sent once per instance.
29. The Recheck button asks the provider again and settles the payment on a definite answer only. It cannot create money or force a result, and every press is audit-logged.

30. Direct debits here are a G-Plan-only feature between a business and a customer, not the Nigerian bank direct-debit scheme (NIBSS e-mandate). The protections are the customer's approval, a cap, notice, one collection per period, cancel-any-time and automatic pause. There is no refund-guarantee flow yet: a customer who disputes a collection uses the normal dispute process.
31. The support chat is read by every staff member with the support role. The server blocks messages that look like card numbers, passwords, PINs or codes, but this is a safety net and not a guarantee. Chat text is stored unencrypted in the database like other customer content, so do not use it for secrets.
32. Argon2id needs the optional package `@node-rs/argon2`. If it fails to install, passwords stay on scrypt and the server logs a warning at start. Existing hashes are upgraded one at a time as people sign in. The real hashing has not been exercised here: run `npm test` where the package is installed.
33. The monthly statement email contains no amounts or transactions by design. The yearly summary is a summary of activity in G-Plan, not tax advice, and is not a tax return.

## Reporting a problem
If you find a security issue, do not post it publicly. Tell the project owner privately.
