# Go-live checklist: what needs other people

No code in this repository can grant a licence, pass an audit or sign off compliance. This list says who is needed,
what to ask them for, and what the code already supports so their work can start.

| Need | Who | What to ask for | What the code is ready for |
|---|---|---|---|
| Licence or licensed partner | A Nigerian financial-services lawyer, then the CBN (or a licensed bank/PSP partner) | Which licence your model needs, or a sponsor-bank agreement | Wallet, ledger, limits and KYC tiers are separate from the provider, so a partner can be plugged in |
| Real bank transfers | Paystack or Flutterwave (business account), or your sponsor bank | Live API keys after their onboarding, a webhook URL, a settlement account | Both adapters exist (`services/paystack.js`, `services/flutterwave.js`), unproven against the live APIs. Start in their sandbox |
| Real identity checks (BVN/NIN) | A KYC provider (for example Smile ID, Dojah, Youverify) | An API contract and their data-processing terms | `services/kyc.js` is the single place to replace. Keep photos with the provider and leave `KYC_DOCUMENTS=off` |
| Email and SMS delivery | Resend/Postmark, Termii or similar | Verified sending domain, sender ID registration | `EMAIL_PROVIDER`, `SMS_PROVIDER` switches |
| Penetration test | An independent security firm | A scoped test of the staging system (scope below) | `docs/SECURITY.md` known limits, test accounts via the demo seed |
| Compliance sign-off | A compliance officer (MLRO) | Policies for AML, sanctions, retention, complaints, incident reporting | Review queue, audit log, AML monitoring rules, retention setting `KYC_DOC_RETENTION_DAYS` |
| Data protection | A data-protection lawyer/officer | NDPR/NDPA registration and a privacy notice, retention periods for KYC records | Encryption at rest for photos and secrets, purge job |
| Hosting and keys | Your cloud provider or a DevOps engineer | Managed Postgres with backups, KMS-held keys, WAF, monitoring | `docs/DEPLOY.md`, `docs/OPERATIONS.md`, `DATA_KEYS` key ring with rotation |
| Push delivery proof | You, on real phones | Test on Android Chrome and iOS (home-screen app) over HTTPS | `services/push.js`, `public/sw.js` |

## Suggested penetration-test scope
- Business limits and ownership: try to spend more than the shared daily total with several team members at once, and try to take over a business by accepting an offer meant for someone else.
- Authentication: sign-up, login, MFA, passkeys, password reset, refresh-token replay, session revocation.
- Authorisation: every `/api/business/*` route as owner, finance, staff, auditor, a member of another business, and an outsider. Business wallet isolation from personal routes.
- Money: idempotency replays, concurrent payouts and approvals, limit bypass, negative or huge amounts, invoice total tampering.
- Uploads: `/api/kyc/documents/*` with malformed images, oversize bodies, polyglot files, wrong content types.
- Push: `/api/push/subscribe` with internal URLs (should be refused).
- Webhooks: forged Paystack and Flutterwave calls.
- Admin console: role separation, reversal approval by a second person, audit-log access.

## Before real money, in this order
1. Run `npm test` against a throwaway PostgreSQL and fix anything in `tests/business.test.js` (written but not yet run).
2. Provider sandbox testing with test keys, including a transfer whose webhook never arrives.
3. Penetration test, fix findings, retest.
4. Compliance policies and sign-off.
5. Licence or sponsor-bank agreement in place.
6. Only then switch any live provider on, with small limits.
