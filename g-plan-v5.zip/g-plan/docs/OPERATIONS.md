# Operations: monitoring, backups, keys, incidents

## Monitoring
- `GET /api/health` is a liveness check. `GET /api/ready` checks the database.
- `GET /api/metrics` returns Prometheus-style counters when `METRICS_TOKEN` is set. Send it as the `x-metrics-token` header.
- Request logs are one JSON line each (method, path, status, time, request id). No bodies, tokens or query strings are logged.
- Set `ALERT_WEBHOOK_URL` (Slack, Discord or any endpoint accepting `{"text": "..."}`) to be told about integrity failures and unhandled errors.
- Add an external uptime monitor on `/api/ready`, and a log or error service. Someone must be on call to act on alerts.
- Watch the **Held payments** queue in the admin console. Held money belongs to customers who are waiting, so review it promptly.
- The admin Overview shows ledger and audit integrity. A job re-checks every 6 hours.

## The watchdog and what each alert means
A watchdog checks every 5 minutes and sends a message to `ALERT_WEBHOOK_URL`. A problem is announced once, reminded hourly if it is urgent ("ACT NOW") or every 12 hours if not, and announced again as "Resolved" when it clears. The same numbers are in `/api/metrics` as `gplan_ops_*` gauges, so you can graph them and alert from your own monitoring too. The **Stuck and failed money** section of the admin console lists every item behind an alert.

| Alert | Urgency | What it means | What to do |
|---|---|---|---|
| Integrity check FAILED | Act now | The ledger or audit chain does not add up | Stop. Do not restart or restore over it. Follow "If something goes wrong" below |
| Payments stuck mid-way | Act now | The server stopped between reserving money and recording the result | Open Stuck and failed money, press **Recheck now**. If it stays stuck, check the provider dashboard for that reference before doing anything else |
| Bank transfers with no answer | Act now | The provider never confirmed or failed a transfer | Look the reference up in the provider's dashboard. Recheck. Never refund by hand until you know the transfer did not happen |
| Background jobs have not run | Act now | Scheduled payments, payroll, round-ups, alerts and push are paused | Check the server logs and restart it. Jobs catch up on their own; items are never paid twice |
| Held payments waiting | Today | Customers are waiting for compliance | Review Held payments |
| Payroll or bulk payments failed | Today | People may not have been paid | Open the item for the reason (wrong name, limit, low balance). The business owner fixes the cause and prepares a new batch |
| Batch not finishing, approvals waiting, reversals waiting, identity checks waiting | Today | A queue is being neglected | Chase the person who owns that queue |

Staff roles: **ops** can open Stuck and failed money and press Recheck. **admin** can look but not act.

## Backups
- Managed databases (Neon, Render) offer point-in-time recovery or snapshots. Turn it on and learn its limits and cost.
- `scripts/backup.sh` makes an encrypted dump. Copy it to storage outside your database provider.
- **Practise restoring.** `scripts/restore-drill.sh` does the whole drill for you: it backs up the database, restores it into a throwaway database on the same server, compares row counts, runs the ledger and audit checks, and deletes the throwaway database. Run it **monthly** against production (or a recent copy) and write the date and result in a drill log. CI also runs it on every change against a test database, so a broken script is caught early. The drill proves your backup restores; it does not prove your provider's snapshots do, so test those as well.
- **How much can you lose, and how fast can you be back?** Write down two numbers and check them against reality: how much recent data you could lose (RPO: with a nightly backup it is up to a day; point-in-time recovery shrinks it to minutes) and how long a full restore takes (RTO: the drill prints the time on a small database, so measure on a realistic size). If the numbers are too big for your customers, change the backup plan before launch.
- Decide and write down your retention period with a lawyer. Financial records usually must be kept for years.

## Encryption keys
- Set `DATA_KEYS="1:<64 hex chars>,2:<64 hex chars>"` and `DATA_KEY_CURRENT=2`. Generate a key with `openssl rand -hex 32`.
- To rotate: add the new key, set it current, run `npm --prefix server run rotate-keys`, confirm it reports the rotation, then retire the old key.
- Keep keys in a secrets manager, never in the repository. Losing a key means losing the data it protects.

## Roles
`npm --prefix server run make-admin -- person@example.com admin|support|ops|compliance|customer`
Give each person the least access they need, and turn on `ADMIN_REQUIRE_MFA=true`.

## If something goes wrong
1. Contain: restrict affected accounts, revoke sessions, rotate secrets.
2. Preserve: do not delete logs. The audit log is tamper-evident.
3. Check integrity: `verify_ledger_chain()` and `verify_audit_chain()`.
4. Tell affected people and the regulator when the law requires it (for data breaches in Nigeria, see the NDPA's notification rules and take legal advice).
5. Write down what happened and fix the cause.
