# Languages and accessibility

## Languages
G-Plan can show the app in English, Naijá (Pidgin), Yorùbá, Hausa and Igbo. People pick a language on the sign-in
screen or in **Profile and help**. The choice is remembered on that device, and the page language (`lang`) is set so screen
readers pronounce text correctly.

**The translations are first drafts and have not been checked by a native speaker.** The app says so under the picker
for each of them. Banking wording matters: a wrong word about money or fees can mislead people. Before launch:
1. Give each language file to a native speaker who knows banking terms (`client/src/locales/`).
2. Ask them to fix wording and tone, and to say which English loanwords people really use (for example "airtime", "data").
3. Only then set that language to `true` in `REVIEWED` in `client/src/i18n.jsx`. The "first draft" notice disappears.

**What is translated today:** every customer screen, in all four languages: sign-in, home, sending money, bills, requests, cards,
goals, insights, global, activity and statements, receipts, pockets, direct debits, business (invoices, team, payroll, payouts,
direct debits), security, profile, alerts, help and chat, and the shared buttons and messages. That is about 790 phrases per
language, in `client/src/locales/<lang>.screens.js` (plus about 100 short keys in `<lang>.js`). `npm run check:i18n` reports
coverage and fails if a placeholder such as `{name}` is lost or a translation is empty.

**Still English, on purpose or because it comes from somewhere else:**
- The **admin console** (staff only). Staff work in English.
- **Assistant answers**: the assistant is rule-based and answers in English, and the suggestion buttons stay English so the questions match.
- **Server text with details in it**: most error messages, alert bodies, transaction descriptions, biller and bank names, and names people typed.
  About 20 common errors (wrong password, low balance, bad code and similar) and the fixed alert titles ("Money received") are translated.
- **Files you download** (statements, CSV, the recovery-codes text file) and **push alerts** (they show the English alert title).

**How the system works:** the English text is the key. Screens call `tx('Send money')`; the other languages map that English phrase to
their own text, and anything missing shows in English. `tx('You have {n} left', { n })` fills placeholders, which must be kept in
every translation. New screens: wrap text in `tx(...)`, run `npm run check:i18n --list` to see what is missing, then add the phrases to the four
`*.screens.js` files.

**Native-speaker review (still required):** the translations are first drafts written without a native speaker. Ask each reviewer to read
the whole `*.screens.js` file, fix wording and tone for money, fees and security, and mark anything that sounds unnatural. Pay
special attention to words about money movement, limits, fees and consent. Then set that language to `true` in `REVIEWED` in
`client/src/i18n.jsx`.

## Accessibility
Done in this pass:
- Skip link ("Skip to main content") for keyboard and screen-reader users.
- When you open a screen, focus moves to the new content and the browser tab title changes, so screen readers announce the change.
- A strong focus ring (dark outline with a yellow halo) that is visible on light and dark backgrounds. The old yellow-only ring failed the 3:1 contrast rule against the light background.
- Touch targets at least 44 px tall.
- Alert badge text now has enough contrast in dark mode; the bell emoji is hidden from screen readers and the button has a proper name.
- Code-entry fields have names and `autocomplete="one-time-code"`.
- Text colours were checked: body and muted text pass WCAG AA (4.5:1) in light and dark.
- `npm run check:a11y` (in `client`) checks every form field has a label, images have alt text, buttons that only show an icon are named, and nothing uses a positive tab order or click handlers on non-buttons.

**Not done, and honestly not verifiable from here:**
- Testing with a real screen reader (TalkBack, VoiceOver, NVDA) and keyboard-only. The lint cannot replace this.
- Text-resize and zoom testing up to 200%, and right-to-left languages (none are offered).
- Colour is never the only signal in new screens, but older screens were not audited line by line (for example red and green amounts also use + and − signs, which is good, but check charts in Insights).
- A full WCAG audit by an accessibility specialist. Ask for one before launch, and ask real users with disabilities to try it.
