# Target launch market (assumption, confirm before building further)
Nigeria first, NGN, English. Held in `country_profiles` so other markets are configuration, not code.
- Segment: salaried young adults, freelancers, small merchants.
- Rails (licensed partners only): bank transfers, bill payments, QR and payment links.
- Identity: tiered KYC (BVN/NIN) through a verified provider.
- Compliance placeholders: licensing route, data protection, AML/CFT. G-Plan claims no licence or approval until verified (see `COMPLIANCE.md`).
- Per-tier limits and risk thresholds in `server/src/config.js` are placeholders, not regulatory figures.

# Phased roadmap and status
0. **Foundations (done):** brand, schema, ledger core, auth, tests, CI.
1. **Sandbox MVP (done in code, needs your testing):** wallet, internal and bank transfers, bills (now and scheduled), requests and payment links, goals with auto-save, activity search, statements (PDF/CSV), alerts, cards (demo), cheque (demo), multi-currency (demo rates), insights, budgets, score, assistant, Security Centre (TOTP, SMS/email codes, passkeys, sessions), KYC (mock), fraud and AML rules, admin console with roles, reversals with maker-checker, audit chains, monitoring, backups.
2. **Real-money pilot (not started, needs partners and approvals):** one licensed partner, real KYC and screening, real SMS and email delivery, reconciliation against provider files, penetration test, compliance sign-off.
3. **Intelligence upgrades:** model-backed assistant with evaluation, better categorisation, forecasting.
4. **Cards and Business:** real card issuing, merchant profiles, invoices, staff permissions.
5. **Global:** real FX provider, international rails, second country profile.

Exit gate for every phase: financial-correctness tests (duplicates, concurrency, reversals, insufficient funds) pass before visual polish ships.
