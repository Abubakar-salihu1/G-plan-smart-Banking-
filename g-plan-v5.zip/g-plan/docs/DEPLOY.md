# Deploying a demo online (Render or similar)

This puts the prototype online so judges can open a link. It is still demo mode with fake money.

1. Push the repository to GitHub.
2. Create a Postgres database (Neon or Render Postgres) and copy its connection string.
3. On Render, create a **Web Service** from the repository:
   - Build command: `npm run build`
   - Start command: `npm run migrate && npm start`
   - Environment variables: `DATABASE_URL`, `JWT_SECRET` (random, 32+ characters), `DATA_KEYS` (like `1:` followed by 64 hex characters, from `openssl rand -hex 32`), `NODE_ENV=production`, `TRUST_PROXY=1`, `ENABLE_DEMO_FUNDING=true` for a demo. Optional: `ALERT_WEBHOOK_URL`, `METRICS_TOKEN`.
   - In production the server will not start with placeholder secrets, no `DATA_KEYS`, or mock SMS and email while demo mode is off. That is deliberate.
4. Open the Render URL. Use it over HTTPS. Sign-in cookies are marked Secure in production, and the app and API must share the same domain (they do here, because the server serves the built app). The server serves the built app, so there is one link.
5. Create your own admin: register an account, then run `npm --prefix server run make-admin -- you@example.com admin` from the Render shell.

**Docker:** `JWT_SECRET=$(openssl rand -hex 32) DATA_KEYS=1:$(openssl rand -hex 32) DB_PASSWORD=$(openssl rand -hex 16) docker compose up --build` runs Postgres and the app together at http://localhost:4000.

For anything beyond a demo, do not enable `ENABLE_DEMO_FUNDING`, add real providers, and complete the steps in `docs/COMPLIANCE.md` and `docs/TESTING.md`.
