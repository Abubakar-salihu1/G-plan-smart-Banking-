# Review of `gplan-smart-banking-secure-v2` and what happened to each lapse

The v2 archive was read in full and every claim below was checked against its code. Patching v2 in place would have meant rewriting its money core (it changed balances directly with no ledger), so the fixes live in this codebase instead. "Fixed" means the code now does the right thing. Nothing here has been run against a live database yet, so treat each as "fixed in code, confirm by running `npm test`".

## Money
| v2 lapse | Status here |
|---|---|
| Transfers debit you and credit nobody; recipient never stored | **Fixed by design.** Double-entry ledger. Internal transfers credit the recipient. Bank, bill and card payments post to a settlement account. The payee is recorded on the transaction |
| Idempotency table never used, so double-submit pays twice | **Fixed.** An `Idempotency-Key` is required and tested (replay, mismatch, concurrent) |
| "Review" fraud decision sent money with no check, "step-up" asked for a code | **Fixed.** `additional_verification` needs a code, enforced server-side. `review` now **holds** the payment: money reserved, nothing sent, a compliance reviewer approves or declines it (tested for transfers and bank payments). `REVIEW_HOLD=false` switches to flag-only |
| Held transfers crashed (status not allowed by the database) | **Not applicable.** States are enforced by an allowed-transitions table and trigger, with tests |
| Webhooks stored but never acted on, no refunds | **Fixed for Paystack and Flutterwave.** Success and failure events settle or release the hold. Flutterwave results are confirmed by asking its API, not by trusting the webhook body |
| Live-provider mode never worked (UI never sent `beneficiaryId`) | **Not applicable.** The server re-resolves the account name itself and pays the account you typed |
| Connection returned to the pool with an open transaction | **Not applicable.** Every transaction goes through one helper that always rolls back and releases |
| External call made while holding database locks | **Fixed.** Funds are reserved by a hold, the provider is called outside any transaction, then the result is posted |
| No transaction limits by KYC tier, no daily limit | **Fixed.** Per-payment and per-day limits by tier (placeholder numbers), enforced under the wallet lock, tested including parallel requests |

## Security
| v2 lapse | Status here |
|---|---|
| Authenticator app set up but never used at login | **Fixed.** Login asks for the method that is actually on |
| Two-step could be turned off with an email code only | **Fixed.** Needs password and a valid code |
| `/api/csrf` issued tokens nobody checked | **Not applicable.** No cookies are used, so there is nothing to forge, and no fake endpoint |
| OTP codes written to logs when SMTP missing, even in production | **Fixed.** Production refuses to start with mock SMS or email unless demo mode is on |
| Webhook signed with an empty key when secret unset | **Fixed.** Verifies with the provider key, constant-time, rejects when the key is missing |
| Placeholder secrets accepted | **Fixed.** Startup guard plus tests |
| Stored XSS (innerHTML, no CSP) with token in storage | **Fixed.** React escapes all text, the server sends a strict CSP, and the access token is memory-only. The long-lived refresh token is in an httpOnly cookie that scripts cannot read |
| ID-number hashes brute-forceable, key reused | **Not applicable.** Full ID numbers are never stored, only the last 4 digits |
| Seeded demo account with known password | **Not applicable.** No seeded accounts |
| "Biometric" toggle only set a flag | **Fixed.** Real passkeys (WebAuthn) verified on the server. Not yet exercised on a real device |
| New-device check could never fire | **Fixed.** The app sends a device id and new devices raise verification |
| No resend or password reset, users stuck | **Fixed.** Password reset by emailed code (plus authenticator code if enabled), signs out every device, tested. Contact verification can be re-sent from Security |
| Account probing through register and verify | **Fixed.** Sign-up gives the same reply for new, pending and existing emails and never hands out a session. Email must be confirmed first. Pre-registering someone else's email does not work (tested). Login timing is equalised and forgot-password replies are identical |
| Rate limits spoofable through `X-Forwarded-For` | **Fixed.** Proxy trust is off unless `TRUST_PROXY` is set |
| No timeouts on provider calls | **Fixed.** 10 to 20 second limits |
| Audit failures swallowed, audit log editable | **Fixed for money.** Audit rows are written inside the payment transaction, are append-only and hash-chained, and a job verifies them. Some non-money audit writes are still best-effort |
| Tokens not pinned to algorithm, issuer or audience | **Fixed.** Plus refresh tokens that rotate and detect replay |
| CSRF on cookie endpoints | **Fixed properly.** The only cookie endpoint is refresh. It needs a custom header, uses SameSite=Strict, and only the one httpOnly cookie is accepted |

## Claims that were not true in v2
| v2 claim | Status here |
|---|---|
| "AI" insight was one `if` | The assistant says it is rule-based, and optionally uses a model if you add a key |
| Prometheus, Sentry, S3 backup mentioned, never used | Real `/metrics` (token protected), alert webhook, encrypted backup scripts. No Sentry and no S3 upload |
| `npm test` ran zero tests, CI file in the wrong place and needed a missing lockfile | Real tests, CI in `.github/workflows`, uses `npm install` |
| No admin or compliance area, so manual-review cases were unreachable | Admin console with roles, KYC, cheque, AML, fraud, dispute and reversal queues |

## Features v2 lacked that now exist
Statements (PDF, CSV), activity search, scheduled bills, goal funding and auto-save, categories and budgets, alerts, card limits and controls, multi-currency, payment requests and links, cheque deposit (demo), profile and data export, service requests.

## Now built that was listed as missing
QR payments (show a QR for any payment link or invoice, and scan with the phone camera where the browser supports it), business profile with invoices and a sales report, held-payment review queue, verified sign-up, password reset, cookie sessions with replay detection.

## Built in v5 (these were listed as missing)
- **Staff logins with roles on a shared business wallet.** Owner, Finance manager, Staff and Auditor. The business has its own wallet, separate from anyone's personal wallet. Invoices pay into it. Payouts leave it. A finance manager's payout above the owner's approval limit waits for the owner. See `server/src/services/businessRules.js`.
- **A Flutterwave adapter** (`PAYMENT_PROVIDER=flutterwave`). Tested only against a stubbed network, never against Flutterwave itself.
- **ID photo upload** (`KYC_DOCUMENTS=on`, off by default). Encrypted, metadata removed, reviewer-only with every view logged, deleted after a retention window. A real KYC provider is still the better home for these photos.
- **Push notifications** (`VAPID_PUBLIC_KEY` set, off by default). Shows only the alert title. In-app alerts still refresh every 20 seconds.

## Also built since
- **Direct debits**, **in-app support chat**, **statement emails and a yearly summary**, **Argon2id passwords**, and every customer screen translated into Pidgin, Yorùbá, Hausa and Igbo (first drafts).
- **Operations.** Watchdog alerts for stuck payments, a hung job loop and neglected queues, a Stuck and failed money admin screen, and a restore drill run by CI.
- **Business-wide limits.** Money leaving the business wallet is limited as one customer: the owner's verification level sets the ceiling, the owner can set a lower daily cap, and the daily total is shared by the whole team.
- **Handing a business to a new owner**, with offer, acceptance, password and two-step code from both people, and a 3-day expiry.
- **Account recovery codes** for a lost second factor (sign-in and password reset only).
- **Browser tests and CI.** Playwright tests and automated accessibility scans, run by CI. Not yet run.

## Still missing, honestly
- **More than one owner** on a business.
- **Everything that needs outside parties:** licences, real providers, a penetration test and compliance sign-off. No code can do these. `docs/GO-LIVE-CHECKLIST.md` lists exactly what is needed, from whom, and what the code already supports.

## What v2 did that is now matched or beaten
Password hashing (scrypt, upgraded on sign-in), refresh-token rotation in httpOnly cookies with replay detection, a Docker setup, provider adapters, encrypted sensitive fields (here: encrypted authenticator secrets, and no full ID numbers at all).
