# Compliance map (not legal advice)

G-Plan is **not licensed, approved or certified** by any regulator or scheme. This page lists what a real launch in Nigeria would need, and where the prototype already helps. Get advice from a Nigerian fintech lawyer before handling real money or personal data.

| Topic | What is needed | Where the prototype stands |
|---|---|---|
| Authorisation to operate | A licence from the Central Bank of Nigeria, or a partnership with a licensed bank or payment company that holds the money | None. Demo money only. Do not describe G-Plan as a bank |
| Customer identification (KYC) | Tiered KYC with BVN/NIN verification through approved providers, according to CBN rules | Tier model, limits, reviewer queue and a mock check exist. No real verification. Only ID last-4 is stored |
| AML / CFT | Risk assessment, screening against official lists, transaction monitoring, case handling, suspicious-activity reporting to the NFIU, record keeping | Monitoring rules, case queue and a placeholder screening list exist. No real list, no reporting |
| Data protection | Nigeria Data Protection Act: lawful basis and consent, privacy notice, data-subject rights, security, breach notification, possibly registration with the NDPC and a data protection officer | Consent records, data export, account closure, data minimisation, encryption of secrets. Notices and registrations still needed |
| Card data | PCI DSS if you store, process or transmit card numbers | Demo cards show last 4 only. Real cards must be issued through a PCI-compliant partner |
| Payments | Agreements with a licensed processor or bank, settlement and reconciliation, dispute handling | Mock providers, ledger reconciliation helpers, dispute and reversal workflow |
| Consumer protection | Clear fees, terms, complaint handling, accessibility | Fees shown before confirmation, demo labels, complaint (dispute) flow |
| Records | Retention periods and the ability to produce records | Append-only ledger and audit log. Retention policy to be decided |
| Independent assurance | Penetration test, security review, possibly SOC 2 or ISO 27001 | Not done. See `docs/TESTING.md` |

## Rules the product follows now
- Never claim a licence, partnership, certification or guaranteed return.
- Mock integrations are labelled "Demo" on screens, receipts and statements.
- Estimated exchange rates and fees are labelled as estimates.
- No full ID numbers or card numbers are stored.
