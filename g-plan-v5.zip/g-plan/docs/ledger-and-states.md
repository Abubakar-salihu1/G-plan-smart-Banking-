# Ledger and transaction-state model

## Ledger rules (enforced in the database, `server/db/001_schema.sql` and `004_full_feature_set.sql`)
- Double-entry, append-only. Every journal entry's debits equal its credits (checked at commit).
- Amounts are BIGINT minor units (kobo/cents). Never floats.
- One currency per entry. A currency conversion is two linked entries through system FX-position accounts, plus a fee entry.
- Balance = credits minus debits, derived from postings. `account_balance_cache` is a performance layer. The view `balance_cache_mismatches` must always be empty.
- Updates and deletes on postings, journal entries and the audit log are blocked. Reversals are new compensating entries.
- Entries and audit rows are hash-chained with a locked, gap-free `chain_no`. `verify_ledger_chain()` and `verify_audit_chain()` return the first broken position, or NULL.
- Holds reduce **available** balance but not **ledger** balance. They reserve money while an outside provider is working.
- Convention: wallet credit increases balance. A transfer debits the sender and credits the recipient.

## Transaction states
`created -> pending_authorisation -> authorised -> processing -> completed`

Side states: `processing_unconfirmed`, `under_review`, `failed`, `cancelled`, `expired`, `reversed`.

- Legal transitions live in `allowed_transitions`. A trigger rejects anything else and every change is logged in `transaction_state_history`.
- `completed` is only set after confirmed success. A provider timeout becomes `processing_unconfirmed`. The money stays reserved, and a status check, webhook or reconciliation job resolves it.
- Retries reuse the same idempotency key.
- Mock providers label receipts "Demo".

## Money-movement flows
**Internal transfer** (`services/transfers.js`): idempotency, lock both accounts, validate (owner, status, currency, KYC limit, available balance), walk the states, post one balanced entry, complete, audit, notify.

**Outgoing payment** (`services/payments.js`, used for bank transfers, bills, cards, international): phase 1 validates, creates the transaction and a hold. The provider is called outside any database transaction. Phase 2 posts the entry and captures the hold on success, releases the hold on failure, or leaves it reserved if the outcome is unknown.

**Reversal** (`services/reversal.js`): a requester proposes, a different administrator approves. The compensating entries are posted, the state becomes `reversed`, and nothing is reversed automatically if the recipient has already spent the money.
