#!/usr/bin/env bash
# Backup-and-restore DRILL: proves that a backup of the real database can actually be restored and still checks out.
# It never touches the source data. It makes a backup, restores it into a throwaway database on the same server,
# compares row counts, runs the ledger and audit integrity checks, then deletes the throwaway database.
#
# Usage:  SOURCE_DATABASE_URL=postgres://... BACKUP_PASSPHRASE=... ./scripts/restore-drill.sh
# Needs:  pg_dump, psql, createdb, dropdb, openssl, node. The database user must be allowed to create databases.
# Run it monthly and after every migration that changes tables. Write the result in your drill log.
set -euo pipefail
: "${SOURCE_DATABASE_URL:?Set SOURCE_DATABASE_URL}"
: "${BACKUP_PASSPHRASE:?Set BACKUP_PASSPHRASE}"
HERE="$(cd "$(dirname "$0")" && pwd)"
export SOURCE_DATABASE_URL
WORK="$(mktemp -d)"
SCRATCH="gplan_drill_$(date -u +%Y%m%d%H%M%S)"
STARTED=$(date +%s)
trap 'rm -rf "$WORK"; if [ -n "${DRILL_DB_CREATED:-}" ]; then ( eval "$(node "$HERE/pgenv.js" SOURCE_DATABASE_URL)"; dropdb --if-exists "$SCRATCH" ) >/dev/null 2>&1 || true; fi' EXIT

echo "1/5 Making an encrypted backup"
DATABASE_URL="$SOURCE_DATABASE_URL" "$HERE/backup.sh" "$WORK" 1 >/dev/null
BACKUP="$(ls "$WORK"/gplan-*.sql.gz.enc | head -1)"
SIZE=$(wc -c < "$BACKUP")
[ "$SIZE" -gt 1000 ] || { echo "FAIL: the backup file is suspiciously small ($SIZE bytes)"; exit 1; }

echo "2/5 Checking the backup file is intact"
sha256sum -c "$BACKUP.sha256" >/dev/null

echo "3/5 Restoring into a throwaway database ($SCRATCH)"
( eval "$(node "$HERE/pgenv.js" SOURCE_DATABASE_URL)"; createdb "$SCRATCH" )
DRILL_DB_CREATED=1
export SCRATCH_URL="$(node -e "const u=new URL(process.env.SOURCE_DATABASE_URL); u.pathname='/'+process.argv[1]; console.log(u.toString())" "$SCRATCH")"
openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -pass env:BACKUP_PASSPHRASE -in "$BACKUP" | gunzip \
  | ( eval "$(node "$HERE/pgenv.js" SCRATCH_URL)"; psql -q -v ON_ERROR_STOP=1 >/dev/null ) 2>&1 || { echo "FAIL: the restore reported errors"; exit 1; }

echo "4/5 Comparing row counts with the source"
FAIL=0
for T in users accounts transactions journal_entries postings audit_log; do
  A=$( ( eval "$(node "$HERE/pgenv.js" SOURCE_DATABASE_URL)"; psql -At -c "SELECT COUNT(*) FROM $T" ) )
  B=$( ( eval "$(node "$HERE/pgenv.js" SCRATCH_URL)"; psql -At -c "SELECT COUNT(*) FROM $T" ) )
  # The live database may have gained rows since the backup started, never fewer.
  if [ "$B" -le "$A" ] && [ "$B" -ge $(( A > 50 ? A - A / 20 : A - 2 )) ]; then echo "   ok   $T: source $A, restored $B"; else echo "   FAIL $T: source $A, restored $B"; FAIL=1; fi
done

echo "5/5 Integrity checks on the restored copy"
RESULT=$( ( eval "$(node "$HERE/pgenv.js" SCRATCH_URL)"; psql -At -F '|' -c "SELECT COALESCE(verify_ledger_chain()::text,'ok'), COALESCE(verify_audit_chain()::text,'ok'), (SELECT COUNT(*) FROM balance_cache_mismatches)" ) )
IFS='|' read -r LEDGER AUDIT MISMATCH <<< "$RESULT"
echo "   ledger chain: $LEDGER, audit chain: $AUDIT, balance mismatches: $MISMATCH"
{ [ "$LEDGER" = "ok" ] && [ "$AUDIT" = "ok" ] && [ "$MISMATCH" = "0" ]; } || FAIL=1

ELAPSED=$(( $(date +%s) - STARTED ))
if [ "$FAIL" = "0" ]; then
  echo "DRILL PASSED in ${ELAPSED}s. Backup size ${SIZE} bytes. Write this in your drill log, with the date."
else
  echo "DRILL FAILED. Do not trust your backups until this is understood and fixed."; exit 1
fi
