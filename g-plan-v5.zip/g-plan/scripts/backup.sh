#!/usr/bin/env bash
# Encrypted database backup with retention.
# Usage:  DATABASE_URL=... BACKUP_PASSPHRASE=... ./scripts/backup.sh [output-dir] [keep-days]
# Needs pg_dump and openssl. Schedule it (cron, GitHub Actions, Render cron job) and copy the output
# to storage OUTSIDE your database provider. A backup you have never restored is not a backup:
# run scripts/restore.sh against a scratch database regularly.
set -euo pipefail
: "${DATABASE_URL:?Set DATABASE_URL}"
: "${BACKUP_PASSPHRASE:?Set BACKUP_PASSPHRASE (store it somewhere safe, separate from the backups)}"
OUT="${1:-./backups}"
KEEP_DAYS="${2:-14}"
mkdir -p "$OUT"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
FILE="$OUT/gplan-$STAMP.sql.gz.enc"
eval "$(node "$(dirname "$0")/pgenv.js" DATABASE_URL)"
pg_dump --no-owner --no-privileges | gzip -9 \
  | openssl enc -aes-256-cbc -pbkdf2 -iter 200000 -salt -pass env:BACKUP_PASSPHRASE -out "$FILE"
sha256sum "$FILE" > "$FILE.sha256"
echo "Backup written: $FILE"
find "$OUT" -name 'gplan-*.enc*' -mtime +"$KEEP_DAYS" -delete
