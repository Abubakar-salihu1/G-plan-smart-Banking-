#!/usr/bin/env bash
# Restore an encrypted backup into a database. NEVER point this at production by accident:
# restore into a scratch database first.
# Usage:  TARGET_DATABASE_URL=... BACKUP_PASSPHRASE=... ./scripts/restore.sh backups/gplan-XXXX.sql.gz.enc
set -euo pipefail
: "${TARGET_DATABASE_URL:?Set TARGET_DATABASE_URL}"
: "${BACKUP_PASSPHRASE:?Set BACKUP_PASSPHRASE}"
FILE="${1:?Give the backup file path}"
if [ -f "$FILE.sha256" ]; then sha256sum -c "$FILE.sha256"; fi
read -r -p "Restore $FILE into the target database? Type YES: " ok
[ "$ok" = "YES" ] || { echo "Cancelled."; exit 1; }
openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -pass env:BACKUP_PASSPHRASE -in "$FILE" | gunzip \
  | ( eval "$(node "$(dirname "$0")/pgenv.js" TARGET_DATABASE_URL)"; psql -v ON_ERROR_STOP=1 )
echo "Restored. Now run the integrity check: SELECT verify_ledger_chain(), verify_audit_chain(); (both should be NULL)"
