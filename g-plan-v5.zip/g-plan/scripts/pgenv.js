// Prints shell exports for the standard PG* variables from DATABASE_URL, so tools like pg_dump and psql
// read the password from the environment instead of the command line (command lines are visible to
// other users through `ps`).  Usage:  eval "$(node scripts/pgenv.js DATABASE_URL)"
const name = process.argv[2] || 'DATABASE_URL';
const raw = process.env[name];
if (!raw) { console.error(`Set ${name}`); process.exit(1); }
const u = new URL(raw);
const q = (v) => `'${String(v).replace(/'/g, `'\\''`)}'`;
const out = {
  PGHOST: u.hostname, PGPORT: u.port || '5432', PGUSER: decodeURIComponent(u.username),
  PGPASSWORD: decodeURIComponent(u.password), PGDATABASE: u.pathname.replace(/^\//, ''),
};
const ssl = u.searchParams.get('sslmode');
if (ssl) out.PGSSLMODE = ssl;
for (const [k, v] of Object.entries(out)) console.log(`export ${k}=${q(v)}`);
