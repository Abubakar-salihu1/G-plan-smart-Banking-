# G-Plan: smart banking prototype

**Everything is demo mode.** No real bank, payment provider, card network, KYC service, SMS or email service is connected, all money is fake, and G-Plan holds no licence or regulatory approval. See `docs/SECURITY.md` and `docs/COMPLIANCE.md` for exactly what is and is not built.

## What is inside
- `server/` Node, Express, PostgreSQL (12 or newer). Double-entry ledger, state machine, idempotent payments, auth, security, fraud/AML rules, admin API, background jobs
- `client/` React (Vite), mobile-first
- `docs/` security, testing, operations, compliance, deployment, ledger model, roadmap
- `scripts/` encrypted backup and restore
- `.github/workflows/ci.yml` runs tests and dependency audits on every push

## Features
Sign-up and sign-in: email code to finish sign-up, no email probing, forgot password, sessions that renew from an httpOnly cookie.
Account: balance, activity search and filters, statements (PDF, CSV), profile, alerts, data export, account closure.
Payments: held for review when the risk rules flag them (compliance approves or declines), QR codes for payment links and invoices (scan with the camera in Chrome on Android), send to G-Plan by email or phone, bank transfer (mock bank), bills (airtime, data, electricity, TV, rent), scheduled and recurring payments, requests, payment links, split a bill, saved recipients, cheque deposit (demo), international transfer (demo).
Security: password rules and lockout, two-step verification (authenticator app, SMS or email codes), passkeys (fingerprint, face, device PIN), device and session control, login history, risk-based verification, KYC tiers (mock check).
Cards (demo): virtual and physical requests, freeze, limits, online and international switches, blocked categories, replacement, a demo purchase to show the controls.
Planning: savings goals with recommended amounts and auto-save rules, round-ups (spare change from payments into a goal), demo savings interest, spending by category, budgets, repeating-payment detection, cash-flow forecast, G-Plan score, G-Plan Intelligence assistant.
Pockets: a joint wallet for two people (payments above a limit need the other person to approve) and a child wallet (parent sets a weekly limit, approves who the child can pay, can freeze it, and can send a weekly allowance).
Business payroll and bulk payouts: keep a payroll list and prepare a month's salaries, or upload a CSV of payments. Every line is checked first and one wrong line refuses the whole file. Sending uses the same roles and owner approval as other payouts, and each item is paid once even if the server restarts.
Languages: English, Naijá (Pidgin), Yorùbá, Hausa and Igbo on every customer screen (about 790 phrases each; first drafts, not yet reviewed by native speakers). The admin console, assistant answers and most server messages stay English. Accessibility improvements: skip link, focus handling, stronger focus ring, bigger touch targets. See `docs/LANGUAGES-AND-ACCESSIBILITY.md`.
Business limits and ownership: payouts are limited as one customer (the owner's verification level, an optional lower daily cap, a daily total shared by the team). The owner can hand the business to a team member, who must accept with password and two-step code.
Operations: a watchdog that alerts about stuck money and neglected queues (once, with reminders and a "resolved" message), a **Stuck and failed money** admin screen with a Recheck button, `gplan_ops_*` metrics, and a backup-and-restore drill (`scripts/restore-drill.sh`, also run by CI). See `docs/OPERATIONS.md`.
Direct debits: a business asks a customer for a mandate (a cap per collection, a rhythm, days of notice). Nothing is collected unless the customer approves, never above the cap, never without notice, only if the wallet has the money, and the customer can cancel at once with no password. Fixed-amount mandates schedule themselves. Three failures in a row pause it.
Help and chat: in-app chat with support staff, with suggested answers first and a block on sending passwords, PINs, card numbers or codes. Staff reply from the admin console (each opening of a chat is audit-logged).
Statements and tax: an optional monthly "your statement is ready" email (no amounts inside) and a yearly summary with CSV (not tax advice).
Passwords: Argon2id when the optional add-on installs (it upgrades older hashes at next sign-in), otherwise scrypt.
Account recovery codes: ten one-time codes shown once when two-step verification is turned on, for signing in or resetting a password if the phone is lost. They never approve payments.
Receipts: type in or scan a receipt (scanning needs `ANTHROPIC_API_KEY` and the person's agreement; only the details are kept, never the photo). Habit alerts: unusually large payments, a regular payment that went up, a new repeating payment; each can be switched off.
Global: multi-currency wallets, conversion with fee shown first (indicative demo rates).
Business: shared business wallet with a team (Owner, Finance manager, Staff, Auditor), invoices with a pay link and QR code, payouts with owner approval above a limit, sales report.
Staff: admin console with roles (support, ops, compliance, admin), AML and fraud queues, KYC and cheque review, disputes, reversals with two-person approval, tamper-evident audit log, integrity checks.

## Run it (Codespaces or any computer)
```
cd server
cp .env.example .env          # set DATABASE_URL and a long random JWT_SECRET
npm install
npm run migrate               # applies 001 to 016 in order, each in one transaction
npm run seed
npm run dev
```
In a second terminal:
```
cd client
npm install
npm run dev
```
Open the printed address. Creating an account asks for a 6-digit email code (shown on screen in demo mode). With `ENABLE_DEMO_FUNDING=true` the Pulse screen shows **Add ₦50,000 demo money** and **Load sample history** (three months of activity so Insights, budgets, the score and repeating payments have data).

## Forgot your password
Tap **Forgot your password?** on the sign-in screen. A 6-digit code goes to your email (shown on screen in demo mode), you choose a new password, and every device is signed out.

## Docker
`JWT_SECRET=$(openssl rand -hex 32) DATA_KEYS=1:$(openssl rand -hex 32) DB_PASSWORD=$(openssl rand -hex 16) docker compose up --build`, then open http://localhost:4000.

## Review of the v2 archive
`docs/V2-REVIEW.md` lists every lapse found in `gplan-smart-banking-secure-v2` and what became of it.

## Try each outcome (demo rules)
- Bank account or bill reference ending **0000**: the provider declines, the payment fails, the hold is released.
- Payments flagged `review` (for example five quick payments in ten minutes) show "Held for review". Sign in as a staff user with the `compliance` role and open **Held payments** to approve or decline.
- Ending **9999**: the provider times out, the payment becomes *pending confirmation* with money reserved, and a background job resolves it within about two minutes.
- Cards: freeze it, block a category, or lower the monthly limit, then try the demo purchase.
- Two-step verification: with it on, payments of ₦100,000 or more (or ₦50,000 on a brand-new device) ask for a code.
- Without a real SMS or email provider, codes are printed in the server log and shown on screen in demo mode.

## Staff accounts (admin console)
Register normal accounts, then:
```
cd server
npm run make-admin -- someone@example.com support
npm run make-admin -- other@example.com admin
```
Roles: `support`, `ops`, `compliance` (also reviews held payments and KYC), `admin`. No role can do everything. A reversal needs one person to request it (support or ops) and a **different** person with the admin role to approve it, so create two staff accounts to demo it. Sign out and in again after changing a role.

## Tests
Use a throwaway database, never real data:
```
cd server
DATABASE_URL=postgres://... npm run migrate
DATABASE_URL=postgres://... npm test
```

## Honest status
This was written without access to a live database or a browser, so it has been **syntax-checked and its pure logic tested** (for example the authenticator codes match the RFC 6238 test vectors), but **it has not been run end to end**. Expect a few first-run bugs. Run the tests first, then walk through each screen, and fix anything that breaks before showing it to anyone.
Passkeys, PDF export, the optional Paystack and Flutterwave adapters, push alerts (needs `npm install` for `web-push`) and the business database tests rely on packages and services I could not exercise here. The pure-logic tests (providers, image checks, roles, push endpoints, config) were run.

## Before any real use
Read `docs/SECURITY.md` (known limitations), `docs/COMPLIANCE.md` (licensing, KYC, AML, data protection) and `docs/TESTING.md` (penetration testing). Real money needs a licensed partner, real KYC and screening, an independent security test, and legal advice. This repository cannot provide those.

## Business team (v5)
Create a business (needs identity level 1), then **Team > Invite someone** by the email of a verified G-Plan account. They accept in **Business**. Roles: **Owner** (everything, approves payouts), **Finance manager** (sees the wallet, sends payouts up to the approval limit, needs identity level 1), **Staff** (invoices only, never sees the balance), **Auditor** (read-only). A person can be active in one business at a time. To demo approval, sign in as a finance manager, send a payout above the limit, then sign in as the owner and approve it.

## Optional switches (all off by default)
- `PAYMENT_PROVIDER=flutterwave` with `FLUTTERWAVE_SECRET_KEY` and `FLUTTERWAVE_WEBHOOK_HASH` (webhook URL `/api/webhooks/flutterwave`). Test keys only.
- `KYC_DOCUMENTS=on` (needs `DATA_KEYS`) for ID photos at identity levels 2 and 3.
- Push alerts: run `npm run vapid` in `server`, set `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `VAPID_SUBJECT`, then each person turns it on under **Alerts**. Needs HTTPS (localhost is fine).
- Run the new database migrations: `npm run migrate` (files `006` to `016`).
- Savings interest is DEMO only: it needs `ENABLE_DEMO_FUNDING=true`, pays pretend money at `SAVINGS_DEMO_APR` (default 0.08), and is not an offer. Real interest needs a licence and real funding.
- The assistant can draft a payment ("Send ₦5,000 to ada@example.com"). It only pre-fills the Send screen. You still authorise it.
