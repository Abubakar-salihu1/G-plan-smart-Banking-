import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    hmr: false,
    allowedHosts: true,
    proxy: { '/api': 'http://localhost:4000' },
  },
});
