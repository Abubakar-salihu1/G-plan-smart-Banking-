// A simple accessibility lint over the JSX. It cannot replace testing with a screen reader and keyboard, but it catches
// the common mistakes. Run: npm run check:a11y
//  - every <input>/<select>/<textarea> has a label (wrapped in <label>, aria-label, or aria-labelledby)
//  - icon-only buttons have an accessible name
//  - images have alt text
//  - no positive tabindex, no onClick on non-interactive elements, no autoFocus outside code-entry fields
import fs from 'node:fs'; import path from 'node:path';
const root = path.resolve(import.meta.dirname, '../src');
const files = []; (function walk(d) { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); fs.statSync(p).isDirectory() ? walk(p) : /\.jsx$/.test(f) && files.push(p); } })(root);
let bad = 0; const fail = (f, line, m) => { console.log(`${path.relative(root, f)}:${line}: ${m}`); bad++; };
for (const f of files) {
  const lines = fs.readFileSync(f, 'utf8').split('\n');
  lines.forEach((ln, i) => {
    const n = i + 1;
    for (const m of ln.matchAll(/<(input|select|textarea)\b((?:[^>=]|=>|=(?:"[^"]*"|'[^']*'|\{(?:[^{}]|\{[^{}]*\})*\}))*)>/g)) {
      const attrs = m[2];
      if (/type=["'](hidden|checkbox|radio)["']/.test(attrs) && /hidden/.test(attrs)) continue;
      // labelled if the same line sits inside a <label ...> ... </label>, or the previous 2 lines open a <label>, or aria-label(ledby) is set
      const near = lines.slice(Math.max(0, i - 2), i + 1).join(' ');
      const wrapped = /<(label|Field)\b/.test(near) && !/<\/label>[^<]*$/.test(near.slice(0, near.lastIndexOf(m[0])));
      if (!/aria-label(ledby)?=/.test(attrs) && !wrapped) fail(f, n, `<${m[1]}> has no label`);
    }
    if (/<img\b/.test(ln) && !/\balt=/.test(ln)) fail(f, n, '<img> has no alt');
    if (/tabIndex=\{?["']?[1-9]/.test(ln)) fail(f, n, 'positive tabIndex');
    if (/<(div|span|p|li)\b[^>]*\bonClick=/.test(ln)) fail(f, n, 'onClick on a non-interactive element (use a button)');
    if (/<button\b[^>]*>\s*(\p{Extended_Pictographic}|[✕×✖])\s*<\/button>/u.test(ln) && !/aria-label=/.test(ln)) fail(f, n, 'icon-only button needs aria-label');
  });
}
console.log(bad ? `${bad} possible problem(s)` : 'no problems found by the lint');
process.exit(bad ? 1 : 0);
