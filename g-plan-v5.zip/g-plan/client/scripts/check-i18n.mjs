// Checks the translation files. Run: npm run check:i18n
//  1. Short keys like 'nav.pulse': used keys exist in English; other languages have no unknown keys.
//  2. English-phrase keys, e.g. tx('Send money'): every placeholder {name} matches in each language, nothing is empty,
//     and no translation is left over for a phrase that no longer exists in the code (stale).
//  3. Coverage: how many phrases each language has translated. Missing is allowed (English shows) but is listed.
//  Exit code 1 only for broken things (wrong placeholders, empty text, unknown short keys), not for missing translations.
import fs from 'node:fs'; import path from 'node:path'; import { pathToFileURL } from 'node:url';
const root = path.resolve(import.meta.dirname, '../src');
const load = async (n) => (await import(pathToFileURL(path.join(root, 'locales', `${n}.js`)).href)).default;
const en = await load('en');
const langs = ['pcm', 'yo', 'ha', 'ig'];
let bad = 0; const fail = (m) => { console.log('PROBLEM:', m); bad++; };
const ph = (s) => [...String(s).matchAll(/\{(\w+)\}/g)].map((m) => m[1]).sort().join(',');
const isShort = (k) => /^[a-z][a-z0-9]*(\.[\w]+)+$/.test(k);

const files = []; (function walk(d) { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) { if (f !== 'locales') walk(p); } else if (/\.jsx?$/.test(f)) files.push(p); } })(root);
const used = new Set(); const phrases = new Set();
for (const f of files) {
  const src = fs.readFileSync(f, 'utf8');
  for (const m of src.matchAll(/\b(?:tr?|tx)\(\s*'((?:[^'\\]|\\.)*)'/g)) {
    const k = m[1].replace(/\\'/g, "'").replace(/\\\\/g, '\\');
    (isShort(k) ? used : phrases).add(k);
  }
  // label tables (const STATUS = { a: 'Text' }) are looked up with tx(TABLE[x]), so their values are phrases too
  for (const t of src.matchAll(/const [A-Z_]+ = \{([^}]*)\}/g)) for (const v of t[1].matchAll(/:\s*'((?:[^'\\]|\\.)*)'/g)) if (/[A-Za-z]{3}/.test(v[1])) phrases.add(v[1].replace(/\\'/g, "'"));
  for (const t of src.matchAll(/const [A-Z_]+ = \[([\s\S]*?)\];/g)) for (const v of t[1].matchAll(/'((?:[^'\\]|\\.)*)'/g)) if (/[A-Za-z]{3}/.test(v[1]) && /^[A-Z]/.test(v[1]) && !/\?/.test(v[1])) phrases.add(v[1].replace(/\\'/g, "'"));
}
// status and type words from the server shown through cap()
const WORDS = JSON.parse(fs.readFileSync(path.resolve(import.meta.dirname, 'server-phrases.json'), 'utf8'));   // statuses, types and alert titles that arrive from the server in English
for (const w of WORDS) phrases.add(w);

for (const k of used) if (!(k in en)) fail(`code uses "${k}" but English has no such key`);
// Phrases that are the same in every language (names, examples, formats) do not need translating.
const neutral = (s) => !/[A-Za-z]{3}/.test(s.replace(/\{\w+\}/g, '')) || ['BVN', 'NIN', 'G-Plan Smart Banking Solution', 'G·Plan', 'name@email.com or 0803…', 'XXXX-XXXX-XXXX-XXXX', 'English', 'Naijá (Pidgin)', 'Yorùbá', 'Hausa', 'Igbo', 'NGN', 'USD', 'GBP', 'EUR', 'Show my largest expenses', 'Send ₦5,000 to a friend@example.com', 'Create a savings plan for me'].includes(s);
const need = [...phrases].filter((p) => !neutral(p));

for (const c of langs) {
  const short = await load(c); const screens = await load(`${c}.screens`);
  for (const [k, v] of Object.entries(short)) {
    if (!(k in en)) { fail(`${c}: unknown key "${k}"`); continue; }
    if (ph(v) !== ph(en[k])) fail(`${c}: "${k}" has placeholders {${ph(v)}} but English has {${ph(en[k])}}`);
    if (!String(v).trim()) fail(`${c}: "${k}" is empty`);
  }
  let have = 0; const missing = [];
  for (const p of need) { const v = screens[p]; if (v) { have++; if (ph(v) !== ph(p)) fail(`${c}: placeholders differ for "${p.slice(0, 50)}"`); } else missing.push(p); }
  for (const [p, v] of Object.entries(screens)) { if (!String(v).trim()) fail(`${c}: empty translation for "${p.slice(0, 50)}"`); if (!phrases.has(p)) console.log(`note: ${c} has a translation for a phrase no longer in the code: "${p.slice(0, 60)}"`); }
  console.log(`${c}: ${Object.keys(short).length}/${Object.keys(en).length} short keys, ${have}/${need.length} screen phrases (${Math.round((have / need.length) * 100)}%)`);
  if (process.argv.includes('--list') && missing.length) console.log(missing.map((m) => '   missing: ' + m).join('\n'));
}
console.log(bad ? `${bad} problem(s)` : 'translation files are consistent');
process.exit(bad ? 1 : 0);
