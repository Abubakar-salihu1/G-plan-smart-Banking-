import React, { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { Err } from './ui.jsx';

// Draws a QR code for any text (here, a G-Plan payment link).
export function QrImage({ text, label = 'QR code' }) {
  const [src, setSrc] = useState('');
  useEffect(() => {
    let on = true;
    QRCode.toDataURL(text, { margin: 1, width: 240, errorCorrectionLevel: 'M' })
      .then((u) => { if (on) setSrc(u); }).catch(() => { if (on) setSrc(''); });
    return () => { on = false; };
  }, [text]);
  return src ? <img className="qr" src={src} alt={label} width="240" height="240" /> : <p className="muted">Making the QR code…</p>;
}

// Scanning uses the phone's built-in QR reader (BarcodeDetector). Chrome on Android supports it; where it
// is missing, the screen offers pasting the link instead.
export const scanSupported = () =>
  typeof window !== 'undefined' && 'BarcodeDetector' in window && !!navigator.mediaDevices?.getUserMedia;

// A scanned code may be a full link (https://…/?pay=CODE) or just the code.
export function payCodeFrom(raw) {
  const v = String(raw || '').trim();
  const m = /[?&]pay=([^&\s#]+)/.exec(v);
  return m ? decodeURIComponent(m[1]) : v;
}

export function QrScan({ onCode, onClose }) {
  const video = useRef(null);
  const cb = useRef(onCode);
  cb.current = onCode;
  const [err, setErr] = useState('');
  useEffect(() => {
    let stream; let timer; let stopped = false;
    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
        if (stopped) { stream.getTracks().forEach((t) => t.stop()); return; }
        video.current.srcObject = stream;
        await video.current.play();
        const detector = new window.BarcodeDetector({ formats: ['qr_code'] });
        timer = setInterval(async () => {
          try {
            const codes = await detector.detect(video.current);
            if (codes[0]?.rawValue) { clearInterval(timer); cb.current(codes[0].rawValue); }
          } catch { /* keep trying */ }
        }, 400);
      } catch { setErr('Could not open the camera. Allow camera access, or paste the link instead.'); }
    })();
    return () => { stopped = true; clearInterval(timer); stream?.getTracks().forEach((t) => t.stop()); };
  }, []);
  return (
    <div className="stack">
      <video ref={video} className="scan" muted playsInline />
      <p className="muted">Point the camera at the QR code.</p>
      <Err>{err}</Err>
      <button onClick={onClose}>Close camera</button>
    </div>
  );
}
