import React, { useEffect, useRef, useState, useCallback } from 'react';
import { useT } from './i18n.jsx';
import { api, setToken, refreshSession } from './api.js';
import Home from './screens/Home.jsx';
import Send from './screens/Send.jsx';
import Goals from './screens/Goals.jsx';
import Insights from './screens/Insights.jsx';
import More from './screens/More.jsx';
import Bills from './screens/Bills.jsx';
import Requests from './screens/Requests.jsx';
import Cards from './screens/Cards.jsx';
import Global from './screens/Global.jsx';
import History from './screens/History.jsx';
import Cheque from './screens/Cheque.jsx';
import Assistant from './screens/Assistant.jsx';
import Alerts from './screens/Alerts.jsx';
import Security from './screens/Security.jsx';
import Profile from './screens/Profile.jsx';
import Admin from './screens/Admin.jsx';
import Business from './screens/Business.jsx';
import Auth from './screens/Auth.jsx';
import { pauseForSignOut, resumePush } from './push.js';
import Pockets from './screens/Pockets.jsx';
import Receipts from './screens/Receipts.jsx';
import Mandates from './screens/Mandates.jsx';
import Support from './screens/Support.jsx';

const TABS = [
  { id: 'home', key: 'nav.pulse' },
  { id: 'send', key: 'nav.flow' },
  { id: 'goals', key: 'nav.goals' },
  { id: 'insights', key: 'nav.insights' },
  { id: 'more', key: 'nav.more' },
];
const SUB = ['bills', 'requests', 'cards', 'global', 'history', 'cheque', 'assistant', 'alerts', 'security', 'profile', 'business', 'pockets', 'receipts', 'mandates', 'support', 'admin'];
const ALL = [...TABS.map((t) => t.id), ...SUB];

const savedScreen = () => {
  const t = sessionStorage.getItem('gp_tab');
  return ALL.includes(t) ? t : 'home';
};

// A shared payment link looks like  /?pay=CODE . Keep the code until the person has signed in.
(() => {
  const code = new URLSearchParams(window.location.search).get('pay');
  if (code) {
    sessionStorage.setItem('gp_paytoken', code);
    sessionStorage.setItem('gp_tab', 'requests');
    window.history.replaceState({}, '', window.location.pathname);
  }
})();

export default function App() {
  const { t: tr } = useT();
  const mainRef = useRef(null);
  const [user, setUser] = useState(null);
  const [booting, setBooting] = useState(true);
  const [screen, setScreenState] = useState(savedScreen());
  const [snapshot, setSnapshot] = useState(null);
  const [txns, setTxns] = useState([]);
  const [unread, setUnread] = useState(0);
  const [demo, setDemo] = useState(false);

  // Screen changes do not reload the page, so move keyboard and screen-reader focus to the new content,
  // and keep the browser tab title in step. Skipped on first load so focus is not stolen.
  const first = useRef(true);
  useEffect(() => {
    const tab = TABS.find((x) => x.id === screen);
    document.title = `${tab ? tr(tab.key) : (SUB.includes(screen) ? tr(`more.${screen}`) : '')} · G-Plan`.replace(/^ · /, '');
    if (first.current) { first.current = false; return; }
    mainRef.current?.focus({ preventScroll: true });
  }, [screen, tr]);

  const go = (s) => { sessionStorage.setItem('gp_tab', s); setScreenState(s); window.scrollTo(0, 0); };

  const refresh = useCallback(async () => {
    const [acc, tx] = await Promise.all([api('/accounts'), api('/transactions')]);
    setSnapshot(acc);
    setTxns(tx.transactions);
  }, []);
  const loadUnread = useCallback(() => api('/notifications').then((d) => setUnread(d.unread)).catch(() => {}), []);
  const loadUser = useCallback(() => api('/auth/me').then((d) => setUser(d.user)).catch(() => {}), []);

  useEffect(() => { fetch('/api/health').then((r) => r.json()).then((d) => setDemo(!!d.demo)).catch(() => {}); }, []);

  // On every load, try to restore the session from the httpOnly refresh cookie.
  useEffect(() => {
    refreshSession()
      .then(async (d) => { if (d) { setUser(d.user); await refresh(); } })
      .finally(() => setBooting(false));
  }, [refresh]);

  useEffect(() => {
    const out = () => { setUser(null); setSnapshot(null); setTxns([]); };
    window.addEventListener('gp:signedout', out);
    return () => window.removeEventListener('gp:signedout', out);
  }, []);

  // Real-time-ish alerts: check for new notifications every 20 seconds while signed in.
  useEffect(() => {
    if (!user) return undefined;
    loadUnread();
    const t = setInterval(loadUnread, 20000);
    return () => clearInterval(t);
  }, [user, loadUnread]);

  // Quietly turn push alerts back on for a person who enabled them on this device before.
  useEffect(() => { if (user) resumePush(user.id); }, [user?.id]);   // eslint-disable-line react-hooks/exhaustive-deps

  async function onAuthed({ token, user: u }) {
    setToken(token);
    setUser(u);
    await refresh();
  }
  async function signOut() {
    await pauseForSignOut();   // while still signed in, so the server stops pushing to this device
    try { await api('/auth/logout', { method: 'POST' }); } catch { /* already ended */ }
    setToken(null); setUser(null); setSnapshot(null); setTxns([]); setUnread(0);
    sessionStorage.removeItem('gp_tab'); setScreenState('home');
  }

  if (booting) return <div className="boot" role="status">{tr('common.loading')}</div>;
  if (!user) return <Auth onAuthed={onAuthed} />;

  const isStaff = ['support', 'ops', 'compliance', 'admin'].includes(user.role);
  const common = { snapshot, refresh, go, demo };
  const activeTab = TABS.some((t) => t.id === screen) ? screen : 'more';

  return (
    <div className="shell">
      <a className="skip" href="#main" onClick={(e) => { e.preventDefault(); mainRef.current?.focus(); }}>{tr('a11y.skip')}</a>
      <header className="top">
        <span className="brand">
          <img className="logo-mark" src="/logo-mark.png" alt="" width="40" height="40" />
          <span className="wordmark">G-Plan</span>
        </span>
        <span className="demo-tag">{tr('hdr.demo')}</span>
        <button className="bell" onClick={() => go('alerts')} aria-label={unread ? tr('hdr.alertsNew', { n: unread }) : tr('hdr.alerts')}>
          <span aria-hidden="true">🔔</span>{unread > 0 && <em className="badge" aria-hidden="true">{unread}</em>}
        </button>
        <button className="link" onClick={signOut}>{tr('hdr.signout')}</button>
      </header>
      <main id="main" tabIndex={-1} ref={mainRef}>
        {screen === 'home' && <Home user={user} txns={txns} {...common} />}
        {screen === 'send' && <Send {...common} />}
        {screen === 'goals' && <Goals refresh={refresh} />}
        {screen === 'insights' && <Insights />}
        {screen === 'more' && <More go={go} isStaff={isStaff} unread={unread} />}
        {screen === 'bills' && <Bills {...common} />}
        {screen === 'requests' && <Requests {...common} />}
        {screen === 'cards' && <Cards go={go} refresh={refresh} />}
        {screen === 'global' && <Global {...common} />}
        {screen === 'history' && <History go={go} />}
        {screen === 'cheque' && <Cheque go={go} />}
        {screen === 'assistant' && <Assistant go={go} />}
        {screen === 'alerts' && <Alerts go={go} userId={user.id} onRead={() => setUnread(0)} />}
        {screen === 'security' && <Security go={go} onUserChanged={loadUser} />}
        {screen === 'profile' && <Profile go={go} onUserChanged={loadUser} onClosed={signOut} />}
        {screen === 'business' && <Business go={go} />}
        {screen === 'pockets' && <Pockets go={go} />}
        {screen === 'receipts' && <Receipts go={go} />}
        {screen === 'mandates' && <Mandates go={go} />}
        {screen === 'support' && <Support go={go} />}
        {screen === 'admin' && isStaff && <Admin go={go} />}
      </main>
      <nav className="tabs" aria-label={tr('nav.main')}>
        {TABS.map((t) => (
          <button key={t.id} aria-current={activeTab === t.id ? 'page' : undefined} onClick={() => go(t.id)}>{tr(t.key)}</button>
        ))}
      </nav>
    </div>
  );
}
