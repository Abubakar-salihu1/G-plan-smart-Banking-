import React, { useState, useEffect, useCallback } from 'react';
import { api, formatMoney, cap } from './api.js';
import { useT, tx } from './i18n.jsx';

export function useLoad(fn, deps = []) {
  const [state, setState] = useState({ data: null, error: '', loading: true });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const load = useCallback(async () => {
    setState((s) => ({ ...s, loading: true, error: '' }));
    try { setState({ data: await fn(), error: '', loading: false }); }
    catch (e) { setState({ data: null, error: e.message, loading: false }); }
  }, deps);
  useEffect(() => { load(); }, [load]);
  return { ...state, reload: load };
}

export const Err = ({ children }) => (children ? <p className="error" role="alert">{children}</p> : null);
export const Note = ({ children }) => <p className="muted">{children}</p>;
export const Field = ({ label, children }) => <label>{label}{children}</label>;

export function Page({ title, go, children, sub }) {
  const { t } = useT();
  return (
    <section className="stack">
      <div className="page-head">
        {go && <button className="link" onClick={() => go('more')} aria-label={t('common.backLabel')}>{t('common.back')}</button>}
        <h2>{title}</h2>
      </div>
      {sub && <p className="muted">{sub}</p>}
      {children}
    </section>
  );
}

export function Tabs({ value, onChange, items }) {
  return (
    <div className="seg" role="tablist">
      {items.map(([id, label]) => (
        <button type="button" key={id} role="tab" aria-selected={value === id} className={value === id ? 'on' : ''} onClick={() => onChange(id)}>{label}</button>
      ))}
    </div>
  );
}

// Password re-entry, plus a verification code when the payment needs extra checking.
export function Authorise({ pw, setPw, otp, setOtp, verification, otpNeeded, method }) {
  const [sent, setSent] = useState(null);
  const [err, setErr] = useState('');
  const needs = otpNeeded || verification?.needsVerification;
  const m = verification?.method || method;
  async function sendCode() {
    setErr('');
    try { setSent(await api('/security/challenge', { method: 'POST' })); } catch (e) { setErr(e.message); }
  }
  return (
    <div className="stack">
      <Field label={tx('Enter your password to authorise')}>
        <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="current-password" required />
      </Field>
      {verification?.blocked && <Err>{verification.message}</Err>}
      {needs && !verification?.blocked && (
        <>
          <Field label={m === 'totp' ? 'Code from your authenticator app' : 'Verification code'}>
            <input inputMode="numeric" maxLength={6} value={otp} onChange={(e) => setOtp(e.target.value)} placeholder={tx('6 digits')} />
          </Field>
          {(m === 'sms' || m === 'email') && (
            <button type="button" className="link" onClick={sendCode}>{tx('Send me a code by {m}', { m })}</button>
          )}
          {sent?.demoCode && <p className="muted">{tx('Demo mode: your code is')} <b>{sent.demoCode}</b> {tx('(no real {m} is sent).', { m })}</p>}
          {sent && !sent.demoCode && <p className="muted">{tx('Code sent.')}</p>}
          <Err>{err}</Err>
        </>
      )}
    </div>
  );
}

export function Receipt({ receipt, title, children, onDone }) {
  const s = receipt.state;
  const head = s === 'completed' ? (title || 'Done') : s === 'failed' ? 'Payment failed' : s === 'under_review' ? 'Held for review' : 'Pending confirmation';
  return (
    <section className="stack receipt" aria-live="polite">
      <h2>{head}</h2>
      <p className="big-amount">{formatMoney(receipt.amountMinor, receipt.currency)}</p>
      {children}
      <dl>
        <dt>{tx('Reference')}</dt><dd>{receipt.reference}</dd>
        <dt>{tx('Status')}</dt><dd>{cap(s)}</dd>
        {receipt.feeMinor > 0 && (<><dt>{tx('Fee')}</dt><dd>{formatMoney(receipt.feeMinor, receipt.currency)}</dd></>)}
        {receipt.extra?.token && (<><dt>{tx('Electricity token')}</dt><dd>{receipt.extra.token}</dd></>)}
        <dt>{tx('Mode')}</dt><dd>{receipt.isDemo ? tx('Demo. No real money moved.') : tx('Live')}</dd>
      </dl>
      {s === 'failed' && <Err>{tx('{failureReason} No money was taken.', { failureReason: receipt.failureReason })}</Err>}
      {s === 'under_review' && (
        <p className="muted">{tx('For your safety our team is checking this payment. Your money is reserved, not sent. You will get an alert when it is approved or declined.')}</p>
      )}
      {s === 'processing_unconfirmed' && (
        <p className="muted">{tx('We have not heard back from the provider yet. Your money is reserved, not lost. We will confirm in a minute, and you will get an alert.')}</p>
      )}
      <button className="primary" onClick={onDone}>{tx('Done')}</button>
    </section>
  );
}

// One activity row. Tap for details, the state history, and "Report a problem".
export function TxnRow({ t, onChanged }) {
  const [open, setOpen] = useState(false);
  const [detail, setDetail] = useState(null);
  const [reason, setReason] = useState('');
  const [msg, setMsg] = useState('');
  const out = t.net_minor < 0;
  async function toggle() {
    setOpen(!open);
    if (!open && !detail) {
      try { setDetail(await api(`/transactions/${t.reference}`)); } catch (e) { setMsg(e.message); }
    }
  }
  async function report(e) {
    e.preventDefault(); setMsg('');
    try { await api('/disputes', { method: 'POST', body: { reference: t.reference, reason } }); setMsg(tx('Thanks. Support will review it.')); setReason(''); onChanged?.(); }
    catch (er) { setMsg(er.message); }
  }
  const pending = ['processing', 'processing_unconfirmed', 'under_review'].includes(t.state);
  return (
    <li className="txn">
      <button className="txn-main" onClick={toggle} aria-expanded={open}>
        <span>
          <span className="txn-title">{t.description || cap(t.type)}</span>
          <small>{new Date(t.created_at).toLocaleString()} · {cap(t.category || t.type)}{t.is_demo ? ' · Demo' : ''}</small>
          {pending && <small className="pill">{cap(t.state)}</small>}
        </span>
        <b className={out ? 'out' : 'in'}>{out ? '−' : '+'}{formatMoney(Math.abs(t.net_minor), t.currency)}</b>
      </button>
      {open && (
        <div className="txn-detail">
          <p className="muted">{tx('Reference {reference}', { reference: t.reference })}</p>
          {detail?.transaction?.failureReason && <Err>{detail.transaction.failureReason}</Err>}
          {detail?.history && (
            <ol className="history">
              {detail.history.map((h, i) => <li key={i}>{cap(h.to_state)}</li>)}
            </ol>
          )}
          <form className="inline" onSubmit={report}>
            <input value={reason} onChange={(e) => setReason(e.target.value)} placeholder={tx('Something wrong? Tell us')} aria-label={tx('Report a problem')} minLength={5} required />
            <button>{tx('Report')}</button>
          </form>
          {msg && <p className="muted">{msg}</p>}
        </div>
      )}
    </li>
  );
}
