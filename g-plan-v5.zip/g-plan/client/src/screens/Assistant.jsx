import { tx } from '../i18n.jsx';
import React, { useState, useRef, useEffect } from 'react';
import { api } from '../api.js';
import { Err, Page } from '../ui.jsx';

const IDEAS = ['How much did I spend this month?', 'Where am I spending the most?', 'Show my largest expenses', 'Why did my spending increase?', 'Can I afford a ₦50,000 purchase?', 'Send ₦5,000 to a friend@example.com', 'Create a savings plan for me'];

export default function Assistant({ go }) {
  const [msgs, setMsgs] = useState([{ who: 'ai', text: 'Hi, I am G-Plan Intelligence. I answer only from your own recorded transactions and goals, and I can draft a payment for you to review. I never send money myself. I label figures as facts or estimates, and I never promise returns.' }]);
  const [q, setQ] = useState(''); const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  const end = useRef(null);
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }); }, [msgs]);

  // Hands the draft to the normal Send screen. Authorisation, limits and risk checks all happen there.
  function review(p) {
    sessionStorage.setItem('gp_prefill', JSON.stringify({ recipient: p.recipient, amount: String(p.amountMinor / 100), note: p.note || '' }));
    go('send');
  }

  async function ask(text) {
    const t = (text ?? q).trim(); if (!t) return;
    setQ(''); setError(''); setBusy(true);
    setMsgs((m) => [...m, { who: 'me', text: t }]);
    try { const d = await api('/assistant', { method: 'POST', body: { question: t } }); setMsgs((m) => [...m, { who: 'ai', text: d.answer, proposal: d.proposal }]); }
    catch (e) { setError(e.message); } finally { setBusy(false); }
  }
  return (
    <Page title={tx('G-Plan Intelligence')} go={go}>
      <div className="chat" aria-live="polite">
        {msgs.map((m, i) => (
          <React.Fragment key={i}>
            <p className={`bubble ${m.who}`}>{m.text}</p>
            {m.proposal && <button className="primary" onClick={() => review(m.proposal)}>{tx('Review on Send screen')}</button>}
          </React.Fragment>
        ))}
        {busy && <p className="bubble ai">{tx('Thinking…')}</p>}
        <span ref={end} />
      </div>
      <div className="chips">{IDEAS.map((s) => <button key={s} className="chip-btn" onClick={() => ask(s)} disabled={busy}>{s}</button>)}</div>
      <form className="inline" onSubmit={(e) => { e.preventDefault(); ask(); }}>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={tx('Ask about your money')} maxLength={400} aria-label={tx('Your question')} />
        <button className="primary" disabled={busy}>{tx('Ask')}</button>
      </form>
      <Err>{error}</Err>
    </Page>
  );
}
