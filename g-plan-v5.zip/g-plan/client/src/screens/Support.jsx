import { tx } from '../i18n.jsx';
import React, { useState } from 'react';
import { api, cap } from '../api.js';
import { Err, useLoad, Page } from '../ui.jsx';

// Help and chat. Answers to common questions come first, so many people do not need to wait for a person.
export default function Support({ go }) {
  const [open, setOpen] = useState(null);
  const list = useLoad(() => api('/support/threads'), []);
  if (open) return <Thread id={open} go={go} onBack={() => { setOpen(null); list.reload(); }} />;
  return (
    <Page title={tx('Help and chat')} go={go} sub={tx('Ask us anything. Never send your password, PIN, card number or codes: we will never ask for them.')}>
      <Err>{list.error}</Err>
      <Ask onDone={(id) => { list.reload(); setOpen(id); }} />
      <h3>{tx('Your chats')}</h3>
      {list.data?.threads.length === 0 && <p className="empty">{tx('No chats yet.')}</p>}
      <ul className="ledger">{list.data?.threads.map((t) => (
        <li key={t.id}><button className="link" style={{ textAlign: 'left', flex: 1 }} onClick={() => setOpen(t.id)}>
          {t.subject}{t.unread && <em className="badge" aria-label={tx('New reply')}> {tx('New')}</em>}<small>{cap(t.status)} · {new Date(t.lastMessageAt).toLocaleString()}</small></button></li>
      ))}</ul>
    </Page>
  );
}

function Ask({ onDone }) {
  const [subject, setSubject] = useState(''); const [body, setBody] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const [tips, setTips] = useState([]);
  async function suggest(v) { setSubject(v); if (v.trim().length < 4) return setTips([]); try { setTips((await api(`/support/faq?q=${encodeURIComponent(v)}`)).suggestions); } catch { setTips([]); } }
  async function send(e) {
    e.preventDefault(); setErr(''); setBusy(true);
    try { const d = await api('/support/threads', { method: 'POST', body: { subject, body } }); onDone(d.id); } catch (er) { setErr(er.message); } finally { setBusy(false); }
  }
  return (
    <form className="stack" onSubmit={send}>
      <h3>{tx('Ask a question')}</h3>
      <label>{tx('What is it about?')}<input value={subject} onChange={(e) => suggest(e.target.value)} maxLength={80} placeholder={tx('For example: my transfer is pending')} required /></label>
      {tips.length > 0 && (
        <div className="demo-box stack" role="region" aria-label={tx('Suggested answers')}>
          <b>{tx('These may answer it:')}</b>
          {tips.map((t) => <details key={t.id}><summary>{t.q}</summary><p>{t.a}</p></details>)}
        </div>
      )}
      <label>{tx('Tell us more')}<textarea rows={5} maxLength={2000} value={body} onChange={(e) => setBody(e.target.value)} required /></label>
      <Err>{err}</Err>
      <button className="primary" disabled={busy}>{busy ? tx('Sending…') : tx('Start chat')}</button>
    </form>
  );
}

function Thread({ id, go, onBack }) {
  const t = useLoad(() => api(`/support/threads/${id}`), [id]);
  const [text, setText] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  async function send(e) {
    e.preventDefault(); setErr(''); setBusy(true);
    try { await api(`/support/threads/${id}/messages`, { method: 'POST', body: { body: text } }); setText(''); t.reload(); } catch (er) { setErr(er.message); } finally { setBusy(false); }
  }
  async function close() { try { await api(`/support/threads/${id}/close`, { method: 'POST' }); onBack(); } catch (er) { setErr(er.message); } }
  return (
    <Page title={t.data?.thread.subject || 'Chat'} go={go}>
      <button className="link" onClick={onBack}>{tx('All chats')}</button>
      <Err>{err || t.error}</Err>
      <div role="log" aria-live="polite" className="stack">
        {t.data?.messages.map((m) => (
          <p key={m.id} className={`bubble ${m.from === 'staff' ? 'ai' : 'me'}`}><small>{m.from === 'staff' ? 'G-Plan support' : tx('You')} · {new Date(m.at).toLocaleString()}</small><br />{m.body}</p>
        ))}
      </div>
      {t.data?.thread.status !== 'closed' ? (
        <form className="stack" onSubmit={send}>
          <label>{tx('Your message')}<textarea rows={3} maxLength={2000} value={text} onChange={(e) => setText(e.target.value)} required /></label>
          <div className="inline"><button className="primary" disabled={busy}>{tx('Send')}</button><button type="button" onClick={close}>{tx('Close this chat')}</button><button type="button" className="link" onClick={t.reload}>{tx('Refresh')}</button></div>
        </form>
      ) : <p className="muted">{tx('This chat is closed. Reply above to reopen it, or start a new one.')}</p>}
    </Page>
  );
}
