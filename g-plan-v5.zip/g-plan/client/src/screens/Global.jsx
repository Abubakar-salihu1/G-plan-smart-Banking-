import { tx } from '../i18n.jsx';
import React, { useState } from 'react';
import { api, formatMoney, toMinor } from '../api.js';
import { Err, Authorise, Receipt, Tabs, useLoad, Page } from '../ui.jsx';

const CCY = ['NGN', 'USD', 'GBP', 'EUR'];

export default function Global({ snapshot, refresh, go }) {
  const rates = useLoad(() => api('/fx/rates'), []);
  const [tab, setTab] = useState('convert');
  const [c, setC] = useState({ from: 'NGN', to: 'USD', amount: '' });
  const [quote, setQuote] = useState(null);
  const [error, setError] = useState('');
  const [receipt, setReceipt] = useState(null);
  const [idem, setIdem] = useState(() => crypto.randomUUID());
  const [x, setX] = useState({ currency: 'USD', amount: '', name: '', country: '', account: '' });
  const [pw, setPw] = useState(''); const [otp, setOtp] = useState(''); const [otpNeeded, setOtpNeeded] = useState(false);
  const have = new Set(snapshot?.wallets.map((w) => w.currency));

  async function addWallet(currency) { setError(''); try { await api('/wallets', { method: 'POST', body: { currency } }); await refresh(); } catch (e) { setError(e.message); } }
  async function getQuote(e) {
    e.preventDefault(); setError(''); setQuote(null);
    const amountMinor = toMinor(c.amount);
    if (!amountMinor) return setError(tx('Enter an amount.'));
    try { setQuote((await api('/fx/quote', { method: 'POST', body: { from: c.from, to: c.to, amountMinor } })).quote); } catch (er) { setError(er.message); }
  }
  async function doConvert() {
    setError('');
    try { const d = await api('/fx/convert', { method: 'POST', idemKey: idem, body: { from: quote.from, to: quote.to, amountMinor: quote.amountMinor } }); setReceipt(d.receipt); await refresh(); }
    catch (e) { setError(e.message); }
  }
  async function sendAbroad(e) {
    e.preventDefault(); setError('');
    const amountMinor = toMinor(x.amount);
    if (!amountMinor) return setError(tx('Enter an amount.'));
    try {
      const d = await api('/transfers/international', { method: 'POST', idemKey: idem, body: { currency: x.currency, amountMinor, beneficiaryName: x.name, country: x.country, accountNumber: x.account, password: pw, otp } });
      setReceipt(d.receipt); await refresh();
    } catch (er) { if (er.code === 'OTP_REQUIRED') setOtpNeeded(true); setError(er.message); }
  }
  const done = () => { setReceipt(null); setQuote(null); setIdem(crypto.randomUUID()); setPw(''); setOtp(''); };

  if (receipt) {
    return (
      <Receipt receipt={receipt} title={receipt.type === 'fx_conversion' ? 'Converted' : 'Sent'} onDone={done}>
        {receipt.type === 'fx_conversion' && <p>{tx('You received {v1}', { v1: formatMoney(receipt.extra.receiveMinor, receipt.extra.to) })}</p>}
      </Receipt>
    );
  }
  const est = (() => {
    const amt = toMinor(x.amount); if (!amt) return null;
    const fee = Math.ceil(amt * ((rates.data?.internationalFeePercent || 1.5) / 100));
    return { fee, total: amt + fee };
  })();

  return (
    <Page title={tx('Global')} go={go} sub={tx('Hold and move money in more than one currency. Rates here are indicative demo rates.')}>
      <ul className="ledger">
        {snapshot?.wallets.map((w) => (
          <li key={w.id}><span>{tx('{currency} wallet', { currency: w.currency })}</span><b>{formatMoney(w.availableMinor, w.currency)}</b></li>
        ))}
      </ul>
      <div className="inline">{CCY.filter((k) => !have.has(k)).map((k) => <button key={k} onClick={() => addWallet(k)}>{tx('Add {k} wallet', { k })}</button>)}</div>

      <Tabs value={tab} onChange={(t) => { setTab(t); setError(''); }} items={[['convert', tx('Convert')], ['abroad', tx('Send abroad')], ['rates', tx('Rates')]]} />

      {tab === 'convert' && (
        <form className="stack" onSubmit={getQuote}>
          <div className="inline">
            <select value={c.from} onChange={(e) => { setC({ ...c, from: e.target.value }); setQuote(null); }} aria-label={tx('From')}>{CCY.map((k) => <option key={k}>{k}</option>)}</select>
            <span aria-hidden="true">→</span>
            <select value={c.to} onChange={(e) => { setC({ ...c, to: e.target.value }); setQuote(null); }} aria-label={tx('To')}>{CCY.map((k) => <option key={k}>{k}</option>)}</select>
          </div>
          <label>{tx('Amount to convert')}<input inputMode="decimal" value={c.amount} onChange={(e) => { setC({ ...c, amount: e.target.value }); setQuote(null); }} required /></label>
          <button>{tx('See the quote')}</button>
          {quote && (
            <div className="demo-box stack">
              <dl>
                <dt>{tx('You convert')}</dt><dd>{formatMoney(quote.amountMinor, quote.from)}</dd>
                <dt>{tx('Fee ({v1}%)', { v1: rates.data?.feePercent })}</dt><dd>{formatMoney(quote.feeMinor, quote.from)}</dd>
                <dt>{tx('Indicative rate')}</dt><dd>1 {quote.from} ≈ {quote.rate.toPrecision(4)} {quote.to}</dd>
                <dt>{tx('You get about')}</dt><dd>{formatMoney(quote.receiveMinor, quote.to)}</dd>
              </dl>
              <p className="muted">{tx('Indicative demo rate. A real rate is only fixed when the conversion completes.')}</p>
              <button type="button" className="primary" onClick={doConvert}>{tx('Confirm conversion')}</button>
            </div>
          )}
          <Err>{error}</Err>
        </form>
      )}

      {tab === 'abroad' && (
        <form className="stack" onSubmit={sendAbroad}>
          <label>{tx('Currency')}<select value={x.currency} onChange={(e) => setX({ ...x, currency: e.target.value })}>{['USD', 'GBP', 'EUR'].map((k) => <option key={k}>{k}</option>)}</select></label>
          {!have.has(x.currency) && <p className="muted">{tx('Add a {currency} wallet and convert some money into it first.', { currency: x.currency })}</p>}
          <label>{tx('Amount')}<input inputMode="decimal" value={x.amount} onChange={(e) => setX({ ...x, amount: e.target.value })} required /></label>
          <label>{tx('Recipient name')}<input value={x.name} onChange={(e) => setX({ ...x, name: e.target.value })} required /></label>
          <label>{tx('Country')}<input value={x.country} onChange={(e) => setX({ ...x, country: e.target.value })} required /></label>
          <label>{tx('Account number or IBAN')}<input value={x.account} onChange={(e) => setX({ ...x, account: e.target.value })} required /></label>
          {est && <p className="muted">{tx('Estimated fee {v1}. Total taken about {v2}. This is an estimate, not a guaranteed final amount.', { v1: formatMoney(est.fee, x.currency), v2: formatMoney(est.total, x.currency) })}</p>}
          <Authorise pw={pw} setPw={setPw} otp={otp} setOtp={setOtp} otpNeeded={otpNeeded} />
          <Err>{error}</Err>
          <button className="primary" disabled={!have.has(x.currency)}>{tx('Send abroad (demo)')}</button>
        </form>
      )}

      {tab === 'rates' && rates.data && (
        <>
          <ul className="ledger">{Object.entries(rates.data.rates).filter(([k]) => k !== 'NGN').map(([k, v]) => <li key={k}><span>1 {k}</span><b>≈ ₦{v.toLocaleString()}</b></li>)}</ul>
          <p className="muted">{rates.data.note}</p>
        </>
      )}
    </Page>
  );
}
