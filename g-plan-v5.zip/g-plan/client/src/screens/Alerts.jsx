import { tx } from '../i18n.jsx';
import React, { useEffect, useState } from 'react';
import { api, cap } from '../api.js';
import { Err, useLoad, Page } from '../ui.jsx';
import { pushState, enablePush, disablePush } from '../push.js';

function PushToggle({ userId }) {
  const [st, setSt] = useState(null);
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const load = () => pushState(userId).then(setSt).catch(() => setSt({ supported: false }));
  useEffect(() => { load(); }, [userId]);   // eslint-disable-line react-hooks/exhaustive-deps
  if (!st || !st.supported || !st.serverEnabled) return null;   // quietly absent where push cannot work
  async function toggle() {
    setErr(''); setBusy(true);
    try { if (st.on) await disablePush(userId); else await enablePush(userId); await load(); }
    catch (e) { setErr(e.message); } finally { setBusy(false); }
  }
  return (
    <div className="demo-box">
      <b>{tx('Alerts on this device')}</b>
      <p className="muted">{tx('{v1} Only the alert title shows on the lock screen, never amounts or names.', { v1: st.on ? tx('On. Your phone will buzz when something happens.') : tx('Get a buzz when money moves, even when the app is closed.') })}</p>
      <Err>{err}</Err>
      <button onClick={toggle} disabled={busy}>{st.on ? tx('Turn off on this device') : tx('Turn on on this device')}</button>
    </div>
  );
}

function HabitToggle() {
  const p = useLoad(() => api('/alerts/prefs'), []);
  const [err, setErr] = useState('');
  if (!p.data) return null;
  async function flip() { setErr(''); try { await api('/alerts/prefs', { method: 'PUT', body: { habitAlerts: !p.data.habitAlerts } }); p.reload(); } catch (e) { setErr(e.message); } }
  return (
    <div className="demo-box">
      <b>{tx('Spending habit alerts')}</b>
      <p className="muted">{tx('{v1} This only adds an alert. It never blocks a payment.', { v1: p.data.habitAlerts ? tx('On. We tell you about unusually large payments, a regular payment that went up, and a new repeating payment.') : tx('Off.') })}</p>
      <Err>{err}</Err>
      <button onClick={flip}>{p.data.habitAlerts ? tx('Turn off') : tx('Turn on')}</button>
    </div>
  );
}

export default function Alerts({ go, onRead, userId }) {
  const { data, error, reload } = useLoad(() => api('/notifications'), []);
  useEffect(() => { if (data?.unread > 0) api('/notifications/read-all', { method: 'POST' }).then(() => onRead?.()).catch(() => {}); }, [data, onRead]);
  return (
    <Page title={tx('Alerts')} go={go}>
      <PushToggle userId={userId} />
      <HabitToggle />
      <Err>{error}</Err>
      {data?.notifications.length === 0 && <p className="empty">{tx('No alerts yet. Payments, sign-ins and security changes appear here.')}</p>}
      <ul className="ledger">
        {data?.notifications.map((n) => (
          <li key={n.id} className={n.read_at ? '' : 'unread'}>
            <span>{tx(n.title)}<small>{n.body}</small><small>{new Date(n.created_at).toLocaleString()} · {cap(n.kind)}</small></span>
          </li>
        ))}
      </ul>
      <p className="muted">{tx('This list also refreshes by itself every 20 seconds while the app is open.')}</p>
      <button className="link" onClick={reload}>{tx('Refresh')}</button>
    </Page>
  );
}
