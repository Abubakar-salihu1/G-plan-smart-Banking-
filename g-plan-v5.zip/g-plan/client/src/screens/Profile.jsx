import React, { useState } from 'react';
import { api, download, cap } from '../api.js';
import { Err, useLoad, Page } from '../ui.jsx';
import { LanguagePicker, tx } from '../i18n.jsx';

export default function Profile({ go, onUserChanged, onClosed }) {
  const p = useLoad(() => api('/profile'), []);
  const svc = useLoad(() => api('/services'), []);
  const dsp = useLoad(() => api('/disputes'), []);
  const [form, setForm] = useState(null);
  const [req, setReq] = useState({ type: 'checkbook', note: '' });
  const [pw, setPw] = useState('');
  const [msg, setMsg] = useState(''); const [err, setErr] = useState('');
  const prof = p.data?.profile;
  const f = form || (prof ? { fullName: prof.full_name, phone: prof.phone ? '0' + prof.phone.slice(3) : '' } : null);

  async function save(e) {
    e.preventDefault(); setErr(''); setMsg('');
    try { await api('/profile', { method: 'PATCH', body: { fullName: f.fullName, phone: f.phone } }); setMsg(tx('Saved.')); setForm(null); p.reload(); onUserChanged?.(); }
    catch (er) { setErr(er.message); }
  }
  async function request(e) {
    e.preventDefault(); setErr(''); setMsg('');
    try { await api('/services', { method: 'POST', body: req }); setReq({ ...req, note: '' }); setMsg(tx('Request received (demo).')); svc.reload(); } catch (er) { setErr(er.message); }
  }
  async function exportData() { setErr(''); try { await download('/privacy/export', 'gplan-my-data.json'); } catch (e) { setErr(e.message); } }
  async function closeAccount() {
    if (!window.confirm(tx('Close your G-Plan account? This cannot be undone.'))) return;
    setErr('');
    try { await api('/privacy/close', { method: 'POST', body: { password: pw } }); onClosed?.(); } catch (e) { setErr(e.message); }
  }

  return (
    <Page title={tx('Profile and help')} go={go}>
      <Err>{p.error}</Err>
      {f && (
        <form className="stack" onSubmit={save}>
          <label>{tx('Full name')}<input value={f.fullName} onChange={(e) => setForm({ ...f, fullName: e.target.value })} required /></label>
          <label>{tx('Phone')}<input inputMode="tel" value={f.phone} onChange={(e) => setForm({ ...f, phone: e.target.value })} placeholder="08031234567" /></label>
          <p className="muted">{tx('Email: {email} · Verification level {kyc_tier}', { email: prof.email, kyc_tier: prof.kyc_tier })}</p>
          <button className="primary">{tx('Save changes')}</button>
        </form>
      )}
      {msg && <p className="ok">{msg}</p>}
      <Err>{err}</Err>

      <LanguagePicker />
      <h3>{tx('Service requests')}</h3>
      <form className="stack" onSubmit={request}>
        <select value={req.type} onChange={(e) => setReq({ ...req, type: e.target.value })} aria-label={tx('Request type')}>
          {(svc.data?.types || ['checkbook']).map((t) => <option key={t} value={t}>{cap(t)}</option>)}
        </select>
        <input value={req.note} onChange={(e) => setReq({ ...req, note: e.target.value })} placeholder={tx('Details (optional)')} maxLength={300} aria-label={tx('Details')} />
        <button>{tx('Send request')}</button>
      </form>
      <ul className="ledger">{svc.data?.requests.map((r) => <li key={r.id}><span>{cap(r.type)}<small>{new Date(r.created_at).toLocaleDateString()}</small></span><b>{cap(r.status)}</b></li>)}</ul>

      <h3>{tx('Problems you reported')}</h3>
      {dsp.data?.disputes.length === 0 && <p className="muted">{tx('None. To report one, open any transaction in Activity and tap Report.')}</p>}
      <ul className="ledger">{dsp.data?.disputes.map((d) => <li key={d.id}><span>{d.reference}<small>{d.reason.slice(0, 50)}{d.resolution_note ? ` · ${d.resolution_note}` : ''}</small></span><b>{cap(d.status)}</b></li>)}</ul>

      <h3>{tx('Your data and privacy')}</h3>
      <p className="muted">{tx('Download everything we hold about you, or close your account. We collect only what the service needs, and never store your full ID numbers or card numbers.')}</p>
      <button onClick={exportData}>{tx('Download my data')}</button>
      <div className="stack">
        <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder={tx('Password to close account')} aria-label={tx('Password')} />
        <button className="danger" onClick={closeAccount} disabled={!pw}>{tx('Close my account')}</button>
        <p className="muted">{tx('Move out all money first, including goals and other currencies. Financial records are kept as long as the law requires.')}</p>
      </div>
    </Page>
  );
}
