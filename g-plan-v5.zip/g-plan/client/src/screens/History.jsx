import { tx } from '../i18n.jsx';
import React, { useState } from 'react';
import { api, download, cap, formatNaira } from '../api.js';
import { Err, useLoad, TxnRow, Page, Tabs } from '../ui.jsx';

const TYPES = ['internal_transfer', 'external_transfer', 'international_transfer', 'bill_payment', 'card_payment', 'deposit', 'cheque_deposit', 'goal_contribution', 'fx_conversion'];

export default function History({ go }) {
  const [tab, setTab] = useState('activity');
  const [f, setF] = useState({ q: '', dir: '', type: '', from: '', to: '', min: '', max: '' });
  const [applied, setApplied] = useState({});
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7));
  const [err, setErr] = useState('');
  const qs = new URLSearchParams(Object.entries(applied).filter(([, v]) => v)).toString();
  const list = useLoad(() => api('/transactions?' + qs + (qs ? '&' : '') + 'limit=100'), [qs]);
  const stmt = useLoad(() => api(`/statements/${month}`), [month]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  async function dl(kind) { setErr(''); try { await download(`/statements/${month}/${kind}`, `gplan-statement-${month}.${kind}`); } catch (e) { setErr(e.message); } }
  const s = stmt.data?.statement;

  return (
    <Page title={tx('Activity and statements')} go={go}>
      <Tabs value={tab} onChange={setTab} items={[['activity', tx('Activity')], ['statements', tx('Statements')], ['summary', tx('Yearly summary')]]} />
      {tab === 'activity' && (
        <>
          <form className="stack" onSubmit={(e) => { e.preventDefault(); setApplied(f); }}>
            <input value={f.q} onChange={set('q')} placeholder={tx('Search by name, note or reference')} aria-label={tx('Search')} />
            <div className="inline">
              <select value={f.dir} onChange={set('dir')} aria-label={tx('Direction')}><option value="">{tx('In and out')}</option><option value="in">{tx('Money in')}</option><option value="out">{tx('Money out')}</option></select>
              <select value={f.type} onChange={set('type')} aria-label={tx('Type')}><option value="">{tx('All types')}</option>{TYPES.map((t) => <option key={t} value={t}>{cap(t)}</option>)}</select>
            </div>
            <div className="inline"><input type="date" value={f.from} onChange={set('from')} aria-label={tx('From date')} /><input type="date" value={f.to} onChange={set('to')} aria-label={tx('To date')} /></div>
            <div className="inline"><input inputMode="decimal" placeholder={tx('Min ₦')} value={f.min} onChange={set('min')} aria-label={tx('Minimum')} /><input inputMode="decimal" placeholder={tx('Max ₦')} value={f.max} onChange={set('max')} aria-label={tx('Maximum')} /></div>
            <div className="inline"><button className="primary">{tx('Search')}</button><button type="button" onClick={() => { setF({ q: '', dir: '', type: '', from: '', to: '', min: '', max: '' }); setApplied({}); }}>{tx('Clear')}</button></div>
          </form>
          <Err>{list.error}</Err>
          {list.data?.transactions.length === 0 && <p className="empty">{tx('Nothing matches. Try fewer filters.')}</p>}
          <ul className="ledger">{list.data?.transactions.map((t) => <TxnRow key={t.id} t={t} onChanged={list.reload} />)}</ul>
        </>
      )}
      {tab === 'summary' && <YearSummary />}
      {tab === 'statements' && (
        <div className="stack">
          <label>{tx('Month')}<input type="month" value={month} onChange={(e) => setMonth(e.target.value)} /></label>
          {s && (
            <>
              <dl><dt>{tx('Opening balance')}</dt><dd>{formatNaira(s.openingMinor)}</dd><dt>{tx('Closing balance')}</dt><dd>{formatNaira(s.closingMinor)}</dd><dt>{tx('Transactions')}</dt><dd>{s.lines.length}</dd></dl>
              <div className="inline"><button className="primary" onClick={() => dl('pdf')}>{tx('Download PDF')}</button><button onClick={() => dl('csv')}>{tx('Download CSV')}</button></div>
              <p className="muted">{tx('Demo statements. Not a bank statement.')}</p>
            </>
          )}
          <Err>{err || stmt.error}</Err>
          <EmailToggle />
        </div>
      )}
    </Page>
  );
}

// Opt in to a monthly email that says the statement is ready. The email never contains balances or transactions.
function EmailToggle() {
  const p = useLoad(() => api('/alerts/prefs'), []);
  const [err, setErr] = useState('');
  if (!p.data) return null;
  async function flip() { setErr(''); try { await api('/alerts/prefs', { method: 'PUT', body: { statementEmail: !p.data.statementEmail } }); p.reload(); } catch (e) { setErr(e.message); } }
  return (
    <div className="demo-box stack">
      <b>{tx('Monthly statement email')}</b>
      <p className="muted">{tx('{v1} The email never contains your balance or transactions.', { v1: p.data.statementEmail ? tx('On. On the 1st of each month we email you that last month\'s statement is ready.') : tx('Off. Turn on to get an email each month saying your statement is ready.') })}</p>
      <Err>{err}</Err>
      <button onClick={flip}>{p.data.statementEmail ? tx('Turn off') : tx('Turn on')}</button>
    </div>
  );
}

// A year of activity added up. A summary of what happened in G-Plan, not tax advice.
function YearSummary() {
  const thisYear = new Date().getUTCFullYear();
  const [year, setYear] = useState(thisYear);
  const [err, setErr] = useState('');
  const d = useLoad(() => api(`/statements/tax-summary/${year}`), [year]);
  const s = d.data?.summary;
  async function dl() { setErr(''); try { await download(`/statements/tax-summary/${year}/csv`, `gplan-summary-${year}.csv`); } catch (e) { setErr(e.message); } }
  const row = (label, v) => v > 0 && <><dt>{label}</dt><dd>{formatNaira(v)}</dd></>;
  return (
    <div className="stack">
      <label>{tx('Year')}<select value={year} onChange={(e) => setYear(Number(e.target.value))}>{[0, 1, 2, 3, 4].map((i) => <option key={i} value={thisYear - i}>{thisYear - i}</option>)}</select></label>
      <Err>{err || d.error}</Err>
      {s && (<>
        <dl>
          {row(tx('Received from other people'), s.totals.receivedFromPeople)}{row(tx('Added to your wallet'), s.totals.addedToWallet)}{row(tx('Interest (demo)'), s.totals.interest)}{row(tx('Other money in'), s.totals.otherIn)}
          {row(tx('Spent'), s.totals.spent)}{row(tx('Put into savings goals'), s.totals.saved)}
        </dl>
        {s.categories.length > 0 && (<><h3>{tx('Where it went')}</h3><ul className="ledger">{s.categories.map((c) => <li key={c.category}><span>{cap(c.category)}</span><b>{formatNaira(c.totalMinor)}</b></li>)}</ul></>)}
        {Object.values(s.totals).every((v) => v === 0) && <p className="empty">{tx('No activity in {year}.', { year })}</p>}
        {s.truncated && <p className="muted">{tx('This year has more than 5,000 transactions, so the totals may be incomplete.')}</p>}
        <button onClick={dl}>{tx('Download CSV')}</button>
        <p className="muted">{s.note}</p>
      </>)}
    </div>
  );
}
