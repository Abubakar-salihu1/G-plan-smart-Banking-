import React, { useState } from 'react';
import { api, fetchBlobUrl } from '../api.js';
import { Err, useLoad, Page } from '../ui.jsx';

// KYC reviewers can open the photos for a submission. Every view is written to the audit log by the server.
function Photos({ id, onClose }) {
  const [imgs, setImgs] = useState([]); const [err, setErr] = useState('');
  React.useEffect(() => {
    let urls = []; let dead = false;
    (async () => {
      try {
        const { documents } = await api(`/admin/kyc/${id}/documents`);
        for (const d of documents) { const u = await fetchBlobUrl(`/admin/kyc-documents/${d.id}`); urls.push(u); if (!dead) setImgs((x) => [...x, { kind: d.kind, url: u }]); }
        if (!documents.length) setErr('No photos on this submission.');
      } catch (e) { setErr(e.message); }
    })();
    return () => { dead = true; urls.forEach((u) => URL.revokeObjectURL(u)); };
  }, [id]);
  return (
    <div className="demo-box stack">
      <b>ID photos (this viewing is logged)</b>
      <Err>{err}</Err>
      {imgs.map((i) => <figure key={i.url}><img src={i.url} alt={i.kind.replace('_', ' ')} style={{ maxWidth: '100%' }} /><figcaption className="muted">{i.kind.replace('_', ' ')}</figcaption></figure>)}
      <button onClick={onClose}>Close</button>
    </div>
  );
}

function Table({ section }) {
  const [photosFor, setPhotosFor] = useState(null);
  const [q, setQ] = useState(''); const [applied, setApplied] = useState('');
  const [msg, setMsg] = useState('');
  const { data, error, reload } = useLoad(() => api(`/admin/section/${section}${applied ? `?q=${encodeURIComponent(applied)}` : ''}`), [section, applied]);
  async function act(id, action) {
    setMsg('');
    if (!window.confirm(`Confirm: ${action.replace(/_/g, ' ')}?`)) return;
    try { await api('/admin/action', { method: 'POST', body: { section, id, action } }); reload(); } catch (e) { setMsg(e.message); }
  }
  return (
    <div className="stack">
      {data?.search && (
        <form className="inline" onSubmit={(e) => { e.preventDefault(); setApplied(q); }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search" aria-label="Search" /><button>Search</button>
        </form>
      )}
      {data?.note && <p className="muted">{data.note}</p>}
      <Err>{error || msg}</Err>
      {data?.rows.length === 0 && <p className="empty">Nothing here.</p>}
      {photosFor && <Photos id={photosFor} onClose={() => setPhotosFor(null)} />}
      <div className="table-wrap">
        <table>
          <thead><tr>{data?.columns.map((c) => <th key={c}>{c}</th>)}<th /></tr></thead>
          <tbody>
            {data?.rows.map((r) => (
              <tr key={r.id}>
                {r.cells.map((c, i) => <td key={i}>{c}</td>)}
                <td className="acts">{r.kycPhotos && <button onClick={() => setPhotosFor(r.id)}>Photos</button>}{r.actions.map((a) => <button key={a.action} className={a.danger ? 'danger' : ''} onClick={() => act(r.id, a.action)}>{a.label}</button>)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function Admin({ go }) {
  const me = useLoad(() => api('/admin/me'), []);
  const [sec, setSec] = useState('overview');
  return (
    <Page title="Admin console" go={go} sub={me.data ? `Signed in as ${me.data.role}. You only see what your role allows. Every action is logged.` : ''}>
      <Err>{me.error}</Err>
      {me.data && (
        <>
          <div className="seg scroll" role="tablist">
            {me.data.sections.map((s) => <button key={s.id} className={sec === s.id ? 'on' : ''} onClick={() => setSec(s.id)}>{s.title}</button>)}
          </div>
          {sec === 'chat' ? <AdminChat key={sec} /> : <Table key={sec} section={sec} />}
        </>
      )}
    </Page>
  );
}

// Customer chat for support staff. Opening a thread is written to the audit log by the server.
function AdminChat() {
  const [status, setStatus] = useState('open'); const [open, setOpen] = useState(null);
  const list = useLoad(() => api(`/admin/support/threads?status=${status}`), [status]);
  if (open) return <AdminThread id={open} onBack={() => { setOpen(null); list.reload(); }} />;
  return (
    <div className="stack">
      <div className="inline">{['open', 'waiting_customer', 'closed'].map((s) => <button key={s} className={status === s ? 'primary' : ''} onClick={() => setStatus(s)}>{s === 'open' ? 'Needs a reply' : s === 'waiting_customer' ? 'Waiting for customer' : 'Closed'}</button>)}</div>
      <Err>{list.error}</Err>
      {list.data?.threads.length === 0 && <p className="empty">Nothing here.</p>}
      <ul className="ledger">{list.data?.threads.map((t) => (
        <li key={t.id}><button className="link" style={{ textAlign: 'left', flex: 1 }} onClick={() => setOpen(t.id)}>{t.subject}<small>{t.name} · {t.preview} · last message {new Date(t.lastMessageAt).toLocaleString()}</small></button></li>
      ))}</ul>
    </div>
  );
}

function AdminThread({ id, onBack }) {
  const t = useLoad(() => api(`/admin/support/threads/${id}`), [id]);
  const [text, setText] = useState(''); const [err, setErr] = useState('');
  async function send(e) { e.preventDefault(); setErr(''); try { await api(`/admin/support/threads/${id}/messages`, { method: 'POST', body: { body: text } }); setText(''); t.reload(); } catch (er) { setErr(er.message); } }
  async function close() { try { await api(`/admin/support/threads/${id}/close`, { method: 'POST' }); onBack(); } catch (er) { setErr(er.message); } }
  return (
    <div className="stack">
      <button className="link" onClick={onBack}>All chats</button>
      {t.data && <p><b>{t.data.thread.subject}</b><br /><small className="muted">{t.data.thread.name} · {t.data.thread.email} · opening this chat was logged</small></p>}
      <Err>{err || t.error}</Err>
      <div role="log" className="stack">{t.data?.messages.map((m) => <p key={m.id} className={`bubble ${m.from === 'staff' ? 'me' : 'ai'}`}><small>{m.from === 'staff' ? 'Staff' : 'Customer'} · {new Date(m.at).toLocaleString()}</small><br />{m.body}</p>)}</div>
      {t.data?.thread.status !== 'closed' && (
        <form className="stack" onSubmit={send}>
          <label>Reply<textarea rows={3} maxLength={2000} value={text} onChange={(e) => setText(e.target.value)} required /></label>
          <p className="muted">Never ask for a password, PIN, full card number or codes.</p>
          <div className="inline"><button className="primary">Send reply</button><button type="button" onClick={close}>Close chat</button></div>
        </form>
      )}
    </div>
  );
}
