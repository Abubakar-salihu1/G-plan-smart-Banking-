import React from 'react';
import { useT } from '../i18n.jsx';

const IDS = ['bills', 'mandates', 'requests', 'cards', 'global', 'history', 'receipts', 'pockets', 'business', 'cheque', 'assistant', 'alerts', 'security', 'support', 'profile'];

export default function More({ go, isStaff, unread }) {
  const { t } = useT();
  const ids = isStaff ? [...IDS, 'admin'] : IDS;
  return (
    <section className="stack">
      <h2>{t('more.title')}</h2>
      <ul className="menu">
        {ids.map((id) => (
          <li key={id}>
            <button onClick={() => go(id)}>
              <span><b>{t(`more.${id}`)}</b><small>{t(`more.${id}.sub`)}</small></span>
              {id === 'alerts' && unread > 0 && <em className="badge" aria-label={t('hdr.alertsNew', { n: unread })}>{unread}</em>}
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}
