import { tx } from '../i18n.jsx';
import React, { useState } from 'react';
import { api, formatNaira, toMinor, cap } from '../api.js';
import { Err, Authorise, Receipt, Tabs, useLoad, Page } from '../ui.jsx';

const CATS = [['airtime', 'Airtime'], ['data', 'Data'], ['electricity', 'Electricity'], ['cable', 'Cable TV'], ['rent', 'Rent']];

export default function Bills({ refresh, go, demo }) {
  const cat = useLoad(() => api('/bills/catalog'), []);
  const sched = useLoad(() => api('/bills/scheduled'), []);
  const [tab, setTab] = useState('airtime');
  const [view, setView] = useState('pay');
  const [f, setF] = useState({ billerCode: '', payeeRef: '', payeeName: '', bundleId: '', amount: '', frequency: 'monthly', startDate: '' });
  const [pw, setPw] = useState(''); const [otp, setOtp] = useState(''); const [otpNeeded, setOtpNeeded] = useState(false);
  const [receipt, setReceipt] = useState(null); const [idem, setIdem] = useState(() => crypto.randomUUID());
  const [error, setError] = useState(''); const [busy, setBusy] = useState(false); const [msg, setMsg] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const billers = cat.data?.billers.filter((b) => b.category === tab) || [];
  const biller = cat.data?.billers.find((b) => b.code === f.billerCode);
  const options = biller?.options === 'data' ? cat.data.dataBundles : biller?.options === 'cable' ? cat.data.cablePackages : null;

  function body() {
    return { billerCode: f.billerCode, payeeRef: f.payeeRef.trim(), payeeName: f.payeeName || undefined, bundleId: f.bundleId || undefined,
      amountMinor: options ? undefined : toMinor(f.amount), password: pw, otp };
  }

  async function pay(e) {
    e.preventDefault(); setError(''); setBusy(true);
    try {
      if (view === 'pay') {
        const d = await api('/bills/pay', { method: 'POST', idemKey: idem, body: body() });
        setReceipt(d.receipt); await refresh();
      } else {
        await api('/bills/scheduled', { method: 'POST', body: { ...body(), frequency: f.frequency, startDate: f.startDate || undefined } });
        setMsg(tx('Scheduled. You can pause or cancel it any time below.')); sched.reload();
      }
      setPw(''); setOtp(''); setIdem(crypto.randomUUID());
    } catch (err) {
      if (err.code === 'OTP_REQUIRED') setOtpNeeded(true);
      setError(err.message);
    } finally { setBusy(false); }
  }

  async function setStatus(id, status) { await api(`/bills/scheduled/${id}`, { method: 'PATCH', body: { status } }); sched.reload(); }
  async function runNow(id) {
    setMsg('');
    try { const d = await api(`/bills/scheduled/${id}/run-now`, { method: 'POST' }); setMsg(tx('Ran now: {result}', { result: cap(d.result) })); sched.reload(); await refresh(); }
    catch (err) { setMsg(err.message); }
  }

  if (receipt) return <Receipt receipt={receipt} title={tx('Payment successful')} onDone={() => { setReceipt(null); setF({ ...f, payeeRef: '', amount: '' }); }}><p>{biller?.name}</p></Receipt>;

  return (
    <Page title={tx('Pay bills')} go={go} sub={tx('Demo providers and prices. No real biller is connected.')}>
      <Tabs value={tab} onChange={(t) => { setTab(t); setF({ ...f, billerCode: '', bundleId: '', payeeRef: '' }); }} items={CATS} />
      <Tabs value={view} onChange={setView} items={[['pay', tx('Pay now')], ['schedule', tx('Schedule')]]} />
      <form className="stack" onSubmit={pay}>
        <label>{tx('Provider')}
          <select value={f.billerCode} onChange={set('billerCode')} required>
            <option value="">{tx('Choose')}</option>
            {billers.map((b) => <option key={b.code} value={b.code}>{b.name}</option>)}
          </select>
        </label>
        {biller && <label>{biller.refLabel}<input value={f.payeeRef} onChange={set('payeeRef')} required /></label>}
        {biller && options && (
          <label>{tx('Package')}
            <select value={f.bundleId} onChange={set('bundleId')} required>
              <option value="">{tx('Choose')}</option>
              {options.map((o) => <option key={o.id} value={o.id}>{o.label} · {formatNaira(o.amountMinor)}</option>)}
            </select>
          </label>
        )}
        {biller && !options && <label>{tx('Amount (₦)')}<input inputMode="decimal" value={f.amount} onChange={set('amount')} required /></label>}
        {biller?.category === 'rent' && <label>{tx('Note for your records (optional)')}<input value={f.payeeName} onChange={set('payeeName')} maxLength={60} /></label>}
        {view === 'schedule' && (
          <>
            <label>{tx('How often')}
              <select value={f.frequency} onChange={set('frequency')}>
                <option value="once">{tx('Once')}</option><option value="weekly">{tx('Every week')}</option><option value="monthly">{tx('Every month')}</option>
              </select>
            </label>
            <label>{tx('First payment on')}<input type="date" value={f.startDate} onChange={set('startDate')} /></label>
          </>
        )}
        <p className="muted">{tx('Demo rule: references ending 0000 fail, and ending 9999 time out.')}</p>
        <Authorise pw={pw} setPw={setPw} otp={otp} setOtp={setOtp} otpNeeded={otpNeeded} />
        <Err>{error}</Err>
        {msg && <p className="ok">{msg}</p>}
        <button className="primary" disabled={busy || !biller}>{busy ? tx('Please wait…') : view === 'pay' ? tx('Pay now') : tx('Schedule payment')}</button>
      </form>

      <h3>{tx('Scheduled payments')}</h3>
      {sched.data?.scheduled.length === 0 && <p className="empty">{tx('Nothing scheduled. Set up rent, airtime or TV to pay itself.')}</p>}
      <ul className="ledger">
        {sched.data?.scheduled.map((s) => (
          <li key={s.id} className="sched">
            <div>
              <span>{s.billerName} · {formatNaira(s.amount_minor)}</span>
              <small>{tx('{v1} · next {next_run_on} · {v3}{v4}', { v1: cap(s.frequency), next_run_on: s.next_run_on, v3: cap(s.status), v4: s.last_status ? ` · last: ${cap(s.last_status)}` : '' })}</small>
            </div>
            <div className="inline">
              <button onClick={() => setStatus(s.id, s.status === 'active' ? 'paused' : 'active')}>{s.status === 'active' ? tx('Pause') : tx('Resume')}</button>
              <button onClick={() => setStatus(s.id, 'cancelled')}>{tx('Cancel')}</button>
              {demo && s.status === 'active' && <button onClick={() => runNow(s.id)}>{tx('Run now (demo)')}</button>}
            </div>
          </li>
        ))}
      </ul>
    </Page>
  );
}
