import { tx } from '../i18n.jsx';
import React, { useState } from 'react';
import { api, formatNaira, toMinor, cap } from '../api.js';
import { Err, useLoad, Page } from '../ui.jsx';

function CardView({ c, categories, reload, refresh }) {
  const [limit, setLimit] = useState('');
  const [buy, setBuy] = useState({ merchant: 'Demo Shop', category: 'shopping', amount: '2500', online: true, international: false });
  const [pw, setPw] = useState('');
  const [msg, setMsg] = useState(''); const [err, setErr] = useState('');
  const patch = async (body) => { setErr(''); try { await api(`/cards/${c.id}`, { method: 'PATCH', body }); reload(); } catch (e) { setErr(e.message); } };
  const frozen = c.status === 'frozen';

  async function charge(e) {
    e.preventDefault(); setErr(''); setMsg('');
    const amountMinor = toMinor(buy.amount);
    if (!amountMinor) return setErr(tx('Enter an amount.'));
    try {
      const d = await api(`/cards/${c.id}/charge`, { method: 'POST', idemKey: crypto.randomUUID(),
        body: { merchant: buy.merchant, category: buy.category, amountMinor, online: buy.online, international: buy.international } });
      setMsg(tx('Approved: {amount} at {merchant}.', { amount: formatNaira(d.receipt.amountMinor), merchant: buy.merchant })); reload(); refresh();
    } catch (er) { setErr(er.message); }
  }
  async function replace() {
    setErr('');
    try { await api(`/cards/${c.id}/replace`, { method: 'POST', body: { password: pw } }); setPw(''); reload(); } catch (e) { setErr(e.message); }
  }
  const toggleCat = (cat) => patch({ blockedCategories: c.blockedCategories.includes(cat) ? c.blockedCategories.filter((x) => x !== cat) : [...c.blockedCategories, cat] });

  return (
    <li className="stack cardbox">
      <div className={`vcard ${frozen ? 'frozen' : ''}`} aria-label={`${c.label} card ending ${c.last4}`}>
        <span className="vc-top"><b>{tx('G·Plan')}</b><em>{tx('DEMO {kind}', { kind: c.kind })}</em></span>
        <span className="vc-num">•••• •••• •••• {c.last4}</span>
        <span className="vc-bot"><span>{c.label}</span><span>{c.expiry}</span></span>
        {frozen && <span className="vc-flag">{tx('Frozen')}</span>}
        {c.physicalStatus && <span className="vc-flag">{tx('Delivery: {v1}', { v1: cap(c.physicalStatus) })}</span>}
      </div>
      <p className="muted">{tx('Spent this month {v1} of {v2}. Full card numbers are never shown.', { v1: formatNaira(c.spentThisMonthMinor), v2: formatNaira(c.monthlyLimitMinor) })}</p>
      <div className="inline">
        <button onClick={() => patch({ status: frozen ? 'active' : 'frozen' })}>{frozen ? tx('Unfreeze card') : tx('Freeze card')}</button>
      </div>
      <label className="check"><input type="checkbox" checked={c.onlineEnabled} onChange={(e) => patch({ onlineEnabled: e.target.checked })} /><span>{tx('Online payments')}</span></label>
      <label className="check"><input type="checkbox" checked={c.internationalEnabled} onChange={(e) => patch({ internationalEnabled: e.target.checked })} /><span>{tx('International use')}</span></label>
      <form className="inline" onSubmit={(e) => { e.preventDefault(); const m = toMinor(limit); if (m) { patch({ monthlyLimitMinor: m }); setLimit(''); } }}>
        <input inputMode="decimal" placeholder={tx('New monthly limit ₦')} value={limit} onChange={(e) => setLimit(e.target.value)} aria-label={tx('Monthly limit')} />
        <button>{tx('Set limit')}</button>
      </form>
      <fieldset className="cats-block"><legend>{tx('Block categories')}</legend>
        {categories.map((cat) => (
          <label key={cat} className="check"><input type="checkbox" checked={c.blockedCategories.includes(cat)} onChange={() => toggleCat(cat)} /><span>{cap(cat)}</span></label>
        ))}
      </fieldset>
      <details>
        <summary>{tx('Try a demo purchase')}</summary>
        <form className="stack" onSubmit={charge}>
          <label>{tx('Merchant')}<input value={buy.merchant} onChange={(e) => setBuy({ ...buy, merchant: e.target.value })} /></label>
          <label>{tx('Category')}<select value={buy.category} onChange={(e) => setBuy({ ...buy, category: e.target.value })}>{categories.map((x) => <option key={x} value={x}>{cap(x)}</option>)}</select></label>
          <label>{tx('Amount (₦)')}<input inputMode="decimal" value={buy.amount} onChange={(e) => setBuy({ ...buy, amount: e.target.value })} /></label>
          <label className="check"><input type="checkbox" checked={buy.online} onChange={(e) => setBuy({ ...buy, online: e.target.checked })} /><span>{tx('Online purchase')}</span></label>
          <label className="check"><input type="checkbox" checked={buy.international} onChange={(e) => setBuy({ ...buy, international: e.target.checked })} /><span>{tx('Abroad')}</span></label>
          <button>{tx('Pay with this card')}</button>
        </form>
      </details>
      <details>
        <summary>{tx('Lost or damaged?')}</summary>
        <div className="stack">
          <p className="muted">{tx('This blocks the card and issues a new one. Enter your password to confirm.')}</p>
          <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder={tx('Password')} aria-label={tx('Password')} />
          <button onClick={replace} disabled={!pw}>{tx('Block and replace')}</button>
        </div>
      </details>
      {msg && <p className="ok">{msg}</p>}
      <Err>{err}</Err>
    </li>
  );
}

export default function Cards({ go, refresh }) {
  const { data, error, reload } = useLoad(() => api('/cards'), []);
  const [label, setLabel] = useState(''); const [err, setErr] = useState('');
  async function add(kind) {
    setErr('');
    try { await api('/cards', { method: 'POST', body: { label: label || undefined, kind } }); setLabel(''); reload(); } catch (e) { setErr(e.message); }
  }
  return (
    <Page title={tx('Cards')} go={go} sub={tx('Demo cards. No real card network is connected, and full card numbers are never shown.')}>
      <Err>{error}</Err>
      {data?.cards.length === 0 && <p className="empty">{tx('No cards yet. Create a virtual card in one tap.')}</p>}
      <ul className="goals">{data?.cards.map((c) => <CardView key={c.id} c={c} categories={data.categories} reload={reload} refresh={refresh} />)}</ul>
      <div className="stack">
        <h3>{tx('New card')}</h3>
        <input value={label} onChange={(e) => setLabel(e.target.value)} placeholder={tx('Name it, e.g. Online shopping')} maxLength={30} aria-label={tx('Card name')} />
        <div className="inline"><button className="primary" onClick={() => add('virtual')}>{tx('Virtual card')}</button><button onClick={() => add('physical')}>{tx('Request physical card')}</button></div>
        <Err>{err}</Err>
      </div>
    </Page>
  );
}
