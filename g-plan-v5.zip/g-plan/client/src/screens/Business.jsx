import { tx } from '../i18n.jsx';
import React, { useState } from 'react';
import { api, formatNaira, toMinor, cap } from '../api.js';
import { Err, Tabs, useLoad, Page, Authorise } from '../ui.jsx';
import { QrImage } from '../Qr.jsx';
import BusinessBulk from './BusinessBulk.jsx';
import BusinessMandates from './BusinessMandates.jsx';

const blank = () => ({ description: '', qty: '1', price: '' });
const ROLE_LABEL = { owner: 'Owner', finance: 'Finance manager', staff: 'Staff', auditor: 'Auditor' };

export default function Business({ go }) {
  const biz = useLoad(() => api('/business'), []);
  const [tab, setTab] = useState('');
  const [setup, setSetup] = useState({ name: '', category: '' });
  const [err, setErr] = useState('');

  async function create(e) {
    e.preventDefault(); setErr('');
    try { await api('/business', { method: 'POST', body: setup }); biz.reload(); }
    catch (er) { setErr(er.message); }
  }
  async function answer(id, decision) {
    setErr('');
    try { await api(`/business/invites/${id}/${decision}`, { method: 'POST' }); biz.reload(); }
    catch (er) { setErr(er.message); }
  }

  if (biz.loading && !biz.data) return <Page title={tx('Business')} go={go}><p role="status">{tx('Loading…')}</p></Page>;
  const b = biz.data?.business;
  const invites = biz.data?.invites || [];

  if (!b) {
    return (
      <Page title={tx('Business')} go={go} sub={tx('A shared business wallet with a team, invoices that customers pay by link or QR, and payouts with owner approval. Demo only.')}>
        {invites.length > 0 && (
          <div className="stack">
            <h3>{tx('Invitations')}</h3>
            <ul className="ledger">{invites.map((i) => (
              <li key={i.id} className="sched"><span>{i.businessName}<small>{tx('As {role}', { role: tx(ROLE_LABEL[i.role]) })}</small></span>
                <span className="inline"><button onClick={() => answer(i.id, 'accept')}>{tx('Accept')}</button><button className="link" onClick={() => answer(i.id, 'decline')}>{tx('Decline')}</button></span></li>
            ))}</ul>
          </div>
        )}
        <form className="stack" onSubmit={create}>
          <h3>{tx('Start your own')}</h3>
          <label>{tx('Business name')}<input value={setup.name} onChange={(e) => setSetup({ ...setup, name: e.target.value })} required /></label>
          <label>{tx('What do you sell? (optional)')}<input value={setup.category} onChange={(e) => setSetup({ ...setup, category: e.target.value })} maxLength={40} /></label>
          <Err>{err || biz.error}</Err>
          <button className="primary">{tx('Create business')}</button>
          {err.includes('Verify your identity') && <button type="button" className="link" onClick={() => go('security')}>{tx('Open Security to verify')}</button>}
        </form>
      </Page>
    );
  }

  const can = (p) => b.permissions.includes(p);
  const tabs = [
    can('invoices.read') && ['invoices', 'Invoices'],
    can('wallet.read') && ['wallet', 'Wallet'],
    can('payouts.read') && ['bulk', 'Payroll & bulk'],
    can('mandates.read') && ['mandates', 'Direct debits'],
    can('team.read') && ['team', 'Team'],
    can('report.read') && ['report', 'Report'],
  ].filter(Boolean);
  const current = tabs.some(([id]) => id === tab) ? tab : tabs[0][0];

  return (
    <Page title={b.name} go={go} sub={b.myRole === 'owner' ? tx('You are the owner. Demo only, no real money.') : tx('You are a {role}. Demo only, no real money.', { role: tx(ROLE_LABEL[b.myRole]).toLowerCase() })}>
      {biz.data?.ownershipOffer && <OwnershipOffer offer={biz.data.ownershipOffer} name={b.name} onDone={biz.reload} />}
      {invites.length > 0 && <p className="muted">{tx('You also have {length} invitation(s) waiting. Leave this business to accept one.', { length: invites.length })}</p>}
      <Err>{err}</Err>
      <Tabs value={current} onChange={setTab} items={tabs} />
      {current === 'invoices' && <Invoices canCancel={can('invoices.cancel')} />}
      {current === 'wallet' && <Wallet can={can} threshold={b.approvalThresholdMinor} cap={b.dailyCapMinor} onThreshold={biz.reload} />}
      {current === 'bulk' && <BusinessBulk can={can} />}
      {current === 'mandates' && <BusinessMandates can={can} />}
      {current === 'team' && <Team can={can} onChanged={biz.reload} />}
      {current === 'report' && <Report />}
      {b.myRole !== 'owner' && <button className="link" onClick={async () => { if (window.confirm(tx('Leave this business?'))) { try { await api('/business/leave', { method: 'POST' }); biz.reload(); } catch (er) { setErr(er.message); } } }}>{tx('Leave this business')}</button>}
    </Page>
  );
}

function Invoices({ canCancel }) {
  const list = useLoad(() => api('/business/invoices'), []);
  const [f, setF] = useState({ customerName: '', customerEmail: '', dueDays: '30', note: '', items: [blank()] });
  const [made, setMade] = useState(null);
  const [err, setErr] = useState('');
  const link = (t) => `${window.location.origin}/?pay=${t}`;
  const setItem = (i, k, v) => setF({ ...f, items: f.items.map((x, n) => (n === i ? { ...x, [k]: v } : x)) });
  const total = f.items.reduce((s, i) => s + (toMinor(i.price) || 0) * (Number(i.qty) || 0), 0);

  async function create(e) {
    e.preventDefault(); setErr(''); setMade(null);
    try {
      const items = f.items.map((i) => ({ description: i.description, qty: Number(i.qty), unitMinor: toMinor(i.price) }));
      if (items.some((i) => !i.unitMinor)) throw new Error(tx('Enter a price for each line, like 2500.'));
      const d = await api('/business/invoices', { method: 'POST', body: { customerName: f.customerName, customerEmail: f.customerEmail || undefined, dueDays: Number(f.dueDays), note: f.note, items } });
      setMade(d.invoice); setF({ ...f, customerName: '', customerEmail: '', note: '', items: [blank()] }); list.reload();
    } catch (er) { setErr(er.message); }
  }
  async function cancel(id) { try { await api(`/business/invoices/${id}/cancel`, { method: 'POST' }); list.reload(); } catch (er) { setErr(er.message); } }

  return (
    <div className="stack">
      <form className="stack" onSubmit={create}>
        <h3>{tx('New invoice')}</h3>
        <label>{tx('Customer name')}<input value={f.customerName} onChange={(e) => setF({ ...f, customerName: e.target.value })} required /></label>
        <label>{tx('Customer email (optional, if they have G-Plan)')}<input type="email" value={f.customerEmail} onChange={(e) => setF({ ...f, customerEmail: e.target.value })} /></label>
        {f.items.map((it, i) => (
          <div key={i} className="inline">
            <input placeholder={tx('Item')} value={it.description} onChange={(e) => setItem(i, 'description', e.target.value)} aria-label={`Item ${i + 1}`} required />
            <input inputMode="numeric" className="narrow" value={it.qty} onChange={(e) => setItem(i, 'qty', e.target.value)} aria-label={tx('Quantity')} />
            <input inputMode="decimal" placeholder={tx('Price ₦')} value={it.price} onChange={(e) => setItem(i, 'price', e.target.value)} aria-label={tx('Price')} required />
          </div>
        ))}
        {f.items.length < 10 && <button type="button" className="link" onClick={() => setF({ ...f, items: [...f.items, blank()] })}>{tx('Add another item')}</button>}
        <label>{tx('Due in')}<select value={f.dueDays} onChange={(e) => setF({ ...f, dueDays: e.target.value })}><option value="7">{tx('7 days')}</option><option value="14">{tx('14 days')}</option><option value="30">{tx('30 days')}</option><option value="60">{tx('60 days')}</option></select></label>
        <p className="muted">{tx('Total shown: {v1}. The server works out the real total itself.', { v1: formatNaira(total) })}</p>
        <Err>{err}</Err>
        <button className="primary">{tx('Create invoice')}</button>
      </form>

      {made && (
        <div className="demo-box stack">
          <p className="ok">{tx('Invoice {number} created for {v2}.', { number: made.number, v2: formatNaira(made.totalMinor) })}</p>
          <p className="muted">{tx('Share this link, or let the customer scan the QR code:')}</p>
          <p className="key">{link(made.token)}</p>
          <QrImage text={link(made.token)} label={`Pay invoice ${made.number}`} />
        </div>
      )}

      <h3>{tx('Your invoices')}</h3>
      {list.data?.invoices.length === 0 && <p className="empty">{tx('No invoices yet.')}</p>}
      <ul className="ledger">
        {list.data?.invoices.map((x) => (
          <li key={x.id} className="sched">
            <div>
              <span>{x.invoice_number} · {x.customer_name}</span>
              <small>{tx('{v1} · {v2} · due {v3} · by {created_by}', { v1: formatNaira(x.amount_minor), v2: x.overdue ? tx('Overdue') : cap(x.status), v3: new Date(x.expires_at).toLocaleDateString(), created_by: x.created_by })}</small>
            </div>
            {canCancel && x.status === 'pending' && <button onClick={() => cancel(x.id)}>{tx('Cancel')}</button>}
          </li>
        ))}
      </ul>
    </div>
  );
}


// Shared wallet: balance, top-up (owner), payouts (owner and finance), approvals (owner).
function Wallet({ can, threshold, cap, onThreshold }) {
  const w = useLoad(() => api('/business/wallet'), []);
  const payouts = useLoad(() => (can('payouts.read') ? api('/business/payouts') : Promise.resolve({ payouts: [] })), []);
  const [mode, setMode] = useState('');   // '', 'topup', 'payout', 'approve'
  const [msg, setMsg] = useState('');
  const reloadAll = () => { w.reload(); payouts.reload(); };
  const pending = (payouts.data?.payouts || []).filter((p) => p.status === 'pending_approval');
  const [limit, setLimit] = useState(''); const [capIn, setCapIn] = useState('');
  async function saveCap(remove) {
    setMsg('');
    const v = remove ? null : (capIn.trim() === '0' ? 0 : toMinor(capIn));
    if (!remove && v === null) return setMsg(tx('Enter an amount like 500000, or 0 to stop all payouts.'));
    try { await api('/business/settings', { method: 'POST', body: { dailyCapMinor: v } }); setCapIn(''); onThreshold(); w.reload(); setMsg(remove ? tx('Daily cap removed.') : tx('Daily cap saved.')); } catch (er) { setMsg(er.message); }
  }

  async function saveThreshold(e) {
    e.preventDefault(); setMsg('');
    const v = limit.trim() === '0' ? 0 : toMinor(limit);
    if (v === null) return setMsg(tx('Enter an amount like 50000, or 0.'));
    try { await api('/business/settings', { method: 'POST', body: { approvalThresholdMinor: v } }); setLimit(''); onThreshold(); setMsg(tx('Saved.')); } catch (er) { setMsg(er.message); }
  }

  return (
    <div className="stack">
      <Err>{w.error}</Err>
      {w.data && (<>
        <p className="big-amount">{formatNaira(w.data.wallet.availableMinor)}</p>
        <p className="muted">{tx('Business wallet, available now. It is separate from anyone\'s personal wallet.')}</p>
        {w.data.limits && <p className="muted">{tx('Paid out today by the whole team: {v1} of {v2}{v3}. The limit follows the owner\'s verification level.', { v1: formatNaira(w.data.limits.usedTodayMinor), v2: formatNaira(w.data.limits.dailyMinor), v3: w.data.limits.capMinor !== null ? ' (the owner set a lower daily cap)' : '' })}</p>}
      </>)}
      <div className="inline">
        {can('wallet.topup') && <button onClick={() => setMode(mode === 'topup' ? '' : 'topup')}>{tx('Top up')}</button>}
        {can('payouts.create') && <button onClick={() => setMode(mode === 'payout' ? '' : 'payout')}>{tx('Send a payout')}</button>}
      </div>
      {msg && <p className="muted" role="status">{msg}</p>}
      {mode === 'topup' && <TopUp onDone={() => { setMode(''); reloadAll(); }} />}
      {mode === 'payout' && <PayoutForm threshold={threshold} isOwner={can('payouts.approve')} onDone={(m) => { setMode(''); setMsg(m); reloadAll(); }} />}

      {pending.length > 0 && (<>
        <h3>{tx('Waiting for approval')}</h3>
        <ul className="ledger">{pending.map((p) => <PendingRow key={p.id} p={p} canApprove={can('payouts.approve')} onDone={reloadAll} />)}</ul>
      </>)}

      {can('payouts.approve') && (
        <form className="stack" onSubmit={saveThreshold}>
          <h3>{tx('Approval limit')}</h3>
          <p className="muted">{tx('A finance manager can send up to {v1} on their own. Anything above waits for you. Your own payouts go straight through.', { v1: formatNaira(threshold ?? 0) })}</p>
          <div className="inline"><input inputMode="decimal" placeholder={tx('New limit in ₦ (0 = everything waits)')} value={limit} onChange={(e) => setLimit(e.target.value)} aria-label={tx('Approval limit')} /><button>{tx('Save')}</button></div>
        </form>
      )}

      {can('settings.manage') && (
        <div className="stack">
          <h3>{tx('Daily cap for the whole team')}</h3>
          <p className="muted">{tx('{v1} A cap can only lower the limit, never raise it.', { v1: cap === null || cap === undefined ? tx('No cap set. Only the limit from your verification level applies.') : `Cap: ${formatNaira(cap)} a day, counted across everyone on the team.` })}</p>
          <div className="inline"><input inputMode="decimal" placeholder={tx('Daily cap in ₦ (0 = no payouts)')} value={capIn} onChange={(e) => setCapIn(e.target.value)} aria-label={tx('Daily cap')} /><button onClick={() => saveCap(false)}>{tx('Save')}</button>{cap !== null && cap !== undefined && <button className="link" onClick={() => saveCap(true)}>{tx('Remove cap')}</button>}</div>
        </div>
      )}

      {can('payouts.read') && (<>
        <h3>{tx('Payouts')}</h3>
        {payouts.data?.payouts.length === 0 && <p className="empty">{tx('No payouts yet.')}</p>}
        <ul className="ledger">{payouts.data?.payouts.map((p) => (
          <li key={p.id}><span>{p.recipient.name}{p.recipient.bank ? ` · ${p.recipient.bank} ••••${p.recipient.accountLast4}` : ''}
            <small>{tx('{v1} · {v2} · by {createdBy} · {v4}', { v1: formatNaira(p.amountMinor), v2: p.status === 'executed' ? cap(p.state || 'processing') : cap(p.status), createdBy: p.createdBy, v4: new Date(p.createdAt).toLocaleDateString() })}</small></span></li>
        ))}</ul>
      </>)}

      <h3>{tx('Wallet activity')}</h3>
      {w.data?.activity.length === 0 && <p className="empty">{tx('No activity yet.')}</p>}
      <ul className="ledger">{w.data?.activity.map((a) => (
        <li key={a.id}><span>{a.description || cap(a.type)}<small>{new Date(a.created_at).toLocaleString()} · {cap(a.state)} · {a.reference}</small></span>
          <b className={a.net_minor >= 0 ? 'in' : 'out'}>{a.net_minor >= 0 ? '+' : '−'}{formatNaira(Math.abs(a.net_minor))}</b></li>
      ))}</ul>
    </div>
  );
}

function useAuth() {
  const [pw, setPw] = useState(''); const [otp, setOtp] = useState(''); const [otpNeeded, setOtpNeeded] = useState(false);
  return { pw, setPw, otp, setOtp, otpNeeded, setOtpNeeded };
}

function TopUp({ onDone }) {
  const a = useAuth();
  const [amount, setAmount] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const [key] = useState(() => crypto.randomUUID());
  async function submit(e) {
    e.preventDefault(); setErr('');
    const amountMinor = toMinor(amount);
    if (!amountMinor) return setErr(tx('Enter an amount like 2500.'));
    setBusy(true);
    try { await api('/business/wallet/topup', { method: 'POST', idemKey: key, body: { amountMinor, password: a.pw, otp: a.otp } }); onDone(); }
    catch (er) { if (er.code === 'OTP_REQUIRED') a.setOtpNeeded(true); setErr(er.message); } finally { setBusy(false); }
  }
  return (
    <form className="stack demo-box" onSubmit={submit}>
      <h3>{tx('Top up from your personal wallet')}</h3>
      <label>{tx('Amount ₦')}<input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} required /></label>
      <Authorise {...a} />
      <Err>{err}</Err>
      <button className="primary" disabled={busy}>{busy ? tx('Moving…') : tx('Move money to the business')}</button>
    </form>
  );
}

function PayoutForm({ threshold, isOwner, onDone }) {
  const a = useAuth();
  const banks = useLoad(() => api('/banks'), []);
  const [kind, setKind] = useState('internal');
  const [f, setF] = useState({ email: '', bankCode: '', accountNumber: '', amount: '', note: '' });
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const [key] = useState(() => crypto.randomUUID());
  const amountMinor = toMinor(f.amount);
  const waits = !isOwner && amountMinor !== null && amountMinor > (threshold ?? 0);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault(); setErr('');
    if (!amountMinor) return setErr(tx('Enter an amount like 2500.'));
    setBusy(true);
    try {
      const body = { kind, amountMinor, note: f.note, password: a.pw, otp: a.otp, ...(kind === 'internal' ? { email: f.email } : { bankCode: f.bankCode, accountNumber: f.accountNumber }) };
      const d = await api('/business/payouts', { method: 'POST', idemKey: key, body });
      onDone(d.needsApproval ? 'Sent to the owner for approval. No money has moved yet.' : 'Payout sent.');
    } catch (er) {
      if (er.code === 'OTP_REQUIRED') a.setOtpNeeded(true);
      setErr(er.status >= 500 || er.code === 'NETWORK' ? tx('We could not confirm if this was sent. Check Payouts before trying again.') : er.message);
    } finally { setBusy(false); }
  }
  return (
    <form className="stack demo-box" onSubmit={submit}>
      <h3>{tx('New payout from the business wallet')}</h3>
      <Tabs value={kind} onChange={setKind} items={[['internal', tx('G-Plan account')], ['bank', tx('Bank account')]]} />
      {kind === 'internal'
        ? <label>{tx('Recipient G-Plan email')}<input type="email" value={f.email} onChange={set('email')} required /></label>
        : (<>
          <label>{tx('Bank')}<select value={f.bankCode} onChange={set('bankCode')} required><option value="">{tx('Choose a bank')}</option>{banks.data?.banks.map((b) => <option key={b.code} value={b.code}>{b.name}</option>)}</select></label>
          <label>{tx('Account number')}<input inputMode="numeric" maxLength={10} value={f.accountNumber} onChange={set('accountNumber')} required /></label>
        </>)}
      <label>{tx('Amount ₦')}<input inputMode="decimal" value={f.amount} onChange={set('amount')} required /></label>
      <label>{tx('Note (optional)')}<input maxLength={140} value={f.note} onChange={set('note')} /></label>
      {waits && <p className="muted">{tx('This is above your limit of {v1}, so it will wait for the owner to approve. No money moves until they do.', { v1: formatNaira(threshold ?? 0) })}</p>}
      <Authorise {...a} />
      <Err>{err}</Err>
      <button className="primary" disabled={busy}>{busy ? tx('Working…') : waits ? tx('Send for approval') : tx('Send payout')}</button>
    </form>
  );
}

function PendingRow({ p, canApprove, onDone }) {
  const a = useAuth();
  const [open, setOpen] = useState(false); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  async function approve(e) {
    e.preventDefault(); setErr(''); setBusy(true);
    try { await api(`/business/payouts/${p.id}/approve`, { method: 'POST', body: { password: a.pw, otp: a.otp } }); onDone(); }
    catch (er) { if (er.code === 'OTP_REQUIRED') a.setOtpNeeded(true); setErr(er.message); } finally { setBusy(false); }
  }
  async function reject() { try { await api(`/business/payouts/${p.id}/reject`, { method: 'POST' }); onDone(); } catch (er) { setErr(er.message); } }
  async function cancel() { try { await api(`/business/payouts/${p.id}/cancel`, { method: 'POST' }); onDone(); } catch (er) { setErr(er.message); } }
  return (
    <li className="sched">
      <span>{p.recipient.name}{p.recipient.bank ? ` · ${p.recipient.bank} ••••${p.recipient.accountLast4}` : ''}<small>{tx('{v1} · proposed by {createdBy}{v3}', { v1: formatNaira(p.amountMinor), createdBy: p.createdBy, v3: p.note ? ` · ${p.note}` : '' })}</small></span>
      {canApprove ? (
        <span className="inline"><button onClick={() => setOpen(!open)}>{tx('Review')}</button><button className="danger" onClick={reject}>{tx('Reject')}</button></span>
      ) : <button onClick={cancel}>{tx('Withdraw')}</button>}
      {open && (
        <form className="stack" style={{ flexBasis: '100%' }} onSubmit={approve}>
          <Authorise {...a} />
          <button className="primary" disabled={busy}>{busy ? tx('Sending…') : `Approve and send ${formatNaira(p.amountMinor)}`}</button>
        </form>
      )}
      {err && <Err>{err}</Err>}
    </li>
  );
}

// Offers or accepts ownership. Both people confirm with their password and a two-step code.
function OwnershipOffer({ offer, name, onDone }) {
  const [pw, setPw] = useState(''); const [code, setCode] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const act = async (what, body) => { setErr(''); setBusy(true); try { await api(`/business/ownership/${offer.id}/${what}`, { method: 'POST', body }); onDone(); } catch (e) { setErr(e.message); } finally { setBusy(false); } };
  const until = new Date(offer.expiresAt).toLocaleDateString();
  if (offer.direction === 'outgoing') {
    return (
      <div className="demo-box stack" role="region" aria-label={tx('Ownership offer')}>
        <b>{tx('You offered {name} to {otherName}', { name, otherName: offer.otherName })}</b>
        <p className="muted">{tx('Waiting for them to accept until {until}. Nothing changes until they do.', { until })}</p>
        <Err>{err}</Err><button onClick={() => act('cancel')} disabled={busy}>{tx('Withdraw the offer')}</button>
      </div>
    );
  }
  return (
    <form className="demo-box stack" role="region" aria-label={tx('Ownership offer')} onSubmit={(e) => { e.preventDefault(); act('accept', { password: pw, code }); }}>
      <b>{tx('{otherName} wants to make you the owner of {name}', { otherName: offer.otherName, name })}</b>
      <p className="muted">{tx('You would control the wallet, the team and approvals. The business limits would follow your verification level. Offer ends {until}. Two-step verification must be on.', { until })}</p>
      <label>{tx('Your password')}<input type="password" autoComplete="current-password" value={pw} onChange={(e) => setPw(e.target.value)} required /></label>
      <label>{tx('Your two-step code')}<input inputMode="numeric" autoComplete="one-time-code" maxLength={6} value={code} onChange={(e) => setCode(e.target.value)} required /></label>
      <Err>{err}</Err>
      <div className="inline"><button className="primary" disabled={busy}>{tx('Accept ownership')}</button><button type="button" onClick={() => act('decline')} disabled={busy}>{tx('Decline')}</button></div>
    </form>
  );
}

function HandOver({ members, onDone }) {
  const [f, setF] = useState({ memberId: '', keepAccess: true, pw: '', code: '' }); const [err, setErr] = useState(''); const [msg, setMsg] = useState('');
  if (!members.length) return null;
  async function offer(e) {
    e.preventDefault(); setErr(''); setMsg('');
    if (!window.confirm(tx('Offer this business to that person? They must accept before anything changes.'))) return;
    try { await api('/business/ownership/offer', { method: 'POST', body: { memberId: f.memberId, keepAccess: f.keepAccess, password: f.pw, code: f.code } }); setMsg(tx('Offer sent. They have 3 days to accept.')); setF({ ...f, pw: '', code: '' }); onDone(); }
    catch (er) { setErr(er.message); }
  }
  return (
    <form className="stack" onSubmit={offer}>
      <h3>{tx('Hand the business to someone else')}</h3>
      <p className="muted">{tx('They must be on your team, verified, and accept the offer themselves. You can stay on as a finance manager. Two-step verification must be on for both of you.')}</p>
      <label>{tx('New owner')}<select value={f.memberId} onChange={(e) => setF({ ...f, memberId: e.target.value })} required><option value="">{tx('Choose someone')}</option>{members.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</select></label>
      <label className="check"><input type="checkbox" checked={f.keepAccess} onChange={(e) => setF({ ...f, keepAccess: e.target.checked })} /> {tx('Keep me on the team as a finance manager')}</label>
      <label>{tx('Your password')}<input type="password" autoComplete="current-password" value={f.pw} onChange={(e) => setF({ ...f, pw: e.target.value })} required /></label>
      <label>{tx('Your two-step code')}<input inputMode="numeric" autoComplete="one-time-code" maxLength={6} value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} required /></label>
      {msg && <p className="muted" role="status">{msg}</p>}<Err>{err}</Err>
      <button className="danger">{tx('Offer ownership')}</button>
    </form>
  );
}

// Team: the owner invites, changes roles and removes. Auditors can look. The reply to an invite never says whether the email has an account.
function Team({ can, onChanged }) {
  const t = useLoad(() => api('/business/members'), []);
  const [f, setF] = useState({ email: '', role: 'staff' });
  const [msg, setMsg] = useState(''); const [err, setErr] = useState('');
  async function invite(e) {
    e.preventDefault(); setErr(''); setMsg('');
    try { const d = await api('/business/members', { method: 'POST', body: f }); setMsg(d.note); setF({ ...f, email: '' }); t.reload(); } catch (er) { setErr(er.message); }
  }
  async function setRole(id, role) { setErr(''); try { await api(`/business/members/${id}/role`, { method: 'POST', body: { role } }); t.reload(); } catch (er) { setErr(er.message); } }
  async function remove(id) { if (!window.confirm(tx('Remove this person?'))) return; setErr(''); try { await api(`/business/members/${id}`, { method: 'DELETE' }); t.reload(); } catch (er) { setErr(er.message); } }
  return (
    <div className="stack">
      <Err>{err || t.error}</Err>
      <ul className="ledger">{t.data?.members.map((m) => (
        <li key={m.id} className="sched"><span>{m.name}{m.you ? ' (you)' : ''}<small>{m.email} · {m.status === 'invited' ? tx('Invited') : ROLE_LABEL[m.role]}</small></span>
          {can('team.manage') && m.role !== 'owner' && (
            <span className="inline">
              <select value={m.role} onChange={(e) => setRole(m.id, e.target.value)} aria-label={tx('Role for {name}', { name: m.name })}>
                <option value="finance">{tx('Finance manager')}</option><option value="staff">{tx('Staff')}</option><option value="auditor">{tx('Auditor')}</option></select>
              <button className="danger" onClick={() => remove(m.id)}>{tx('Remove')}</button>
            </span>)}
        </li>
      ))}</ul>
      {can('team.manage') && (
        <form className="stack" onSubmit={invite}>
          <h3>{tx('Invite someone')}</h3>
          <label>{tx('Their G-Plan email')}<input type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} required /></label>
          <label>{tx('Role')}<select value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })}>
            <option value="staff">{tx('Staff: makes invoices, cannot see the balance')}</option>
            <option value="finance">{tx('Finance manager: sees the wallet, sends payouts up to your limit')}</option>
            <option value="auditor">{tx('Auditor: can look at everything, change nothing')}</option></select></label>
          {msg && <p className="muted" role="status">{msg}</p>}
          <button className="primary">{tx('Send invitation')}</button>
        </form>
      )}
      {can('settings.manage') && <HandOver members={(t.data?.members || []).filter((m) => m.status === 'active' && m.role !== 'owner')} onDone={() => { t.reload(); onChanged?.(); }} />}
    </div>
  );
}

function Report() {
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7));
  const r = useLoad(() => api(`/business/report?month=${month}`), [month]);
  const rep = r.data?.report;
  return (
    <div className="stack">
      <label>{tx('Month')}<input type="month" value={month} onChange={(e) => setMonth(e.target.value)} /></label>
      <Err>{r.error}</Err>
      {rep && (
        <>
          <dl>
            <dt>{tx('Paid this month')}</dt><dd>{formatNaira(rep.paidMinor)} ({rep.paidCount})</dd>
            <dt>{tx('Waiting to be paid')}</dt><dd>{formatNaira(rep.outstandingMinor)} ({rep.outstandingCount})</dd>
            <dt>{tx('Overdue invoices')}</dt><dd>{rep.overdueCount}</dd>
          </dl>
          {rep.topCustomers.length > 0 && (<>
            <h3>{tx('Top customers')}</h3>
            <ul className="ledger">{rep.topCustomers.map((c) => <li key={c.name}><span>{c.name}</span><b>{formatNaira(c.totalMinor)}</b></li>)}</ul>
          </>)}
        </>
      )}
    </div>
  );
}
