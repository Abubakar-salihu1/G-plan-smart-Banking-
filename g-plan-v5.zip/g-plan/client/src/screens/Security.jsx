import { tx } from '../i18n.jsx';
import React, { useState } from 'react';
import { api, uploadPhoto, cap } from '../api.js';
import { Err, useLoad, Page, Tabs } from '../ui.jsx';
import { passkeysSupported, createPasskey } from '../webauthn.js';

const PHOTO_LABEL = { id_front: 'Front of your ID', selfie: 'A selfie holding your ID', id_back: 'Back of your ID (optional)' };

// Recovery codes are shown once. Save them somewhere safe and offline: they let you in if you lose your phone,
// so anyone who finds them can use them too.
function RecoveryPanel({ codes, onDone }) {
  const [saved, setSaved] = useState(false); const [copied, setCopied] = useState(false);
  const text = `G-Plan recovery codes. Each works once.\n${codes.join('\n')}\n`;
  async function copy() { try { await navigator.clipboard.writeText(text); setCopied(true); } catch { setCopied(false); } }
  return (
    <div className="stack demo-box" role="region" aria-label={tx('Your recovery codes')}>
      <h3>{tx('Save your recovery codes')}</h3>
      <p>{tx('If you lose your phone, each of these lets you sign in once.')} <b>{tx('We cannot show them again.')}</b> {tx('Keep them offline, like on paper in a safe place, and not in a screenshot or an email.')}</p>
      <ul className="key" style={{ listStyle: 'none', padding: 0, columns: 2, fontFamily: 'ui-monospace, monospace' }}>{codes.map((c) => <li key={c}>{c}</li>)}</ul>
      <div className="inline">
        <button onClick={copy}>{copied ? tx('Copied') : tx('Copy')}</button>
        <a className="link" href={`data:text/plain;charset=utf-8,${encodeURIComponent(text)}`} download="g-plan-recovery-codes.txt">{tx('Download')}</a>
      </div>
      <label className="check"><input type="checkbox" checked={saved} onChange={(e) => setSaved(e.target.checked)} /> {tx('I have saved these codes somewhere safe.')}</label>
      <button className="primary" disabled={!saved} onClick={onDone}>{tx('Done')}</button>
    </div>
  );
}

// ID photos for levels 2 and 3. Only shown when the server has photo upload switched on.
// Photos are sent once, stored encrypted, and never shown back to you here.
function KycPhotos({ tier, onChange }) {
  const cfg = useLoad(() => api('/kyc/documents/config'), []);
  const docs = useLoad(() => (cfg.data?.enabled ? api('/kyc/documents') : Promise.resolve({ documents: [] })), [cfg.data?.enabled]);
  const [err, setErr] = useState(''); const [busy, setBusy] = useState('');
  if (!cfg.data?.enabled || tier < 2) return null;
  const need = cfg.data.required[tier] || [];
  const waiting = (docs.data?.documents || []).filter((d) => !d.submitted);
  const has = (k) => waiting.some((d) => d.kind === k);
  async function pick(kind, file) {
    setErr('');
    if (!file) return;
    if (!['image/jpeg', 'image/png'].includes(file.type)) return setErr(tx('Use a JPEG or PNG photo.'));
    if (file.size > cfg.data.maxBytes) return setErr(`Photo is too big. Keep it under ${Math.round(cfg.data.maxBytes / 1048576)} MB.`);
    setBusy(kind);
    try { await uploadPhoto(`/kyc/documents/${kind}`, file); docs.reload(); onChange?.(); } catch (e) { setErr(e.message); } finally { setBusy(''); }
  }
  async function remove(kind) {
    const d = waiting.find((x) => x.kind === kind);
    if (d) { try { await api(`/kyc/documents/${d.id}`, { method: 'DELETE' }); docs.reload(); onChange?.(); } catch (e) { setErr(e.message); } }
  }
  return (
    <div className="stack">
      <h3>{tx('Photos for level {tier}', { tier })}</h3>
      <p className="muted">{tx('Photos are encrypted, removed of location data, seen only by our verification team, and deleted {retentionDays} days after a decision. Make sure the whole ID is visible and readable.', { retentionDays: cfg.data.retentionDays })}</p>
      {['id_front', 'selfie', 'id_back'].map((k) => (
        <div key={k} className="inline">
          <span style={{ flex: 2 }}>{PHOTO_LABEL[k]}{need.includes(k) ? '' : ''}{has(k) ? ' ✓ added' : ''}</span>
          <label className="link" style={{ flex: 1 }}>
            {busy === k ? tx('Uploading…') : has(k) ? tx('Replace') : tx('Add photo')}
            <input type="file" accept="image/jpeg,image/png" capture={k === 'selfie' ? 'user' : 'environment'} hidden disabled={!!busy} onChange={(e) => { pick(k, e.target.files[0]); e.target.value = ''; }} />
          </label>
          {has(k) && <button className="link" onClick={() => remove(k)}>{tx('Remove')}</button>}
        </div>
      ))}
      {need.some((k) => !has(k)) && <p className="muted">{tx('Still needed: {v1}.', { v1: need.filter((k) => !has(k)).map((k) => PHOTO_LABEL[k].toLowerCase()).join(', ') })}</p>}
      <Err>{err}</Err>
    </div>
  );
}

const short = (ua) => (ua || 'Unknown device').replace(/\(.*?\)/g, '').slice(0, 40);

export default function Security({ go, onUserChanged }) {
  const ov = useLoad(() => api('/security/overview'), []);
  const [msg, setMsg] = useState(''); const [err, setErr] = useState('');
  const [pw, setPw] = useState('');
  const [mfa, setMfa] = useState(null);       // { kind, secret?, otpauthUrl?, channel?, demoCode? }
  const [code, setCode] = useState('');
  const [kyc, setKyc] = useState({ idType: 'bvn', idNumber: '' });
  const [label, setLabel] = useState('');
  const [recovery, setRecovery] = useState(null);   // the fresh codes, shown once
  const o = ov.data;

  const wrap = (fn) => async (...a) => { setErr(''); setMsg(''); try { await fn(...a); } catch (e) { setErr(e.message); } };

  const startTotp = wrap(async () => { setMfa({ kind: 'totp', ...(await api('/security/mfa/totp/setup', { method: 'POST', body: { password: pw } })) }); });
  const confirmTotp = wrap(async () => { const d = await api('/security/mfa/totp/confirm', { method: 'POST', body: { code } }); setRecovery(d.recoveryCodes); setMfa(null); setCode(''); setPw(''); setMsg(tx('Authenticator app turned on.')); ov.reload(); onUserChanged?.(); });
  const startOtp = (channel) => wrap(async () => { const d = await api('/security/mfa/otp/start', { method: 'POST', body: { channel, password: pw } }); setMfa({ kind: 'otp', channel, demoCode: d.demoCode }); });
  const confirmOtp = wrap(async () => { const d = await api('/security/mfa/otp/confirm', { method: 'POST', body: { channel: mfa.channel, code } }); setRecovery(d.recoveryCodes); setMfa(null); setCode(''); setPw(''); setMsg(tx('Two-step verification turned on.')); ov.reload(); onUserChanged?.(); });
  const regenerate = wrap(async () => { const d = await api('/security/recovery-codes/regenerate', { method: 'POST', body: { password: pw, code } }); setRecovery(d.recoveryCodes); setPw(''); setCode(''); ov.reload(); });
  const disable = wrap(async () => { await api('/security/mfa/disable', { method: 'POST', body: { password: pw, code } }); setPw(''); setCode(''); setMsg(tx('Two-step verification turned off.')); ov.reload(); onUserChanged?.(); });

  const addPasskey = wrap(async () => {
    const options = await api('/security/passkeys/options', { method: 'POST', body: { password: pw } });
    const response = await createPasskey(options);
    await api('/security/passkeys/verify', { method: 'POST', body: { response, label: label || 'This device' } });
    setPw(''); setLabel(''); setMsg(tx('Passkey added. You can now sign in with your fingerprint, face or device PIN.')); ov.reload();
  });
  const removePasskey = (id) => wrap(async () => { await api(`/security/passkeys/${id}`, { method: 'DELETE', body: { password: pw } }); ov.reload(); });
  const revoke = (id) => wrap(async () => { await api(`/security/sessions/${id}/revoke`, { method: 'POST' }); ov.reload(); });
  const revokeOthers = wrap(async () => { await api('/security/sessions/revoke-others', { method: 'POST' }); setMsg(tx('Signed out of all other devices.')); ov.reload(); });
  const submitKyc = (tier) => wrap(async () => { const d = await api('/kyc', { method: 'POST', body: { tier, idType: kyc.idType, idNumber: kyc.idNumber } }); setKyc({ ...kyc, idNumber: '' }); setMsg(d.note); ov.reload(); onUserChanged?.(); });
  const verifyContact = (channel) => wrap(async () => { const d = await api('/security/verify/send', { method: 'POST', body: { channel } }); setMfa({ kind: 'verify', channel, demoCode: d.demoCode }); });
  const confirmVerify = wrap(async () => { await api('/security/verify/confirm', { method: 'POST', body: { channel: mfa.channel, code } }); setMfa(null); setCode(''); setMsg(tx('Verified.')); ov.reload(); });

  return (
    <Page title={tx('Security centre')} go={go}>
      <Err>{ov.error}</Err>
      {o && (
        <>
          <div className="shield">
            <b>{tx('{done} of {total} protections on', { done: o.protection.done, total: o.protection.total })}</b>
            <div className="bar"><i style={{ width: (o.protection.done / o.protection.total) * 100 + '%' }} /></div>
            <small>{tx('Two-step verification, passkey, verified email, verified phone, identity check.')}</small>
          </div>
          {msg && <p className="ok">{msg}</p>}
          <Err>{err}</Err>

          {recovery && <RecoveryPanel codes={recovery} onDone={() => setRecovery(null)} />}
          <h3>{tx('Two-step verification')}</h3>
          <p className="muted">{o.mfaMethod ? `On: ${o.mfaMethod === 'totp' ? 'authenticator app' : o.mfaMethod === 'sms' ? 'code by SMS' : 'code by email'}.` : tx('Off. Turn it on to protect larger payments and sign-ins.')}</p>
          {!mfa && (
            <div className="stack">
              <label>{tx('Your password (to change security settings)')}<input type="password" value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="current-password" /></label>
              {!o.mfaMethod ? (
                <div className="inline">
                  <button onClick={startTotp} disabled={!pw}>{tx('Authenticator app')}</button>
                  <button onClick={startOtp('sms')} disabled={!pw || !o.hasPhone}>{tx('SMS code')}</button>
                  <button onClick={startOtp('email')} disabled={!pw}>{tx('Email code')}</button>
                </div>
              ) : (
                <div className="stack">
                  <label>{tx('Current verification code')}<input inputMode="numeric" maxLength={6} value={code} onChange={(e) => setCode(e.target.value)} /></label>
                  <button onClick={disable} disabled={!pw || !code}>{tx('Turn off')}</button>
                  <p className="muted">{tx('{v1} Making a new set cancels the old one.', { v1: o.recoveryCodesLeft > 0 ? `Recovery codes: ${o.recoveryCodesLeft} left.${o.recoveryCodesLeft <= 2 ? ' Make a new set soon.' : ''}` : tx('You have no recovery codes. Make some now, in case you lose your phone.') })}</p>
                  <button onClick={regenerate} disabled={!pw || !code}>{tx('Make new recovery codes')}</button>
                  <p className="muted">{tx('For SMS or email users, request a code first by trying to send a payment, or sign in again.')}</p>
                </div>
              )}
              {!o.hasPhone && !o.mfaMethod && <p className="muted">{tx('Add a phone number in Profile to use SMS codes.')}</p>}
            </div>
          )}
          {mfa?.kind === 'totp' && (
            <div className="stack demo-box">
              <p>{tx('1. Open your authenticator app (Google Authenticator, Authy, Microsoft Authenticator).')}</p>
              <p>{tx('2. Add an account by choosing "Enter a setup key", and type this key:')}</p>
              <p className="key">{mfa.secret}</p>
              <p className="muted">{tx('Name: G-Plan · Type: time-based. Or')} <a href={mfa.otpauthUrl}>{tx('tap here to open it in your app')}</a>.</p>
              <label>{tx('3. Enter the 6-digit code it shows')}<input inputMode="numeric" maxLength={6} value={code} onChange={(e) => setCode(e.target.value)} /></label>
              <button className="primary" onClick={confirmTotp} disabled={code.length !== 6}>{tx('Turn on')}</button>
              <button className="link" onClick={() => setMfa(null)}>{tx('Cancel')}</button>
            </div>
          )}
          {(mfa?.kind === 'otp' || mfa?.kind === 'verify') && (
            <div className="stack demo-box">
              <p>{tx('We sent a code by {channel}.', { channel: mfa.channel })}</p>
              {mfa.demoCode && <p className="muted">{tx('Demo mode: your code is')} <b>{mfa.demoCode}</b> {tx('(no real {channel} is sent).', { channel: mfa.channel })}</p>}
              <input inputMode="numeric" maxLength={6} value={code} onChange={(e) => setCode(e.target.value)} placeholder={tx('6 digits')} aria-label={tx('Code')} />
              <button className="primary" onClick={mfa.kind === 'otp' ? confirmOtp : confirmVerify} disabled={code.length !== 6}>{tx('Confirm')}</button>
              <button className="link" onClick={() => setMfa(null)}>{tx('Cancel')}</button>
            </div>
          )}

          <h3>{tx('Passkeys (fingerprint, face or device PIN)')}</h3>
          {!passkeysSupported() && <p className="muted">{tx('This browser does not support passkeys.')}</p>}
          {o.passkeys.length === 0 && <p className="muted">{tx('None yet.')}</p>}
          <ul className="ledger">{o.passkeys.map((p) => (
            <li key={p.id}><span>{p.label}<small>{tx('Added {v1}', { v1: new Date(p.created_at).toLocaleDateString() })}</small></span><button onClick={removePasskey(p.id)} disabled={!pw}>{tx('Remove')}</button></li>
          ))}</ul>
          {passkeysSupported() && (
            <div className="inline">
              <input value={label} onChange={(e) => setLabel(e.target.value)} placeholder={tx('Name this device')} aria-label={tx('Passkey name')} maxLength={40} />
              <button onClick={addPasskey} disabled={!pw}>{tx('Add passkey')}</button>
            </div>
          )}
          <p className="muted">{tx('Enter your password above, then add or remove a passkey.')}</p>

          <h3>{tx('Verify your contact details')}</h3>
          <div className="inline">
            <button onClick={verifyContact('email')} disabled={o.emailVerified}>{o.emailVerified ? tx('Email verified') : tx('Verify email')}</button>
            <button onClick={verifyContact('sms')} disabled={o.phoneVerified || !o.hasPhone}>{o.phoneVerified ? tx('Phone verified') : tx('Verify phone')}</button>
          </div>

          <h3>{tx('Identity verification (KYC)')}</h3>
          <p className="muted">{tx('Level {kycTier} of 3. Higher levels raise your limits. Demo: level 1 is approved instantly after a format check; levels 2 and 3 wait for a reviewer and may ask for ID photos. We use your ID number for the check and keep only the last 4 digits.', { kycTier: o.kycTier })}</p>
          {o.kyc.map((k, i) => <p key={i} className="muted">{tx('Level {tier_requested}: {v2}', { tier_requested: k.tier_requested, v2: cap(k.status) })}</p>)}
          {o.kycTier < 3 && (
            <div className="stack">
              <div className="inline">
                <select value={kyc.idType} onChange={(e) => setKyc({ ...kyc, idType: e.target.value })} aria-label={tx('ID type')}><option value="bvn">{tx('BVN')}</option><option value="nin">{tx('NIN')}</option></select>
                <input inputMode="numeric" maxLength={11} value={kyc.idNumber} onChange={(e) => setKyc({ ...kyc, idNumber: e.target.value })} placeholder={tx('11 digits')} aria-label={tx('ID number')} />
              </div>
              <KycPhotos tier={o.kycTier + 1} />
              <button onClick={submitKyc(o.kycTier + 1)} disabled={kyc.idNumber.length !== 11}>{tx('Verify for level {v1}', { v1: o.kycTier + 1 })}</button>
            </div>
          )}

          <h3>{tx('Where you are signed in')}</h3>
          <ul className="ledger">{o.sessions.map((s) => (
            <li key={s.id}><span>{short(s.user_agent)}{s.current ? ' (this device)' : ''}<small>{tx('{ip} · last active {v2}', { ip: s.ip, v2: new Date(s.last_seen_at).toLocaleString() })}</small></span>
              {!s.current && <button onClick={revoke(s.id)}>{tx('Sign out')}</button>}</li>
          ))}</ul>
          {o.sessions.length > 1 && <button onClick={revokeOthers}>{tx('Sign out all other devices')}</button>}

          <h3>{tx('Recent sign-ins')}</h3>
          <ul className="ledger">{o.logins.map((l, i) => (
            <li key={i}><span>{l.success ? tx('Signed in') : tx('Failed attempt')}{l.reason ? ` (${cap(l.reason)})` : ''}<small>{new Date(l.created_at).toLocaleString()} · {l.ip}</small></span><b className={l.success ? 'in' : 'out'}>{cap(l.method)}</b></li>
          ))}</ul>
          <p className="muted">{tx('See something you do not recognise? Change your password and sign out other devices.')}</p>
        </>
      )}
    </Page>
  );
}
