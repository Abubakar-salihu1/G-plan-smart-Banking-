import { tx } from '../i18n.jsx';
import React, { useState, useCallback } from 'react';
import { api, formatNaira, toMinor, cap } from '../api.js';
import { Err, useLoad } from '../ui.jsx';

function GoalRow({ g, refresh }) {
  const [amount, setAmount] = useState('');
  const [rule, setRule] = useState({ amount: '', frequency: 'monthly' });
  const [error, setError] = useState('');
  const pct = Math.min(100, Math.round((g.currentMinor / g.targetMinor) * 100));

  async function move(kind) {
    setError('');
    const amountMinor = toMinor(amount);
    if (!amountMinor) return setError(tx('Enter an amount like 5000.'));
    try {
      await api(`/goals/${g.id}/${kind}`, { method: 'POST', body: { amountMinor }, idemKey: crypto.randomUUID() });
      setAmount(''); await refresh();
    } catch (e) { setError(e.message); }
  }
  async function addRule(e) {
    e.preventDefault(); setError('');
    const amountMinor = toMinor(rule.amount);
    if (!amountMinor) return setError(tx('Enter the amount to save each time.'));
    try { await api(`/goals/${g.id}/rules`, { method: 'POST', body: { amountMinor, frequency: rule.frequency } }); setRule({ ...rule, amount: '' }); await refresh(); }
    catch (er) { setError(er.message); }
  }
  async function ruleStatus(id, status) { await api(`/goals/rules/${id}`, { method: 'PATCH', body: { status } }); await refresh(); }

  return (
    <li className="goal">
      <div className="goal-head"><h3>{g.name}</h3><b>{pct}%</b></div>
      <div className="bar" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label={`${g.name} progress`}><i style={{ width: pct + '%' }} /></div>
      <p className="muted">
        {tx('{v1} of {v2} · {v3} to go {v4}', { v1: formatNaira(g.currentMinor), v2: formatNaira(g.targetMinor), v3: formatNaira(g.remainingMinor), v4: g.deadline && ` · by ${new Date(g.deadline + 'T00:00:00').toLocaleDateString()}` })}
      </p>
      {g.recommendedMonthlyMinor && (
        <p className="muted">{tx('To finish on time, save about {v1} a month. This is an estimate based on your deadline.', { v1: formatNaira(g.recommendedMonthlyMinor) })}</p>
      )}
      <div className="inline">
        <input inputMode="decimal" placeholder={tx('Amount (₦)')} value={amount} onChange={(e) => setAmount(e.target.value)} aria-label={tx('Amount for {name}', { name: g.name })} />
        <button onClick={() => move('contribute')}>{tx('Add')}</button>
        <button onClick={() => move('withdraw')}>{tx('Take out')}</button>
      </div>
      {g.rules.map((r) => (
        <p key={r.id} className="rule">{tx('Auto-save {v1} {frequency}, next {next_run_on} ({v4})', { v1: formatNaira(r.amount_minor), frequency: r.frequency, next_run_on: r.next_run_on, v4: cap(r.status) })}<button className="link" onClick={() => ruleStatus(r.id, r.status === 'active' ? 'paused' : 'active')}>{r.status === 'active' ? tx('Pause') : tx('Resume')}</button>
          {' '}<button className="link" onClick={() => ruleStatus(r.id, 'cancelled')}>{tx('Remove')}</button></p>
      ))}
      <form className="inline" onSubmit={addRule}>
        <input inputMode="decimal" placeholder={tx('Auto-save ₦')} value={rule.amount} onChange={(e) => setRule({ ...rule, amount: e.target.value })} aria-label={`Auto-save amount for ${g.name}`} />
        <select value={rule.frequency} onChange={(e) => setRule({ ...rule, frequency: e.target.value })} aria-label={tx('How often')}><option value="weekly">{tx('Weekly')}</option><option value="monthly">{tx('Monthly')}</option></select>
        <button>{tx('Set up')}</button>
      </form>
      <Err>{error}</Err>
    </li>
  );
}

// Round-ups: spare change from payments goes into one goal.
function RoundUps({ goals }) {
  const r = useLoad(() => api('/goals/roundup'), []);
  const [goalId, setGoalId] = useState(''); const [step, setStep] = useState(10000); const [err, setErr] = useState('');
  const cur = r.data?.roundup;
  const on = !!cur?.enabled;
  if (!goals.length) return null;
  async function save(enabled) {
    setErr('');
    try { await api('/goals/roundup', { method: 'PUT', body: { enabled, goalId: goalId || cur?.goalId || goals[0].id, stepMinor: step } }); r.reload(); }
    catch (e) { setErr(e.message); }
  }
  const label = (s) => `Next ₦${s / 100}`;
  return (
    <div className="stack demo-box">
      <h3>{tx('Round-ups')}</h3>
      <p className="muted">{tx('After a bank transfer, bill or card payment, round it up and save the spare change. A ₦1,275 bill rounded to the next ₦100 saves ₦25. Only payments after you switch this on count, and a round-up is skipped if you do not have the money.')}</p>
      {on && <p>{tx('On: {v1} into {v2}. Saved so far {v3} from {count} payments.', { v1: label(cur.stepMinor), v2: goals.find((g) => g.id === cur.goalId)?.name || 'your goal', v3: formatNaira(r.data.savedMinor), count: r.data.count })}</p>}
      <div className="inline">
        <select value={goalId || cur?.goalId || goals[0].id} onChange={(e) => setGoalId(e.target.value)} aria-label={tx('Goal for round-ups')}>{goals.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}</select>
        <select value={step} onChange={(e) => setStep(Number(e.target.value))} aria-label={tx('Round up to')}>{(r.data?.steps || [10000]).map((s) => <option key={s} value={s}>{label(s)}</option>)}</select>
      </div>
      <Err>{err || r.error}</Err>
      <div className="inline"><button className="primary" onClick={() => save(true)}>{on ? tx('Update') : tx('Turn on')}</button>{on && <button onClick={() => save(false)}>{tx('Turn off')}</button>}</div>
    </div>
  );
}

export default function Goals({ refresh: refreshHome }) {
  const goals = useLoad(() => api('/goals'), []);
  const [form, setForm] = useState({ name: '', target: '', deadline: '' });
  const [error, setError] = useState('');
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const reload = goals.reload;
  const refresh = useCallback(async () => { await reload(); await refreshHome(); }, [reload, refreshHome]);

  async function create(e) {
    e.preventDefault(); setError('');
    const targetMinor = toMinor(form.target);
    if (!targetMinor) return setError(tx('Enter a target like 250000.'));
    try {
      await api('/goals', { method: 'POST', body: { name: form.name, targetMinor, deadline: form.deadline || undefined } });
      setForm({ name: '', target: '', deadline: '' }); await refresh();
    } catch (err) { setError(err.message); }
  }

  return (
    <section className="stack">
      <h2>{tx('Savings goals')}</h2>
      {goals.data?.goals.length === 0 && <p className="empty">{tx('No goals yet. Name something you\'re saving for, like rent or a laptop.')}</p>}
      {goals.data?.demoInterestApr && <p className="muted">{tx('Demo mode: savings goals earn pretend interest at {v1}% a year, added monthly. It is not real money and not an offer.', { v1: Math.round(goals.data.demoInterestApr * 1000) / 10 })}</p>}
      <ul className="goals">{goals.data?.goals.map((g) => <GoalRow key={g.id} g={g} refresh={refresh} />)}</ul>
      {goals.data && <RoundUps key={goals.data.goals.length} goals={goals.data.goals} />}
      <form className="stack" onSubmit={create}>
        <h3>{tx('New goal')}</h3>
        <label>{tx('Name')}<input value={form.name} onChange={set('name')} required /></label>
        <label>{tx('Target (₦)')}<input inputMode="decimal" value={form.target} onChange={set('target')} required /></label>
        <label>{tx('Deadline (optional)')}<input type="date" value={form.deadline} onChange={set('deadline')} /></label>
        <Err>{error}</Err>
        <button className="primary">{tx('Create goal')}</button>
      </form>
    </section>
  );
}
