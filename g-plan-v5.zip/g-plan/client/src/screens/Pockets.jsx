import { tx } from '../i18n.jsx';
import React, { useState } from 'react';
import { api, formatNaira, toMinor, cap } from '../api.js';
import { Err, Authorise, useLoad, Page, Tabs } from '../ui.jsx';

const KIND = { joint: 'Joint wallet', child: 'Child wallet' };
const ROLE = { owner: 'Owner', partner: 'Partner', child: 'Child' };

function useAuth() {
  const [pw, setPw] = useState(''); const [otp, setOtp] = useState(''); const [otpNeeded, setOtpNeeded] = useState(false);
  return { pw, setPw, otp, setOtp, otpNeeded, setOtpNeeded };
}

export default function Pockets({ go }) {
  const list = useLoad(() => api('/pockets'), []);
  const [openId, setOpenId] = useState(null);
  const [f, setF] = useState({ kind: 'joint', name: '' });
  const [err, setErr] = useState('');

  async function create(e) {
    e.preventDefault(); setErr('');
    try { const d = await api('/pockets', { method: 'POST', body: f }); setF({ ...f, name: '' }); await list.reload(); setOpenId(d.id); }
    catch (er) { setErr(er.message); }
  }
  async function answer(id, decision) {
    setErr('');
    try { await api(`/pockets/invites/${id}/${decision}`, { method: 'POST' }); list.reload(); } catch (er) { setErr(er.message); }
  }

  if (openId) return <PocketView id={openId} go={go} onBack={() => { setOpenId(null); list.reload(); }} />;

  return (
    <Page title={tx('Pockets')} go={go} sub={tx('Share money with someone you trust. A joint wallet needs both people for big payments. A child wallet lets a parent set the rules. Demo only.')}>
      <Err>{err || list.error}</Err>
      {list.data?.invites.length > 0 && (<>
        <h3>{tx('Invitations')}</h3>
        <ul className="ledger">{list.data.invites.map((i) => (
          <li key={i.id} className="sched"><span>{i.name}<small>{tx('{fromName} invited you to a {v2} as {v3}', { fromName: i.fromName, v2: KIND[i.kind].toLowerCase(), v3: ROLE[i.role].toLowerCase() })}</small></span>
            <span className="inline"><button onClick={() => answer(i.id, 'accept')}>{tx('Accept')}</button><button className="link" onClick={() => answer(i.id, 'decline')}>{tx('Decline')}</button></span></li>
        ))}</ul>
      </>)}
      {list.data?.pockets.length === 0 && <p className="empty">{tx('No pockets yet.')}</p>}
      <ul className="ledger">{list.data?.pockets.map((p) => (
        <li key={p.id}><button className="link" onClick={() => setOpenId(p.id)} style={{ textAlign: 'left', flex: 1 }}>
          {p.name}<small>{KIND[p.kind]} · {ROLE[p.myRole]}{p.frozen ? ' · Frozen' : ''}{p.pendingCount ? ` · ${p.pendingCount} waiting` : ''}</small></button>
          <b>{formatNaira(p.balanceMinor)}</b></li>
      ))}</ul>
      <form className="stack" onSubmit={create}>
        <h3>{tx('New pocket')}</h3>
        <Tabs value={f.kind} onChange={(kind) => setF({ ...f, kind })} items={[['joint', tx('Joint wallet')], ['child', tx('Child wallet')]]} />
        <label>{tx('Name')}<input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} maxLength={40} required /></label>
        <button className="primary">{tx('Create')}</button>
        {err.includes('Verify your identity') && <button type="button" className="link" onClick={() => go('security')}>{tx('Open Security to verify')}</button>}
      </form>
    </Page>
  );
}

function PocketView({ id, go, onBack }) {
  const d = useLoad(() => api(`/pockets/${id}`), [id]);
  const [mode, setMode] = useState('');
  const [msg, setMsg] = useState(''); const [err, setErr] = useState('');
  if (!d.data) return <Page title={tx('Pocket')} go={go}><button className="link" onClick={onBack}>{tx('Back')}</button><Err>{d.error}</Err>{d.loading && <p role="status">{tx('Loading…')}</p>}</Page>;
  const { pocket: p, members, recipients, payments } = d.data;
  const owner = p.myRole === 'owner';
  const child = p.myRole === 'child';
  const canFund = !child;
  const done = (m) => { setMode(''); setMsg(m || ''); d.reload(); };
  const pending = payments.filter((x) => x.status === 'pending_approval');

  return (
    <Page title={p.name} go={go} sub={`${KIND[p.kind]} · you are ${ROLE[p.myRole].toLowerCase()}${p.frozen ? ' · frozen' : ''}`}>
      <button className="link" onClick={onBack}>{tx('All pockets')}</button>
      <p className="big-amount">{formatNaira(p.balanceMinor)}</p>
      {child && <p className="muted">{tx('You have spent {v1} of your {v2} weekly limit. Weeks start on Monday.', { v1: formatNaira(p.spentThisWeekMinor || 0), v2: formatNaira(p.weeklyLimitMinor) })}</p>}
      {p.kind === 'joint' && !child && <p className="muted">{tx('Either of you can pay up to {v1} alone. Above that, the other person must approve.', { v1: formatNaira(p.soloLimitMinor) })}</p>}
      <Err>{err}</Err>
      {msg && <p className="muted" role="status">{msg}</p>}
      <div className="inline">
        {canFund && <button onClick={() => setMode(mode === 'fund' ? '' : 'fund')}>{tx('Add money')}</button>}
        <button onClick={() => setMode(mode === 'pay' ? '' : 'pay')} disabled={p.frozen && !owner}>{tx('Pay someone')}</button>
      </div>
      {mode === 'fund' && <Fund id={id} onDone={() => done('Money added.')} />}
      {mode === 'pay' && <Pay id={id} p={p} recipients={recipients} onDone={(m) => done(m)} />}

      {pending.length > 0 && (<><h3>{tx('Waiting for approval')}</h3>
        <ul className="ledger">{pending.map((x) => <PendingRow key={x.id} id={id} x={x} canApprove={!child && !x.mine} onDone={() => done()} />)}</ul></>)}

      <h3>{tx('People')}</h3>
      <ul className="ledger">{members.map((m) => (
        <li key={m.id} className="sched"><span>{m.name}{m.you ? ' (you)' : ''}<small>{m.status === 'invited' ? tx('Invited') : ROLE[m.role]}{m.email ? ` · ${m.email}` : ''}</small></span>
          {owner && m.role !== 'owner' && <button className="danger" onClick={async () => { if (window.confirm(tx('Remove this person?'))) { try { await api(`/pockets/${id}/members/${m.id}`, { method: 'DELETE' }); d.reload(); } catch (e) { setErr(e.message); } } }}>{tx('Remove')}</button>}
        </li>
      ))}</ul>
      {!owner && <button className="link" onClick={async () => { if (window.confirm(tx('Leave this pocket?'))) { try { await api(`/pockets/${id}/leave`, { method: 'POST' }); onBack(); } catch (e) { setErr(e.message); } } }}>{tx('Leave this pocket')}</button>}
      {owner && <Invite id={id} kind={p.kind} onDone={() => d.reload()} />}
      {owner && <Settings id={id} p={p} onDone={() => d.reload()} />}
      {p.kind === 'child' && <Recipients id={id} list={recipients} canEdit={owner} onDone={() => d.reload()} />}

      <h3>{tx('Payments')}</h3>
      {payments.length === 0 && <p className="empty">{tx('No payments yet.')}</p>}
      <ul className="ledger">{payments.map((x) => (
        <li key={x.id}><span>{tx('To {to}{v2}', { to: x.to, v2: x.note ? ` · ${x.note}` : '' })}<small>{tx('{v1} · {v2} · by {by} · {v4}', { v1: formatNaira(x.amountMinor), v2: x.status === 'executed' ? cap(x.state || 'processing') : cap(x.status), by: x.by, v4: new Date(x.createdAt).toLocaleDateString() })}</small></span></li>
      ))}</ul>
    </Page>
  );
}

function Fund({ id, onDone }) {
  const a = useAuth(); const [amount, setAmount] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false); const [key] = useState(() => crypto.randomUUID());
  async function go(e) {
    e.preventDefault(); setErr('');
    const amountMinor = toMinor(amount); if (!amountMinor) return setErr(tx('Enter an amount like 2500.'));
    setBusy(true);
    try { await api(`/pockets/${id}/fund`, { method: 'POST', idemKey: key, body: { amountMinor, password: a.pw, otp: a.otp } }); onDone(); }
    catch (er) { if (er.code === 'OTP_REQUIRED') a.setOtpNeeded(true); setErr(er.message); } finally { setBusy(false); }
  }
  return (
    <form className="stack demo-box" onSubmit={go}>
      <h3>{tx('Add from your wallet')}</h3>
      <label>{tx('Amount ₦')}<input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} required /></label>
      <Authorise {...a} /><Err>{err}</Err>
      <button className="primary" disabled={busy}>{busy ? tx('Moving…') : tx('Add money')}</button>
    </form>
  );
}

function Pay({ id, p, recipients, onDone }) {
  const a = useAuth(); const child = p.myRole === 'child';
  const [f, setF] = useState({ email: '', recipientId: child ? (recipients[0]?.id || '') : '', amount: '', note: '' });
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false); const [key] = useState(() => crypto.randomUUID());
  const amountMinor = toMinor(f.amount);
  const waits = p.kind === 'joint' && amountMinor !== null && amountMinor > p.soloLimitMinor;
  async function submit(e) {
    e.preventDefault(); setErr('');
    if (!amountMinor) return setErr(tx('Enter an amount like 2500.'));
    setBusy(true);
    try {
      const body = { amountMinor, note: f.note, password: a.pw, otp: a.otp, ...(child || f.recipientId ? { recipientId: f.recipientId } : { email: f.email }) };
      const r = await api(`/pockets/${id}/pay`, { method: 'POST', idemKey: key, body });
      onDone(r.needsApproval ? 'Sent for approval. No money has moved yet.' : 'Payment sent.');
    } catch (er) {
      if (er.code === 'OTP_REQUIRED') a.setOtpNeeded(true);
      setErr(er.status >= 500 || er.code === 'NETWORK' ? tx('We could not confirm if this was sent. Check Payments before trying again.') : er.message);
    } finally { setBusy(false); }
  }
  return (
    <form className="stack demo-box" onSubmit={submit}>
      <h3>{tx('Pay someone')}</h3>
      {child
        ? (recipients.length === 0 ? <p className="muted">{tx('Your parent has not approved anyone yet.')}</p>
          : <label>{tx('To')}<select value={f.recipientId} onChange={(e) => setF({ ...f, recipientId: e.target.value })}>{recipients.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</select></label>)
        : <label>{tx('Their G-Plan email')}<input type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value, recipientId: '' })} required /></label>}
      <label>{tx('Amount ₦')}<input inputMode="decimal" value={f.amount} onChange={(e) => setF({ ...f, amount: e.target.value })} required /></label>
      <label>{tx('Note (optional)')}<input maxLength={140} value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} /></label>
      {waits && <p className="muted">{tx('This is above {v1}, so the other person must approve it. No money moves until they do.', { v1: formatNaira(p.soloLimitMinor) })}</p>}
      <Authorise {...a} /><Err>{err}</Err>
      <button className="primary" disabled={busy || (child && recipients.length === 0)}>{busy ? tx('Working…') : waits ? tx('Send for approval') : tx('Send')}</button>
    </form>
  );
}

function PendingRow({ id, x, canApprove, onDone }) {
  const a = useAuth(); const [open, setOpen] = useState(false); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  async function approve(e) {
    e.preventDefault(); setErr(''); setBusy(true);
    try { await api(`/pockets/${id}/payments/${x.id}/approve`, { method: 'POST', body: { password: a.pw, otp: a.otp } }); onDone(); }
    catch (er) { if (er.code === 'OTP_REQUIRED') a.setOtpNeeded(true); setErr(er.message); } finally { setBusy(false); }
  }
  const act = (what) => async () => { try { await api(`/pockets/${id}/payments/${x.id}/${what}`, { method: 'POST' }); onDone(); } catch (er) { setErr(er.message); } };
  return (
    <li className="sched">
      <span>{tx('To {to}', { to: x.to })}<small>{tx('{v1} · proposed by {by}{v3}', { v1: formatNaira(x.amountMinor), by: x.by, v3: x.note ? ` · ${x.note}` : '' })}</small></span>
      {canApprove ? <span className="inline"><button onClick={() => setOpen(!open)}>{tx('Review')}</button><button className="danger" onClick={act('reject')}>{tx('Reject')}</button></span>
        : x.mine ? <button onClick={act('cancel')}>{tx('Withdraw')}</button> : null}
      {open && <form className="stack" style={{ flexBasis: '100%' }} onSubmit={approve}><Authorise {...a} /><button className="primary" disabled={busy}>{busy ? tx('Sending…') : `Approve and send ${formatNaira(x.amountMinor)}`}</button></form>}
      {err && <Err>{err}</Err>}
    </li>
  );
}

function Invite({ id, kind, onDone }) {
  const [email, setEmail] = useState(''); const [msg, setMsg] = useState(''); const [err, setErr] = useState('');
  async function go(e) {
    e.preventDefault(); setErr(''); setMsg('');
    try { const r = await api(`/pockets/${id}/members`, { method: 'POST', body: { email } }); setMsg(r.note); setEmail(''); onDone(); } catch (er) { setErr(er.message); }
  }
  return (
    <form className="stack" onSubmit={go}>
      <h3>{kind === 'joint' ? tx('Invite your partner') : tx('Add your child')}</h3>
      <p className="muted">{kind === 'child' ? tx('They need their own verified G-Plan account. You stay in control of limits, who they can pay, and freezing.') : tx('They need a verified G-Plan account and will see your invitation in Pockets.')}</p>
      <label>{tx('Their G-Plan email')}<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></label>
      {msg && <p className="muted" role="status">{msg}</p>}<Err>{err}</Err>
      <button>{tx('Send invitation')}</button>
    </form>
  );
}

function Settings({ id, p, onDone }) {
  const [v, setV] = useState({ solo: '', weekly: '', allowance: '' }); const [err, setErr] = useState(''); const [msg, setMsg] = useState('');
  async function save(body) { setErr(''); setMsg(''); try { await api(`/pockets/${id}/settings`, { method: 'POST', body }); setMsg(tx('Saved.')); onDone(); } catch (er) { setErr(er.message); } }
  const amt = (s) => (s.trim() === '0' ? 0 : toMinor(s));
  return (
    <div className="stack">
      <h3>{tx('Rules')}</h3>
      <button onClick={() => save({ frozen: !p.frozen })}>{p.frozen ? tx('Unfreeze this pocket') : tx('Freeze this pocket')}</button>
      {p.kind === 'joint' && (
        <div className="inline"><input inputMode="decimal" placeholder={`Solo limit, now ${formatNaira(p.soloLimitMinor)}`} value={v.solo} onChange={(e) => setV({ ...v, solo: e.target.value })} aria-label={tx('Solo limit')} />
          <button onClick={() => { const n = amt(v.solo); if (n === null) return setErr(tx('Enter an amount.')); save({ soloLimitMinor: n }); setV({ ...v, solo: '' }); }}>{tx('Save')}</button></div>
      )}
      {p.kind === 'child' && (<>
        <div className="inline"><input inputMode="decimal" placeholder={`Weekly limit, now ${formatNaira(p.weeklyLimitMinor)}`} value={v.weekly} onChange={(e) => setV({ ...v, weekly: e.target.value })} aria-label={tx('Weekly limit')} />
          <button onClick={() => { const n = amt(v.weekly); if (n === null) return setErr(tx('Enter an amount.')); save({ weeklyLimitMinor: n }); setV({ ...v, weekly: '' }); }}>{tx('Save')}</button></div>
        <div className="inline"><input inputMode="decimal" placeholder={`Weekly allowance from you, now ${formatNaira(p.allowanceMinor)} (0 = none)`} value={v.allowance} onChange={(e) => setV({ ...v, allowance: e.target.value })} aria-label={tx('Weekly allowance')} />
          <button onClick={() => { const n = amt(v.allowance); if (n === null) return setErr(tx('Enter an amount.')); save({ allowanceMinor: n }); setV({ ...v, allowance: '' }); }}>{tx('Save')}</button></div>
        {p.allowanceMinor > 0 && <p className="muted">{tx('Next allowance: {v1}. It comes from your wallet and is skipped if you are short.', { v1: p.allowanceNextOn ? String(p.allowanceNextOn).slice(0, 10) : 'soon' })}</p>}
      </>)}
      {msg && <p className="muted" role="status">{msg}</p>}<Err>{err}</Err>
    </div>
  );
}

function Recipients({ id, list, canEdit, onDone }) {
  const [email, setEmail] = useState(''); const [err, setErr] = useState('');
  async function add(e) { e.preventDefault(); setErr(''); try { await api(`/pockets/${id}/recipients`, { method: 'POST', body: { email } }); setEmail(''); onDone(); } catch (er) { setErr(er.message); } }
  return (
    <div className="stack">
      <h3>{tx('People the child can pay')}</h3>
      {list.length === 0 && <p className="empty">{tx('No one yet.')}</p>}
      <ul className="ledger">{list.map((r) => (
        <li key={r.id} className="sched"><span>{r.name}{canEdit ? <small>{r.email}</small> : null}</span>
          {canEdit && <button className="danger" onClick={async () => { await api(`/pockets/${id}/recipients/${r.id}`, { method: 'DELETE' }); onDone(); }}>{tx('Remove')}</button>}</li>
      ))}</ul>
      {canEdit && (
        <form className="inline" onSubmit={add}>
          <input type="email" placeholder={tx('G-Plan email to approve')} value={email} onChange={(e) => setEmail(e.target.value)} required aria-label={tx('Email to approve')} /><button>{tx('Approve')}</button>
        </form>
      )}
      <Err>{err}</Err>
    </div>
  );
}
