import React, { useState } from 'react';
import { api, formatNaira, toMinor, cap } from '../api.js';
import { useLoad, TxnRow, Err } from '../ui.jsx';
import { useT } from '../i18n.jsx';

// The Pulse ring shows only real figures: available balance vs money set aside in goals.
function Pulse({ available, saved }) {
  const { t } = useT();
  const total = available + saved;
  const r = 78, c = 2 * Math.PI * r;
  const savedLen = total > 0 ? c * (saved / total) : 0;
  const availLen = total > 0 ? c - savedLen : 0;
  return (
    <figure className="pulse">
      <svg viewBox="0 0 200 200" role="img"
        aria-label={t('home.ringLabel', { available: formatNaira(available), saved: formatNaira(saved) })}>
        <circle cx="100" cy="100" r={r} className="ring-bg" />
        {availLen > 0 && <circle cx="100" cy="100" r={r} className="ring-avail" strokeDasharray={`${availLen} ${c}`} />}
        {savedLen > 0 && <circle cx="100" cy="100" r={r} className="ring-saved" strokeDasharray={`${savedLen} ${c}`} strokeDashoffset={-availLen} />}
      </svg>
      <figcaption>
        <small>{t('home.available')}</small>
        <strong>{formatNaira(available)}</strong>
        <em>{t('home.savedInGoals', { amount: formatNaira(saved) })}</em>
      </figcaption>
    </figure>
  );
}

export default function Home({ user, snapshot, txns, refresh, go, demo }) {
  const { t } = useT();
  const [busy, setBusy] = useState('');
  const [msg, setMsg] = useState('');
  const ins = useLoad(() => api('/insights'), [txns.length]);
  if (!snapshot) return <p role="status">{t('home.loadingBalance')}</p>;

  async function run(kind, fn) {
    setBusy(kind); setMsg('');
    try { await fn(); await refresh(); ins.reload(); } catch (e) { setMsg(e.message); } finally { setBusy(''); }
  }
  const addDemo = () => run('fund', () => api('/demo/fund', { method: 'POST', body: { amountMinor: toMinor('50000') }, idemKey: crypto.randomUUID() }));
  const sample = () => run('sample', () => api('/demo/sample-data', { method: 'POST' }));

  const i = ins.data?.insights;
  const trend = i && i.prev.spending > 0 ? Math.round(((i.spending - i.prev.spending) / i.prev.spending) * 100) : null;

  return (
    <section className="stack">
      <h2>{t('home.hello', { name: user.full_name.split(' ')[0] })}</h2>
      <Pulse available={snapshot.wallet.availableMinor} saved={snapshot.savedMinor} />

      <div className="quick" role="group" aria-label={t('home.quick')}>
        <button className="primary" onClick={() => go('send')}>{t('q.send')}</button>
        <button onClick={() => go('requests')}>{t('q.receive')}</button>
        <button onClick={() => go('bills')}>{t('q.pay')}</button>
        <button onClick={() => go('goals')}>{t('q.save')}</button>
        <button onClick={() => go('global')}>{t('q.exchange')}</button>
        <button onClick={() => go('cards')}>{t('q.cards')}</button>
      </div>

      {i && (i.income > 0 || i.spending > 0) && (
        <div className="overview">
          <h3>{t('home.overview')}</h3>
          <ul>
            <li><span>{t('home.spent')}</span><b>{formatNaira(i.spending)}</b></li>
            {trend !== null && <li><span>{t('home.vsLast')}</span><b className={trend > 0 ? 'out' : 'in'}>{trend > 0 ? '+' : ''}{trend}%</b></li>}
            <li><span>{t('home.safe')} <em>{t('home.estimate')}</em></span><b>{formatNaira(i.forecast.safeToSpendMinor)}</b></li>
            {i.forecast.upcomingMinor > 0 && <li><span>{t('home.due')}</span><b>{formatNaira(i.forecast.upcomingMinor)}</b></li>}
            {i.byCategory.filter((c) => c.budgetMinor && c.spentMinor > c.budgetMinor).slice(0, 1).map((c) => (
              <li key={c.category}><span>{t('home.overBudget')}</span><b className="out">{cap(c.category)}</b></li>
            ))}
          </ul>
          <button className="link" onClick={() => go('insights')}>{t('home.seeInsights')}</button>
        </div>
      )}

      {demo && (
        <div className="demo-box">
          <p className="muted">Demo tools</p>
          <div className="inline">
            <button onClick={addDemo} disabled={!!busy}>{busy === 'fund' ? 'Adding…' : 'Add ₦50,000 demo money'}</button>
            <button onClick={sample} disabled={!!busy}>{busy === 'sample' ? 'Loading…' : 'Load sample history'}</button>
          </div>
        </div>
      )}
      <Err>{msg}</Err>

      <h3>{t('home.recent')}</h3>
      {txns.length === 0 ? (
        <p className="empty">{t('home.empty')}</p>
      ) : (
        <ul className="ledger">{txns.slice(0, 8).map((t) => <TxnRow key={t.id} t={t} />)}</ul>
      )}
      {txns.length > 8 && <button className="link" onClick={() => go('history')}>{t('home.seeAll')}</button>}
    </section>
  );
}
