import { tx } from '../i18n.jsx';
import React, { useState } from 'react';
import { api, uploadPhoto, formatNaira, toMinor, cap } from '../api.js';
import { Err, useLoad, Page } from '../ui.jsx';

const today = () => new Date().toISOString().slice(0, 10);

export default function Receipts({ go }) {
  const cfg = useLoad(() => api('/receipts/config'), []);
  const list = useLoad(() => api('/receipts'), []);
  const [f, setF] = useState({ merchant: '', total: '', date: today(), category: 'other', note: '' });
  const [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(''); const [err, setErr] = useState(''); const [msg, setMsg] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function scan(file) {
    setErr(''); setMsg('');
    if (!file) return;
    if (!['image/jpeg', 'image/png'].includes(file.type)) return setErr(tx('Use a JPEG or PNG photo.'));
    if (file.size > (cfg.data?.maxBytes || 2097152)) return setErr(tx('That photo is too big. Try again at normal camera quality.'));
    setBusy('scan');
    try {
      const d = await uploadPhoto('/receipts/scan', file, { 'X-Receipt-Consent': 'yes' });
      if (d.manual) setMsg(d.message);
      else {
        setF({ merchant: d.draft.merchant, total: String(d.draft.totalMinor / 100), date: d.draft.date || today(), category: d.draft.category, note: '' });
        setMsg(tx('Check the details below, fix anything that is wrong, then save.'));
      }
    } catch (e) { setErr(e.message); } finally { setBusy(''); }
  }
  async function save(e) {
    e.preventDefault(); setErr(''); setMsg('');
    const totalMinor = toMinor(f.total);
    if (!totalMinor) return setErr(tx('Enter the total like 4500.'));
    setBusy('save');
    try {
      const d = await api('/receipts', { method: 'POST', body: { merchant: f.merchant, totalMinor, date: f.date, category: f.category, note: f.note } });
      setMsg(d.matchedReference ? tx('Saved and linked to your payment {ref}.', { ref: d.matchedReference }) : tx('Saved.'));
      setF({ merchant: '', total: '', date: today(), category: 'other', note: '' }); list.reload();
    } catch (er) { setErr(er.message); } finally { setBusy(''); }
  }
  const total = Object.values(list.data?.byCategory || {}).reduce((a, b) => a + b, 0);

  return (
    <Page title={tx('Receipts')} go={go} sub={tx('Keep track of what you bought. Only the details are saved, never the photo.')}>
      <Err>{err || list.error}</Err>
      {msg && <p className="muted" role="status">{msg}</p>}
      {cfg.data?.reader && (
        <div className="stack demo-box">
          <b>{tx('Scan a receipt')}</b>
          <label className="inline"><input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
            <span className="muted">{tx('I agree to send this photo to Anthropic, the AI company, to be read. It is not stored by G-Plan.')}</span></label>
          <label className="link">{busy === 'scan' ? tx('Reading…') : tx('Take or choose a photo')}
            <input type="file" accept="image/jpeg,image/png" capture="environment" hidden disabled={!consent || !!busy}
              onChange={(e) => { scan(e.target.files[0]); e.target.value = ''; }} /></label>
        </div>
      )}
      <form className="stack" onSubmit={save}>
        <h3>{cfg.data?.reader ? tx('Check and save') : tx('Add a receipt')}</h3>
        <label>{tx('Shop or business')}<input value={f.merchant} onChange={set('merchant')} maxLength={80} required /></label>
        <label>{tx('Total ₦')}<input inputMode="decimal" value={f.total} onChange={set('total')} required /></label>
        <label>{tx('Date')}<input type="date" value={f.date} max={today()} onChange={set('date')} required /></label>
        <label>{tx('Category')}<select value={f.category} onChange={set('category')}>{(cfg.data?.categories || ['other']).map((c) => <option key={c} value={c}>{cap(c)}</option>)}</select></label>
        <label>{tx('Note (optional)')}<input value={f.note} onChange={set('note')} maxLength={140} /></label>
        <button className="primary" disabled={!!busy}>{busy === 'save' ? tx('Saving…') : tx('Save receipt')}</button>
      </form>

      {total > 0 && (<>
        <h3>{tx('This month')}</h3>
        <ul className="ledger">{Object.entries(list.data.byCategory).sort((a, b) => b[1] - a[1]).map(([c, v]) => <li key={c}><span>{cap(c)}</span><b>{formatNaira(v)}</b></li>)}
          <li><span>{tx('Total')}</span><b>{formatNaira(total)}</b></li></ul>
      </>)}
      <h3>{tx('Saved receipts')}</h3>
      {list.data?.receipts.length === 0 && <p className="empty">{tx('No receipts yet.')}</p>}
      <ul className="ledger">{list.data?.receipts.map((r) => (
        <li key={r.id} className="sched"><span>{r.merchant}<small>{r.date} · {cap(r.category)}{r.matched ? ' · linked to a payment' : ''}{r.note ? ` · ${r.note}` : ''}</small></span>
          <span className="inline"><b>{formatNaira(r.totalMinor)}</b><button className="link" onClick={async () => { await api(`/receipts/${r.id}`, { method: 'DELETE' }); list.reload(); }}>{tx('Delete')}</button></span></li>
      ))}</ul>
    </Page>
  );
}
