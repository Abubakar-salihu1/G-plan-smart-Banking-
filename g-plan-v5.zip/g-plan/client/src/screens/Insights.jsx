import { tx } from '../i18n.jsx';
import React, { useState } from 'react';
import { api, formatNaira, toMinor, cap } from '../api.js';
import { Err, useLoad } from '../ui.jsx';

const CATS = ['food', 'transport', 'shopping', 'entertainment', 'rent', 'airtime', 'data', 'electricity', 'cable', 'health', 'education', 'transfers'];
const shift = (m, d) => { const [y, mo] = m.split('-').map(Number); const t = new Date(Date.UTC(y, mo - 1 + d, 1)); return t.toISOString().slice(0, 7); };

export default function Insights() {
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7));
  const { data, error, reload } = useLoad(() => api(`/insights?month=${month}`), [month]);
  const [b, setB] = useState({ category: 'food', limit: '' });
  const [msg, setMsg] = useState('');
  const i = data?.insights;

  async function saveBudget(e) {
    e.preventDefault(); setMsg('');
    const limitMinor = toMinor(b.limit);
    if (!limitMinor) return setMsg(tx('Enter a monthly limit like 30000.'));
    try { await api('/budgets', { method: 'PUT', body: { category: b.category, limitMinor } }); setB({ ...b, limit: '' }); reload(); }
    catch (er) { setMsg(er.message); }
  }
  async function delBudget(c) { await api(`/budgets/${c}`, { method: 'DELETE' }); reload(); }

  const maxBar = i ? Math.max(i.income, i.spending, 1) : 1;
  return (
    <section className="stack">
      <h2>{tx('Insights')}</h2>
      <div className="month-nav">
        <button onClick={() => setMonth(shift(month, -1))} aria-label={tx('Previous month')}>‹</button>
        <b>{new Date(month + '-01T00:00:00').toLocaleDateString('en-NG', { month: 'long', year: 'numeric' })}</b>
        <button onClick={() => setMonth(shift(month, 1))} aria-label={tx('Next month')}>›</button>
      </div>
      <Err>{error}</Err>
      {i && (
        <>
          <div className="flowbars" aria-label={tx('Income versus spending')}>
            <div><span>{tx('Money in')}</span><i className="in" style={{ width: (i.income / maxBar) * 100 + '%' }} /><b>{formatNaira(i.income)}</b></div>
            <div><span>{tx('Spent')}</span><i className="out" style={{ width: (i.spending / maxBar) * 100 + '%' }} /><b>{formatNaira(i.spending)}</b></div>
            <div><span>{tx('Saved')}</span><i className="sv" style={{ width: (Math.max(0, i.saved) / maxBar) * 100 + '%' }} /><b>{formatNaira(i.saved)}</b></div>
          </div>

          <h3>{tx('Where your money went')}</h3>
          {i.byCategory.length === 0 && <p className="empty">{tx('No spending in this month yet. Load sample history on the Pulse screen to see this working.')}</p>}
          <ul className="cats">
            {i.byCategory.map((c) => {
              const over = c.budgetMinor && c.spentMinor > c.budgetMinor;
              const pct = c.budgetMinor ? Math.min(100, (c.spentMinor / c.budgetMinor) * 100) : (c.spentMinor / Math.max(i.spending, 1)) * 100;
              return (
                <li key={c.category}>
                  <div className="goal-head"><span>{cap(c.category)}</span><b className={over ? 'out' : ''}>{formatNaira(c.spentMinor)}{c.budgetMinor ? ` / ${formatNaira(c.budgetMinor)}` : ''}</b></div>
                  <div className="bar"><i className={over ? 'over' : ''} style={{ width: pct + '%' }} /></div>
                  {c.budgetMinor && <button className="link" onClick={() => delBudget(c.category)}>{tx('Remove budget')}</button>}
                </li>
              );
            })}
          </ul>
          <form className="inline" onSubmit={saveBudget}>
            <select value={b.category} onChange={(e) => setB({ ...b, category: e.target.value })} aria-label={tx('Category')}>{CATS.map((c) => <option key={c} value={c}>{cap(c)}</option>)}</select>
            <input inputMode="decimal" placeholder={tx('Monthly limit ₦')} value={b.limit} onChange={(e) => setB({ ...b, limit: e.target.value })} aria-label={tx('Monthly limit')} />
            <button>{tx('Set budget')}</button>
          </form>
          <Err>{msg}</Err>

          {i.topExpenses.length > 0 && (<>
            <h3>{tx('Largest expenses')}</h3>
            <ul className="ledger">{i.topExpenses.map((e) => <li key={e.reference}><span>{e.description || cap(e.category)}</span><b className="out">{formatNaira(e.amountMinor)}</b></li>)}</ul>
          </>)}

          <h3>{tx('Cash-flow forecast')} <small className="pill">{tx('Estimate')}</small></h3>
          <dl>
            <dt>{tx('Available now')}</dt><dd>{formatNaira(i.forecast.availableMinor)}</dd>
            <dt>{tx('Due in 30 days')}</dt><dd>{formatNaira(i.forecast.upcomingMinor)}</dd>
            <dt>{tx('Safe to spend')}</dt><dd>{formatNaira(i.forecast.safeToSpendMinor)}</dd>
            <dt>{tx('Average daily spend')}</dt><dd>{formatNaira(i.forecast.avgDailySpendMinor)}</dd>
            {i.forecast.runwayDays !== null && (<><dt>{tx('Lasts about')}</dt><dd>{tx('{runwayDays} days', { runwayDays: i.forecast.runwayDays })}</dd></>)}
          </dl>
          <p className="muted">{tx('Based on your recorded activity and scheduled payments. Real life can differ.')}</p>

          <h3>{tx('Repeating payments')}</h3>
          {i.recurring.length === 0 ? <p className="muted">{tx('None found yet. I need at least three similar payments to spot a pattern.')}</p> : (
            <ul className="ledger">{i.recurring.map((r) => <li key={r.name}><span>{r.name}<small>{tx('{v1} · every {every}', { v1: cap(r.kind), every: r.every })}</small></span><b>{formatNaira(r.amountMinor)}</b></li>)}</ul>
          )}

          <h3>{tx('G-Plan score')}</h3>
          {i.health.score === null ? <p className="muted">{i.health.note}</p> : (
            <>
              <p className="big-amount">{i.health.score}<small>/100</small></p>
              <ul className="ledger">{i.health.factors.map((f) => <li key={f.name}><span>{f.name}<small>{f.why}</small></span><b>{f.points}/{f.outOf}</b></li>)}</ul>
              <p className="muted">{i.health.note}</p>
            </>
          )}
        </>
      )}
    </section>
  );
}
