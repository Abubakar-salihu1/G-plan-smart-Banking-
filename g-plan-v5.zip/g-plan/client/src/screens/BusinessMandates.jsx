import { tx } from '../i18n.jsx';
import React, { useState } from 'react';
import { api, formatNaira, toMinor, cap } from '../api.js';
import { Err, useLoad } from '../ui.jsx';

const today = () => new Date().toISOString().slice(0, 10);
const FREQ = { weekly: 'weekly', monthly: 'monthly', quarterly: 'quarterly' };

// Direct debits from the business side: ask a customer, then schedule collections within what they agreed.
export default function BusinessMandates({ can }) {
  const list = useLoad(() => api('/business/mandates'), []);
  const manage = can('mandates.manage');
  return (
    <div className="stack">
      <Err>{list.error}</Err>
      {list.data?.mandates.length === 0 && <p className="empty">{tx('No direct debits yet.')}</p>}
      <ul className="ledger">{list.data?.mandates.map((m) => <Item key={m.id} m={m} manage={manage} onDone={list.reload} />)}</ul>
      {manage && <Request onDone={list.reload} />}
    </div>
  );
}

function Item({ m, manage, onDone }) {
  const [open, setOpen] = useState(false); const [f, setF] = useState({ amount: m.fixedAmountMinor ? String(m.fixedAmountMinor / 100) : '', dueOn: '' }); const [err, setErr] = useState('');
  async function schedule(e) {
    e.preventDefault(); setErr('');
    const amountMinor = toMinor(f.amount); if (!amountMinor) return setErr(tx('Enter an amount like 5000.'));
    try { await api(`/business/mandates/${m.id}/collections`, { method: 'POST', body: { amountMinor, dueOn: f.dueOn } }); setF({ ...f, dueOn: '' }); onDone(); } catch (er) { setErr(er.message); }
  }
  async function cancel() { if (!window.confirm(tx('Cancel this direct debit?'))) return; try { await api(`/business/mandates/${m.id}/cancel`, { method: 'POST' }); onDone(); } catch (er) { setErr(er.message); } }
  return (
    <li style={{ display: 'block' }}>
      <button className="link" style={{ textAlign: 'left' }} onClick={() => setOpen(!open)} aria-expanded={open}>
        {m.payer} · {m.label}<small>{tx('{v1} · up to {v2} {freq}{v4}{v5}', { v1: cap(m.status), v2: formatNaira(m.maxAmountMinor), freq: tx(FREQ[m.frequency]), v4: m.fixedAmountMinor ? ` · fixed ${formatNaira(m.fixedAmountMinor)}, scheduled automatically` : '', v5: m.failuresInARow ? ` · ${m.failuresInARow} failed in a row` : '' })}</small></button>
      {open && (
        <div className="stack">
          <ul className="ledger">{m.collections.map((c) => <li key={c.id}><span>{c.dueOn}<small>{cap(c.status)}{c.error ? ` · ${c.error}` : ''}</small></span><b>{formatNaira(c.amountMinor)}</b></li>)}</ul>
          {manage && m.status === 'active' && !m.fixedAmountMinor && (
            <form className="inline" onSubmit={schedule}>
              <input inputMode="decimal" placeholder={tx('Amount ₦')} value={f.amount} onChange={(e) => setF({ ...f, amount: e.target.value })} aria-label={tx('Collection amount')} required />
              <input type="date" min={today()} value={f.dueOn} onChange={(e) => setF({ ...f, dueOn: e.target.value })} aria-label={tx('Collection date')} required />
              <button>{tx('Schedule')}</button>
            </form>
          )}
          <Err>{err}</Err>
          {manage && ['pending', 'active', 'paused'].includes(m.status) && <button className="danger" onClick={cancel}>{tx('Cancel direct debit')}</button>}
        </div>
      )}
    </li>
  );
}

function Request({ onDone }) {
  const [f, setF] = useState({ email: '', label: '', max: '', fixed: '', frequency: 'monthly', startDate: today(), endDate: '', noticeDays: 3 });
  const [msg, setMsg] = useState(''); const [err, setErr] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  async function send(e) {
    e.preventDefault(); setErr(''); setMsg('');
    const max = toMinor(f.max); if (!max) return setErr(tx('Enter the most you may collect each time.'));
    const fixed = f.fixed.trim() ? toMinor(f.fixed) : null; if (f.fixed.trim() && !fixed) return setErr(tx('Enter the fixed amount like 5000, or leave it empty.'));
    try { const d = await api('/business/mandates', { method: 'POST', body: { email: f.email, label: f.label, maxAmountMinor: max, fixedAmountMinor: fixed, frequency: f.frequency, startDate: f.startDate, endDate: f.endDate || null, noticeDays: Number(f.noticeDays) } }); setMsg(d.note); setF({ ...f, email: '', label: '', max: '', fixed: '' }); onDone(); }
    catch (er) { setErr(er.message); }
  }
  return (
    <form className="stack" onSubmit={send}>
      <h3>{tx('Ask a customer for a direct debit')}</h3>
      <p className="muted">{tx('They must approve it. You can never collect more than the limit you set here, and they get notice before each collection. They can cancel any time.')}</p>
      <label>{tx('Customer G-Plan email')}<input type="email" value={f.email} onChange={set('email')} required /></label>
      <label>{tx('What it is for')}<input value={f.label} onChange={set('label')} maxLength={60} placeholder={tx('Gym membership')} required /></label>
      <label>{tx('Most you may collect each time ₦')}<input inputMode="decimal" value={f.max} onChange={set('max')} required /></label>
      <label>{tx('Fixed amount ₦ (optional: collected automatically)')}<input inputMode="decimal" value={f.fixed} onChange={set('fixed')} /></label>
      <label>{tx('How often')}<select value={f.frequency} onChange={set('frequency')}><option value="weekly">{tx('Weekly')}</option><option value="monthly">{tx('Monthly')}</option><option value="quarterly">{tx('Every 3 months')}</option></select></label>
      <label>{tx('Starts')}<input type="date" min={today()} value={f.startDate} onChange={set('startDate')} required /></label>
      <label>{tx('Ends (optional)')}<input type="date" min={f.startDate} value={f.endDate} onChange={set('endDate')} /></label>
      <label>{tx('Days of notice before each collection')}<select value={f.noticeDays} onChange={set('noticeDays')}>{[2, 3, 5, 7, 14].map((n) => <option key={n} value={n}>{tx('{n} days', { n })}</option>)}</select></label>
      {msg && <p className="muted" role="status">{msg}</p>}<Err>{err}</Err>
      <button className="primary">{tx('Send request')}</button>
    </form>
  );
}
