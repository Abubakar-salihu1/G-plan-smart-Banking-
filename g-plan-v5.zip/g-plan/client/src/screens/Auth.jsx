import { LanguagePicker, useT, tx } from '../i18n.jsx';
import React, { useState } from 'react';
import { api } from '../api.js';
import { Err } from '../ui.jsx';
import { passkeysSupported, getPasskey } from '../webauthn.js';

export default function Auth({ onAuthed }) {
  const { t: tr } = useT();
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ fullName: '', email: '', phone: '', password: '', acceptTerms: false });
  const [mfa, setMfa] = useState(null);   // { mfaToken, method, demoCode }
  const [reset, setReset] = useState(null); // { step: 'ask' | 'code', demoCode, done }
  const [verify, setVerify] = useState(null); // { demoCode } while the sign-up email code is awaited
  const [vcode, setVcode] = useState('');
  const [rf, setRf] = useState({ code: '', password: '', mfaCode: '' });
  const [code, setCode] = useState('');
  const [useRec, setUseRec] = useState(false);   // sign in with a recovery code instead
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });

  async function submit(e) {
    e.preventDefault();
    setBusy(true); setError('');
    try {
      if (mode === 'login') {
        const d = await api('/auth/login', { method: 'POST', body: { email: form.email, password: form.password } });
        if (d.mfaRequired) { setMfa(d); return; }
        await onAuthed(d);
      } else {
        const d = await api('/auth/register', { method: 'POST', body: form });
        setVerify({ demoCode: d.demoCode });
      }
    } catch (err) {
      if (err.code === 'EMAIL_NOT_VERIFIED') {
        const r = await api('/auth/register/resend', { method: 'POST', body: { email: form.email } }).catch(() => ({}));
        setVerify({ demoCode: r.demoCode });
      } else setError(err.message);
    } finally { setBusy(false); }
  }

  async function submitVerify(e) {
    e.preventDefault(); setBusy(true); setError('');
    try { await onAuthed(await api('/auth/register/verify', { method: 'POST', body: { email: form.email, code: vcode } })); }
    catch (err) { setError(err.message); } finally { setBusy(false); }
  }
  async function resendVerify() {
    setError('');
    try { const r = await api('/auth/register/resend', { method: 'POST', body: { email: form.email } }); setVerify({ demoCode: r.demoCode }); }
    catch (err) { setError(err.message); }
  }

  async function submitMfa(e) {
    e.preventDefault();
    setBusy(true); setError('');
    try { await onAuthed(await api('/auth/login/mfa', { method: 'POST', body: { mfaToken: mfa.mfaToken, code } })); }
    catch (err) { setError(err.message); } finally { setBusy(false); }
  }
  async function resend() {
    setError('');
    try { const d = await api('/auth/login/resend', { method: 'POST', body: { mfaToken: mfa.mfaToken } }); setMfa({ ...mfa, demoCode: d.demoCode }); }
    catch (err) { setError(err.message); }
  }

  async function askReset(e) {
    e.preventDefault(); setBusy(true); setError('');
    try {
      const d = await api('/auth/password/forgot', { method: 'POST', body: { email: form.email } });
      setReset({ step: 'code', demoCode: d.demoCode });
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  }
  async function doReset(e) {
    e.preventDefault(); setBusy(true); setError('');
    try {
      await api('/auth/password/reset', { method: 'POST', body: { email: form.email, code: rf.code, newPassword: rf.password, mfaCode: rf.mfaCode || undefined } });
      setReset({ step: 'done' }); setRf({ code: '', password: '', mfaCode: '' });
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  }

  async function passkeyLogin() {
    setBusy(true); setError('');
    try {
      if (!form.email) throw new Error(tx('Enter your email first, then tap the passkey button.'));
      const options = await api('/auth/login/passkey/options', { method: 'POST', body: { email: form.email } });
      const response = await getPasskey(options);
      await onAuthed(await api('/auth/login/passkey/verify', { method: 'POST', body: { email: form.email, response } }));
    } catch (err) { setError(err.message || tx('Passkey sign-in did not work.')); } finally { setBusy(false); }
  }

  if (verify) {
    return (
      <div className="auth">
        <img className="logo-full" src="/logo-full.png" alt={tx('G-Plan Smart Banking Solution')} />
        <form onSubmit={submitVerify} className="stack">
          <h2>{tx('Check your email')}</h2>
          <p className="muted">{tx('If these details are new, we sent a 6-digit code to {email}. Enter it to finish creating your account.', { email: form.email })}</p>
          {verify.demoCode && <p className="muted">{tx('Demo mode: your code is')} <b>{verify.demoCode}</b> {tx('(no real email is sent).')}</p>}
          <input inputMode="numeric" maxLength={6} value={vcode} onChange={(e) => setVcode(e.target.value)} placeholder={tx('6 digits')} aria-label={tx('Verification code')} autoComplete="one-time-code" autoFocus required />
          <Err>{error}</Err>
          <button className="primary" disabled={busy}>{busy ? tx('Checking…') : tx('Confirm and continue')}</button>
          <button type="button" className="link" onClick={resendVerify}>{tx('Send a new code')}</button>
          <button type="button" className="link" onClick={() => { setVerify(null); setVcode(''); setError(''); }}>{tx('Back')}</button>
        </form>
      </div>
    );
  }

  if (reset) {
    return (
      <div className="auth">
        <img className="logo-full" src="/logo-full.png" alt={tx('G-Plan Smart Banking Solution')} />
        {reset.step === 'done' ? (
          <div className="stack">
            <h2>{tx('Password changed')}</h2>
            <p className="muted">{tx('Every device was signed out. Sign in with your new password.')}</p>
            <button className="primary" onClick={() => { setReset(null); setError(''); }}>{tx('Back to sign in')}</button>
          </div>
        ) : (
          <form onSubmit={reset.step === 'ask' ? askReset : doReset} className="stack">
            <h2>{tx('Reset your password')}</h2>
            <label>{tx('Your email')}<input type="email" value={form.email} onChange={set('email')} autoComplete="email" required /></label>
            {reset.step === 'code' && (
              <>
                <p className="muted">{tx('If that email has an account, we sent a 6-digit code to it.')}</p>
                {reset.demoCode && <p className="muted">{tx('Demo mode: your code is')} <b>{reset.demoCode}</b>.</p>}
                <label>{tx('Code')}<input inputMode="numeric" maxLength={6} value={rf.code} onChange={(e) => setRf({ ...rf, code: e.target.value })} required /></label>
                <label>{tx('New password')}<input type="password" value={rf.password} onChange={(e) => setRf({ ...rf, password: e.target.value })} autoComplete="new-password" minLength={8} required /></label>
                <label>{tx('Authenticator code or a recovery code (only if you use an authenticator app)')}<input maxLength={19} autoComplete="off" value={rf.mfaCode} onChange={(e) => setRf({ ...rf, mfaCode: e.target.value })} /></label>
              </>
            )}
            <Err>{error}</Err>
            <button className="primary" disabled={busy}>{busy ? tx('Please wait…') : reset.step === 'ask' ? tx('Send me a code') : tx('Change password')}</button>
            <button type="button" className="link" onClick={() => { setReset(null); setError(''); }}>{tx('Back')}</button>
          </form>
        )}
      </div>
    );
  }

  if (mfa) {
    return (
      <div className="auth">
        <img className="logo-full" src="/logo-full.png" alt={tx('G-Plan Smart Banking Solution')} />
        <form onSubmit={submitMfa} className="stack">
          <h2>{tx('Two-step verification')}</h2>
          <p className="muted">{useRec ? tx('Enter one of the recovery codes you saved when you turned on two-step verification. Each one works only once.') : mfa.method === 'totp' ? tx('Enter the 6-digit code from your authenticator app.') : `Enter the 6-digit code we sent by ${mfa.method}.`}</p>
          {!useRec && mfa.demoCode && <p className="muted">{tx('Demo mode: your code is')} <b>{mfa.demoCode}</b>.</p>}
          {useRec
            ? <input maxLength={19} value={code} onChange={(e) => setCode(e.target.value)} placeholder={tx('XXXX-XXXX-XXXX-XXXX')} aria-label={tx('Recovery code')} autoComplete="off" autoCapitalize="characters" spellCheck={false} autoFocus required />
            : <input inputMode="numeric" maxLength={6} value={code} onChange={(e) => setCode(e.target.value)} placeholder={tx('6 digits')} aria-label={tx('Sign-in code')} autoComplete="one-time-code" autoFocus required />}
          <Err>{error}</Err>
          <button className="primary" disabled={busy}>{busy ? tx('Checking…') : tx('Verify')}</button>
          {!useRec && mfa.method !== 'totp' && <button type="button" className="link" onClick={resend}>{tx('Send a new code')}</button>}
          <button type="button" className="link" onClick={() => { setUseRec(!useRec); setCode(''); setError(''); }}>{useRec ? tx('Use my usual code instead') : tx('Lost your phone? Use a recovery code')}</button>
          <button type="button" className="link" onClick={() => { setMfa(null); setCode(''); setError(''); setUseRec(false); }}>{tx('Back')}</button>
        </form>
      </div>
    );
  }

  return (
    <div className="auth">
      <img className="logo-full" src="/logo-full.png" alt={tx('G-Plan Smart Banking Solution')} />
      <LanguagePicker />
      <p className="lede">{tr('auth.lede')}</p>
      <form onSubmit={submit} className="stack">
        {mode === 'register' && (
          <label>{tr('auth.fullName')}<input value={form.fullName} onChange={set('fullName')} autoComplete="name" required /></label>
        )}
        <label>{tr('auth.email')}<input type="email" value={form.email} onChange={set('email')} autoComplete="email" required /></label>
        {mode === 'register' && (
          <label>{tr('auth.phone')}
            <input inputMode="tel" value={form.phone} onChange={set('phone')} autoComplete="tel" placeholder="08031234567" />
          </label>
        )}
        <label>{tr('auth.password')}
          <input type="password" value={form.password} onChange={set('password')}
            autoComplete={mode === 'login' ? 'current-password' : 'new-password'} minLength={8} required />
        </label>
        {mode === 'register' && (
          <>
            <p className="muted">{tr('auth.pwHint')}</p>
            <label className="check">
              <input type="checkbox" checked={form.acceptTerms} onChange={set('acceptTerms')} required />
              <span>{tr('auth.terms')}</span>
            </label>
          </>
        )}
        <Err>{error}</Err>
        <button className="primary" disabled={busy}>{busy ? tr('auth.wait') : mode === 'login' ? tr('auth.signIn') : tr('auth.create')}</button>
      </form>
      {mode === 'login' && passkeysSupported() && (
        <button className="ghost" onClick={passkeyLogin} disabled={busy}>{tr('auth.passkey')}</button>
      )}
      {mode === 'login' && <button className="link" onClick={() => { setReset({ step: 'ask' }); setError(''); }}>{tr('auth.forgot')}</button>}
      <button className="link" onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError(''); }}>
        {mode === 'login' ? tr('auth.newHere') : tr('auth.haveAccount')}
      </button>
      <p className="fine">{tr('auth.prototype')}</p>
    </div>
  );
}
