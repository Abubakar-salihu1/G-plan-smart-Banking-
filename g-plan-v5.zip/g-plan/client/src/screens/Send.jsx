import { tx } from '../i18n.jsx';
import React, { useState } from 'react';
import { api, formatNaira, toMinor } from '../api.js';
import { Err, Authorise, Receipt, Tabs, useLoad } from '../ui.jsx';

// Flow: Review -> Authorise -> Process -> Verify -> Receipt. Nothing is sent before authorising.
export default function Send({ snapshot, refresh, go }) {
  const [mode, setMode] = useState('gplan');
  const [step, setStep] = useState('form');
  const [f, setF] = useState(() => {
    const base = { recipient: '', bankCode: '', accountNumber: '', amount: '', note: '', save: false };
    // A draft from the assistant only fills the form. The person still reviews and authorises it.
    try { const p = JSON.parse(sessionStorage.getItem('gp_prefill') || 'null'); sessionStorage.removeItem('gp_prefill'); return p ? { ...base, ...p } : base; } catch { return base; }
  });
  const [acctName, setAcctName] = useState('');
  const [review, setReview] = useState(null);
  const [pw, setPw] = useState(''); const [otp, setOtp] = useState('');
  const [otpNeeded, setOtpNeeded] = useState(false);
  const [receipt, setReceipt] = useState(null);
  const [idemKey, setIdemKey] = useState('');
  const [error, setError] = useState(''); const [busy, setBusy] = useState(false);
  const banks = useLoad(() => api('/banks'), []);
  const recips = useLoad(() => api('/recipients'), []);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
  const amountMinor = toMinor(f.amount);

  async function useRecipient(r) {
    try {
      const d = await api(`/recipients/${r.id}/use`);
      if (d.kind === 'internal') { setMode('gplan'); setF({ ...f, recipient: d.email || d.phone || '' }); }
      else if (d.kind === 'external') { setMode('bank'); setF({ ...f, bankCode: d.bankCode, accountNumber: d.accountNumber }); setAcctName(d.name); }
    } catch (e) { setError(e.message); }
  }
  async function removeRecipient(id) { await api(`/recipients/${id}`, { method: 'DELETE' }); recips.reload(); }

  async function verifyAccount() {
    setError(''); setBusy(true);
    try { setAcctName((await api('/transfers/name-enquiry', { method: 'POST', body: { bankCode: f.bankCode, accountNumber: f.accountNumber } })).accountName); }
    catch (e) { setError(e.message); setAcctName(''); } finally { setBusy(false); }
  }

  async function doReview(e) {
    e.preventDefault(); setError('');
    if (!amountMinor) return setError(tx('Enter an amount like 2500 or 2500.50.'));
    setBusy(true);
    try {
      if (mode === 'gplan') {
        setReview(await api('/transfers/review', { method: 'POST', body: { recipient: f.recipient, amountMinor } }));
      } else {
        if (!acctName) throw new Error(tx('Verify the account first.'));
        setReview(await api('/transfers/external/review', { method: 'POST', body: { amountMinor } }));
      }
      setIdemKey(crypto.randomUUID());
      setStep('confirm');
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  }

  async function doSend(e) {
    e.preventDefault(); setError(''); setBusy(true);
    try {
      const body = mode === 'gplan'
        ? { recipient: f.recipient, amountMinor, description: f.note, password: pw, otp, saveRecipient: f.save }
        : { bankCode: f.bankCode, accountNumber: f.accountNumber, amountMinor, description: f.note, password: pw, otp, saveRecipient: f.save };
      const d = await api(mode === 'gplan' ? '/transfers' : '/transfers/external', { method: 'POST', idemKey, body });
      setReceipt({ ...d.receipt, who: d.recipientName || d.accountName });
      setStep('done'); await refresh(); recips.reload();
    } catch (err) {
      if (err.code === 'OTP_REQUIRED') setOtpNeeded(true);
      setError(err.status >= 500 || err.code === 'NETWORK'
        ? tx('We could not confirm if this was sent. Check Recent activity before trying again.') : err.message);
    } finally { setBusy(false); }
  }

  function reset() {
    setStep('form'); setF({ recipient: '', bankCode: '', accountNumber: '', amount: '', note: '', save: false });
    setAcctName(''); setPw(''); setOtp(''); setOtpNeeded(false); setError(''); setReceipt(null);
  }

  if (step === 'done') {
    return <Receipt receipt={receipt} title={tx('Sent')} onDone={reset}><p>{tx('to {who}', { who: receipt.who })}</p></Receipt>;
  }

  if (step === 'confirm') {
    const fee = review.feeMinor || 0;
    return (
      <form className="stack" onSubmit={doSend}>
        <h2>{tx('Review and confirm')}</h2>
        <dl>
          <dt>{tx('To')}</dt><dd>{mode === 'gplan' ? review.recipientName : acctName}</dd>
          {mode === 'bank' && (<><dt>{tx('Bank')}</dt><dd>{banks.data?.banks.find((b) => b.code === f.bankCode)?.name}</dd><dt>{tx('Account')}</dt><dd>••••{f.accountNumber.slice(-4)}</dd></>)}
          <dt>{tx('Amount')}</dt><dd>{formatNaira(amountMinor)}</dd>
          <dt>{tx('Fee')}</dt><dd>{formatNaira(fee)}</dd>
          <dt>{tx('You pay')}</dt><dd>{formatNaira(amountMinor + fee)}</dd>
        </dl>
        <Authorise pw={pw} setPw={setPw} otp={otp} setOtp={setOtp} verification={review.verification} otpNeeded={otpNeeded} />
        <Err>{error}</Err>
        <button className="primary" disabled={busy || review.verification?.blocked}>{busy ? tx('Sending…') : `Send ${formatNaira(amountMinor)}`}</button>
        <button type="button" className="link" onClick={() => setStep('form')}>{tx('Change details')}</button>
      </form>
    );
  }

  return (
    <section className="stack">
      <h2>{tx('Send money')}</h2>
      <p className="muted">{tx('Available: {v1}', { v1: formatNaira(snapshot?.wallet.availableMinor ?? 0) })}</p>
      <Tabs value={mode} onChange={(m) => { setMode(m); setError(''); }} items={[['gplan', tx('To G-Plan')], ['bank', tx('To a bank')]]} />
      {recips.data?.recipients.length > 0 && (
        <div className="chips" aria-label={tx('Saved recipients')}>
          {recips.data.recipients.map((r) => (
            <span key={r.id} className="chip">
              <button onClick={() => useRecipient(r)}>{r.name.slice(0, 18)}</button>
              <button className="x" aria-label={`Remove ${r.name}`} onClick={() => removeRecipient(r.id)}>×</button>
            </span>
          ))}
        </div>
      )}
      <form className="stack" onSubmit={doReview}>
        {mode === 'gplan' ? (
          <label>{tx('Recipient\'s G-Plan email or phone')}
            <input value={f.recipient} onChange={set('recipient')} placeholder={tx('name@email.com or 0803…')} required />
          </label>
        ) : (
          <>
            <label>{tx('Bank')}
              <select value={f.bankCode} onChange={(e) => { set('bankCode')(e); setAcctName(''); }} required>
                <option value="">{tx('Choose a bank')}</option>
                {banks.data?.banks.map((b) => <option key={b.code} value={b.code}>{b.name}</option>)}
              </select>
            </label>
            <label>{tx('Account number')}
              <input inputMode="numeric" maxLength={10} value={f.accountNumber} onChange={(e) => { set('accountNumber')(e); setAcctName(''); }} required />
            </label>
            <button type="button" onClick={verifyAccount} disabled={busy || f.accountNumber.length !== 10 || !f.bankCode}>{tx('Verify account')}</button>
            {acctName && <p className="ok">{tx('Account name:')} <b>{acctName}</b></p>}
            <p className="muted">{tx('Demo bank: account numbers ending 0000 are declined, and ending 9999 time out, so you can see each outcome.')}</p>
          </>
        )}
        <label>{tx('Amount (₦)')}<input inputMode="decimal" value={f.amount} onChange={set('amount')} placeholder="0.00" required /></label>
        <label>{tx('Note (optional)')}<input value={f.note} onChange={set('note')} maxLength={140} /></label>
        <label className="check"><input type="checkbox" checked={f.save} onChange={set('save')} /><span>{tx('Save this recipient')}</span></label>
        <Err>{error}</Err>
        <button className="primary" disabled={busy}>{busy ? tx('Checking…') : tx('Review')}</button>
      </form>
    </section>
  );
}
