import { tx } from '../i18n.jsx';
import React, { useState } from 'react';
import { api, formatNaira, toMinor, cap } from '../api.js';
import { Err, Authorise, useLoad, Tabs } from '../ui.jsx';

const TEMPLATE = 'name,bank_code,account_number,email,amount,note\nAda Obi,058,0123456789,,150000,October supplies\nChidi Eze,,,chidi@example.com,95000.50,Refund\n';
const STATUS = { draft: 'Ready to send', pending_approval: 'Waiting for the owner', running: 'Sending', done: 'Finished', rejected: 'Rejected', cancelled: 'Cancelled' };

function useAuth() {
  const [pw, setPw] = useState(''); const [otp, setOtp] = useState(''); const [otpNeeded, setOtpNeeded] = useState(false);
  return { pw, setPw, otp, setOtp, otpNeeded, setOtpNeeded };
}

export default function BusinessBulk({ can, userId }) {
  const [tab, setTab] = useState('batches');
  const list = useLoad(() => api('/business/bulk'), []);
  const canSend = can('payouts.create');
  return (
    <div className="stack">
      <Tabs value={tab} onChange={setTab} items={[['batches', tx('Batches')], ...(canSend ? [['csv', tx('Upload a file')], ['payroll', tx('Payroll')]] : [])]} />
      {tab === 'batches' && <Batches list={list} can={can} />}
      {tab === 'csv' && <FromCsv onDone={() => { list.reload(); setTab('batches'); }} />}
      {tab === 'payroll' && <Payroll onDone={() => { list.reload(); setTab('batches'); }} />}
    </div>
  );
}

function Batches({ list, can }) {
  const [open, setOpen] = useState(null);
  return (
    <div className="stack">
      <Err>{list.error}</Err>
      {list.data?.batches.length === 0 && <p className="empty">{tx('No batches yet. Upload a file or run payroll.')}</p>}
      <ul className="ledger">{list.data?.batches.map((b) => (
        <li key={b.id} className="sched"><button className="link" style={{ textAlign: 'left', flex: 1 }} onClick={() => setOpen(open === b.id ? null : b.id)}>
          {b.label}<small>{tx('{v1} · {count} people · {status}{v4} · by {createdBy}', { v1: formatNaira(b.totalMinor), count: b.count, status: tx(STATUS[b.status]), v4: b.status === 'done' || b.status === 'running' ? ` · ${b.sent || 0} paid${b.failed ? `, ${b.failed} not paid` : ''}` : '', createdBy: b.createdBy })}</small></button>
          {open === b.id && <BatchDetail id={b.id} status={b.status} can={can} onDone={() => { setOpen(null); list.reload(); }} />}
        </li>
      ))}</ul>
      <button className="link" onClick={list.reload}>{tx('Refresh')}</button>
    </div>
  );
}

function BatchDetail({ id, status, can, onDone }) {
  const d = useLoad(() => api(`/business/bulk/${id}`), [id]);
  const a = useAuth();
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false); const [ask, setAsk] = useState('');
  async function act(what, body) {
    setErr(''); setBusy(true);
    try { const r = await api(`/business/bulk/${id}/${what}`, { method: 'POST', body }); if (r.needsApproval) setErr(tx('Sent to the owner for approval. No money has moved yet.')); onDone(); }
    catch (er) { if (er.code === 'OTP_REQUIRED') a.setOtpNeeded(true); setErr(er.message); } finally { setBusy(false); }
  }
  return (
    <div className="stack" style={{ flexBasis: '100%' }}>
      <Err>{err || d.error}</Err>
      <ul className="ledger">{d.data?.items.map((i) => (
        <li key={i.line}><span>{i.name}<small>{i.to} · {cap(i.status)}{i.error ? ` · ${i.error}` : ''}</small></span><b>{formatNaira(i.amountMinor)}</b></li>
      ))}</ul>
      {(status === 'draft' || (status === 'pending_approval' && can('payouts.approve'))) && (
        <form className="stack demo-box" onSubmit={(e) => { e.preventDefault(); act(status === 'draft' ? 'send' : 'approve', { password: a.pw, otp: a.otp }); }}>
          <p className="muted">{status === 'draft' ? tx('Check the list, then confirm with your password to send.') : tx('Check the list, then confirm with your password to approve and send.')}</p>
          <Authorise {...a} />
          <button className="primary" disabled={busy}>{busy ? tx('Working…') : status === 'draft' ? tx('Send this batch') : tx('Approve and send')}</button>
        </form>
      )}
      <div className="inline">
        {status === 'pending_approval' && can('payouts.approve') && <button className="danger" onClick={() => act('reject')}>{tx('Reject')}</button>}
        {(status === 'draft' || status === 'pending_approval') && can('payouts.create') && <button onClick={() => act('cancel')}>{tx('Cancel batch')}</button>}
      </div>
    </div>
  );
}

function FromCsv({ onDone }) {
  const [label, setLabel] = useState(''); const [csv, setCsv] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  function readFile(file) {
    if (!file) return;
    if (file.size > 40000) return setErr(tx('That file is too big. Split it into smaller files.'));
    const r = new FileReader(); r.onload = () => setCsv(String(r.result || '')); r.readAsText(file);
  }
  async function prepare(e) {
    e.preventDefault(); setErr(''); setBusy(true);
    try { await api('/business/bulk/prepare', { method: 'POST', body: { label, csv } }); onDone(); } catch (er) { setErr(er.message); } finally { setBusy(false); }
  }
  return (
    <form className="stack" onSubmit={prepare}>
      <p className="muted">{tx('One person per line. Give either an email (a G-Plan account) or a bank code with a 10-digit account number. We check every line first. If any line is wrong, nothing is saved and nothing is sent.')}</p>
      <a className="link" href={`data:text/csv;charset=utf-8,${encodeURIComponent(TEMPLATE)}`} download="payouts-template.csv">{tx('Download the template')}</a>
      <label>{tx('Name this batch')}<input value={label} onChange={(e) => setLabel(e.target.value)} maxLength={60} required placeholder={tx('October suppliers')} /></label>
      <label>{tx('Choose a CSV file')}<input type="file" accept=".csv,text/csv" onChange={(e) => readFile(e.target.files[0])} /></label>
      <label>{tx('Or paste it here')}<textarea rows={8} value={csv} onChange={(e) => setCsv(e.target.value)} spellCheck={false} required /></label>
      <Err>{err}</Err>
      <button className="primary" disabled={busy}>{busy ? tx('Checking…') : tx('Check the file')}</button>
    </form>
  );
}

function Payroll({ onDone }) {
  const emps = useLoad(() => api('/business/payroll/employees'), []);
  const banks = useLoad(() => api('/banks'), []);
  const [f, setF] = useState({ name: '', kind: 'bank', bankCode: '', accountNumber: '', email: '', salary: '' });
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7));
  const [err, setErr] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const total = (emps.data?.employees || []).reduce((s, e) => s + e.salaryMinor, 0);

  async function add(e) {
    e.preventDefault(); setErr('');
    const salaryMinor = toMinor(f.salary); if (!salaryMinor) return setErr(tx('Enter a salary like 150000.'));
    try { await api('/business/payroll/employees', { method: 'POST', body: { name: f.name, kind: f.kind, bankCode: f.bankCode, accountNumber: f.accountNumber, email: f.email, salaryMinor } }); setF({ ...f, name: '', accountNumber: '', email: '', salary: '' }); emps.reload(); }
    catch (er) { setErr(er.message); }
  }
  async function run() { setErr(''); try { await api('/business/payroll/run', { method: 'POST', body: { month } }); onDone(); } catch (er) { setErr(er.message); } }

  return (
    <div className="stack">
      <Err>{err || emps.error}</Err>
      {emps.data?.employees.length === 0 && <p className="empty">{tx('No one on your payroll list yet.')}</p>}
      <ul className="ledger">{emps.data?.employees.map((e) => (
        <li key={e.id} className="sched"><span>{e.name}<small>{e.to}</small></span>
          <span className="inline"><b>{formatNaira(e.salaryMinor)}</b><button className="link" onClick={async () => { await api(`/business/payroll/employees/${e.id}`, { method: 'DELETE' }); emps.reload(); }}>{tx('Remove')}</button></span></li>
      ))}</ul>
      {total > 0 && (
        <div className="inline"><input type="month" value={month} onChange={(e) => setMonth(e.target.value)} aria-label={tx('Payroll month')} /><button className="primary" onClick={run}>{tx('Prepare payroll · {v1}', { v1: formatNaira(total) })}</button></div>
      )}
      <form className="stack" onSubmit={add}>
        <h3>{tx('Add someone')}</h3>
        <label>{tx('Name')}<input value={f.name} onChange={set('name')} required maxLength={80} /></label>
        <Tabs value={f.kind} onChange={(kind) => setF({ ...f, kind })} items={[['bank', tx('Bank account')], ['internal', tx('G-Plan account')]]} />
        {f.kind === 'bank' ? (<>
          <label>{tx('Bank')}<select value={f.bankCode} onChange={set('bankCode')} required><option value="">{tx('Choose a bank')}</option>{banks.data?.banks.map((b) => <option key={b.code} value={b.code}>{b.name}</option>)}</select></label>
          <label>{tx('Account number')}<input inputMode="numeric" maxLength={10} value={f.accountNumber} onChange={set('accountNumber')} required /></label>
        </>) : <label>{tx('G-Plan email')}<input type="email" value={f.email} onChange={set('email')} required /></label>}
        <label>{tx('Monthly salary ₦')}<input inputMode="decimal" value={f.salary} onChange={set('salary')} required /></label>
        <button>{tx('Add to payroll')}</button>
      </form>
    </div>
  );
}
