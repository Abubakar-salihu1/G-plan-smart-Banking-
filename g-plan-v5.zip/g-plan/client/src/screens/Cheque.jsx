import { tx } from '../i18n.jsx';
import React, { useState } from 'react';
import { api, formatNaira, toMinor, cap } from '../api.js';
import { Err, useLoad, Page } from '../ui.jsx';

export default function Cheque({ go }) {
  const list = useLoad(() => api('/cheques'), []);
  const [f, setF] = useState({ amount: '', payer: '', last4: '' });
  const [preview, setPreview] = useState(null);
  const [error, setError] = useState(''); const [msg, setMsg] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  function pick(e) {
    const file = e.target.files?.[0];
    if (preview) URL.revokeObjectURL(preview);
    setPreview(file ? URL.createObjectURL(file) : null);
  }
  async function submit(e) {
    e.preventDefault(); setError(''); setMsg('');
    const amountMinor = toMinor(f.amount);
    if (!amountMinor) return setError(tx('Enter the amount written on the cheque.'));
    try {
      await api('/cheques', { method: 'POST', body: { amountMinor, payerName: f.payer, chequeLast4: f.last4 || undefined } });
      setMsg(tx('Cheque sent for review.')); setF({ amount: '', payer: '', last4: '' }); setPreview(null); list.reload();
    } catch (er) { setError(er.message); }
  }
  return (
    <Page title={tx('Deposit a cheque')} go={go} sub={tx('Demo feature. Your photo stays on your phone: it is not uploaded or stored. A reviewer approves the deposit, then your wallet is credited.')}>
      <form className="stack" onSubmit={submit}>
        <label>{tx('Photo of the cheque (front)')}
          <input type="file" accept="image/*" capture="environment" onChange={pick} />
        </label>
        {preview && <img className="cheque-preview" src={preview} alt={tx('Your cheque, shown only on this device')} />}
        <label>{tx('Amount (₦)')}<input inputMode="decimal" value={f.amount} onChange={set('amount')} required /></label>
        <label>{tx('Name on the cheque')}<input value={f.payer} onChange={set('payer')} required /></label>
        <label>{tx('Last 4 digits of the cheque number (optional)')}<input inputMode="numeric" maxLength={4} value={f.last4} onChange={set('last4')} /></label>
        <Err>{error}</Err>
        {msg && <p className="ok">{msg}</p>}
        <button className="primary">{tx('Submit cheque')}</button>
      </form>
      <h3>{tx('Your deposits')}</h3>
      {list.data?.cheques.length === 0 && <p className="empty">{tx('No cheque deposits yet.')}</p>}
      <ul className="ledger">{list.data?.cheques.map((c) => <li key={c.id}><span>{c.payer_name}<small>{new Date(c.created_at).toLocaleString()}</small></span><b>{formatNaira(c.amount_minor)} · {cap(c.status)}</b></li>)}</ul>
    </Page>
  );
}
