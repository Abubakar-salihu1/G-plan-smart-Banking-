import { tx } from '../i18n.jsx';
import React, { useState, useEffect } from 'react';
import { api, formatNaira, toMinor, cap } from '../api.js';
import { Err, Authorise, Receipt, Tabs, useLoad, Page } from '../ui.jsx';
import { QrImage, QrScan, scanSupported, payCodeFrom } from '../Qr.jsx';

export default function Requests({ refresh, go }) {
  const [tab, setTab] = useState(sessionStorage.getItem('gp_paytoken') ? 'code' : 'inbox');
  const box = useLoad(() => api('/requests'), []);
  const [f, setF] = useState({ amount: '', note: '', email: '', splitEmails: '', splitTotal: '', mode: 'one' });
  const [made, setMade] = useState(null); const [error, setError] = useState(''); const [busy, setBusy] = useState(false);
  const [code, setCode] = useState(sessionStorage.getItem('gp_paytoken') || ''); const [link, setLink] = useState(null);
  const [pw, setPw] = useState(''); const [otp, setOtp] = useState(''); const [otpNeeded, setOtpNeeded] = useState(false);
  const [receipt, setReceipt] = useState(null); const [idem, setIdem] = useState(() => crypto.randomUUID());
  const [scan, setScan] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function create(e) {
    e.preventDefault(); setError(''); setMade(null); setBusy(true);
    try {
      const body = f.mode === 'split'
        ? { splitEmails: f.splitEmails.split(/[\s,;]+/).filter(Boolean), splitTotalMinor: toMinor(f.splitTotal), note: f.note }
        : { amountMinor: toMinor(f.amount), note: f.note, payerEmail: f.mode === 'one' ? f.email : undefined };
      const d = await api('/requests', { method: 'POST', body });
      setMade(d); box.reload();
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  }

  async function lookup(tk) {
    setError(''); setLink(null);
    try { setLink({ ...(await api(`/requests/link/${tk}`)), token: tk }); } catch (err) { setError(err.message); }
  }

  async function pay(tk) {
    setError(''); setBusy(true);
    try {
      const d = await api('/requests/pay', { method: 'POST', idemKey: idem, body: { token: tk, password: pw, otp } });
      setReceipt(d.receipt); sessionStorage.removeItem('gp_paytoken'); await refresh(); box.reload();
    } catch (err) { if (err.code === 'OTP_REQUIRED') setOtpNeeded(true); setError(err.message); } finally { setBusy(false); }
  }
  useEffect(() => { if (code && tab === 'code') lookup(code); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  async function act(id, what) { await api(`/requests/${id}/${what}`, { method: 'POST' }); box.reload(); }

  if (receipt) return <Receipt receipt={receipt} title={tx('Paid')} onDone={() => { setReceipt(null); setLink(null); setCode(''); setPw(''); setOtp(''); setIdem(crypto.randomUUID()); }} />;

  const url = (tk) => `${window.location.origin}/?pay=${tk}`;

  return (
    <Page title={tx('Receive money')} go={go}>
      <Tabs value={tab} onChange={setTab} items={[['inbox', tx('Requests')], ['new', tx('Ask for money')], ['code', tx('Pay a link')]]} />

      {tab === 'inbox' && (
        <>
          <h3>{tx('Asking you to pay')}</h3>
          {box.data?.incoming.length === 0 && <p className="empty">{tx('Nobody is asking you for money.')}</p>}
          <ul className="ledger">
            {box.data?.incoming.map((r) => (
              <li key={r.id} className="sched">
                <div><span>{r.requester} · {formatNaira(r.amount_minor)}</span><small>{r.note || tx('No note')}</small></div>
                <div className="inline"><button className="primary" onClick={() => { setTab('code'); setCode(r.token); lookup(r.token); }}>{tx('Pay')}</button><button onClick={() => act(r.id, 'decline')}>{tx('Decline')}</button></div>
              </li>
            ))}
          </ul>
          <h3>{tx('You asked')}</h3>
          {box.data?.outgoing.length === 0 && <p className="empty">{tx('You have not asked anyone yet.')}</p>}
          <ul className="ledger">
            {box.data?.outgoing.map((r) => (
              <li key={r.id} className="sched">
                <div><span>{formatNaira(r.amount_minor)} {r.payer_email ? `from ${r.payer_email}` : '(link)'}</span><small>{tx('{v1} · code {token}', { v1: cap(r.status), token: r.token })}</small></div>
                {r.status === 'pending' && <button onClick={() => act(r.id, 'cancel')}>{tx('Cancel')}</button>}
              </li>
            ))}
          </ul>
        </>
      )}

      {tab === 'new' && (
        <form className="stack" onSubmit={create}>
          <Tabs value={f.mode} onChange={(m) => setF({ ...f, mode: m })} items={[['one', tx('One person')], ['link', tx('Payment link')], ['split', tx('Split a bill')]]} />
          {f.mode !== 'split' && <label>{tx('Amount (₦)')}<input inputMode="decimal" value={f.amount} onChange={set('amount')} required /></label>}
          {f.mode === 'one' && <label>{tx('Their email')}<input type="email" value={f.email} onChange={set('email')} required /></label>}
          {f.mode === 'split' && (
            <>
              <label>{tx('Total bill (₦)')}<input inputMode="decimal" value={f.splitTotal} onChange={set('splitTotal')} required /></label>
              <label>{tx('Friends\' emails (separate with commas)')}<textarea rows={3} value={f.splitEmails} onChange={set('splitEmails')} required /></label>
              <p className="muted">{tx('Everyone pays an equal share, including you.')}</p>
            </>
          )}
          <label>{tx('Note (optional)')}<input value={f.note} onChange={set('note')} maxLength={140} /></label>
          <Err>{error}</Err>
          <button className="primary" disabled={busy}>{busy ? tx('Creating…') : tx('Create request')}</button>
          {made && (
            <div className="demo-box">
              <p className="ok">{tx('Request created.{v1}', { v1: made.shareMinor ? ` Each share: ${formatNaira(made.shareMinor)}.` : '' })}</p>
              {made.requests.map((r) => (
                <div key={r.id} className="stack">
                  <p className="muted">{tx('Link to share:')} <b>{url(r.token)}</b></p>
                  <QrImage text={url(r.token)} label={tx('Scan to pay')} />
                </div>
              ))}
            </div>
          )}
        </form>
      )}

      {tab === 'code' && (
        <div className="stack">
          {scanSupported() && !scan && <button onClick={() => setScan(true)}>{tx('Scan a QR code to pay')}</button>}
          {scan && <QrScan onCode={(v) => { setScan(false); const c = payCodeFrom(v); setCode(c); lookup(c); }} onClose={() => setScan(false)} />}
          <label>{tx('Payment link code')}
            <input value={code} onChange={(e) => setCode(e.target.value.trim().replace(/^.*pay=/, ''))} placeholder={tx('Paste the code or link')} />
          </label>
          <button onClick={() => lookup(code)} disabled={!code}>{tx('Look up')}</button>
          {link && (
            <div className="stack">
              <dl>
                <dt>{tx('From')}</dt><dd>{link.request.requester}</dd>
                <dt>{tx('Amount')}</dt><dd>{formatNaira(link.request.amountMinor)}</dd>
                <dt>{tx('Note')}</dt><dd>{link.request.note || '—'}</dd>
                <dt>{tx('Status')}</dt><dd>{link.request.expired ? tx('Expired') : cap(link.request.status)}</dd>
              </dl>
              {link.request.status === 'pending' && !link.request.expired && (
                <>
                  <Authorise pw={pw} setPw={setPw} otp={otp} setOtp={setOtp} verification={link.verification} otpNeeded={otpNeeded} />
                  <button className="primary" disabled={busy || link.verification?.blocked} onClick={() => pay(link.token)}>{busy ? tx('Paying…') : `Pay ${formatNaira(link.request.amountMinor)}`}</button>
                </>
              )}
            </div>
          )}
          <Err>{error}</Err>
        </div>
      )}
    </Page>
  );
}
