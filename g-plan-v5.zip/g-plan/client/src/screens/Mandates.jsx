import { tx } from '../i18n.jsx';
import React, { useState } from 'react';
import { api, formatNaira, cap } from '../api.js';
import { Err, Authorise, useLoad, Page } from '../ui.jsx';

const FREQ = { weekly: 'every week', monthly: 'every month', quarterly: 'every 3 months' };
const STATUS = { pending: 'Waiting for you', active: 'Active', paused: 'Paused' };

function useAuth() {
  const [pw, setPw] = useState(''); const [otp, setOtp] = useState(''); const [otpNeeded, setOtpNeeded] = useState(false);
  return { pw, setPw, otp, setOtp, otpNeeded, setOtpNeeded };
}

// Direct debits from the customer's side. You stay in control: you approve each one, you can pause or cancel any time
// (cancelling needs no password), and nothing is ever collected above the limit you agreed to.
export default function Mandates({ go }) {
  const list = useLoad(() => api('/mandates'), []);
  return (
    <Page title={tx('Direct debits')} go={go} sub={tx('Businesses can collect from your wallet only after you approve, never more than the limit you agree, and with notice first. Demo only.')}>
      <Err>{list.error}</Err>
      {list.data?.mandates.length === 0 && <p className="empty">{tx('No direct debits. If a business asks to collect from you, the request appears here.')}</p>}
      <ul className="ledger">{list.data?.mandates.map((m) => <Row key={m.id} m={m} onDone={list.reload} />)}</ul>
    </Page>
  );
}

function Row({ m, onDone }) {
  const a = useAuth(); const [open, setOpen] = useState(m.status === 'pending'); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const post = async (what, body) => { setErr(''); setBusy(true); try { await api(`/mandates/${m.id}/${what}`, { method: 'POST', body }); onDone(); } catch (e) { if (e.code === 'OTP_REQUIRED') a.setOtpNeeded(true); setErr(e.message); } finally { setBusy(false); } };
  return (
    <li className="stack" style={{ display: 'block' }}>
      <button className="link" style={{ textAlign: 'left' }} onClick={() => setOpen(!open)} aria-expanded={open}>
        <b>{m.business}</b> · {m.label}<small>{tx('{status} · up to {v2} {freq}{v4}', { status: tx(STATUS[m.status]), v2: formatNaira(m.maxAmountMinor), freq: tx(FREQ[m.frequency]), v4: m.fixedAmountMinor ? ` · fixed ${formatNaira(m.fixedAmountMinor)}` : '' })}</small>
      </button>
      {open && (
        <div className="stack">
          <p className="muted">{tx('Starts {startOn}{v2}. You get at least {noticeDays} days notice before each collection. Money is taken only if your wallet has enough, never more than {v4} each time.', { startOn: m.startOn, v2: m.endOn ? `, ends ${m.endOn}` : '', noticeDays: m.noticeDays, v4: formatNaira(m.maxAmountMinor) })}</p>
          {m.collections.length > 0 && (<ul className="ledger">{m.collections.map((c) => (
            <li key={c.dueOn}><span>{c.dueOn}<small>{cap(c.status)}{c.error ? ` · ${c.error}` : ''}</small></span><b>{formatNaira(c.amountMinor)}</b></li>
          ))}</ul>)}
          <Err>{err}</Err>
          {(m.status === 'pending' || m.status === 'paused') && (
            <form className="stack demo-box" onSubmit={(e) => { e.preventDefault(); post(m.status === 'pending' ? 'approve' : 'resume', { password: a.pw, otp: a.otp }); }}>
              <p>{tx('{v1} This needs your password.', { v1: m.status === 'pending' ? tx('Allow {business} to collect from your wallet?', { business: m.business }) : tx('Start collections again?') })}</p>
              <Authorise {...a} />
              <button className="primary" disabled={busy}>{m.status === 'pending' ? tx('Approve') : tx('Resume')}</button>
            </form>
          )}
          <div className="inline">
            {m.status === 'pending' && <button onClick={() => post('decline')} disabled={busy}>{tx('Decline')}</button>}
            {m.status === 'active' && <button onClick={() => post('pause')} disabled={busy}>{tx('Pause')}</button>}
            <button className="danger" onClick={() => { if (window.confirm(tx('Cancel this direct debit? Nothing more will be collected.'))) post('cancel'); }} disabled={busy}>{tx('Cancel direct debit')}</button>
          </div>
        </div>
      )}
    </li>
  );
}
