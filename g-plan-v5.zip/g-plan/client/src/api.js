import { tError, tx } from './i18n.jsx';
// The short-lived access token is kept in memory only (never in storage), so a script injected into the
// page cannot copy a long-lived login. A long-lived refresh token sits in an httpOnly cookie that
// JavaScript cannot read, and is used to get a new access token after a reload or when it expires.
let token = null;
sessionStorage.removeItem('gp_token');   // clean up the old storage location

const deviceId = (() => {
  let d = localStorage.getItem('gp_device');
  if (!d) { d = crypto.randomUUID(); localStorage.setItem('gp_device', d); }
  return d;
})();

export const setToken = (t) => { token = t; };
export const hasToken = () => !!token;

let refreshing = null;
// Asks the server for a fresh access token using the httpOnly cookie. Resolves to { token, user } or null.
export function refreshSession() {
  if (!refreshing) {
    refreshing = (async () => {
      try {
        const res = await fetch('/api/auth/refresh', { method: 'POST', headers: { 'X-GPlan-Client': 'web', 'X-Device-Id': deviceId } });
        if (!res.ok) return null;
        const d = await res.json();
        token = d.token;
        return d;
      } catch { return null; } finally { refreshing = null; }
    })();
  }
  return refreshing;
}

const headers = (idemKey) => ({
  'Content-Type': 'application/json',
  'X-Device-Id': deviceId,
  ...(token ? { Authorization: `Bearer ${token}` } : {}),
  ...(idemKey ? { 'Idempotency-Key': idemKey } : {}),
});

export async function api(path, { method = 'GET', body, idemKey, _retried = false } = {}) {
  let res;
  try {
    res = await fetch('/api' + path, { method, headers: headers(idemKey), body: body ? JSON.stringify(body) : undefined });
  } catch {
    const err = new Error(tError('NETWORK', 'No connection. Check your internet and try again.'));
    err.code = 'NETWORK';
    throw err;
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(tError(data?.error?.code, data?.error?.message || 'Request failed. Please try again.'));
    err.code = data?.error?.code;
    err.status = res.status;
    // The access token expired: quietly get a new one and repeat the request once (same idempotency key).
    if (!_retried && token && err.code === 'SESSION_EXPIRED' && !path.startsWith('/auth/')) {
      if (await refreshSession()) return api(path, { method, body, idemKey, _retried: true });
    }
    if (token && ['SESSION_EXPIRED', 'SESSION_ENDED', 'UNAUTHENTICATED'].includes(err.code)) {
      setToken(null);
      window.dispatchEvent(new Event('gp:signedout'));
    }
    throw err;
  }
  return data;
}

export async function download(path, filename) {
  let res = await fetch('/api' + path, { headers: headers() });
  if (res.status === 401 && (await refreshSession())) res = await fetch('/api' + path, { headers: headers() });
  if (!res.ok) {
    const d = await res.json().catch(() => ({}));
    throw new Error(d?.error?.message || 'Download failed.');
  }
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

// Upload one photo as raw bytes (not JSON). The server never sends ID photos back to this page.
export async function uploadPhoto(path, file, extraHeaders = {}) {
  const send = () => fetch('/api' + path, { method: 'POST', body: file,
    headers: { ...extraHeaders, 'Content-Type': file.type, 'X-Device-Id': deviceId, ...(token ? { Authorization: `Bearer ${token}` } : {}) } });
  let res;
  try { res = await send(); } catch { throw new Error('No connection. Check your internet and try again.'); }
  if (res.status === 401 && (await refreshSession())) res = await send();
  const data = await res.json().catch(() => ({}));
  if (!res.ok) { const e = new Error(data?.error?.message || 'Upload failed. Please try again.'); e.code = data?.error?.code; throw e; }
  return data;
}

// Fetches a protected image (reviewers only) and returns a temporary blob URL. Call URL.revokeObjectURL when done.
export async function fetchBlobUrl(path) {
  let res = await fetch('/api' + path, { headers: headers() });
  if (res.status === 401 && (await refreshSession())) res = await fetch('/api' + path, { headers: headers() });
  if (!res.ok) { const d = await res.json().catch(() => ({})); throw new Error(d?.error?.message || 'Could not open the photo.'); }
  return URL.createObjectURL(await res.blob());
}

// Money helpers: amounts are integers in minor units (kobo). Never use floats for math.
export function toMinor(input) {
  const s = String(input ?? '').replace(/,/g, '').trim();
  if (!/^\d+(\.\d{1,2})?$/.test(s)) return null;
  const [whole, frac = ''] = s.split('.');
  const v = Number(whole) * 100 + Number((frac + '00').slice(0, 2));
  return v > 0 ? v : null;
}
export const formatMoney = (minor, ccy = 'NGN') =>
  new Intl.NumberFormat('en-NG', { style: 'currency', currency: ccy }).format((minor || 0) / 100);
export const formatNaira = (minor) => formatMoney(minor, 'NGN');
// Capitalises a status word such as "under_review" and translates it (statuses come from the server in English).
export const cap = (s) => (s ? tx(s.charAt(0).toUpperCase() + s.slice(1).replace(/_/g, ' ')) : '');
