// Push alerts on this device. Alerts always appear in the app too (refreshed every 20 seconds); push is an extra.
// The subscription is tied to the signed-in session on the server, so signing out stops it. The "on" choice is
// remembered per person on this device, so someone else signing in on a shared phone is not switched on.
import { api } from './api.js';

const flag = (userId) => `gp_push_${userId}`;
export const pushSupported = () => 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;

const toBytes = (b64url) => {
  const pad = '='.repeat((4 - (b64url.length % 4)) % 4);
  const raw = atob((b64url + pad).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from([...raw].map((c) => c.charCodeAt(0)));
};

async function currentSub() {
  const reg = await navigator.serviceWorker.getRegistration('/');
  return reg ? reg.pushManager.getSubscription() : null;
}

export async function pushState(userId) {
  if (!pushSupported()) return { supported: false };
  const cfg = await api('/push/config').catch(() => ({ enabled: false }));
  const sub = await currentSub().catch(() => null);
  return { supported: true, serverEnabled: !!cfg.enabled, permission: Notification.permission, on: !!sub && localStorage.getItem(flag(userId)) === '1' };
}

export async function enablePush(userId) {
  if (!pushSupported()) throw new Error('This browser cannot show push alerts.');
  const cfg = await api('/push/config');
  if (!cfg.enabled) throw new Error('Push alerts are not switched on for this server.');
  const perm = await Notification.requestPermission();
  if (perm !== 'granted') throw new Error('Notifications are blocked. Allow them in your browser settings to turn this on.');
  const reg = await navigator.serviceWorker.register('/sw.js');
  await navigator.serviceWorker.ready;
  const sub = (await reg.pushManager.getSubscription()) || await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: toBytes(cfg.publicKey) });
  const j = sub.toJSON();
  await api('/push/subscribe', { method: 'POST', body: { endpoint: j.endpoint, keys: j.keys } });
  localStorage.setItem(flag(userId), '1');
}

// Turn off: stop on the server and in the browser, and forget the choice.
export async function disablePush(userId) {
  localStorage.removeItem(flag(userId));
  const sub = await currentSub().catch(() => null);
  if (sub) {
    await api('/push/unsubscribe', { method: 'POST', body: { endpoint: sub.endpoint } }).catch(() => {});
    await sub.unsubscribe().catch(() => {});
  }
}

// Sign-out: stop this device on the server, but keep the person's choice so the next sign-in can resume quietly.
export async function pauseForSignOut() {
  const sub = await currentSub().catch(() => null);
  if (sub) {
    await api('/push/unsubscribe', { method: 'POST', body: { endpoint: sub.endpoint } }).catch(() => {});
    await sub.unsubscribe().catch(() => {});
  }
}

// After sign-in: if this person turned push on here before and permission is still granted, subscribe again silently.
export async function resumePush(userId) {
  if (!pushSupported() || Notification.permission !== 'granted' || localStorage.getItem(flag(userId)) !== '1') return;
  try { await enablePush(userId); } catch { /* not available now; the in-app alerts still work */ }
}
