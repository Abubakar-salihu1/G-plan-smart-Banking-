// Languages. English is the source; other languages fall back to English key by key, so a missing phrase
// shows English rather than a blank. The chosen language is remembered on this device.
// All non-English dictionaries are FIRST DRAFTS until a native speaker has checked them (see REVIEWED below).
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import en from './locales/en.js';
import pcm from './locales/pcm.js';
import yo from './locales/yo.js';
import ha from './locales/ha.js';
import ig from './locales/ig.js';
import pcmS from './locales/pcm.screens.js';
import yoS from './locales/yo.screens.js';
import haS from './locales/ha.screens.js';
import igS from './locales/ig.screens.js';

export const LANGS = [
  { code: 'en', name: 'English', dict: en },
  { code: 'pcm', name: 'Naijá (Pidgin)', dict: { ...pcm, ...pcmS } },
  { code: 'yo', name: 'Yorùbá', dict: { ...yo, ...yoS } },
  { code: 'ha', name: 'Hausa', dict: { ...ha, ...haS } },
  { code: 'ig', name: 'Igbo', dict: { ...ig, ...igS } },
];
// Flip a language to true ONLY after a native speaker has reviewed it. Until then the picker shows a notice.
export const REVIEWED = { en: true, pcm: false, yo: false, ha: false, ig: false };

const KEY = 'gp_lang';
const saved = () => { try { const c = localStorage.getItem(KEY); return LANGS.some((l) => l.code === c) ? c : null; } catch { return null; } };
const guess = () => {
  const prefs = (typeof navigator !== 'undefined' && navigator.languages) || [];
  for (const p of prefs) { const c = String(p).toLowerCase().slice(0, 3); const hit = LANGS.find((l) => c.startsWith(l.code)); if (hit) return hit.code; }
  return 'en';
};

// Fills {name}-style placeholders. Unknown placeholders are left visible so a mistake is easy to spot.
export const fill = (s, vars) => (vars ? s.replace(/\{(\w+)\}/g, (m, k) => (k in vars ? String(vars[k]) : m)) : s);

// Server errors arrive with a code and an English message. In another language, show the translation for that code when we
// have one, and the server's own message when we do not. Used by api.js, which is not a React component.
let activeDict = null;
export function tError(code, fallback) {
  const d = activeDict;
  return (d && code && d[`err.${code}`]) || fallback;
}

// Translate an English phrase. The English text is the key, so the code stays readable and anything without a
// translation simply shows in English. {name} placeholders are filled from vars. Works anywhere, not only in components.
export function tx(key, vars) {
  const d = activeDict;
  return fill((d && d[key]) ?? en[key] ?? key, vars);
}

const Ctx = createContext({ lang: 'en', setLang: () => {}, t: (k, v) => fill(en[k] ?? k, v) });

export function LanguageProvider({ children }) {
  const [lang, setLangState] = useState(() => saved() || guess());
  useEffect(() => { document.documentElement.lang = lang; }, [lang]);
  const value = useMemo(() => {
    const dict = LANGS.find((l) => l.code === lang)?.dict || en;
    activeDict = lang === 'en' ? null : dict;
    return {
      lang,
      setLang: (c) => { try { localStorage.setItem(KEY, c); } catch { /* private mode */ } setLangState(c); },
      t: (key, vars) => fill(dict[key] ?? en[key] ?? key, vars),
    };
  }, [lang]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useT = () => useContext(Ctx);

export function LanguagePicker() {
  const { lang, setLang, t } = useT();
  return (
    <div className="lang-picker">
      <label>{t('lang.label')}
        <select value={lang} onChange={(e) => setLang(e.target.value)}>
          {LANGS.map((l) => <option key={l.code} value={l.code} lang={l.code}>{l.name}</option>)}
        </select>
      </label>
      {!REVIEWED[lang] && <p className="muted" role="note">{t('lang.draft')}</p>}
    </div>
  );
}
