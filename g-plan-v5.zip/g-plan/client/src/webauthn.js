// Browser side of passkeys (fingerprint / face / device PIN) using the standard WebAuthn API.
const toBuf = (s) => {
  const b = s.replace(/-/g, '+').replace(/_/g, '/');
  const bin = atob(b + '='.repeat((4 - (b.length % 4)) % 4));
  return Uint8Array.from(bin, (c) => c.charCodeAt(0)).buffer;
};
const toB64u = (buf) => {
  let s = '';
  new Uint8Array(buf).forEach((x) => { s += String.fromCharCode(x); });
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
};

export const passkeysSupported = () => typeof window !== 'undefined' && !!window.PublicKeyCredential && !!navigator.credentials;

export async function createPasskey(options) {
  const cred = await navigator.credentials.create({
    publicKey: {
      ...options,
      challenge: toBuf(options.challenge),
      user: { ...options.user, id: toBuf(options.user.id) },
      excludeCredentials: (options.excludeCredentials || []).map((c) => ({ ...c, id: toBuf(c.id) })),
    },
  });
  return {
    id: cred.id, rawId: toB64u(cred.rawId), type: cred.type,
    response: {
      clientDataJSON: toB64u(cred.response.clientDataJSON),
      attestationObject: toB64u(cred.response.attestationObject),
      transports: cred.response.getTransports ? cred.response.getTransports() : [],
    },
    clientExtensionResults: cred.getClientExtensionResults ? cred.getClientExtensionResults() : {},
    authenticatorAttachment: cred.authenticatorAttachment,
  };
}

export async function getPasskey(options) {
  const a = await navigator.credentials.get({
    publicKey: {
      ...options,
      challenge: toBuf(options.challenge),
      allowCredentials: (options.allowCredentials || []).map((c) => ({ ...c, id: toBuf(c.id) })),
    },
  });
  return {
    id: a.id, rawId: toB64u(a.rawId), type: a.type,
    response: {
      clientDataJSON: toB64u(a.response.clientDataJSON),
      authenticatorData: toB64u(a.response.authenticatorData),
      signature: toB64u(a.response.signature),
      userHandle: a.response.userHandle ? toB64u(a.response.userHandle) : undefined,
    },
    clientExtensionResults: a.getClientExtensionResults ? a.getClientExtensionResults() : {},
    authenticatorAttachment: a.authenticatorAttachment,
  };
}
