// G-Plan service worker: only shows push alerts and opens the app when one is tapped. It caches nothing.
// A push carries just the alert title. Amounts and names stay in the app, because lock screens are visible to others.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));

self.addEventListener('push', (event) => {
  let d = {};
  try { d = event.data ? event.data.json() : {}; } catch { d = {}; }
  event.waitUntil(self.registration.showNotification(String(d.title || 'G-Plan'), {
    body: String(d.body || 'Open G-Plan to see the details.'), tag: d.tag || 'gp', icon: '/icon-192.png', badge: '/favicon.png', data: { url: '/' },
  }));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
    for (const c of list) if ('focus' in c) return c.focus();
    return self.clients.openWindow('/');
  }));
});
